# yach_53_im
# 英文版文案收集
1. /src/locales  各语言配置文件
2. 分别创建 XXX.json 
3. 注册到 对应的语言目录下的 index.js中
4. 各语言的 json 文件要一一对应 ex： en-US  common.json  对应 zh-CN common.json
5. json 中的 key 命名规则 大模块名_自定义名
