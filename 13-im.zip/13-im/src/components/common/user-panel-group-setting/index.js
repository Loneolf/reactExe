// react
import React from 'react';

// css
import css from './index.scss';

import { Checkbox,Row,Col,Button } from 'antd';
import * as util from '@u/util.js';

// BoxOperation
export default function  Index(props) {
    const {
        list,
        selectList,
        edit,
        handleSelectChange,
        handleSave
    } = props;
    return (
        <div className={css.box}>
            <div className={css.content}>
                    <Checkbox.Group style={{ width: '100%' }} value={selectList} onChange={handleSelectChange}>
                        {
                            list.map(item=>{
                                const {id,name,user_count}=item;
                                return (
                                    <div className={css.item} key={id}>
                                        <Checkbox
                                            value={id}
                                        >
                                            {name}<em>({user_count})</em>
                                        </Checkbox>
                                    </div>
                                )
                            })
                        }
                    </Checkbox.Group>
                </div>           

            <div className={css.bottom}>
            <Button
                type="primary"
                ghost
                className={edit?css.edit_btn:[css.edit_btn,css.disable_btn]}
                onClick={handleSave}
            >
                {util.locale('im_save')}
            </Button>
            </div>
        </div>
    );
}
