// react
import React from 'react';
import {connect} from 'react-redux';

// component
import Index from '.';
import * as util from '@/utils/util';

import { teamInfoLists,teamMemberRelate,teamMemberRest} from "@/services/team/team.js";
import { message } from 'antd';

// BoxSquadSettingContainer
class IndexContainer extends React.Component {
    state={
        list:[],
        selectListOrigin:[],
        selectList:[],
        edit:false
    }
    async componentDidMount(){
        this.getTeamMemberRelate();
        this.getTeamInfoLists();

        util.sensorsData.track('PageView_Chat', {
            pageName: '01-132',
        });
    }

    // 请求自己的
    getTeamMemberRelate=async()=>{
        const s= await teamMemberRelate({uid:this.props.id});
        const {code,msg,obj}=s;
        const arr=obj?obj:[];
        const ids=arr.map(item=>item.id);
        if(code==200){
            this.setState({
                selectListOrigin:ids,
                selectList:ids
            })
        }else{
            message.error(msg);
        }
    }

    // 请求所有分组
    getTeamInfoLists =async()=>{
        const s=await teamInfoLists({});
        const {code,msg,obj}=s;
        const arr=obj.list||[];
        
        if(code==200){
            this.setState({
                list:arr.filter(item=>item.type==1||item.type==2)
            })
        }else{
            message.error(msg);
        }
    }

    componentWillUnmount(){
        this.handleSave();
    }

    handleSelectChange=(value=[])=>{
        const {selectListOrigin}=this.state;
        const oldvalue=JSON.stringify(selectListOrigin);
        const newvalue=JSON.stringify(value);

        this.setState({
            selectList:value,
            edit:oldvalue!==newvalue
        })
    }

    handleSave= async ()=>{
        const uid=this.props.id;
        const {edit,selectList}=this.state;
        if(!edit) return;
        const s= await teamMemberRest({team_id:selectList.join('|'),uid});
        this.setState({
            edit:false
        },()=>{
            this.props.hiddenModal();
        })
        util.sensorsData.track('Click_Schedule_Element', {
            pageName: '01-132',
            $element_name: '01-211'
        });
        // if(s&&s.code==200) message.success('保存成功！')
    }


    render() {
        const {list,selectList,edit}=this.state;
        const props = {
            edit,
            list,
            selectList,
            handleSelectChange:this.handleSelectChange,
            handleSave:this.handleSave
        };
        return <Index {...props} />;
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
    };
};

export default connect(
    mapStateToProps,
    null
)(IndexContainer);
