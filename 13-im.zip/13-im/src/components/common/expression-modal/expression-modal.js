// react
import React, { Fragment } from 'react';
// css
import css from './index.scss';

import { Tooltip } from 'antd';

export default class ExpressionModal extends React.Component {
    constructor(props) {
        super(props);
    }


    getExpressionItem = (item, index) => {
        const {clickEmojiItem, imageLoadHandler, isShowDf, onMouseFn, mouseIsShow} = this.props;
        return <div key={`${item.expressionUrl}${index}`} 
                onMouseOver={()=>{onMouseFn(index)}} 
                onMouseOut={()=>{onMouseFn(-1)}}
                className={css.expressionItem} 
                onClick={()=>clickEmojiItem({...item, type:'expression'})}>
                {
                    !isShowDf && <img src={require("@a/imgs/expression_default.png")}/>
                }
                {
                    (isShowDf && mouseIsShow == index) && <img src={item.expressionUrlBase64} onError={imageLoadHandler}/>
                    
                }
                {
                    (isShowDf && mouseIsShow != index) && <img src={item.firstFrame} onError={imageLoadHandler}/>
                    
                }
            </div>
    }

    render() {
        const {expressionList} = this.props;
        return (
            <div className={css.box}>
                {expressionList.map((item, index) => 
                <Fragment key={`${item.expressionUrl}${index}`}>
                    {
                        item.isShowTip ?
                        <Tooltip
                            mouseEnterDelay={0.3}
                            align={{ offset: [0, 10]  }}
                            trigger= 'hover'
                            placement= 'top'
                            title={item.expressionName}
                            key={`${item.expressionUrl}${index}`}
                            getPopupContainer={()=> document.getElementById('expression')}
                        >
                            {this.getExpressionItem(item, index)}    
                        </Tooltip> : this.getExpressionItem(item, index)
                    }
                </Fragment>
                )}
            </div>
        )
    }
}
