// react
import React from 'react';
import ExpressionModal from './expression-modal';
import * as util from '@u/util.js';

// debounce
import debounce from 'lodash/debounce';

// emoji-modal-container
export default class ExpressionModalContainer extends React.Component {

    state = {
        newExpressionList: this.props.expressionList,
        isShowDf: false,
        mouseIsShow: -1
    }

    componentDidMount() {
        this.initData();
        this.onMouseFn = debounce(this.onMouseFn, 200);
        
    }

    initData = async() => {
        let {expressionList} = this.props;
        let newExpressionList = [];
        for(let i of expressionList){
            const expressionUrlBase64 = await util.yach.base64ImgGetTmp(i.expressionUrl);
            const firstFrame = await util.yach.base64ImgGetTmp(i.firstFrame);
            newExpressionList.push({...i, expressionUrlBase64, firstFrame});
        }
        this.setState({newExpressionList}, ()=> {
            const {newExpressionList} = this.state;
            if(newExpressionList && newExpressionList.length) this.setState({isShowDf: true});
        });
    }

    imageLoadHandler = e => {
        e.target.src = require("@a/imgs/expression_default.png");
    }

    onMouseFn = index => {
        const {mouseIsShow} = this.state;
        if(index == mouseIsShow) return;
        this.setState({mouseIsShow: index});
    }

    
    render() {
        const {isShowDf, newExpressionList, mouseIsShow} = this.state;
        const {clickEmojiItem} = this.props;
        
        return (
            <ExpressionModal
                isShowDf = {isShowDf}
                mouseIsShow = {mouseIsShow}
                expressionList = {newExpressionList}
                clickEmojiItem = {clickEmojiItem}
                onMouseFn = {this.onMouseFn}
                imageLoadHandler = {this.imageLoadHandler}
            />
        );
    }
}
