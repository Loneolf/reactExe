import React from 'react';
//util
import * as util from '@u/util.js';
//css
import css from './index.scss';

//antd 
import {Tooltip} from 'antd';
export default class AtHighlighted extends React.Component {
    constructor (props){
        super(props);
        this.noticeRef = React.createRef();
        this.state = {
            isRobot : false
        }
    }
    componentDidMount = () =>{
        const {userid, isRead} = this.props;
        !isRead && this.isRobot(userid);
    }
    isRobot = async(userid) => {
        if(userid == -1) return;
        const user = await util.nimUtil.getUser(userid);
        if(!user.custom) return;
        
        const custom = util.nimUtil.getJson(user.custom);
        if(custom['identification'] && custom['identification']== 'robot_user') {
            this.setState({isRobot: true});
        }

       // window.store.getState().getRobotList.includes(String(userid)) && this.setState({isRobot: true});
    }
    render = () => {
        let {showUserInfo, userid, showFlag, isRead, atName} = this.props; 
        showFlag = showFlag && !!userid && (userid!=-1);
        isRead = isRead || this.state.isRobot;
        return (
            <div className = {css.modAtHighlighted} ref= {this.noticeRef}>
                <div className = {(userid && (userid!= -1))? css.user: css.all} 
                    onClick = {() => {userid!= -1 && showUserInfo(userid)}}
                >
                    <span dangerouslySetInnerHTML = {{__html: atName}}></span>
                </div>
                <Tooltip placement="top" 
                    title={isRead ? util.locale('common_read') : util.locale('common_unread') }
                    getPopupContainer = {()=>{return this.noticeRef.current}}
                >
                    <div className = {`iconfont-yach ${isRead? `yach-goutong-yidutishi ${css.read}`: `yach-goutong-weidutishi ${css.unread}`}`} style= {{display: showFlag?'':'none'}}></div>
                </Tooltip>
            </div>
        )
    }
}