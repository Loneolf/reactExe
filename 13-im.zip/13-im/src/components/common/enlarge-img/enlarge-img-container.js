import React from 'react';
import {connect} from 'react-redux';
import styles from './index.scss';
import {hideEnlargeModal} from '@r/actions/commonModal'

class ElargeImg extends React.Component {
    toggleImgVisible=(e)=>{
        e.stopPropagation();
        this.props.dispatch(hideEnlargeModal());
    }
    render() {
        return this.props.enlargeModal.isshow ? <div
                className={styles.maskImg}
                onClick={this.toggleImgVisible}
                onMouseDown={e => {
                    e.nativeEvent.stopImmediatePropagation();
                }}
            >
                <div className={styles.bigimg} onClick={e => {
                    e.stopPropagation()
                }}>
                    <span className="iconfont iconguanbi" onClick={this.toggleImgVisible} />
                    <img src={this.props.enlargeModal.pic} alt=""/>
                </div>
            </div> : null
    }
}

const mapStateToProps = state => {
    return {
        enlargeModal: state.enlargeModal
    };
};

export default connect(
    mapStateToProps,
    null
)(ElargeImg);
