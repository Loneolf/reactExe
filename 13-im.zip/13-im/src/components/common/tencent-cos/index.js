import * as util from '@/utils/util';
// import md5 from 'md5';
/**  专为日程设计，不通用 */
/*
const fileTypeConfig =[
    //rep 正则，type 类型，noPreview 不可预览（默认false）
    { rep:/gif|jpg|jpeg|png|bmp$/i, type:'image'},
    { rep:/doc|docx$/i, type:'word'},
    { rep:/xls|xlsx$/i, type:'excel'},
    { rep:/pptx|ppt$/i, type:'ppt'},
    { rep:/pdf/i, type:'pdf'},
    { rep:/AVI|MOV|QT|RM|MPEG|MP4$/i, type:'video'},
    { rep:/rar|zip/i, type:'zip', noPreview:true}

];
//type  name   size   
function getFileInfo(file){
    const mine = file.type;
    const name = file.name;   
    const index = name.lastIndexOf(".");
    const ext = name.substr(index+1);
    const size = file.size;
    //dev/schedule/2020323/undefined1584945048667/${ Date.now()}
    //Key = 'model/日期/修改时间+当前毫秒数/文件名
    const env = util.yach.getEnvironment();
    const baseKey = `${env}/schedule/${new Date().toLocaleDateString().replace(/[^0-9]/g,'')}/${file.lastModified}${new Date().getTime()}/${name}`;
    const conf = fileTypeConfig.find((item) => {
        return item.rep.test(ext)
    });
    let fileInfo = {
        mine,
        name,
        size,
        ext,
        baseKey
    }
    if(conf){
        fileInfo.type = conf.type;
        fileInfo.noPreview = conf.noPreview;
        if(conf.type === 'image'){
           fileInfo.thumberName = `${name.substring(0, index-1)}_thumb.${ext}`;
        }
    }else {
        fileInfo.type = 'other';
        fileInfo.noPreview = true;
    }
    return fileInfo;
}
export async function uploadImg(file){
    console.log("getFileInfof",file)
    const {mine, name, size, type, thumberName, baseKey} = getFileInfo(file);
    console.log('--*****uploadImg-->>>', name, thumberName, size, type, baseKey);
    let thumber = await util.imageDealer.blobFileToBase64(file);
    thumber = await util.imageDealer.compressImg(thumber);
    const data = await util.cosFiles.uploadFiles({
        files:[{
            Body: file,
            Key: `${baseKey}${name}`                
        },{
            Body: thumber,
            Key: `${baseKey}${thumberName}`
        }]

    }); 
    console.log('--*****uploadImg-->>>', data)
    if(data && data.files){
        let df = data.files;
        console.log('--*****uploadImg-->>>', !!df[0].data , !! df[0].err)
        if(!!df[0].data && !!df[1].data){
            console.log('--*****uploadImg-df->>>', df)
            return {
                name,
                type,
                file :`https:\/\/${df[0].data.Location}`,
                thumb:`https:\/\/${df[1].data.Location}`
            }
            //上传到服务器
        }else{
            return null
        }
    }else{
        return null
    }    
}

// export async function uploadFile(file){
//     console.log("getFileinfo",file)
//     const {name, size, type, noPreview, baseKey} = getFileInfo(file);
//     console.log('--*****uploadFile-->>>', name, size, type, baseKey, file);
//     console.log(file)
//     const data = await util.cosFiles.sliceUploadFile({
//         Body: file,
//         Key: `${baseKey}${name}`  
//     });
//     console.log("uploadFile返回数据",data);
//     if(data && data.statusCode === 200){
//         return {
//             name,
//             type,
//             noPreview,
//             file :`https:\/\/${data.Location}`
//         }
//     }
// }  
*/
const env = util.yach.getEnvironment();
const uid = util.yach.getAccount();
//env/项目/uid/time/namemd5+随机码/filename
const baseKey = `${env}/yach/${uid}/${new Date().getTime()}/`;
 
export async function uploadFile(fileObj){
    console.log(fileObj)
    const {name,file} = fileObj;
    const m5 = name+Math.random();
    const data= await  util.cosFiles.sliceUploadFile({
        Body: file,
        Key:`${baseKey}${m5}/${name}`
    })
    return data
}