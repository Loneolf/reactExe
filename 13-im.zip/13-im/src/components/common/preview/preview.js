// react
import React from 'react';

// css
import css from './preview.scss';

// Preview
export default class Preview extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        let ctx = null;
        if(this.props.type == 'img')    ctx = <div className={css.img}><img src={this.props.url} /></div>;
        if(this.props.type == 'pdf')    ctx = <div className={css.content}><iframe src={this.props.url} sandbox="allow-scripts allow-popups allow-forms allow-same-origin"></iframe></div>;
        if(this.props.type == 'office') ctx = <div className={css.content}><iframe src={this.props.url} sandbox="allow-scripts allow-popups allow-forms allow-same-origin"></iframe></div>;

        return (this.props.show ? 
            <div className={css.box} onMouseDown={this.props.onStopPropagation}>
                <div className={css.close} onClick={this.props.close}>
                    <span className="icon iconfont iconguanbi"/>
                </div>
                {ctx}
            </div> 
        : null);
    }
}

