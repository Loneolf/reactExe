// react
import React from 'react';
import { connect } from 'react-redux';

// util
import * as util from '@u/util.js';

// redux
import { hidePreviewModal } from '@r/actions/commonModal.js';

// Preview
import Preview from './preview.js';

// PreviewContainer
class PreviewContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    close = () => {
        this.props.dispatch(hidePreviewModal());
	}
	
	handleStopPropagation = e => {
        e.nativeEvent.stopImmediatePropagation();
    };

    render() {
        let show = this.props.show;
        let type = this.props.type;
        let url  = this.props.url;
        let pdfhost = util.config.preview.pdf
        let officehost = util.config.preview.office

        // url
        if(url) {
            url = decodeURIComponent(url)

            let urldata = new URL(url) 
            
            if (urldata.hostname == 'yach-xstatic.zhiyinlou.com')
            pdfhost = util.config.preview.pdfx

            url = encodeURIComponent(url)
        }

        // pdf
        if(type == 'pdf'){
            url = pdfhost + url;
        }

        // office
        if(type == 'office'){
            url = officehost + url; 
        }

        // img
        // if(type == 'img'){
        //     url = url;
        // }

        return (
            <Preview
                show={show}
                type={type}
                url ={url}
				close={this.close}
				onStopPropagation = {this.handleStopPropagation}
            />
        );
    }
}

const mapStateToProps = state => ({
});

export default connect(
    mapStateToProps,
    null
)(PreviewContainer);
