// react
import React from 'react';
import EmojiModal from './emoji-modal';

// util
import * as util from '@u/util.js';

// css
import css from './index.scss';

export default React.memo(({clickEmojiItem, isTab, back}) => {

    function clickEmojiItemHandle(emojiName){
        clickEmojiItem(emojiName)
        if(back){
            util.sensorsData.track('Click_Chat_Element', { pageName: '135',$element_name:'01-165', expression_type: '01-101', expression_name:emojiName});
        }
    }

    const emojiList = util.emoji('common').list;
        const emojiItem = Object.keys(emojiList.emoji).map((key, index) => {
            const item = (
                <EmojiModal
                    key={index}
                    emojiName={key}
                    file={emojiList.emoji[key].file}
                    clickEmojiItem={clickEmojiItemHandle}
                />
            );
            return item;
        });

        const emojiCommon = Object.keys(emojiList.common).map((key, index) => {
            const item = (
                <EmojiModal
                    key={index}
                    emojiName={key}
                    file={emojiList.common[key].file}
                    clickEmojiItem={emojiName =>
                        clickEmojiItem(emojiName)
                    }
                />
            );
            return item;
        });


        return (
            <div className={css.emojiContent}>
                <ul className={css.content}>
                    <div className={css.common}>{emojiCommon}</div>
                    <div className={`${css.emoji_item} ${isTab ? '' : css.isTab}`}>{emojiItem}</div>
                </ul>
            </div>
        );
})

// emoji-modal-container
// export default class EmojiModalContainer extends React.Component {
//     constructor(props) {
//         super(props);
//     }

//     clickEmojiItemHandle=(emojiName)=>{
//         this.props.clickEmojiItem(emojiName)
//         if(this.props.back){
//             util.sensorsData.track('Click_Chat_Element', { pageName: '135',$element_name:'01-165', expression_type: '01-101', expression_name:emojiName});
//         }

//     }
//     render() {
//         const emojiList = util.emoji('common').list;
//         const emojiItem = Object.keys(emojiList.emoji).map((key, index) => {
//             const item = (
//                 <EmojiModal
//                     key={index}
//                     emojiName={key}
//                     file={emojiList.emoji[key].file}
//                     clickEmojiItem={this.clickEmojiItemHandle}
//                 />
//             );
//             return item;
//         });

//         const emojiCommon = Object.keys(emojiList.common).map((key, index) => {
//             const item = (
//                 <EmojiModal
//                     key={index}
//                     emojiName={key}
//                     file={emojiList.common[key].file}
//                     clickEmojiItem={emojiName =>
//                         this.props.clickEmojiItem(emojiName)
//                     }
//                 />
//             );
//             return item;
//         });
//         const {isTab} = this.props;
//         return (
//             <div className={css.emojiContent}>
//                 <ul className={css.content}>
//                     <div className={css.common}>{emojiCommon}</div>
//                     <div className={`${css.emoji_item} ${isTab ? '' : css.isTab}`}>{emojiItem}</div>
//                 </ul>
//             </div>
//         );
//     }
// }
