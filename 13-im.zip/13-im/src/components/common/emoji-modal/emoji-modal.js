// react
import React from 'react';
import { getEmojiPath } from '@/emoji'

import { Tooltip } from 'antd';
// css
import css from './index.scss';

export default class EmojiModal extends React.PureComponent {
    render() {
        const { emojiName, file, clickEmojiItem } = this.props;
        return (
            <li className={css.box}>
                <Tooltip placement="top" title={emojiName.replace(/\s+|\[|\]/g, "")} mouseLeaveDelay={0} mouseEnterDelay={0}>
                    <img src={getEmojiPath(file)} alt="" onClick={() => clickEmojiItem(emojiName)} />
                </Tooltip>
            </li>
        );
    }
}
