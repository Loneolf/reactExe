// react
import React from 'react';

// react-redux
import { connect } from 'react-redux';

// action
import { hideGroupModal, hideSlideModal } from '@r/actions/commonModal';

// antd
import { Checkbox, Select, Spin, Row, Col, Input, message, Button } from 'antd';

//css
import css from './creat-group.scss';

// api
import { ucenterUserList } from '@s/ucenter/ucenter-user.js';
import { searchUserSearch } from '@s/search/search.js';
import {
    groupUsersAdd,
    groupInfoCreate,
    groupUsersListGet
} from '@s/group/group-info.js';

const Option = Select.Option;

// CreatGroup
export class CreatGroup extends React.Component {
    constructor(props) {
        super(props);
        this.lastFetchId = 0;
    }

    state = {
        value: [],
        fetching: false,
        selectUsers: 0,
        usersLimit: 200,
        useSearchData: [],
        userList: [],
        modalObj: this.props.groupModal,
        groupUsersIds: [],
        groupName: '',
        loading: false
    };

    componentDidMount() {
        this.getUserList();
        const { type, id } = this.state.modalObj;
        if (type === 'addNumber') {
            groupUsersListGet({ id }).then(datas => {
                const { code, obj } = datas;
                if (code === 200) {
                    const arr = obj.list || [];
                    let groupUsersList = [];
                    arr.forEach(item => {
                        groupUsersList = [...groupUsersList, ...item.value];
                    });
                    const groupUsersIds = groupUsersList.map(
                        item => item.user_id
                    );
                    this.setState({
                        groupUsersIds
                    });
                }
            });
        } else if (type === 'create') {
            this.setState({
                groupUsersIds: [this.props.userInfo.id]
            });
        }
    }

    // 下拉框选择
    handleChange = selectValue => {
        const changeValue = selectValue.slice(-1)[0] || {};
        if (!this.state.groupUsersIds.includes(Number(changeValue.key))) {
            let selectValueFilter = [];
            selectValue.forEach(element => {
                selectValueFilter.push(Number.parseInt(element.key));
            });
            this.setState({
                value: selectValue,
                selectValue: selectValueFilter,
                fetching: false,
                selectUsers: selectValue.length
            });
        } else {
            message.warning(`${changeValue.label} ${this.locale('common_warn_msg1')}`);
        }
    };

    // 联系人选择
    onChange = checkedValues => {
        let checkedValuesFilter = [];
        checkedValues.forEach(element => {
            for (let index = 0; index < this.state.userList.length; index++) {
                if (element == this.state.userList[index].user_id) {
                    checkedValuesFilter.push({
                        key: this.state.userList[index].user_id + '',
                        label: this.state.userList[index].user_name
                    });
                }
            }
        });
        this.setState({
            value: checkedValuesFilter,
            selectValue: checkedValues,
            fetching: false,
            selectUsers: checkedValues.length
        });
    };

    hindModal = () => {
        this.props.dispatch(hideGroupModal(false));
    };

    async getUserList() {
        let queryUserData = [];
        let UserData = await ucenterUserList();
        if (UserData.code == 200 && UserData.obj && UserData.obj.length > 0) {
            let userDataList = UserData.obj;
            let itemLength = userDataList.length;
            for (let x = 0; x < itemLength; x++) {
                for (let y = 0; y < userDataList[x].value.length; y++) {
                    queryUserData.push(userDataList[x].value[y]);
                }
            }
            this.setState({ userList: queryUserData });
        }
    }

    // 联系人查询
    useSearch = async searchKye => {
        if (!searchKye)
            return this.setState({ useSearchData: [], fetching: false });
        let UseSearchData = await searchUserSearch({
            querystr: searchKye,
            page: 1,
            pagesize: 200
        });
        if (
            UseSearchData.code == 200 &&
            UseSearchData.obj.list &&
            UseSearchData.obj.list.length > 0
        ) {
            let sliceList = [];
            sliceList = UseSearchData.obj.list;
            this.replaceKeyWord(sliceList, searchKye);
        } else {
            this.setState({ useSearchData: [], fetching: true });
        }
    };

    replaceKeyWord(searchData, searchKye) {
        let keyword = searchKye;
        if (keyword) {
            searchData.filter((value, index) => {
                value.selectName = value.name.replace(
                    keyword,
                    `<span style="color:#298DFF;">${keyword}</span>`
                ); //进行替换，并定义高亮的样式
            });
        }
        this.setState({ useSearchData: searchData, fetching: false });
    }

    // 组名
    inputGroupName = value => {
        this.setState({ groupName: value.target.value });
    };

    // 新建
    submit = async () => {
        this.setState({ loading: true });
        if (this.state.selectValue && this.state.selectValue.length < 2)
            return message.warning(this.locale('common_warn_msg2'));
        let defaultGroupName = '';

        if (this.state.value && this.state.value.length > 0) {
            this.state.value.forEach((item, index) => {
                if (index < 2) {
                    defaultGroupName += item.label + ',';
                }
            });
            defaultGroupName = defaultGroupName.substring(
                0,
                defaultGroupName.length - 1
            );
            if (this.state.value.length > 2) defaultGroupName += `${this.locale('common_warn_msg3')}`;
        }

        let GroupInfoCreate = await groupInfoCreate({
            name:
                this.state.groupName.trim().length > 0
                    ? this.state.groupName
                    : this.props.userInfo.name + ',' + defaultGroupName,
            users: JSON.stringify(this.state.selectValue)
        });

        if (GroupInfoCreate.code == 200) {
            message.success(this.locale('common_warn_msg4'));
            this.setState({ loading: false });
            this.hindModal(false);
            return;
        } else {
            message.error(GroupInfoCreate.msg);
            this.setState({ loading: false });
            return;
        }
    };

    // 添加
    addNum = async () => {
        // const { id } = this.props.sessionActive || {};
        const id = window.session_active.id;
        let r = await groupUsersAdd({
            id,
            users: JSON.stringify(this.state.selectValue)
        });

        if (r.code == 200) {
            this.hindModal(false);
            this.props.dispatch(hideSlideModal());
        } else {
            message.error(r.msg);
        }
    };

    render() {
        const { groupModal } = this.props;
        return (
            <div
                onMouseDown={e => {
                    e.nativeEvent.stopImmediatePropagation();
                }}
            >
                <div
                    className={css.mask}
                    onClick={e => this.hindModal(false)}
                />
                <div className={css.box}>
                    <div className={css.header}>
                        <p className={css.headerTile}>
                            {groupModal.type === 'create'
                                ? this.locale('common_warn_msg5')
                                : this.locale('common_warn_msg6')}
                        </p>
                        <div
                            className={css.close}
                            onClick={e => this.hindModal(false)}
                        >
                            <span className="iconfont iconguanbi" />
                        </div>
                    </div>
                    <div className={css.content}>
                        <div className={css.containerLeft}>
                            <p className={css.containerLeftTile}>
                                {groupModal.type === 'create'
                                    ? `${this.locale("common_warn_msg7")}：`
                                    : `${this.locale("common_warn_msg8")}：`}
                            </p>
                            <div
                                className={css.addUser}
                                style={
                                    groupModal.type === 'create'
                                        ? {}
                                        : { border: 'none', height: '340px' }
                                }
                            >
                                <Select
                                    mode="multiple"
                                    labelInValue={true}
                                    value={this.state.value}
                                    placeholder={this.locale('common_place2')}
                                    notFoundContent={
                                        this.state.fetching ? (
                                            <span> {this.locale("common_warn_msg9")} </span>
                                        ) : null
                                    }
                                    filterOption={false}
                                    onSearch={this.useSearch}
                                    onChange={this.handleChange}
                                    style={{ width: '100%' }}
                                    autoFocus={true}
                                    optionLabelProp="text"
                                    className="multipleSelect"
                                    autoClearSearchValue={true}
                                >
                                    {this.state.useSearchData.map(user => (
                                        <Option key={user.id} text={user.name}>
                                            <img
                                                style={{
                                                    display: 'inline-block',
                                                    width: '34px',
                                                    height: '34px',
                                                    borderRadius: '100%'
                                                }}
                                                src={user.pic}
                                                alt=""
                                            />
                                            <span
                                                style={{
                                                    lineHeight: '34px',
                                                    marginLeft: '7px'
                                                }}
                                                dangerouslySetInnerHTML={{
                                                    __html: user.selectName
                                                }}
                                            />
                                        </Option>
                                    ))}
                                </Select>
                            </div>
                            {groupModal.type === 'create' ? (
                                <div className={css.groupName}>
                                    <p>{this.locale('common_team_name')}</p>
                                    <Input
                                        maxLength={20}
                                        placeholder={`${this.locale('common_place1')} (${this.locale('common_optional')})`}
                                        onChange={this.inputGroupName}
                                    />
                                </div>
                            ) : null}

                            <Button
                                className={css.subButton}
                                loading={this.state.loading}
                                disabled={this.state.loading}
                            >
                                <p
                                    className={
                                        this.state.selectUsers > 0
                                            ? css.normalButton
                                            : css.disabledButton
                                    }
                                    onClick={
                                        groupModal.type === 'create'
                                            ? this.submit
                                            : this.addNum
                                    }
                                >
                                    {this.locale("common_make_sure")}({this.state.selectUsers}/
                                    {this.state.usersLimit -
                                        this.state.groupUsersIds.length}
                                    )
                                </p>
                            </Button>
                        </div>
                        <div className={css.containerRight}>
                            <p className={css.containerRightTile}>
                                {groupModal.type === 'create'
                                    ? `${this.locale('common_team_msg25')}：`
                                    : `${this.locale('common_team_msg26')}：`}
                            </p>
                            <div className={css.selectUser}>
                                <p>{this.locale('common_contact_er')}</p>
                                <Checkbox.Group
                                    style={{ width: '100%' }}
                                    onChange={this.onChange}
                                    value={this.state.selectValue}
                                >
                                    {this.state.userList.map(user => (
                                        <Row key={user.user_id}>
                                            <Col span={24}>
                                                <Checkbox
                                                    value={user.user_id}
                                                    disabled={this.state.groupUsersIds.includes(
                                                        user.user_id
                                                    )}
                                                >
                                                    <img
                                                        src={user.user_pic}
                                                        alt=""
                                                    />
                                                    <span
                                                        className={css.userName}
                                                    >
                                                        {user.user_name}
                                                    </span>
                                                </Checkbox>
                                            </Col>
                                        </Row>
                                    ))}
                                </Checkbox.Group>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

// mapStateToProps：将state映射到组件的props中
const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
        groupModal: state.groupModal,
        // sessionActive: state.sessionActive
    };
};

export default connect(mapStateToProps)(CreatGroup);
