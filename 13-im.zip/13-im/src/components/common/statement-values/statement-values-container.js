// react
import React, {Component} from 'react';
import { connect } from 'react-redux';
// statement
import StatementValues from './statement-values';

// util
import * as util from '@u/util.js';

// antd
import {message} from 'antd';

// services
import { cnfStaticsValuestag, cnfValuestagSet } from '@s/cnf/cnf.js';
import { ucenterUserInfoGet } from "@/services/ucenter/ucenter-user";

// ImContainer
class StatementValuesContainer extends Component {
    constructor(props) {
        super(props);

        this.state = {
            isSelect: 0,
            valuesList: [],
            valuesTag: {}
        }
    }

    componentDidMount() {
        this.getUserInfo();
        this.getStaticsValuestag();
    }

    getUserInfo = async() => {
        const { id } = this.props.userInfo;
        const data  = await ucenterUserInfoGet({ user_id: id });
        const {code, msg, obj} = data;
        if(code != 200 || !obj) return message.error(msg);
        this.setState({valuesTag: obj.values_tag, isSelect: obj.values_tag.values_tag_id})
    }
    
    /**
     * 获取价值观列表
     */
    getStaticsValuestag = async() => {
        const data = await cnfStaticsValuestag();
        const {code, msg, obj} = data;
        if(code != 200 || !obj) return message.error(msg);
        this.setState({valuesList: obj.values_list})
    }

    /**
     * 设置要代言的价值观
     */
    setValuestag = async(param) => {
        const data = await cnfValuestagSet(param);
        const {code, msg} = data;
        if(code != 200) return message.error(msg);
        
        message.success(util.locale('im_set_successfully'));
        this.closeWin();
    }

    /**
     * 价值观item点击
     * @param {num} value : 选择的item id
     */
    itemClick = (value) => {
        this.setState({isSelect: value});
    }

    /**
     * 关闭弹框
     */
    closeWin = () => {
        util.eventBus.emit('userpanelShowEndorsement', false);
    }

    /**
     * 数据提交
     */
    submitData = () => {
        if(!this.state.isSelect) return;

        const {values_tag_status} = this.state.valuesTag;
        const actionData = values_tag_status == 1 ? 'add' : 'modify';
        const param = {
            tag_id: this.state.isSelect || 0,
            action: actionData
        }
        
        this.setValuestag(param);
    }

    render() {
        const {itemClick, closeWin, submitData} = this;
        const {isSelect, valuesList, valuesTag} = this.state;
        return (
            <div onMouseDown={e => e.stopPropagation()}>
                <StatementValues
                    isSelect = {isSelect}
                    valuesList = {valuesList}
                    valuesTag = {valuesTag}
                    itemClick = {itemClick}
                    closeWin = {closeWin}
                    submitData = {submitData}
                />
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        // sessionActive: state.sessionActive,
        userInfo: state.userInfo,
    };
};

export default connect(mapStateToProps)(StatementValuesContainer);
