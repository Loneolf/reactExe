// react
import React from 'react';

// css
import css from './index.scss';

// util
import * as util from '@u/util.js';

// Im
export default class StatementValues extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
		const {itemClick, isSelect, closeWin, valuesList, submitData} = this.props;
        return (
			<div className = {css.boxall} onMouseDown={(e)=>e.stopPropagation()}>
				{/* mask */}
				<div className = {css.mask}></div>
				{/* box */}
				<div className = {css.box}>
					<span className={css.close+' iconfont-yach yach-guanbi'} onClick={closeWin}></span>
					<img className={css.headerImg} src={require("@a/imgs/statement/statement-header.png")} />
					<div className={css.content}>
						{valuesList.map((i) =>{
								const selected = isSelect == i.tag_id;
								return(
									<div key={i.tag_id} className={`${css.item} ${selected ? css.itemSelect : ''}`} onClick={() => itemClick(i.tag_id)}>
										<span>{i.tag_name}</span>
										{selected ? <img src={require("@a/imgs/statement/select.png")}/> : <img src={require("@a/imgs/statement/no-select.png")}/> }
									</div>
								)
							}
						)}
					</div>
					<div className={css.footer}>
						<div onClick={submitData} className={`${css.footerButton} ${!isSelect ? css.footerNoClick : ''}`}>{util.locale('common_remote_login_ok')}</div>
						<span>{util.locale('im_mmcm')}</span>
					</div>
				</div>
			</div>
        );
    }
}
