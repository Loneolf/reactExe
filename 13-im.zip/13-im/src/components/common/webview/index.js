import React, { Component, useState } from 'react';
import { Spin } from 'antd';

import css from './index.scss';
//const { remote } = require('electron')
import { jsapiMessageChannel, electronipc } from '@u/util';
const { handleReceiveMessage } = electronipc;
import * as util from '@u/util.js';

export default function({id, url, preloadPath}){
    const [isLoadingWebview, setIsLoadingWebview] = useState(true);

    const webviewId = jsapiMessageChannel.getWebviewId(id);
    React.useEffect(() => {
        const webview = document.getElementById(webviewId);
        webview.addEventListener('dom-ready', async () => {
            let APP_CLIENT_STATUS = await util.electronipc.getGlobalData('APP_CLIENT_STATUS')
            APP_CLIENT_STATUS && APP_CLIENT_STATUS.DEVTOOL && webview.openDevTools();
            //remote.getGlobal('APP_CLIENT_STATUS').DEVTOOL && webview.openDevTools();
        })
        webview.addEventListener('ipc-message', handleReceiveMessage)

        // 解决 webview 内页面跳转后输入框无法展示光标、正常输入问题
        document.getElementById('autoFocusInput').focus()

        webview.addEventListener('did-stop-loading', e => {
            setIsLoadingWebview(false);
        })
    }, [id, url, preloadPath])
    return <div className={css.webviewBox}>
                <input id="autoFocusInput" type="text" className={css.autoFocusInput}/>
                <webview id={webviewId} src={url}  preload={preloadPath} />
                {isLoadingWebview && <div className={css.webviewLoading}><Spin tip={`${util.locale("im_loading")}...`} /></div>}
           </div>
}