import React from 'react';
import css from './index.scss';
import * as util from '@u/util.js';
const isElectronAndWin = util.electron.isElectron() && util.electron.isWin();

class ResizeBox extends React.Component {
    componentDidMount() {
        this.line.addEventListener('mousedown', this.go);
    }

    componentWillUnmount() {
        this.line.removeEventListener('mousedown', this.go);
    }

    go = event => {
        const lineEl = this.line;
        const leftEl = this.left;
        const { min, max } = this.props;

        let disX = event.clientX;
        lineEl.left = lineEl.offsetLeft;

        document.onmousemove = function(e) {
            let iT = lineEl.left + (e.clientX - disX);
            iT > max && (iT = max);
            iT < min && (iT = min);
            leftEl.style.width = iT + 'px';
            return false;
        };
        document.onmouseup = function() {
            document.onmousemove = null;
            document.onmouseup = null;
        };
    };

    render() {
        const Left = this.props.children[0] || null;
        const Right = this.props.children[1] || null;

        return (
            <div className={css.out + ' ' + (isElectronAndWin ? css.isWindows : '')}>
                <div className={css.left} ref={el => (this.left = el)}>
                    {Left}
                    <div className={css.line} ref={el => (this.line = el)} />
                </div>
                <div className={css.right + util.style.getWinStyle(css, 'rightWin')}>{Right}</div>
            </div>
        );
    }
}

export default ResizeBox;
