import React from 'react';
//util
import * as util from '@u/util.js';
//css
import css from './index.scss';

//antd 
import {Tooltip} from 'antd';

export default class Progress extends React.Component {
    constructor (props){
        super(props);
        this.cancelRef = React.createRef();
    }
    render = () => {
        const {percent, speed, handleCancle, popupContainer} = this.props; 
        return (
            <div className = {css.modProgress} ref= {this.cancelRef}>
                <div className = {css.barContainer} >
                    <div className = {css.bar} style= {{width: percent || 0}}></div>
                </div>
                <div className = {css.speed} style= {{display: speed ?'':'none'}}>{speed||'0kb/s'}</div>
                <Tooltip placement="left" 
                    title={util.locale('im_file_upload_cancel')}
                    getPopupContainer = {()=>{return popupContainer ||this.cancelRef.current}}
                >
                    <div className = {`iconfont-yach yach-0428_richengxiangqing-chuangjianricheng-fujianshangchuanzhongzhi ${css.button}`} onClick = {handleCancle}></div>
                </Tooltip>
            </div>
        )
    }
}