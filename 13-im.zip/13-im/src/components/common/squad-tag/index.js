import css from './index.scss';

// react
import React from 'react';

export default class SquadTag extends React.Component {
    render() {
        
        return (
            <img src={require('@a/imgs/squad.png')} alt="" className={css.squadTag}/>                
        );
    }
}
