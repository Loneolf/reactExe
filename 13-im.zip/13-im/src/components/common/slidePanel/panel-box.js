import React from 'react';
import { connect } from 'react-redux';

import css from './index.scss';
import Webview from '../webview/index';
import { closeSlidePanel } from '@r/actions/slidePanel';
import { electronipc } from '@u/util';

const box = (props) => {
    const { slidePanels = [], preloadPath = '' } = props;
    const onLeftClick = id => {
        electronipc.handleEventPostMessage({eventName: 'leftBtnClick', containerId: id})
    }
    const onRightClick = id => {
        electronipc.handleEventPostMessage({eventName: 'rightBtnClick', containerId: id})
    }
    return (
        <div className={css.out} id="slidePanel" style={slidePanels.length > 0 ? null : { display: 'none' }}>
            {slidePanels.map((item, index) => {
                const {
                    id,
                    title = '',
                    url = '',
                    text = '',
                    left = '',
                    right = '',
                    hideTitle = 0,
                } = item || {};
                const webviewProps = { id, url, text, preloadPath };
                return (
                    <div className={css.item} key={id}>
                        {!hideTitle &&
                            <div className={css.top}>
                                <div className={css.header}>
                                    <div className={css.left} onClick={onLeftClick.bind(this, id)} dangerouslySetInnerHTML={{ __html: left }}></div>
                                    <div className={css.middle} dangerouslySetInnerHTML={{ __html: title }}></div>
                                    <div className={css.right} onClick={onRightClick.bind(this, id)} dangerouslySetInnerHTML={{ __html: right }}></div>
                                </div>

                                <span
                                    className="icon iconfont iconguanbi iconfontsize--ldKNC"
                                    onClick={() => {
                                        props.dispatch(closeSlidePanel({ id }));
                                    }}
                                />
                            </div>
                        }
                        <div className={css.connect}>
                            <Webview {...webviewProps} />
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        slidePanels: state.slidePanels,
        preloadPath: state.preloadPath,
    };
};
export default connect(mapStateToProps)(box);
