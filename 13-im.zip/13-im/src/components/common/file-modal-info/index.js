import React from 'react';


export default class FileModalInfo extends React.Component {
    render() {
        const {
            username,
            fileType,
            fileName,
            fileSize,
            iconName
        } = this.props;
        const imgAddress = require(`@a/imgs/modelFileType/${iconName}.svg`)
        return (
            <div>
            <div className={`file-title`}>{this.locale('commom_file_msg')}{username}</div>
                <div className={`file-content`}>
                    <img src={imgAddress} className={`file-svg`} />
                    <span className={`fontsize-file-name `}>
                        <span className={`text-dot`}>
                            [{fileType}]{fileName}
                        </span>
                        <br></br>
                        <span className={`file-size`}>{fileSize}</span>
                    </span>
                </div>
               
            </div>
        );
    }
}
