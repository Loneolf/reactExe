// react
import React from 'react';
import {connect} from 'react-redux';
// util
import * as util from '@u/util.js';

// actions
import { memberInSessionActive } from '@r/actions/session.js';
import {electronMainFocusChange} from '@r/actions/env.js';

import RepeatGroupModal from './repeat-group-modal'

class RepeatGroupModalContainer extends React.Component{
  constructor(props) {
    super(props)
  }

  enterGroup = (id) => {
      this.props.dispatch(electronMainFocusChange({focus:true}));
      if(id && (id+'').length>4) {
        util.nim.getTeamMemberInfos(id)
          .then((user)=>{
              // user 当前的你在该群的信息
              this.props.dispatch(memberInSessionActive(user));
          })
          .catch(err => {
              console.log("itemClick catch 解散群会被执行 " + err); 
          });
      }
      this.props.closeGroupCreate()
      this.activeRow({id});
  }

  activeRow = ({id}) => {
    util.yach.itemActiveRow(id, 'team')
    util.yachLocalStorage.ls('weekly_entrance', 101);
  }

  showInfoContent = (item) => {
    if (!item.lastMsg) return null;
    if (typeof item.showmsg == 'object') return item.lastMsg.pushContent
    if (typeof item.showmsg == 'string') return item.showmsg
  }

  render () {
    return (
      <RepeatGroupModal 
        {...this.props}
        enterGroup={this.enterGroup}
        showInfoContent={this.showInfoContent}
      />
    )
  }
}

const mapStateToProps = state => {
  return {
      electronMainFocusChange: state.electronMainFocusChange
  };
};

export default connect(mapStateToProps)(RepeatGroupModalContainer)
