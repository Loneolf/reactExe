// react
import React from 'react';

import { Button } from 'antd';

import css from './index.scss';

import * as util from '@u/util.js';

export default function RepeatGroupModal(props) {
  const {showModal, groupInfo, repeatData, repeatLoading, closeGroupCreate, enterGroup, noRepeatCreateGroup, showInfoContent} = props
  return (
    <div style = {{display: showModal ? '' : 'none'}} className={css.boxModal} onMouseDown={(e)=>e.stopPropagation()}>
      <div className = {css.mask}></div>
      <div className={css.box}>
        <div className = {css.title}>
            <span>{util.locale('common_team_msg27')}</span>
            <span className='iconfont-yach yach-quanju-xuanren-jianqunguanbi' onClick={() => closeGroupCreate()}></span>
        </div>
        <div className = {css.main}>
            <ul>
                {groupInfo && groupInfo.length > 0 && groupInfo.map(item=>(
                        <li key={item.id} onClick={()=>enterGroup(item.id)}>
                            <div className={css.item}>
                                <img src={item.showimg} />
                                <div>
                                    <div className={css.infoBox}>
                                        <span>{item.showname || ''}</span>
                                        <span>{item.showtime || ''}</span>
                                    </div>
                                    <div className={css.infoContent}>
                                        <p className={css.lastMsg}  dangerouslySetInnerHTML={{__html:showInfoContent(item) || ''}}></p>
                                        {item.disnotice ? (
                                            <div className={css.disnotice}>
                                                <em className="icon iconfont iconmiandarao" />
                                                {item.showunread ? <i /> : null}
                                            </div>
                                        ) : (
                                            <div className={css.unread}>
                                                {
                                                    !item.showunread ? null :
                                                    <div>{item.showunread > 99 ? '99+' : item.showunread}</div>
                                                }
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </li>
                    ))
                }
            </ul>
        </div>
        <div className={css.footer}>
            <Button 
                type="primary" 
                loading={repeatLoading}
                disabled={repeatLoading}
                className={repeatLoading ? css.loadingBtn : ''}
                onClick={() => noRepeatCreateGroup(repeatData, true)}>
                    {util.locale('common_team_msg28')}
            </Button>
            <Button onClick={() => closeGroupCreate()}>{util.locale('common_cancel')}</Button>
        </div>
      </div>
    </div>
  )
}