import DepartTag from '@c/common/departmentTag/index.js'
import ApproveTag from '@c/common/approveTag/index.js'
// react
import React from 'react';
import * as util from '@u/util.js';
import css from './index.scss';

export default class DepartmentTag extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            idDepart: 0
        }
    }
    componentDidMount(){
            if(this.props && this.props.id && typeof(this.props.id) == 'string' && this.props.id.indexOf('team') > -1) {
                try{
                    // console.log('use nim getuser or getteam xx000');
                    util.nimUtil.getTeam(parseInt(this.props.id)).then((res)=>{
                       const {serverCustom} = res;
                       if(!serverCustom) return;
                       const serverCustomJson = JSON.parse(serverCustom);
                       let type = serverCustomJson.type 
                       if(type == 1) {
                         this.setState({
                           idDepart: 1
                         })
                       } else if(type == 3){
                           this.setState({
                               idDepart: 3
                           })
                       }else{
                        this.setState({
                            idDepart: 0
                        })
                       }
                    });
                }
                catch(e){
                    console.error('获取群信息出',e);
                }
            }
        }
    render() {
        return (
            this.state.idDepart == 1 ? 
                <div className={css.departmentTagBox}><DepartTag/></div>
            : (this.state.idDepart == 3 ? <div className={css.departmentTagBox}><ApproveTag/></div> : null)
        );
    }
}