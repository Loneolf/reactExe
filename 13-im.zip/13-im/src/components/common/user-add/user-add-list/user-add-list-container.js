/*
 * @Descripttion:
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-02 16:41:53
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-16 14:11:14
 */
import React from 'react';

import UserAddList from './user-add-list';

class UserAddListContainer extends React.Component {
    change = e => {
        let newCurrList = [...this.props.currList];
        let ids = newCurrList.map(v => v.id);
        // let item = this.props.list.find(v => v.id == e.target.value);
        let item = this.props.list.find(v => (v.id && v.id.split('-user-')[0]) == e.target.value);
        if (ids.includes(e.target.value) && !e.target.checked) {
            newCurrList = newCurrList.filter(v => v.id != e.target.value);
        }
        if (!ids.includes(e.target.value) && e.target.checked) {
            newCurrList.push(item);
        }

        this.props.currListSet(newCurrList);
    };
    render() {
        let list = []
        if (this.props.type === 'squad' && this.props.isAdmin) {
            list = this.props.list.map(item => {
                if (this.props.disabledids.includes(item.user_id) && item.role === 2) {
                    item.role = 1
                    item.status = 'admin'
                }
                if (!this.props.disabledids.includes(item.user_id) && item.role === 1) {
                    item.role = 2
                    item.status = 'common'
                }
                return item
            }).sort((a, b) => a.role - b.role)
        } else list = this.props.list.map(item => {
            item.id = item.id && String(item.id)
            return item
        })

        const listIds = this.props.currList && this.props.currList.map(v => v.id);
        //const list = this.props.list.filter(v => v.id > 9999)
        list.forEach(item => {
            if (item.user_id) item.id = item.user_id
        })

        const props = {
            listIds: listIds,
            // list: this.props.list,
            list,
            change: this.change,
            disabledids: this.props.disabledids,
            title: this.props.title,
            listType: this.props.listType,
            type: this.props.type || '',
            groupInfo: this.props.groupInfo,
            getSquadUserList: this.props.getSquadUserList,
        };
        return <UserAddList {...props} />;
    }
}

export default UserAddListContainer;
