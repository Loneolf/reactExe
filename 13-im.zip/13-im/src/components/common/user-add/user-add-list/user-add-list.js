/*
 * @Descripttion:
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-02 16:42:32
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-16 14:10:57
 */
import React from 'react';

import css from './index.scss';

import { Checkbox, Row, Col } from 'antd';

import * as util from '@u/util.js';
import DepartmentTag from './index.js';

/**
 * 修改原有： 最近会话无法选准disabled的群，只能disabled人。添加36代码。
 */
export default props => (    
    <div className={css.box}>
        {props.title &&
            <div className={css.title}>
                <p className={css.titleItem}>{props.title}</p>
            </div>
        }
        <div className={css.commonly}>
            <Checkbox.Group style={{ width: '100%' }} value={props.listIds}>
                {props.list.map(user => (
                    <Row key={user.id}>
                        <Col span={24}>
                            <Checkbox
                                // value={user.id}
                                value={user.id && user.id.split('-user-')[0]}
                                onChange={props.change}
                                disabled={props.disabledids && (props.disabledids.includes(user.id) || props.disabledids.includes(user.id.split('-user-')[0]) || props.disabledids.includes(user.id.split('-team-')[0]) )}
                            >
                                <img className={css.pic} src={user.pic || util.config.nim.showimg} alt="" />
                                <div className={css.userNameContent}>
                                    <div className={css.userNameBox}>
                                        <span className={css.userName}>
                                            {user.name_nick || user.name}
                                        </span>
                                        {user.id.length >6 && <DepartmentTag id={user.id}/> }
                                    </div>
                                    {props.listType && props.type!=='squad' && <span className={css.userOrg}>
                                        {user.name}{user.dept_name?'('+user.dept_name+')':''}
                                    </span>}

                                </div>
                                {(user.role == 0) && <span className={css.owner}>{props.type !== 'squad' ?  util.locale('common_manager1') : util.locale('im_group_leader')}</span>}
                                {(user.role == 1) && <span className={css.owner}>{util.locale('common_manager2')}</span>}
                            </Checkbox>
                        </Col>
                    </Row>
                ))}
            </Checkbox.Group>
        </div>
        {
            props.groupInfo && props.list.length < props.groupInfo.user_total ? <div onClick={() => {props.getSquadUserList(props.groupInfo.offset_id)}} className={css.more}>{util.locale('common_msg26')}</div> : null
        }
    </div>
);
