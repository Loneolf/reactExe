import React from 'react';

// util
import * as util from '@u/util.js';

import css from './index.scss';
import { Checkbox, Row } from 'antd';
import UserAddList from '../user-add-list/user-add-list-container';
import {Spin} from 'antd';
import InfiniteScroll from 'react-infinite-scroller';
import DepartTag from '@c/common/departmentTag/index.js'
import ApproveTag from '@c/common/approveTag/index.js'

export default props => {
    const recentSession = (
        <div className={css.box}>
            <div className={css.title} onClick={props.goGroupPage}>
                <span className="iconfont iconzhankai"></span>
                <span className={css.titleName}>{props.titleName}</span>
            </div>
            {(props.showPage == 'groupList' && props.isShow()) &&
                <div className={css.group}>
                    <div className={css.content}>
                        {
                            props.groupList.length > 0 ? <InfiniteScroll
                                initialLoad={false}
                                pageStart={0}
                                loadMore={props.handleInfiniteOnLoad}
                                hasMore={!props.moreLoading && props.hasMore}
                                useWindow={false}
                            >
                                {props.groupList.map(item => {
                                    const {tid, id, name, pic, group_users_count,source} = item;
                                    return (
                                        <div
                                            onClick={() => props.handleGorupClick(tid, name)}
                                            key={id}
                                            className={css.item}
                                        >
                                            <img src={pic} className={css.showimg} alt=""/>
                                            <div className={css.itemMain}>
                                                <div className={css.nameBox}>
                                                    <div className={css.name}>
                                                        {name}
                                                    </div>
                                                    {/* 接口获取 0：普通群；1：部门群；3:审批群 */}
                                                    {source == 1 && <div className={css.depart}>
                                                        <DepartTag />
                                                    </div>}
                                                    {source == 3 && <div className={css.depart}>
                                                        <ApproveTag />
                                                    </div>}
                                                </div>
                                                <span>{group_users_count}{ util.locale('common_persion')}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                                {props.moreLoading && props.hasMore && (
                                    <div className={css.loading}>
                                        <Spin/>
                                    </div>
                                )}
                                </InfiniteScroll> : <p>{util.locale('common_team_msg36')}</p>
                        }
                    </div>
                </div>
            }
            {(props.type == 'forward' || props.type == 'recordGroup') &&
                <div className={css.group}>
                    <div className={css.content}>
                        {
                            props.groupList.length > 0 ? <InfiniteScroll
                                initialLoad={false}
                                pageStart={0}
                                loadMore={props.handleInfiniteOnLoad}
                                hasMore={!props.moreLoading && props.hasMore}
                                useWindow={false}
                            >
                                <UserAddList {...props} list={props.groupList} title=''/>
                                {props.moreLoading && props.hasMore && (
                                    <div className={css.loading}>
                                        <Spin/>
                                    </div>
                                )}
                            </InfiniteScroll> : <p>{util.locale('common_team_msg36')}</p>
                        }
                    </div>
                </div>
            }
            {(props.showPage == 'members' && props.isShow()) &&
                <div className={css.addList}>
                    <div className={css.all}>
                        {(!props.radio && props.list && props.list.length>0) &&
                            <Row>
                                <Checkbox checked={props.isCheckedAll()} onChange={props.checkAll}>
                                    <span>{util.locale('common_select_all')}</span>
                                </Checkbox>
                            </Row>
                        }
                    </div>
                    <UserAddList {...props} title=''/>
                </div>
            }
        </div>
    );
    return recentSession;
};
