import React from 'react';
import { connect } from 'react-redux';
import * as util from "@/utils/util";

import MyGroup from './my-group';

import { groupUsersEsList } from '@/services/group/group-user';
import { groupUsersEnterGet } from '@s/group/group-user';

class MyGroupContainer extends React.Component {
    constructor(props){
        super(props)
    };

    state = {
        showPage: 'groupList',
        titleName: util.locale('common_team_msg35'),
        list: [],
        groupList: [],
        moreLoading: false,
        hasMore: true,
        currentPage: 1,
        total: 0,
    }

    componentDidMount() {
       this.initData();
       if(this.props.type == 'members')util.eventBus.addListener('userMembers', obj => this.handleGorupClick(obj.id, obj.showname));
    };

    componentWillUnmount() {
        if(this.props.type == 'members') util.eventBus.removeListener('userMembers');
    }

    initData = async() => {
        const obj = await this.getData(1);
        const {groupList, total, currentPage} = obj || {};
        const arr= await util.yach.base64ImgArrGetTmp(groupList,'pic');

        this.setState({
            groupList: this.reorganizationData(arr),
            total,
            currentPage,
        });
    }

    getData = async (page) => {
        const data = await groupUsersEnterGet({page, rows: 300, top_session: 1});
        const {code, obj = {}} = data || {};
        let groupList = [],
            total = 0,
            top = [],
            currentPage = 1;
        if (code === 200) {
            const arr= await util.yach.base64ImgArrGetTmp(obj.list,'pic');
            const topArr= await util.yach.base64ImgArrGetTmp(obj.top,'pic');
            groupList = this.reorganizationData(arr || []);
            total = obj.total;
            currentPage = obj.page;
            top = this.reorganizationData(topArr || []);
        }

        top = await util.yach.getSortGroup(top, 1);
        groupList = await util.yach.getSortGroup(groupList, 2);

        groupList = top.concat(groupList);

        // 数据问题，加一层判断去重
        groupList = util.yach.handleGroupRepeat(groupList);

        return {
            groupList,
            total,
            currentPage,
        }
    };

    // 144 版本去掉加载更多
    handleInfiniteOnLoad = async () => {
        // let {groupList, total, currentPage} = this.state;
        // this.setState({
        //     moreLoading: true,
        // });
        // if (groupList.length >= total) {
        //     this.setState({
        //         hasMore: false,
        //         moreLoading: false,
        //     });
        //     return;
        // }
        // const obj = await this.getData(currentPage + 1);
        // this.setState({
        //     groupList: groupList.concat(obj.groupList),
        //     total: obj.total,
        //     currentPage: obj.currentPage,
        //     moreLoading: false,
        // });
        // if(obj.groupList.length == 0){
        //     this.setState({
        //         hasMore: false
        //     });
        // }
    };

    reorganizationData = (arr) => {
        return arr.map(i=>(Object.assign(i, {id: i.tid + "-team-"})));
    }

    handleGorupClick = (tid, name) => {
        this.getTeamMembers(tid, name);
    };

    getTeamMembers = async(tid, name) => {
        this.setState({list:[], titleName: name, showPage: 'members'});
        const datas = await groupUsersEsList({
            tid: tid, 
            page: 1,
            rows: 2000,
        });
        if (datas) {
            const {code, obj = {}} = datas || {};
            if (code === 200) {
                this.setState({list: obj.list});
            }
        }
    };

    goGroupPage = () => {
        if(this.state.showPage == 'groupList'){
            this.props.openAll('orgAll');
        } else if(this.state.showPage == 'members') {
            this.initData();
            this.setState({titleName: util.locale('common_team_msg35'), showPage: 'groupList'});
        }
    };

    isCheckedAll = () => {
        let newCurrList = [...this.props.currList];
        let allList = this.state.list;
        for (let i = 0; i < allList.length; i++) {
            const el = allList[i];
            if(el.id == util.yach.getAccount()) newCurrList.push(el);
        }
        let ids = newCurrList.map(v => v.id);
        let listAll = [];
        this.state.list.forEach(v => {
            listAll = [...listAll, v]
        })
        return listAll.every(v => ids.includes(v.id) || this.props.disabledids.includes(v.id));
    }

    checkAll = e => {
        let newCurrList = [...this.props.currList];
        let ids = newCurrList.map(v => v.id);
        let listAll = [];
        this.state.list.forEach(v => {
            listAll = [...listAll, v]
        })
        if (e.target.checked) {
            listAll.forEach(v => {
                if (!ids.includes(v.id) && !this.props.disabledids.includes(v.id))
                newCurrList.push(v)
            });
        } else {
            let groupids = listAll.map(v => v.id);
            newCurrList = newCurrList.filter(v => !groupids.includes(v.id));
        }
        if(!this.checkType()) newCurrList=newCurrList.filter(item=>item.id != util.yach.getAccount());
        this.props.currListSet(newCurrList);
    }

    checkType = () => {
        const{type} = this.props;
        const types = ['creatGroup', 'members'];
        return types.includes(type);
    }
    
    render() {
        const myGroupProps = {
            ...this.state,
            ...this.props,
            isShow: this.checkType,
            checkAll: this.checkAll,
            isCheckedAll: this.isCheckedAll,
            goGroupPage: this.goGroupPage,
            handleGorupClick: this.handleGorupClick,
            handleInfiniteOnLoad: this.handleInfiniteOnLoad
        };
        return <MyGroup {...myGroupProps} />;
    }
}

const mapStateToProps = state => {

    return {
        userInfo: state.userInfo,
        sessionList: state.sessionList
    };

};

// export default MyGroupContainer;
export default connect(mapStateToProps)(MyGroupContainer);
