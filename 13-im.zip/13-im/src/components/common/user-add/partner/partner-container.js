import React from 'react';
import {connect} from 'react-redux'

import * as util from '@u/util.js';


import Partner from './partner';
import { teamInfoLists, teamMemberLists } from '@s/team/team';
import * as useraddAction from '@/redux/actions/user'

class PartnerContainer extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            showPage: props.partnerType,
            titleName: util.locale('common_accepter12'),
            partnerLists: [],
            teamMember: [],
            chooseTeamIds: []
        }
    }

    componentDidMount() {
       this.initData();
    }

    // componentWillUnmount() {
    //     if(this.props.type == 'members') util.eventBus.removeListener('userMembers');
    // }

    initData = async() => {
        this.getData();
    }

    getData = async () => {
        // this.setState({titleName: name, showPage: 'partnerList'});
        const data = await teamInfoLists();
        if (data && data.code == 200) {
            let partnerLists = data.obj.list || [];
            partnerLists = partnerLists.filter(item => item.user_count !== 0);
            partnerLists = this.reorganizationData(partnerLists)
            this.setState({
                partnerLists: partnerLists || [],
            })
        }
    };

    //点击查看
    getTeamMember = async (team, event) => {
        event && event.stopPropagation()
        let id = team.id.split('-partner-')[0]
        if (!id) return false;

        this.setState({titleName: team.name, showPage: 'members'});
        const data = await teamMemberLists({
            team_id: id,
            all: 1 // 获取全员
        });
        if (data && data.code == 200) {
            let teamMember = data.obj.user_list || []
            // teamMember = this.reorganizationData(teamMember)

            let teamMemberList = teamMember.slice(0,20);

            this.setState({
                teamMember: teamMemberList,
            });

            setTimeout(()=>{
                this.setState({ teamMember })
            })
        }
    };

    reorganizationData = (arr) => {
        if(this.state.showPage == 'members') {
            return arr.map(i=>(Object.assign(i, {teamId: i.id, id: i.id + "-user-"})));
        } else if(this.state.showPage == 'partnerList') {
            return arr.map(i=>(Object.assign(i, {teamId: i.id, id: i.id + "-partner-" + i.user_count})));
        }
    }

    goPartnerPage = () => {
        if(this.state.showPage == 'partnerList') {
            this.props.openAll('orgAll');
        } else if(this.state.showPage == 'members') {
            this.setState({
                showPage: 'partnerList',
                titleName: util.locale('common_accepter12'),
            })
        }
    };

    //是否全选
    isCheckedAll = () => {
        let newCurrList = [...this.props.currList];
        let currids = newCurrList.map(v => (v.id && v.id.split('-')[0]));
        let all = []
        if(this.state.showPage == 'partnerList') {
            all = [...this.state.partnerLists]
        } else if(this.state.showPage == 'members') {
            all = [...this.state.teamMember]
        }

        for (let i of all) {
            if(this.state.showPage == 'partnerList') {
                if (!currids.includes(i.id.split('-')[0]) && !this.props.disabledids.includes(i.id.split('-')[0])) return false
            } else if(this.state.showPage == 'members') {
                if (!currids.includes(typeof i.id === "number" ? i.id.toString() : i.id) && !this.props.disabledids.includes(typeof i.id === "number" ? i.id.toString() : i.id)) return false
            }
        }

        if(!all.length) return false;

        return true
    };

    checkAll = e => {
        let newCurrList = [...this.props.currList];
        let ids = newCurrList.map(v => v.id);
        let listAll = []
        if(this.state.showPage == 'partnerList') {
            listAll = [...listAll, ...this.state.partnerLists]
        } else if(this.state.showPage == 'members') {
            listAll = [...listAll, ...this.state.teamMember]
        }

        if (e.target.checked) {
            listAll.forEach(v => {
                // if (!ids.includes(v.id) && !this.props.disabledids.includes(v.id))
                if (!ids.includes(v.id) && !this.props.disabledids.includes(v.id && v.id.split('-')[0]))
                    newCurrList.push(v)
            });
        } else {
            let groupids = listAll.map(v => v.id);
            newCurrList = newCurrList.filter(v => !groupids.includes(v.id) || this.props.disabledids.includes(v.id && v.id.split('-')[0]));
            // newCurrList = newCurrList.filter(v => !groupids.includes(v.id) || this.props.disabledids.includes(v.id));
        }

        this.props.currListSet(newCurrList);
        this.props.dispatch(useraddAction.useraddCurrListSet(newCurrList))
        // 选择小组无法查看下级
        this.setState({chooseTeamIds: newCurrList.map(item => item.id)})
    }

    //选择某一分组
    chooseTeam = (e) => {
        let newCurrList = [...this.props.currList];
        let ids = newCurrList.map(v => v.id);
        let item = this.state.partnerLists.find(v => v.id == e.target.value);

        if (ids.includes(e.target.value) && !e.target.checked) {
            newCurrList = newCurrList.filter(i => i.id !== item.id);
            this.props.currListSet(newCurrList);
            this.props.dispatch(useraddAction.useraddCurrListRemove(e.target.value))
        }
        if (!ids.includes(e.target.value) && e.target.checked) {
            newCurrList.push(item);
            this.props.currListSet(newCurrList);
            this.props.dispatch(useraddAction.useraddCurrListPush(item))
        }
        // 选择小组无法查看下级
        this.setState({chooseTeamIds: newCurrList.map(items => items.id)})
    };

    isCanNext = (team) => {
        if(this.props.disabledids.includes(team.id.split('-partner-')[0]))  return true;
        else if(this.state.chooseTeamIds.includes(team.id)) return true;
        else return false;
    };

    render() {
        const partnerProps = {
            ...this.state,
            ...this.props,
            checkAll: this.checkAll,
            isCheckedAll: this.isCheckedAll,
            getTeamMember: this.getTeamMember,
            goPartnerPage: this.goPartnerPage,
            chooseTeam: this.chooseTeam,
            isCanNext: this.isCanNext,
        };
        return <Partner {...partnerProps} />;
    }
}

const mapStateToProps = state => ({});

export default connect(mapStateToProps)(PartnerContainer);
