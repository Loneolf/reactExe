import React from 'react';
import { Checkbox, Row } from 'antd';

// util
import * as util from '@u/util.js';


import css from './index.scss';
import UserAddList from '../user-add-list/user-add-list-container';

export default props => {
    //我的伙伴-分组 页
    const partnerList = (
        <div className={css.partners}>
            <div className={css.paperbacks}>
                {props.showPage == 'partnerList' &&
                    <div className={css.titles}>
                        <Row className={css.item + ' ' + css.itemall}>
                            <Checkbox
                                onChange={props.checkAll}
                                checked={props.isCheckedAll()}
                                // disabled={props.partnerLists && props.partnerLists.map(item => item.id.split('-partner-')[0]).includes(props.disabledids[0])}
                            >
                                <span className={css.name}>{util.locale('common_select_all')}</span>
                            </Checkbox>
                        </Row>
                        <Checkbox.Group style={{ width: '100%', display: 'block' }} value={props.currList.map(v => v.id)}>
                            {props.partnerLists.map(team => (
                                <Row key={team.id} className={css.item}>
                                    <Checkbox
                                        value={team.id}
                                        onChange={props.chooseTeam}
                                        disabled={props.disabledids.includes(team.id.split('-partner-')[0])}
                                    >
                                        <span className={css.name}>
                                            {team.name}
                                        </span>
                                    </Checkbox>
                                    <span className={css.next + ' ' + (props.isChecked(team.id) ? css.disabled : '')}
                                        onClick={props.isChecked(team.id) ? null : props.getTeamMember.bind(null, team)}>
                                        {util.locale('common_check')}
                                    </span>
                                </Row>
                            ))}
                        </Checkbox.Group>
                    </div>
                }
                {props.showPage == "members" &&
                    <div>
                      { props.teamMember.length > 0 ?
                        <Row className={css.item + ' ' + css.iterall}>
                          <Checkbox
                              onChange={props.checkAll}
                              checked={props.isCheckedAll()}
                          >
                            <span className={css.name}>{util.locale('common_select_all')}</span>
                          </Checkbox>
                        </Row> : null
                      }
                        <div className={css.orgUser}>
                            <UserAddList
                                list={props.teamMember}
                                currList={props.currList}
                                currListSet={props.currListSet}
                                disabledids={props.disabledids}
                            />
                        </div>
                    </div>
                }
            </div>
        </div>
    )

    const myPartner = (
        <div className={css.box}>
            <div className={css.title} onClick={props.goPartnerPage}>
                <span className="iconfont iconzhankai"></span>
                <span className={css.titleName}>{props.titleName}</span>
            </div>
            {partnerList}
        </div>
    );

    return myPartner;
};
