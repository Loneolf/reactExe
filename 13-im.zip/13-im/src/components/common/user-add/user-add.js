/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-02 16:42:32
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-08-10 16:41:31
 */
import React from 'react';

import css from './index.scss';

import { Input, Button } from 'antd';
import UserAddAll from './user-add-all/user-add-all-container';
import UserAddList from './user-add-list/user-add-list-container';
// import SingleOptionContainer from './single-option/single-option-container';
import UserSelectContainer from './user-select/user-select-container';

import * as util from '@u/util.js';

// TextArea
const { TextArea } = Input;
// TODO 选择参与人 取消100人限制 开放到5000
export default props => (
    <div className={css.boxall}>
        <div className={css.mask} onClick={props.close}></div>
        <div className={css.box} id="userAdd">
            <div className={css.title}>
                <span>{props.title}</span>
                <span className={`${css.close} iconfont-yach yach-quanju-xuanren-jianqunguanbi`} onClick={props.close} />
            </div>
            <div className={css.main}>
                <div className={css.search}>
                    {props.leftTitle && <div className={css.searchtitle}>{props.leftTitle}</div>}
                    <div className={css.searchcontent}>
                        <UserSelectContainer {...props} />
                    </div>
                    {(props.type == 'forward' && !props.noNeedLeaveWord) &&
                        <div style={{marginRight: 68 }}>
                            <TextArea
                                placeholder= {util.locale('common_place4')}
                                maxLength={2000}
                                style={{background: '#F0F2F6', padding: 8}}
                                onChange={props.textareaValue}
                            />   
                        </div>
                    }
                    {props.input && (
                        <div className={css.groupname}>
                            <p>{props.input}</p>
                            <Input maxLength={20} placeholder={util.locale('common_place5')} onChange={props.inputGroupName} style={{background: 'rgba(240,242,246,1)'}} />
                        </div>
                    )}
                    {props.maxLength ?
                        <Button
                        className={css.save + ' ' + (props.checkCanCB() ? '' : css.disabled)}
                        onClick={props.callback}
                        loading={props.loading || props.clickCB}
                        disabled={props.loading || props.clickCB}
                        >
                            {util.locale('common_make_sure')} {
                                props.maxLength - props.disabledids.length > 1 ?
                                 <>(<span className={props.checkOutLength() ? css.warn : ''}>{props.getLength()}</span>/
                                {props.squadMax || (props.maxLength - props.disabledids.length)})</>
                                 : null
                            }
                        </Button> : null
                    }
                    {!props.maxLength &&
                        <Button
                        className={css.save + ' ' + (props.checkCanCB() ? '' : css.disabled)}
                        onClick={props.callback}
                        loading={props.loading || props.clickCB}
                        disabled={props.loading || props.clickCB}
                        >
                            {util.locale('common_make_sure')} 
                        </Button>
                    }
                </div>
                <div className={css.list}>
                    {(props.type == 'group' || props.type == 'session') && (
                        <div className={css.listcontainer}>
                            <UserAddList {...props} list={props.usersList} title={props.userListTile}/>
                        </div>
                    )}
                    {(props.type == 'creatGroup' || 
                    props.type == 'addMembers' || 
                    props.type == 'forward' || 
                    props.type == 'recordGroup' ||
                    props.type == 'members' ||
                    props.type === 'squad' ||
                    !!!props.type)&& (
                        <UserAddAll {...props}/>
                    )}
                </div>
            </div>
        </div>
    </div>
);
