import React from 'react';

import css from './index.scss';

import UserAddList from '../user-add-list/user-add-list-container';

export default props => {
    const recentSession = (
        <div className={css.boxorgall}>
            <div className={css.commonly}>
                <UserAddList
                    currList={props.currList}
                    currListSet={props.currListSet}
                    disabledids={props.disabledids}
                    list={props.commonlyList}
                    title={props.rightTitle}
                />
            </div>
        </div>
    );
    return recentSession;
};
