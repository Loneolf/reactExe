import React from 'react';

import RecentSession from './recent-session';

import {ucenterUserConnectList} from '@/services/ucenter/ucenter-user';
import {organInfoPerson,organInfoDeptNextList} from '@/services/organ/organ-info';

class RecentSessionContainer extends React.Component {
    constructor(props){
        super(props)
    };

    state = {
        commonlyList: [],
    }

    componentDidMount() {
        this.getCommonlyList();
    };

    getCommonlyList = async () => {
        let data = await ucenterUserConnectList();
        if (data && data.code === 200) {
            let list = data.obj.list || [];
            this.setState({ commonlyList: list });
        }
    };
    
    render() {
        const props = {
            ...this.state,
            disabledids: this.props.disabledids,
            currList: this.props.currList,
            currListSet: this.props.currListSet,
            rightTitle: this.props.rightTitle
        };
        return <RecentSession {...props} />;
    }
}

export default RecentSessionContainer;
