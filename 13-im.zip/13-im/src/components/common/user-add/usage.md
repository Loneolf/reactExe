
# 1. 引入

    import UserAdd from '@c/common/user-add/user-add-container'

    <UserAdd />


# 2. 参数

    show: 组件是否显示 [必传*]

    onOk: 点击确定的回调 [必传*]

    onClose: 点击关闭的回调 [必传*]

    type: 右侧选择类型，默认是组织架构和常用联系人 [可选]

        - type = group 在群组里选

            |- groupId: 群id

        - type = session 在最近会话中选

        - type = ...
    
    check: radio 设置单选，默认多选 [可选]

    checkedids: 默认选中列表 [可选]

    disabledids: 禁用id列表 [可选]

    input: 左侧输入框标题 [可选]

    loading: 点击确定后loading转圈 [可选]

    title: 总标题 [可选]

    leftTitle: 左侧标题 [可选]

    userListTile: 右侧用户列表标题 [可选]

    selectType: 选择单位 [可选] 默认可以选人选部门（单选是默认为选人）

        - selectType = person 只能选人
        

# 3. 回调

    data {
        users: [] 选择的用户列表
        orgs: []
        teams: []
        allDataUsers: []
        inputValue: '' 输入框内容
    }

    