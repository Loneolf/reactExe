import React from 'react';
import {connect} from 'react-redux';

import debounce from 'lodash/debounce';

import UserAdd from './user-add';
import {message} from 'antd';

import {groupInfoGetMore, groupUsersListGet} from '@s/group/group-info.js';
import {ucenterMultiuserInfoGet} from '@s/ucenter/ucenter-multiuser.js';
import {organInfoMultideptList, organInfoUsersList} from '@s/organ/organ-info.js';
import {squadUserList} from '@/services/group/group-user';

import * as util from '@u/util.js';

class UserAddContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            organizList: [], //右侧 - 全部组织列表
            usersList: [], //右侧 - 用户列表
            limitList: [], //限定用户列表
            currList: [], //当前选择列表
            groupName: '', //新群组名称
            groupInfo: {},
            disabledids: [],
            clickCB: false
        };
        this.limit = 100
        this.initData();
    }

    componentDidMount() {
        this.setUsersList();
        this.callback = debounce(this.callback, 800);
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.show != this.props.show) {
            if (this.props.show) {
                this.setDefaultConfig();
            } else {
                this.clear();
            }
        }
        if (prevProps.sessionList != this.props.sessionList && this.props.type !== 'squad') {
            this.setUsersList();
        }
        if (prevState.currList != this.state.currList) {
            this.checkWarn();
        }
    }

    // 初始化参数
    initData = () => {
        this.isCBing = false;
        this.title = this.props.title || '';
        this.leftTitle = this.props.leftTitle || '';
        this.input = this.props.input || '';
        this.userListTile = this.props.userListTile || '';
        this.placeholder = this.props.placeholder || util.locale('common_place2');
    }

    //设置默认配置
    setDefaultConfig = async () => {
        this.title = this.props.title || '';
        if (this.props.disabledids) {
            this.setState({ disabledids: Array.isArray(this.props.disabledids) ? this.props.disabledids.concat(this.owner || []) : this.props.disabledids })
        }
        if (this.props.checkedids) {
            let userids = this.props.checkedids.filter(v => !v.toString().includes('-'))
            let orgids = this.props.checkedids.filter(v => v.toString().includes('-org-'))
            let levelids = this.props.checkedids.filter(v => v.toString().includes('-level-'))
            let teamids = this.props.checkedids.filter(v => v.toString().includes('-team-'))
            let userData = await this.userIdsToInfos(userids)
            let orgData = await this.orgIdsToInfos(orgids)
            // let levelData = commonfn.getLevelInfo(levelids.map(v => v.split('-level-')[0]))
            let levelData = []
            let teamData = await groupInfoGetMore({tids: teamids.map(v => v.split('-team-')[0]).join()})
            orgData = orgData.map(v => ({
                id: v.deptId + '-org-' + v.userNum,
                name: v.deptName + `(${v.userNum}${util.locale('common_persion')})`
            }))
            levelData = levelData.map(v => ({
                id: v.id + '-level-',
                name: v.name
            }))
            teamData = teamData.obj.map(v => ({
                id: v.group_tid + '-team-',
                name: v.group_name
            }))
            this.currListSet([...userData, ...orgData, ...levelData, ...teamData])
        }
    }

    //左侧搜索点击选择
    searchChoose = data => {
        let curr = this.transToId(data);
        if (this.state.limitList.length) {
            let limitids = this.state.limitList.map(v => v.id);
            let limitLock = false;
            curr.forEach(v => {
                if (!limitids.includes(v.id)) {
                    message.error(util.locale('common_msg40'));
                    limitLock = true;
                }
            });
            if (limitLock) return false;
        }
        this.currListSet(curr);
    };

    //设置右侧限制列表
    setUsersList = () => {
        if (this.props.loading) return;
        if (this.props.type == 'group') {
            this.setGroupUserList();
            return false;
        }
        if (this.props.type == 'session' || this.props.type == 'forward' || this.props.type == 'recordGroup') {
            this.setSessionList();
            return false;
        }
        if (this.props.type === 'squad') {
            this.getSquadUserList()
            return false
        }
    };

    // 获取小组列表
    getSquadUserList = async (offset_id = 0, where) => {
        if (this.isRequestSquad) return
        const isAddress = location.pathname.match(/\/address-list/)
        this.isRequestSquad = true
        // const {id} =  this.props.sessionActive;
        const id = window.session_active.id;
        const opt = {
            squad_id: id,
            offset_id,
            limit: this.limit
        }
        where && (opt.where = where)
        const datas = await squadUserList(opt)
        if (datas) {
            const {code, obj = {}} = datas || {};
            if (code !== 200 || !obj.data || !obj.data.list) return
            const list = []
            for (const key in obj.data.list) {
                const users = obj.data.list[key]
                Array.prototype.push.apply(list, users.map(item => {
                    item.role = key === 'admin' ? 1 : (key === 'owner' ? 0 : 2)
                    return item
                }))
            }
            if (obj.data.list && obj.data.list.owner) this.owner = obj.data.list.owner.map(item => {
                return item.user_id || item.id
            })
            // if (list.length < this.limit) obj.data.info.offset_id = 0
            this.setState({
                usersList: offset_id !== 0 ? this.state.usersList.concat(list) : list,
                groupInfo: {...obj.data.info, ...obj.data.ex},
                // TODO
                // disabledids: this.props.disabledids.concat(this.owner)
            })
        }
        this.isRequestSquad = false
    }

    //设置右侧限制列表为群组内用户
    setGroupUserList = async () => {
        let data = await groupUsersListGet({ tid: this.props.groupId });
        if (data && data.code == 200) {
            let olgArr = [],
            newArr = [];
            olgArr = data.obj.list.owner.concat(data.obj.list.normal, data.obj.list.admin)
            olgArr.forEach(v => {
                newArr = [...newArr, ...v.value];
            });
            this.setState({ limitList: newArr, usersList: newArr });
            // if (data.obj.list.owner.length) this.owner = data.obj.list.owner.map(item => item.value[0].id)
        }
    };

    //设置右侧限制列表为当前会话
    setSessionList = () => {
        let sessionList = this.props.sessionList
        let list = []

        if (this.props.type == 'recordGroup') {
            list = sessionList.filter(v => (
                v.type == 'team' && !v.isDismiss && !v.isSecret)
            )
        } else {
            list = sessionList.filter(v =>
                (v.type == 'p2p' && v.id && `${v.id}`.length>4 && !v.isSquad && !v.isChatRobot) || (v.type == 'team' && !v.isDismiss && !v.isSecret))
        }

        list = list.slice(0, 50).map(v => ({
            id: v.type == 'team' ? v.id + '-team-' : v.id,
            name: v.showname,
            pic: v.showimg
        }))
        this.setState({ usersList: list })
    }

    //检查单选多选[Deprecated]
    checkRadio = data => {
        if (this.props.check == 'radio') {
            if (data.length > 1) {
                message.error(util.locale('common_msg24'));
                return false;
            }
        }
        return true;
    }

    //设置当前选择用户列表
    currListSet = data => {
        data = data.map(item => {
            if (!item.user_id) {
                // const obj = this.state.usersList.find(i => i.id === item.id) || {}
                // item.user_id = obj.user_id || item.id
                const obj = this.state.usersList.find(i => i.id === (item.id && item.id.split('-user-')[0])) || {}
                item.user_id = obj.user_id || (item.id && item.id.split('-user-')[0])
            }
            return item
        })
        if (this.props.check == 'radio') {
            data = data.slice(-1)
        }

        this.setState({ currList: data });
    };

    //计算人数
    getLength = () => {
        let length = 0
        this.state.currList.forEach( v => {
            if (v.id.toString().includes('-org-')) {
                length += +v.id.split('-org-')[1]
            } else if (v.id.toString().includes('-team-')) {
                length += 1
            } else if (v.id.toString().includes('-level-')) {
                length += 1
            } else if (v.id.toString().includes('-partner-')) {
                // length += +v.user_count
                length += +v.id.split('-partner-')[1]
            } else if (v.id.toString().includes('-user-')) {
                length += 1
            } else {
                length += 1
            }
        })
        return length
    };

    //数据转label格式
    transToLabel = arr => {
        return arr.map(v => ({
            key: v.id,
            label: v.name
        }));
    };

    //数据转id格式
    transToId = arr => {
        return arr.map(v => ({
            id: v.key,
            name: v.label
        }));
    };

    //输入群名称
    inputGroupName = event => {
        let text = event.target.value;
        this.setState({ groupName: text });
    };

    //检查是否超出限制
    checkOutLength = () => {
        if (!this.props.maxLength) return false;
        let len = this.props.maxLength - this.state.disabledids.length
        this.owner && (len += this.owner.length)
        if (this.getLength() > len) {
            return true
        }
        return false
    };

    //检查能否回调
    checkCanCB = () => {
        if (this.isCBing) {
            return false
        }
        if (!this.getLength()) {
            return false
        }
        if (this.checkOutLength()) {
            return false
        }
        return true
    };

    //检查用户的选择错误
    checkWarn = () => {
        if (this.checkOutLength()) {
            message.error(util.locale('common_msg25'))
            return false
        }
    };

    //根据用户id获取用户信息
    userIdsToInfos = async ids => {
        let data = await ucenterMultiuserInfoGet({
            user_ids: JSON.stringify(ids)
        })
        if (data && data.code) {
            return data.obj
        }
        return [];
    };

    //根据组织id获取组织信息
    orgIdsToInfos = async ids => {
        let data = await organInfoMultideptList({
            department_ids: JSON.stringify(ids)
        })
        if (data && data.code) {
            return data.obj
        }
        return [];
    };

    //回调
    callback = () => {
        if(!navigator.onLine) return message.error(util.locale('common_online_dsp'));

        if (!this.checkCanCB()) return false;
        this.setState({clickCB: true});
        this.isCBing = true;
        let userids = [],
        orgids = [],
        teamids = [],
        levelids = [],
        users = [],
        orgs = [],
        teams = [],
        levels = [],
        partnerids = [],
        allDataUsers = [];

        //split
        this.state.currList.forEach(v => {
            if (v.id.toString().includes('-org-')) {
                orgids.push(v.id.split('-org-')[0])
            } else if (v.id.toString().includes('-team-')) {
                teamids.push(v.id.split('-team-')[0])
            } else if (v.id.toString().includes('-level-')) {
                levelids.push(v.id.split('-level-')[0])
            } else if (v.id.toString().includes('-partner-')) {
                partnerids.push(v.id.split('-partner-')[0])
            } else if (v.id.toString().includes('-user-')) {
                userids.push(v.id.split('-user-')[0])
            } else {
                userids.push(v.id)
            }
        });

        if (this.props.typeMsg && this.props.typeMsg.type === 'squad') {
            this.squad(this.state.currList)
            return
        }
        this.group(userids, orgids, teamids, levelids, users, orgs, teams, levels, allDataUsers,partnerids)
    };

    //小组
    squad = currList => {
        this.props.onOk({
            currList: this.state.currList
        });
        this.isCBing = false;
        this.setState({clickCB: false});
    }

    // 群
    group = async (userids, orgids, teamids, levelids, users, orgs, teams, levels, allDataUsers,partnerids) => {

        //return user info
        if(userids && userids.length > 0){
            let usersData = await ucenterMultiuserInfoGet({
                user_ids: JSON.stringify(userids)
            })
            if (usersData && usersData.code == 200) {
                users = usersData.obj || [];
            }
        };

        //return org info
        if(orgids && orgids.length>0){
            let orgsData = await organInfoMultideptList({
                department_ids: JSON.stringify(orgids)
            })
            if (orgsData && orgsData.code == 200) {
                orgs = orgsData.obj || [];
            }
        };

        //return user & org user info
        if(userids || orgids || partnerids){
            let allData = await organInfoUsersList({
                og_ids: JSON.stringify(orgids),
                user_ids: JSON.stringify(userids),
                team_ids: JSON.stringify(partnerids)
            });
            if (allData && allData.code == 200) {
                allDataUsers = allData.obj.list;
            }
        };

        // return team info
        if (teamids && teamids.length) {
            let teamsData = await groupInfoGetMore({
                tids: teamids.join()
            })
            if (teamsData && teamsData.code == 200) {
                teams = teamsData.obj;
            }
        };

        //return level info
        if (levelids && levelids.length) {
            // levels = commonfn.getLevelInfo(levelids)
        };

        let data = {
            users,
            orgs,
            teams,
            teamids,
            levels,
            allDataUsers,
            inputValue: this.state.groupName,
            textareaValue: this.state.textareaValue
        };

        this.props.onOk(data);
        this.isCBing = false;
        this.setState({clickCB: false});
    }

    //关闭
    close = () => { this.props.onClose() };

    //清除数据
    clear = () => {
        this.setState({
            currList: [],
            groupName: '',
            textareaValue: '',
            clickCB: false
        });
        this.isCBing = false;
    };

    textareaValue = value => {
        this.setState({ textareaValue: value.target.value });
    };

    render() {
        if (!this.props.show) return null;
        const { state, props } = this;
        const { loading, isAdmin=false, maxLength, authority, canCheckMyOrg, type,check,selectType='all',noNeedLeaveWord=false } = props;
        const { groupInfo, currList, usersList, disabledids, userSearchList, clickCB } = state;

        const len = this.owner ? (maxLength + this.owner.length) : maxLength
        // delete this.owner

        const id = window.session_active.id;

        const childProps = {
            squadMax: this.props.squadMax,
            isAdmin,
            // groupInfo: {...groupInfo, squad_id: this.props.sessionActive.id },
            groupInfo: {...groupInfo, squad_id: id},
            getSquadUserList: this.getSquadUserList,
            groupId: this.props.groupId,
            currListLabel: this.transToLabel(currList),
            clickCB: clickCB,
            currList: currList,
            usersList: usersList,
            disabledids: disabledids,
            userSearchList: userSearchList,
            loading: loading,
            maxLength: len,
            authority: authority,
            canCheckMyOrg: canCheckMyOrg,
            placeholder: this.placeholder,
            searchChoose: this.searchChoose,
            inputGroupName: this.inputGroupName,
            callback: this.callback,
            currListSet: this.currListSet,
            type: type,
            close: this.close,
            title: this.title,
            input: this.input,
            leftTitle: this.leftTitle,
            userListTile: this.userListTile,
            getLength: this.getLength,
            checkOutLength: this.checkOutLength,
            selectOnBlur: this.selectOnBlur,
            textareaValue: this.textareaValue,
            checkCanCB: this.checkCanCB,
            radio:check=='radio',
            selectType: check=='radio'?'person':selectType,
            noNeedLeaveWord
        };
        return <UserAdd {...childProps} />;
    }
}

const mapStateToProps = state => ({
    userInfo: state.userInfo,
    sessionList: state.sessionList,
    slideModal: state.slideModal,
    // sessionActive: state.sessionActive,
    
});

export default connect(mapStateToProps)(UserAddContainer);
