import React from 'react';

import UserAddAll from './user-add-all';

import {ucenterUserConnectList} from '@/services/ucenter/ucenter-user';
import {organInfoPerson,organInfoDeptNextList} from '@/services/organ/organ-info';

import * as util from '@u/util.js';

class UserAddAllContainer extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            page: this.checkType(),
            pageData: null,
            commonlyList: [],
            orgBread: [], //组织架构面包屑
            orgList: [], //组织架构当前节点组织
            orgUsers: [], //组织架构当前节点用户
            authorityOrgId: '', //权限可访问的组织id
            rootList:[],// 当前用户根组织节点
            partnerType: 'partnerList', // 我的伙伴页面类型：我的伙伴: partnerList | 成员: members
        }
    }
    componentDidMount(){
        if (this.props.type !== 'squad') {
            this.openAll();
            this.getCommonlyList();
        }
    }

    checkType = () => {
        const{type} = this.props;
        if(type == 'forward'){
            return 'session'
        }else if(type == 'members'){
            return 'myGroup'
        }
        // else if(type == 'inviteMembers'){
        //     return 'inviteGroup'
        // }
        return 'orgAll'
    }

    //切换页面
    changePage = page => {
        this.setState({ page })
    }

    // 首页 -> 我的伙伴
    openPartner = () => {
        this.setState({partnerType: 'partnerList'});
        this.changePage('myPartner');
    }


    //获取用户所有组织架构
    getOrgansAll = async () => {
        let data = await organInfoPerson()
        if (data && data.code == 200) {
            let list = data.obj.map(v => v[v.length - 1]);
            let rootList=data.obj[0];
            list.forEach(v => {
                v.deptName = v.name
                v.id = v.deptId + '-org-' + v.userNum
                v.name = `${v.name}( ${v.userNum} ${ util.locale('common_persion')})`
            })
            this.setState({ orgList: list,rootList })
        }
    }

    //获取右侧常用联系人用户列表
    getCommonlyList = async () => {
        let data = await ucenterUserConnectList({type: 0});
        if (data && data.code === 200) {
            const list = await util.yach.base64ImgArrGetTmp(data.obj.list || [],'pic');
            console.warn(list,333);
            this.setState({ commonlyList: list });
        }
    };

    //切换到all页面
    openAll = (pageName) => {
        this.changePage(pageName || this.state.page);
        this.getOrgansAll();
    };

    //切换到list页面
    openOrg = id => {
        this.changePage('orgList')
        this.changeOrgList(id)
        if (this.props.authority == 'orgself') {
            this.setState({ authorityOrgId: id })
        }
    };

    //点击下一级
    openNext = (id, event) => {
        event && event.stopPropagation()
        if (!id) return false;
        if (this.isChecked(id)) return false;

        if (this.state.page == 'orgAll') {
            this.openOrg(id)
        }
        if (this.state.page == 'orgList') {
            this.changeOrgList(id)
        }
    };

    //展开组织架构
    changeOrgList = async id => {
        let data = await organInfoDeptNextList({
            department_id: id.toString().split('-org-')[0]
        })
        if (data && data.code == 200) {
            let userList=data.obj.userList||[],
                manager=data.obj.root.manager;

            data.obj.ogList.forEach(v => {
                v.id = v.deptId + '-org-' + v.userNum
                v.name = `${v.deptName} (${v.userNum} ${ util.locale('common_persion')})`
            })

            if (this.state.authorityOrgId){
                let authorityid = this.state.authorityOrgId.split('-org-')[0]
                let authorityindex = data.obj.root.full.findIndex(v => v.og_id == authorityid)
                if (authorityindex != -1) {
                    data.obj.root.full = data.obj.root.full.filter((v, index) => index >= authorityindex)
                }
            }
            if (manager) {
                userList.unshift(manager)
            }
            userList=await util.yach.base64ImgArrGetTmp(userList,'pic');
            this.setState({
                orgBread: data.obj.root.full || [],
                orgList: data.obj.ogList || [],
                orgUsers: userList || []
            })
        }
    };

    //选择组织架构
    chooseOrg = e => {
        let newCurrList = [...this.props.currList];
        let ids = newCurrList.map(v => v.id);
        let item = this.state.orgList.find(v => v.id == e.target.value);
        if (ids.includes(e.target.value) && !e.target.checked) {
            newCurrList = newCurrList.filter(v => v.id != e.target.value);
        }
        if (!ids.includes(e.target.value) && e.target.checked) {
            newCurrList.push(item);
        }
        this.props.currListSet(newCurrList);
    };

    //选择全部的组织架构和人
    checkAll = e => {
        let newCurrList = [...this.props.currList];
        let currids = newCurrList.map(v => v.id);
        let all = [...this.state.orgUsers, ...this.state.orgList]
        let allids = all.map(v => v.id)

        if (e.target.checked) {
            all.forEach(user => {
                if (!currids.includes(user.id) && !this.props.disabledids.includes(user.id)) {
                    newCurrList.push(user)
                }
            })
        } else {
            newCurrList = newCurrList.filter(v => !allids.includes(v.id))
        }

        this.props.currListSet(newCurrList);
    };

    //是否全选
    isCheckAll = () => {
        let newCurrList = [...this.props.currList];
        let currids = newCurrList.map(v => v.id);
        let all = [...this.state.orgUsers, ...this.state.orgList]

        for (let i of all) {
            if (!currids.includes(i.id) && !this.props.disabledids.includes(i.id)) return false
        }
        return true
    };

    //普通复选框是否选中
    isChecked = id => {
        return this.props.currList.map(v => v.id).includes(id)
    };

    //切换到levellist页面
    openLevel = () => {
        this.changePage('levelList')
    };

    render() {
        const userAllProps = {
            ...this.state,
            ...this.props,
            isAdmin: this.props.isAdmin || false,
            currList: this.props.currList,
            currListSet: this.props.currListSet,
            disabledids: this.props.disabledids,
            openAll: this.openAll,
            openOrg: this.openOrg,
            openNext: this.openNext,
            changeOrgList: this.changeOrgList,
            chooseOrg: this.chooseOrg,
            checkAll: this.checkAll,
            isCheckAll: this.isCheckAll,
            isChecked: this.isChecked,
            authority: this.props.authority,
            canCheckMyOrg: this.props.canCheckMyOrg,
            openLevel: this.openLevel,
            changePage: this.changePage,
            openPartner: this.openPartner,
        };
        return <UserAddAll {...userAllProps} />;
    }
}

export default UserAddAllContainer;
