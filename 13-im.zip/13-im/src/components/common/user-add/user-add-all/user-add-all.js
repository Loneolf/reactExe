import React from 'react';

import css from './index.scss';

import { Checkbox, Row } from 'antd';
import UserAddList from '../user-add-list/user-add-list-container';
import UserAddLevel from '../user-add-level/user-add-level-container';
import MyGroup from '../my-group/my-group-container';
import LatestSession from '../latest-session/latest-session-container';
import PartnerContainer from '../partner/partner-container';

import * as util from '@u/util.js';

export default props => {
    let slist = []
    if (props.type == 'squad') {
        slist = props.usersList.map(item => {
            // item.id = item.user_id
            item.type = 'squad'
            return item
        })
    } else {
        slist = props.commonlyList
    }
    const allTitle = (
        <div className={css.alltitle}>
            <div className={css.title} onClick={() => props.changePage('myPartner')}>
                <img src={require("@a/imgs/my-partner@2x.png")} />
                <span>{util.locale('common_accepter12') }</span>
            </div>
            {(props.type == 'forward' || props.type == 'creatGroup' || props.type == 'recordGroup') &&
                <div className={css.title} onClick={() => props.changePage('myGroup')}>
                    <img src={require("@a/imgs/my-group.png")} />
                    <span>{util.locale('common_team_msg35') }</span>
                </div>
            }
            {(props.type == 'forward' || props.type == 'group' || props.type == 'recordGroup') &&
                <div className={css.title} onClick={() => props.changePage('session')}>
                    <img src={require("@a/imgs/recent-session.png")} />
                    <span>{util.locale('common_topic2') }</span>
                </div>
            }
            {(props.type == 'squad') &&
                <div className={css.title + ' ' +css.compTitle + ' ' + css.titlecom}>
                    {/* <img src={require("@a/imgs/tal.png")} /> */}
                    <span>{util.locale('common_topic3') }</span>
                </div>
            }
            {(props.type != 'recordGroup' && props.type != 'squad') &&
                <div className={css.title + ' ' +css.compTitle + ' ' + css.titlecom}>
                    {/* <img src={require("@a/imgs/tal.png")} /> */}
                    <span>{util.locale('common_topic4') }</span>
                </div>
            }

        </div>
    );
    const rootList=props.rootList||[];
    //索引首页
    const orgAll = (props.type == 'recordGroup') ? allTitle : (
        <div className={css.boxorgall}>
            {
                props.type !== 'squad' ?
                <>
                    {allTitle}
                    {props.authority == 'level' && (
                        <div className={css.organiz}>
                            <p onClick={props.openLevel}>
                                <span>{util.locale('common_topic5') }</span>
                                <span className="iconfont iconzhankai"></span>
                            </p>
                        </div>
                    )}
                    <div className={css.organiz}>
                        {props.authority != 'orgself' && (
                            <p onClick={props.openOrg.bind(null, rootList[0]&&rootList[0].deptId)}>
                                <span className={css.titleItem}>{util.locale('common_topic6') }</span>
                                <span className={`${css.jiantou_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`}></span>
                            </p>
                        )}
                        {!props.canCheckMyOrg && props.orgList.map(v => (
                            <div key={v.id} className={css.orgitem} onClick={props.openOrg.bind(null, v.id)}>
                                <span style={{position: 'relative', top: 5}} className="iconfont-yach yach-quanju-xuanren-zuzhijiagou-xiangxiazhankai"></span>
                                <span>{v.deptName}</span>
                            </div>
                        ))}
                        {!!props.canCheckMyOrg && (
                            <div className={css.orglist}>
                                <Checkbox.Group style={{ width: '100%', display: 'block' }} value={props.currList.map(v => v.id)}>
                                    {props.orgList.map((v, index) => (
                                        <Row key={index} className={css.item}>
                                            <Checkbox value={v.id} onChange={props.chooseOrg}>
                                                <span className={css.name}>
                                                    {v.deptName}
                                                <span>（{v.userNum || 0}{ util.locale('common_persion')}）</span>
                                                </span>
                                            </Checkbox>
                                            <span
                                                className={css.next + ' ' + (props.isChecked(v.id) ? css.disabled : '')}
                                                onClick={props.openNext.bind(null, v.id)}
                                            >
                                                {util.locale('common_accepter7')}
                                            </span>
                                        </Row>
                                    ))}
                                </Checkbox.Group>
                            </div>
                        )}
                    </div>
                </>
                : null
            }
            <div className={css.commonly}>
                <UserAddList
                    isAdmin={props.isAdmin}
                    listType={true}
                    currList={props.currList}
                    disabledids={props.disabledids}
                    currListSet={props.currListSet}
                    type={props.type}
                    list={slist}
                    groupInfo={props.groupInfo}
                    getSquadUserList={props.getSquadUserList}
                    title={props.type !== 'squad' ? util.locale('common_accepter9') : ''}
                />
            </div>
        </div>
    );

    //组织列表分页
    const orgList = (
        <div className={css.boxorglist}>
            <div className={css.blocktitle}>
                <div className={css.title} onClick={()=>props.openAll('orgAll')}>
                    <span className="iconfont iconzhankai"></span>
                    <span style={{fontSize: 16}}>{util.locale('common_topic4')}</span>
                </div>
                <div className={css.bread}>
                    {props.orgBread.slice(0, -1).map(v => (
                        <div key={v.og_id} className={css.item} onClick={props.changeOrgList.bind(null, v.og_id)}>
                            <span>{v.og_name}</span>
                            <span className={css.right}>/</span>
                        </div>
                    ))}
                    {props.orgBread.slice(-1).map(v => (
                        <div key={v.og_id} className={css.item}>
                            <span>{v.og_name}</span>
                        </div>
                    ))}
                </div>
            </div>
            <div className={css.blockorg}>
                <div className={css.orglist}>
                    {
                        !props.radio?<Row className={css.item + ' ' + css.itemall}>
                            <Checkbox onChange={props.checkAll} checked={props.isCheckAll()}>
                                <span className={css.name}>{util.locale('common_select_all')}</span>
                            </Checkbox>
                        </Row>:null
                    }
                    <Checkbox.Group style={{ width: '100%', display: 'block' }} value={props.currList.map(v => v.id)}>
                        {props.orgList.map(org => (
                            <Row key={org.id} className={css.item}>
                                {
                                    props.selectType==='person'?(<>
                                            <span className={css.name}>
                                                {org.deptName}
                                    <span>（{org.userNum || 0}{ util.locale('common_persion')}）</span>
                                            </span>
                                            <span
                                                className={css.next + ' ' + (props.isChecked(org.id) ? css.disabled : '')}
                                                onClick={props.openNext.bind(null, org.id)}
                                            >
                                                <span className="iconfont-yach yach-quanju-xuanren-xiajichangtai" style={{fontSize: 13,marginRight:"3px"}}></span>{util.locale('common_accepter7')}
                                            </span>
                                        </>):(<>
                                                <Checkbox
                                                    value={org.id}
                                                    onChange={props.chooseOrg}
                                                    disabled={props.disabledids.includes(org.id)}
                                                >
                                                <span className={css.name}>
                                                    {org.deptName}
                                        <span>（{org.userNum || 0}）</span>
                                                </span>
                                                </Checkbox>
                                                <span
                                                    className={css.next + ' ' + (props.isChecked(org.id) ? css.disabled : '')}
                                                    onClick={props.openNext.bind(null, org.id)}
                                                >
                                                    <span className="iconfont-yach yach-quanju-xuanren-xiajichangtai" style={{fontSize: 13,marginRight:"3px"}}></span>{util.locale('common_accepter7')}
                                                </span>
                                            </>)
                                }
                            </Row>
                        ))}
                    </Checkbox.Group>
                </div>
                <div className={css.orguser}>
                    <UserAddList
                        isAdmin={props.isAdmin || false}
                        currList={props.currList}
                        disabledids={props.disabledids}
                        currListSet={props.currListSet}
                        list={props.orgUsers}
                    />
                </div>
            </div>
        </div>
    );

    //职级选择分页
    const levelList = (
        <div className={css.boxlevellist}>
            <div className={css.title} onClick={()=>props.openAll('orgAll')}>
                <span className="iconfont iconzhankai"></span>
                <span>{util.locale('common_topic4')}</span>
            </div>
            <div className={css.title}>
                <span>{util.locale('common_accepter8')}</span>
            </div>
            <div className={css.levellist}>
                <UserAddLevel currList={props.currList} currListSet={props.currListSet} />
            </div>
        </div>
    );
    switch (props.page) {
        case 'orgAll':
            return orgAll;
        case 'orgList':
            return orgList;
        case 'levelList':
            return levelList;
        case 'myGroup':
            return <MyGroup {...props}/>;
        case 'session':
            return <LatestSession {...props} list={props.usersList}/>;
        case 'myPartner':
            return <PartnerContainer {...props}/>;
        default:
            return null;
    }
};
