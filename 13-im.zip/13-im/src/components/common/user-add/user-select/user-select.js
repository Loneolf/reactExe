/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-16 14:36:32
 * @LastEditors: olei<wangzheng_jzb@100tal.com>
 * @LastEditTime: 2020-04-23 11:15:40
 */
import React from 'react';
import css from './index.scss';
import { Select } from 'antd';

import * as util from '@u/util.js';
const { Option, OptGroup } = Select;

export default props => (  
    <div className={css.box}>
        <Select
            mode = "multiple"
            onBlur = {props.selectOnBlur}
            labelInValue = {true}
            value = {props.currListLabel}
            placeholder = {props.placeholder}
            notFoundContent = {props.hindSelectItem && <span> {util.locale('common_msg16')} </span>}
            filterOption = {false}
            onSearch = {props.searchInput}
            onChange = {props.searchChoose}
            style = {{ width: '100%' }}
            autoFocus = {true}
            optionLabelProp = "text"
            className = "multipleSelect"
            autoClearSearchValue = {true}
            getPopupContainer = {() => document.getElementById('userAdd')}
            // defaultOpen = {true}
            // open = {true}
        >
        {props.hindSelectItem && props.getSingle() && props.userSearchList.map(user => (
                <Option 
                    key={user.id}
                    className={css.option} 
                    text={user.name}
                    disabled={props.disabledids.includes(user.id) || props.disabledids.includes(user.user_id) || props.disableOption(user)}
                    onClick={()=>{props.optionClick(user)}}
                >
                    <img src={user.pic} alt="" />
                    <div>
                        <span>{user.name}</span>
                        {!!user.dept && (
                            <span style={{color: '#757b82'}}>
                                {user.dept.length > 17
                                    ? user.dept.slice(0, 8) + '...' + user.dept.slice(-8)
                                    : user.dept}
                            </span>
                        )}
                    </div>
                </Option>
            ))}
            {props.hindSelectItem && props.getGroup() &&
                props.groupList.map((item, index) =>(
                    <OptGroup label={item.title} key={index}>
                        {item.data.map(user => (
                            <Option
                                key={user.id}
                                className={css.option}
                                text={user.newName}
                                disabled={props.disabledids.includes(user.id)}
                            >
                                {(user.id != -1 && user.id != -2) &&
                                    <div className='antSelectItem'>
                                        <img src={user.pic} alt="" />
                                        <div>
                                            <p dangerouslySetInnerHTML={{__html: user.showName}} />
                                            {!!user.dept ? (
                                                <span>
                                                    {user.dept.length > 17
                                                        ? user.dept.slice(0, 8) + '...' + user.dept.slice(-8)
                                                        : user.dept}
                                                </span>
                                            ) : 
                                            (
                                                user.groupShowName ? 
                                                <p
                                                    dangerouslySetInnerHTML={{__html: `${util.locale('common_have')}：` + user.groupShowName + `(${user.groupName})`}}>
                                                </p> : null
                                            )
                                            }
                                        </div>
                                    </div>
                                }
                                {(user.id == -1 || user.id == -2) && user.isShowMore &&
                                    <div className='antSelectLoadMore' onMouseDown={e => e.preventDefault()} onClick={(e)=>props.loadMore(user.id, e)}>
                                        {user.id == -1 ? util.locale('common_view_more2') : util.locale('common_view_more3')}
                                    </div>
                                }
                            </Option>
                        ))}
                    </OptGroup>
                ))
            }
        </Select>
    </div>
)