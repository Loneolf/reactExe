import React from 'react';
import UserSelect from './user-select';
import debounce from 'lodash/debounce';
import {searchGpinusersearch, searchGpsearch, searchUserSearch} from '@s/search/search.js';
import {squadUserList} from '@/services/group/group-user';
import * as util from '@/utils/util';

class UserSelectContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state={
        userSearchList: [], //左侧 - 用户搜索列表
        hindSelectItem: false,
        pagesize: 20,
        groupRows: 20,
        userRows: 20,
        isShowMore: false,
        groupList: [],
        searchKey: '',
        sortGroupData: [],
    }

    componentDidMount() { 
        this.searchInput = debounce(this.searchInput, 800);
    }

    //左侧输入实时查询
    searchInput = async text => {
        text = text + '';
        if(!text) return this.hindSelect();
        this.setState({searchKey: text, groupRows: 20});
        let list = [];
        if(this.props.type == 'group'){
            list = await this.getGroupUsersList(text, 1, 1000);
        }else if (this.props.type == 'session') {
            list = await this.getSessionList(text, 1, 1000);
        }else if (this.props.type == 'recordGroup') {
            list = await this.getSessionList(text, 1, 1000);
        }else if(this.props.type == 'forward'){
            this.getGroupList(text, 1, this.state.pagesize);
        }else if (this.props.type == 'squad') {
            list = await this.getSquadList(text)
        }else {
            list = await this.getUserList(text, 1, 1000);
        }
        list.forEach(v => v.id = v.id + '');
        this.setState({
            userSearchList: list,
            hindSelectItem: true
        });
    };

    getSquadList = async where => {
        const owner = this.props.usersList.filter(item => item.role === 0).map(item => item.id)
        const opt = {
            squad_id: this.props.groupInfo.squad_id, 
            offset_id: 0,
            limit: 1000,
            where
        }
        const datas = await squadUserList(opt)
        if (datas) {
            const {code, obj = {}} = datas || {};
            if (code !== 200 || !obj.data || !obj.data.list) return
            const list = []
            for (const key in obj.data.list) {
                const users = obj.data.list[key]
                Array.prototype.push.apply(list, users.map(item => {
                    item.role = key === 'admin' ? 1 : (key === 'owner' ? 0 : 2)
                    return item
                }))
            }
            // return list.filter(item => !owner.includes(item.user_id))
            return list
        }
        return []
    }

    getUserList = async(text, page, pagesize) => {
        let list = [];
        const data = await searchUserSearch({querystr: text, page: page, pagesize: pagesize});
        if (data && data.code == 200) list = data.obj.list;
        return list;
    }

    getGroupUsersList = async(text, page, pagesize) => {
        let list = [];
        let data = await searchGpinusersearch({ groupid: this.props.groupId, querystr:text, page:page, pagesize:pagesize });
        if (data && data.code == 200) list = data.obj.list;
        return list;
    }

    getSessionList = async(text, page, pagesize) => {
        let size = this.props.type == 'forward' ? 100 : pagesize
        let list = [];
        if(this.props.type != 'forward' && this.props.type != 'recordGroup') list = await this.getUserList(text, page, pagesize);
        let data = await searchGpsearch({ querystr: text, page:page, pagesize: size})
        data.obj.list = data.obj.list.map(v => ({
            ...v,
            id: v.tid + '-team-'
        }))
        if (data && data.code == 200) list = list.concat(data.obj.list);
        // 只针对转发、多选转发对搜索出来的群组排序。
        if (this.props.type == 'forward') {
            // let resultSortGroup = await util.yach.handleSessionGroupSort(list, true);
            let resultSortGroup = list
            resultSortGroup = util.yach.searchHighlighted(resultSortGroup, text);
            this.setState({sortGroupData: resultSortGroup})
        }
        return list;
    }

    getGroupSessionList = async(text, page, pagesize, flag = true) => {
        if (flag) await this.getSessionList(text, page, pagesize);
        let groupList = [],
            sessionListLen = 0,
            sessionList =  [];
        sessionList = this.state.sortGroupData.slice(0, pagesize);
        sessionListLen = sessionList.length
        if(sessionList && sessionListLen>0){
            sessionList.push({
                id: -2, 
                name: '',
                isShowMore: sessionListLen == pagesize ? true : false
            });
            groupList.push(
                {
                    title: util.locale('common_team_group'),
                    data: sessionList
                }
            )
        }  
        return groupList;
    };

    getGroupUserList = async(text, page, pagesize) => {
        let userList = await this.getUserList(text, page, pagesize);
        let groupList = [],
            userListLen = userList.length;
        if(userList && userListLen>0){
            userList = util.yach.searchHighlighted(userList, text);
            userList.push({
                id: -1, 
                name: '', 
                isShowMore: userListLen == pagesize ? true : false
            });
            groupList.push( 
                {
                    title: util.locale('common_contact'),
                    data: userList
                }
            )
        }
        return groupList;
    }

    getGroupList = async(text, page, pagesize) =>{
        let groupUserList = await this.getGroupUserList(text, page, pagesize);
        let groupSessionList = await this.getGroupSessionList(text, page, pagesize);
        groupSessionList = groupSessionList.map(i => ({
            ...i,
            id: i.tid + '-team-'
        }))
        this.setState({groupList: [...groupUserList, ...groupSessionList]});
    }

    hindSelect = () => {
        this.setState({
            hindSelectItem: false, 
            userSearchList: [],
            groupRows: 20,
            userRows: 20
        });
    }

    searchChoose = (data) => {
        this.hindSelect();
        if(this.cancelSelect) return this.cancelSelect = false
        this.props.searchChoose(data);
    }

    selectOnBlur = () => {
        this.hindSelect();
    }

    getSingle = () => {
        return this.props.type != 'forward';
    }

    getGroup = () => {
        return this.props.type == 'forward';
    }

    loadMore = (id, e) => {
        e.stopPropagation();
        e.nativeEvent.stopImmediatePropagation();

        const {userRows, groupRows, pagesize, searchKey, groupList} = this.state;
        if(id == -1) {
            this.setState({userRows: userRows + pagesize}, async()=>{
                let groupUserList = await this.getGroupUserList(searchKey, 1, this.state.userRows);
                groupList[0] = groupUserList && groupUserList.length && groupUserList[0];
                this.setState({groupList: groupList});
            });
        }else if(id == -2){
            this.setState({groupRows: groupRows + pagesize}, async()=>{
                let groupSessionList = await this.getGroupSessionList(searchKey, 1, this.state.groupRows, false);
                groupList[groupList.length-1] = groupSessionList && groupSessionList.length && groupSessionList[0];
                this.setState({groupList: groupList});
            });
        }
    }

    // 当选中选项后，判断是否已有这个选项，如果已有选项，设置开关，不进行searchchoose，没有选项是才进行searchchoose
    optionClick = (data)=>{
        if(!this.input) this.input = document.querySelector('.ant-select-search__field')
        this.props.currList.forEach((item)=>{
            if(item.id === data.id){
                // 之所以让输入框失焦然后在聚焦，是为了清除输入框中的内容，
                // 当鼠标点击选项的时候不存在这个问题，但是在键盘enter选择的时候会发生内容不自动清除的问题
                this.input && this.input.blur();
                this.time && clearTimeout(this.time)
                this.time = setTimeout(() => {
                    this.input && this.input.focus();
                }, 10);
                return this.cancelSelect = true
            } 
        })
    }

    // 选中项禁止再选择
    disableOption = (data)=>{
        for (let i = 0; i <  this.props.currList.length; i++) {
            if(this.props.currList[i].id === data.id) return true 
        }
        return false
    }

    render() {
        const props = {
            ...this.props,
            loadMore: this.loadMore,
            getGroup: this.getGroup,
            getSingle: this.getSingle,
            searchInput: this.searchInput,
            searchChoose: this.searchChoose,
            selectOnBlur: this.selectOnBlur,
            optionClick: this.optionClick,
            disableOption: this.disableOption,
            groupList:this.state.groupList,
            userSearchList: this.state.userSearchList,
            hindSelectItem: this.state.hindSelectItem,
        }
        return <UserSelect {...props} />;
    }
}

export default UserSelectContainer;
