import React from 'react';

import UserAddLevel from './user-add-level';

import { ucenterUserLevel } from '@s/ucenter/ucenter-user.js';

class UserAddLevelContainer extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            level: [],
            list: []
        }
    }
    componentDidMount(){
        this.getLevelList()
    }
    getLevelList = async () => {
        let data = await ucenterUserLevel()
        if (data && data.code == 200) {
            let list = []

            data.obj.forEach(v => {
                if (v.id >= 3 && v.id <=5) {
                    v.list.forEach(v => {
                        v.id = v.level + '-level-'
                        v.name = v.level
                    })
                    list.push({
                        id: v.id,
                        group: v.group,
                        hasSub: true,
                        showSub: false,
                        list: v.list
                    })
                }
                if (v.id == 6) {
                    v.list.forEach(v => {
                        v.id = v.level + '-level-'
                        v.name = this.locale('common_accepter10').replace('[xxx]', v.level)
                    })
                    list.push({
                        id: v.id,
                        group: v.group,
                        hasSub: false,
                        list: v.list
                    })
                }
            })
            this.setState({ list })
        }
    }
    openGroup = group => {
        let newList = [...this.state.list]
        let curr = newList.find(v => v.group == group.group)
        if (!curr) return false
        curr.showSub = !curr.showSub
        this.setState({
            list: newList
        })
    }
    change = (item, e) => {
        let newCurrList = [...this.props.currList];
        let ids = newCurrList.map(v => v.id);

        if (ids.includes(item.id) && !e.target.checked) {
            newCurrList = newCurrList.filter(v => v.id != item.id);
        }
        if (!ids.includes(item.id) && e.target.checked) {
            newCurrList.push(item);
        }
        this.props.currListSet(newCurrList);
    }
    checkGroup = (group, e) => {
        let newCurrList = [...this.props.currList];
        let ids = newCurrList.map(v => v.id);

        if (e.target.checked) {
            group.list.forEach(v => {
                if (!ids.includes(v.id))
                newCurrList.push(v)
            })
        } else {
            let groupids = group.list.map(v => v.id)
            newCurrList = newCurrList.filter(v => !groupids.includes(v.id))
        }

        this.props.currListSet(newCurrList);
    }
    isCheckedGroup = group => {
        let newCurrList = this.props.currList;
        let ids = newCurrList.map(v => v.id);

        return group.list.every(v => ids.includes(v.id))
    }
    checkAll = e => {
        let newCurrList = [...this.props.currList];
        let ids = newCurrList.map(v => v.id);
        let listAll = []
        this.state.list.forEach(v => {
            listAll = [...listAll, ...v.list]
        })

        if (e.target.checked) {
            listAll.forEach(v => {
                if (!ids.includes(v.id))
                newCurrList.push(v)
            })
        } else {
            let groupids = listAll.map(v => v.id)
            newCurrList = newCurrList.filter(v => !groupids.includes(v.id))
        }

        this.props.currListSet(newCurrList);
    }
    isCheckedAll = () => {
        let newCurrList = this.props.currList;
        let ids = newCurrList.map(v => v.id);
        let listAll = []
        this.state.list.forEach(v => {
            listAll = [...listAll, ...v.list]
        })

        return listAll.every(v => ids.includes(v.id))
    }
    render() {
        const props = {
            list: this.state.list,
            currList: this.props.currList,
            change: this.change,
            openGroup: this.openGroup,
            checkGroup: this.checkGroup,
            isCheckedGroup: this.isCheckedGroup,
            checkAll: this.checkAll,
            isCheckedAll: this.isCheckedAll
        };
        return <UserAddLevel {...props} />;
    }
}

export default UserAddLevelContainer;
