import React from 'react';

import css from './index.scss';

import { Checkbox, Row } from 'antd';

import * as util from '@u/util.js';

export default props => (
    <div className={css.box}>
        <div className={css.all}>
            <Row>
                <Checkbox checked={props.isCheckedAll()} onChange={props.checkAll}>
                    <span>{util.locale('common_select_all')}</span>
                </Checkbox>
            </Row>
        </div>
        <div className={css.list}>
            {props.list.map(v => (
                <div className={css.group} key={v.id}>
                    <Row>
                        <Checkbox checked={props.isCheckedGroup(v)} onChange={props.checkGroup.bind(null, v)}>
                            <span>{v.group}</span>
                        </Checkbox>
                        {!!v.hasSub && (
                            <span className={css.fold} onClick={props.openGroup.bind(null, v)}>
                                {v.showSub ? util.locale('common_fold') : util.locale('common_unfold')}
                            </span>
                        )}
                    </Row>
                    <Checkbox.Group
                        className={css.items + ' ' + (v.showSub ? '' : css.hide)}
                        value={props.currList.map(v => v.id)}
                    >
                        {v.list.map(v => (
                            <Row key={v.id}>
                                <Checkbox value={v.id} onChange={props.change.bind(null, v)}>
                                    <span>{v.level}</span>
                                </Checkbox>
                            </Row>
                        ))}
                    </Checkbox.Group>
                </div>
            ))}
        </div>
    </div>
);
