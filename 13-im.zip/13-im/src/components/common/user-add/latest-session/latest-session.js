import React from 'react';
import css from './index.scss';
import UserAddList from '../user-add-list/user-add-list-container';
import * as util from '@u/util.js';

export default props => {
    return(
        <div className={css.boxsessionlist}>
            <div className={css.title} onClick={()=>props.openAll('orgAll')}>
                <span className="iconfont iconzhankai"></span>
                <span>{util.locale('common_topic2')}</span>
            </div>
            <div className={css.sessionlist} style={{padding: 0}}>
                <UserAddList {...props} list={props.usersList} title=''/>
            </div>
        </div>
    );
};
