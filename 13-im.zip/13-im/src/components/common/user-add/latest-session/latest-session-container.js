import React from 'react';

import * as util from "@/utils/util";

import LatestSession from './latest-session';



class LatestSessionContainer extends React.Component {
    constructor(props){
        super(props)
    };
    
    render() {
        const LatestSessionProps = {
            ...this.props
        };
        return <LatestSession {...LatestSessionProps} />;
    }
}

export default LatestSessionContainer;
