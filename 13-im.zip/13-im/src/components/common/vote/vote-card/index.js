import React, { Component } from 'react';
import {connect} from 'react-redux';
import css from './index.scss';
import { Radio,Checkbox, message } from 'antd';
import {voteChoiceAdd} from "@/services/vote";
import {updateVoteStoreData} from '../common';
import * as util from '@u/util.js';
import { showSlideModal} from "@/redux/actions/commonModal";

import {NUM,getVoteDataLsCache} from '../common';



class Index extends Component {
    state={
        option:[],
        localShowResult:0,//0/1/2,为投票/已投票/已过期
    }
    shouldComponentUpdate(nextProps, nextState) {
        return (
            !_.isEqual(nextState.localShowResult, this.state.localShowResult) ||
            !_.isEqual(nextState.option, this.state.option) ||
            !_.isEqual(nextProps.idClient, this.props.idClient) ||
            !_.isEqual(nextProps.customData, this.props.customData) ||
            !_.isEqual(nextProps.children.props, this.props.children.props) ||
            !_.isEqual(nextProps.messageVoteData, this.props.messageVoteData)
        );
    }

    componentDidMount(){
        const {customData:{vid},sessionId}=this.props;
        const localShowResult=getVoteDataLsCache(sessionId,vid);
        if (localShowResult){
            this.setState({
                localShowResult
            })
        }
    }
    

    handleRadioChange=(value)=>{
        this.setState({
            option:value
        })
    }

    genOption=(arr=[],type)=>{
        let el=null;
        if(!type){
            el=(
                <Radio.Group className={css.middle} onChange={(e)=>this.handleRadioChange(e.target.value)} value={this.state.option}>
                    {
                        arr.map((item,index)=><Radio key={item.op_id} className={css.item} value={item.op_id}><em>{NUM[index]}</em>{item.content}</Radio>)
                    }
                </Radio.Group>
            )
        }else{
            el=(
                <Checkbox.Group className={css.middle} onChange={this.handleRadioChange} value={this.state.option}>
                    {
                        arr.map((item,index)=><Checkbox key={item.op_id} className={css.item} value={item.op_id}><em>{NUM[index]}</em>{item.content}</Checkbox>)
                    }
                </Checkbox.Group>
            )
        }
        return el;
    }

    genResultOption=(arr)=>{
        const el=arr.map((item,index)=>{
            const {op_id,content,votes_num=0,votes_rate=0,vote_flag}=item;
            const rate=(votes_rate*100).toFixed(1)+'%';
            return (
                <div className={css.item} key={op_id}>
                    <div className={css.contentTop}>
                        <em>{NUM[index]}</em> 
                        <div>
                            {vote_flag?<span>{this.locale('im_vote_voted')}</span>:null}{content}
                        </div>
                    </div>
                    <div className={css.contentMiddle}>
                        <span>{votes_num} {this.locale('im_vote_vote_ss')}</span>{rate}
                    </div>
                    <div className={css.progress}>
                        <div style={{width:rate}}></div>
                    </div>
                </div>
            )
        })

        return <div className={css.middleResult}>{el}</div>
    }

    handleSubmit=async ()=>{
        const {option}=this.state;
        const {sessionId,customData,idClient}=this.props;
        try{
            const s= await voteChoiceAdd({
                vid:customData.vid,
                sessionId,
                opId:typeof(option)==='string'?option:option.join(','),
                msgId:idClient
            });
            if(s&&s.code==200){
                // 投票成功，调用updateVoteStoreData更新数据
                util.yach.updateVoteStoreData ([s.obj]);
            }else{
                message.error(s.msg);
                util.log('vote','voteChoiceAdd: error',`vid:${customData.vid},sessionId:${sessionId},msg:${s.msg}`.slice(0,100));
            }
        }catch(e){
            util.log('vote','voteChoiceAdd: error',`vid:${customData.vid},sessionId:${sessionId},${e.toString()}`.slice(0,100));
        }
    }

    handleGoInfo=(value)=>{
        const {sessionId}=this.props;
        const ids=JSON.stringify([value]);
        this.props.dispatch(showSlideModal('VoteDetails', { ids, sessionId }));
    }
   
    render() {
        const {option,localShowResult}=this.state;
        const { children,messageVoteData,idClient, customData:{
            vid,
            title,
            voteOption,
            isMultiple,
        } } = this.props;

        const {showResult,option_list,end_flag}=messageVoteData[vid]||{};
        const show=showResult===undefined?localShowResult:showResult;

        return (
            <div key={vid} className={`${css.out} ${children ? css.hasEmoji : ''}`}>
                <div className={css.content}>
                    <div className={css.top} style={show==2?{background:'linear-gradient(270deg,rgba(183,191,208,1) 0%,rgba(162,176,200,1) 100%)'}:null}>
                        <p>{end_flag?this.locale('im_vote_end'):this.locale('im_vote')}</p>
                        <div>
                            <span>[{isMultiple?this.locale('im_vote_multiple_choice'):this.locale('im_vote_single_choice')}]</span>{title}
                        </div>
                    </div>
                    {
                        show?this.genResultOption(option_list||voteOption):this.genOption(voteOption,isMultiple)
                    }
                    {
                        show?(
                            <div className={`${css.disabled} ${css.btn}`} onClick={()=>this.handleGoInfo({vid,msg_id:idClient})}>{this.locale('im_vote_view_info')}</div>
                        ):option.length>0?(
                            <div className={`${css.disabled} ${css.btn}`} onClick={this.handleSubmit}>{this.locale('im_vote')}</div>
                        ):(
                            <div className={css.disabled}>{this.locale('im_vote_choise_vote')}</div>
                        )
                    }
                    {children && <div className={css.emoji}>{children}</div>}
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        messageVoteData:state.messageVoteData
    };
};

export default connect(
    mapStateToProps,
    null
)(Index);

