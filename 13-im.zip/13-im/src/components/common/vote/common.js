import * as util from '@u/util.js';

export const NUM=['A','B','C','D','E','F','G','H','I','J'];

// 0/1=>true/false
export const getVoteDataLsCache=(sessionId,vid)=>{
    const lsObj = util.yachLocalStorage.ls('voteStatus');
    return lsObj&&lsObj[sessionId]&&lsObj[sessionId][vid]; 
}


