// react
import React from 'react';
import {connect} from 'react-redux';
import Index from '.';
import * as util from '@/utils/util';
import {voteCreate} from "@/services/vote/index";
import { message } from 'antd';
import _ from 'lodash';



// BoxSquadSettingContainer
class IndexContainer extends React.Component {
    constructor(props){
        super(props)
        this.state={
            modalVisible:false,
            title:'',
            multiple:false,
            end_time:util.moment().add(1,'d'),
            optionList:['',''],
        }

        this.titleInput = React.createRef();
        this.handleSubmit = _.throttle(this.handleSubmit, 1000,{
            leading: true,
            trailing: false
          })
    }

    componentDidMount(){
        const title=this.titleInput.current;
        setTimeout(()=>{
            title && title.focus();
        },300)
    }
    componentDidUpdate(prevProps,preState){
        if(preState.optionList.length!==this.state.optionList.length){
            const inputs=document.querySelectorAll('#optionOut input');
            const input=inputs[inputs.length-1];
            input && input.focus();
        }
    }

    handleSubmit= async ()=>{
        const sessionId=this.props.id;
        const {
            title='',
            optionList,
            multiple,
            end_time
        }=this.state;
        const trimOptionList=optionList.map(item=>item.trim());
        if(!title.trim().length){
            message.warn(this.locale('im_vote_submit_blank_toast'));
            return;
        }else if(new Set(trimOptionList).size<trimOptionList.length){
            message.warn(this.locale('im_vote_submit_same_toast'));
            return;
        }

        const params={
            title,
            optionContent:JSON.stringify(trimOptionList),
            sessionId,
            entTime:end_time.format('X'),
            isMultiple:+ multiple
        }
        try{
            const s= await voteCreate(params);
            if(s&&s.code==200){
                this.props.hiddenModal();
            }else{
                message.error(s.msg);
                util.log('vote','voteCreate: error',`title:${title},sessionId:${sessionId},msg:${s.msg}`.slice(0,100));
            }
        }catch(e){
            util.log('vote','voteCreate: error',`title:${title},sessionId:${sessionId},${e.toString()}`.slice(0,100));
        }
        

        // util.sensorsData.track('Click_Schedule_Element', {
        //     pageName: '01-132',
        //     $element_name: '01-211'
        // });
    }

    handleTitleChange = (e) => {
        this.setState({
            title:e.target.value
        })
    }

    handleMultipleChange=(value)=>{
        this.setState({
            multiple:value
        })
    }

    // 截止时间
    handleTimeChange=(value)=>{
        if(+value< + util.moment()) return message.warn(this.locale('im_vote_endTime_toast'));
        this.setState({
            end_time:value
        })
    }

    handleAddOption=()=>{
        this.setState(pre=>{
            const arr=pre.optionList;
            return {
                optionList:[...arr,'']
            }
        })
    }

    handleOptionInputChange=(index,value)=>{
        this.setState(pre=>{
            const arr=pre.optionList;
            arr[index]=value;
            return{
                optionList:arr
            }
        })
    }

    handleDeleteOption=(index)=>{
        this.setState(pre=>{
            const arr=pre.optionList;
            return {
                optionList:arr.filter((t,i)=>i!==index)
            }
        })
    }

    maskClick = (e)=>{
        e.stopPropagation();
        const {
            title,
            multiple,
            optionList,
        } = this.state;
        const arr=optionList.filter(item=>!!item);
        
        if(title || arr.length||multiple){
            this.setState({ modalVisible: true });
        } else {
            this.props.hiddenModal()
        }
    }

    ok=()=>{
        this.setState({
            modalVisible:false
        })
        this.props.hiddenModal()
    }

    cancel=()=>{
        this.setState({
            modalVisible:false
        })
    }

    render() {
        const {modalVisible,title,multiple,end_time,optionList}=this.state;
        const props = {
            locale:this.locale,
            title,
            modalVisible,
            multiple,
            end_time,
            optionList,
            titleInput:this.titleInput,
            maskClick:this.maskClick,
            ok:this.ok,
            cancel:this.cancel,
            handleTitleChange:this.handleTitleChange,
            handleMultipleChange:this.handleMultipleChange,
            handleSubmit:this.handleSubmit,
            handleTimeChange:this.handleTimeChange,
            handleAddOption:this.handleAddOption,
            handleDeleteOption:this.handleDeleteOption,
            handleOptionInputChange:this.handleOptionInputChange
        };
        return <Index {...props} />;
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
    };
};

export default connect(
    mapStateToProps,
    null
)(IndexContainer);
