// react
import React from 'react';

// css
import css from './index.scss';

import {Button,Input,Switch, DatePicker,Tooltip} from 'antd';
import CommonModal from '@c/common/common-modal';
import {NUM} from '../common';

const { TextArea } = Input;


// BoxOperation
export default function  Index(props) {
    const {
        locale,
        title,
        modalVisible,
        end_time,
        optionList,
        multiple,
        titleInput,
        ok,
        cancel,
        maskClick,
        handleTitleChange,
        handleMultipleChange,
        handleSubmit,
        handleTimeChange,
        handleAddOption,
        handleDeleteOption,
        handleOptionInputChange
    } = props;

    const submitBtn= title.length && !optionList.filter(item=>!item.trim().length).length;
    return (
        <>
            <div className={css.box}>
                <div className={css.mask} onClick={maskClick}></div>
                <div className={css.content}>
                    <div className={css.title}>
                        <TextArea
                            ref={titleInput}
                            maxLength={100}
                            onChange={e => handleTitleChange(e)}
                            value={title}
                            className={css.textContent}
                            autoSize = {{minRows: 5}}
                            placeholder={locale('im_vote_title_placeholder')}
                        />
                        <div>{title.length}/100</div>
                    </div>
                    <div className={css.option} id='optionOut'>
                        {
                            optionList.map((item,index)=>{
                                let dBtn=<Tooltip title={locale('im_vote_delOption_toast')}><span className='iconfont-yach yach-pctoupiaozujian-faqitoupiao-shanchuxuanxiang'/></Tooltip>;
                                if(optionList.length>2) dBtn=<span onClick={()=>{handleDeleteOption(index)}} className={`${css.active} iconfont-yach yach-pctoupiaozujian-faqitoupiao-shanchuxuanxiang`} />;

                                return (
                                    <div className={css.item}>
                                        {dBtn}
                                        <div>
                                            <em>{NUM[index]}</em>
                                            <input placeholder={locale('im_vote_create_option_placehoder')} value={item} onChange={(e)=>{handleOptionInputChange(index,e.target.value)}} maxLength={100} type='text' />
                                        </div>
                                    </div>
                                )
                            })
                        }
                        {
                            optionList.length<10?(
                                <div className={css.add} onClick={handleAddOption}>
                                    <span className='iconfont-yach yach-pctoupiaozujian-faqitoupiao-tianjiaxuanxiang'></span>
                                    <div>{locale('im_vote_create_add_option')}</div>
                                </div>
                            ):(
                                <Tooltip title={locale('im_vote_addOption_toast')}>
                                    <div className={`${css.add} ${css.disabled}`}>
                                        <span className='iconfont-yach yach-pctoupiaozujian-faqitoupiao-tianjiaxuanxiang'></span>
                                        <div>{locale('im_vote_create_add_option')}</div>
                                    </div>
                                </Tooltip>
                            )
                        }
                    </div>
                    <div className={css.bottom}>
                        <div>
                            <p>{locale('im_vote_create_allow_options')}</p>
                            <Switch checked={multiple} onChange={handleMultipleChange}/>
                        </div>
                        <div>
                            <p>{locale('im_vote_create_deadline')}</p>
                            <div className={css.out} id='datePickerOut'>
                                <DatePicker
                                    showTime={{ format: 'HH:mm' }}
                                    format="YYYY-MM-DD HH:mm"
                                    value={end_time}
                                    style={{width:150,minWidth:150}}
                                    onChange={handleTimeChange}
                                    suffixIcon={<span className={`${css.pickerIcon} iconfont-yach yach-quanju-qunshezhi-youcedianji`}/>}
                                    allowClear={false}
                                    dropdownClassName={css.dataPicker}
                                    showToday={false}
                                    getCalendarContainer={()=>document.getElementById('datePickerOut')}
                                />
                            </div>
                        </div>
                    </div>
                    <div className={css.btn}>
                        <Button
                            type="primary"
                            ghost
                            className={`${submitBtn ? css.edit_btn : css.disable_btn} ${css.edit_btn}`}
                            onClick={submitBtn?handleSubmit:()=>{}}
                        >
                            {locale('im_vote_save_btn')}
                        </Button>
                    </div>
                </div>
            </div>
            <CommonModal
                modalTile={locale('im_vote_close_edit_toast')}
                modalVisible={modalVisible}
                setOKModal={ok}
                setonCancelModal={cancel}
                // modalContent={locale('im_editTip_exit')}
            />
        </>
    )
}
