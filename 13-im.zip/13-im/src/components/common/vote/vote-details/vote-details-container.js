// react
import React from 'react';
import {connect} from 'react-redux';

// component
import VoteDetails from './vote-details';

import {voteChoiceDetail, optionUserList} from "@/services/vote/index";

import { message } from 'antd';

import * as util from '@/utils/util';

// BoxSquadSettingContainer
class VoteDetailsContainer extends React.Component {

    state = {
        optionsList: [],
        showIndex: -1,
        peopleList: [],
        detailInfo: {},
        page: 1,
        size: 50,
        votesItem: {},
        showMoreTag: false,
    }

    componentDidMount() {
        this.getData();
    }

    /**
     * api获取投票详情
     */
    getData = async() => {
        util.log('zhangyongchang','voteDetails: getData');
        const {ids, sessionId}=this.props;

        const data = await voteChoiceDetail({ids,sessionId});
        const {obj=[], code, msg} = data || {};
        util.log('zhangyongchang','voteDetails: getData:api', code);
        if(!data || code != 200 || !obj) return message.error(msg);
        const {detail_info, option_list} = obj[0] || {};

        this.setState({
            optionsList: option_list || [],
            detailInfo: detail_info || {},
        })
    }

    /**
     * 选项点击
     */
    itemClick = (item, showIndex) => {
        util.log('zhangyongchang','voteDetails: itemClick', showIndex);
        if(showIndex == this.state.showIndex) showIndex = -1;
        if(item.votes_num == 0) return this.setState({showIndex: -1});

        this.setState({showIndex, peopleList: [], votesItem: item}, ()=>{
            this.getpeopleList(1, 50);
        });
    }

    /**
     * api 获取投票人员
     * @param {*} page 
     * @param {*} size 
     */
    getpeopleList = async(page, size) => {
        const {op_id, vid} = this.state.votesItem;
        const {sessionId}=this.props;
        let params = {
            page,
            size,
            vid,
            opId: op_id,
            sessionId
        }

        util.log('zhangyongchang','voteDetails: getpeopleList', `page:${page}, size:${size}, vid:${vid}, opId:${op_id}, sessionId:${sessionId}`);

        const data = await optionUserList(params);
        const {obj, code, msg} = data || {};
        util.log('zhangyongchang','voteDetails: getpeopleList: api', `code:${code}`);
        if(!data || code != 200 || !obj) return message.error(msg);
        const {voters_list = []} = obj || {};
        const allPeopleList = [...this.state.peopleList, ...voters_list];

        this.showMoreTag(allPeopleList);

        this.setState({
            peopleList: [...this.state.peopleList, ...voters_list],
            page
        });
    }

    /**
     * 【加载更多】是否显示
     * @param {*} list 
     */
    showMoreTag = (list) => {
        const {votesItem} = this.state;
        util.log('zhangyongchang','voteDetails: showMoreTag', `votesNum:${votesItem.votes_num}, showList:${list.length}`);
        if(votesItem.votes_num > list.length) return this.setState({showMoreTag: true});

        this.setState({showMoreTag: false})
    }

    /**
     * 显示个人信息页
     * @param {*} e 
     * @param {*} value 
     */
    showUserinfo = (e, value) => {
        e.stopPropagation();
        util.log('zhangyongchang','voteDetails: showUserinfo', `userId:${value}`);
        util.yach.showUserinfo(value);
    }

    /**
     * 加载更多人员
     * @param {*} e 
     */
    showMore = (e) => {
        e.stopPropagation();
        util.log('zhangyongchang','voteDetails: showMore', `showMore:${this.state.page + 1}`);
        this.getpeopleList(this.state.page + 1, 50);
    }

    render() {
        const {
            optionsList, 
            showIndex, 
            peopleList, 
            detailInfo,
            showMoreTag,
        } = this.state;

        const {
            itemClick, 
            showMore, 
            showUserinfo,
        } = this;

        const props = {
            optionsList,
            showIndex,
            peopleList,
            detailInfo,
            showMoreTag,
            itemClick,
            showMore,
            showUserinfo,
        }
        return <VoteDetails {...props}/>;
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
    };
};

export default connect(
    mapStateToProps,
    null
)(VoteDetailsContainer);
