// react
import React from 'react';

// css
import css from './index.scss';

import { Progress } from 'antd';

// BoxOperation
export default class VoteDetails extends React.Component {

    render(){
        const {
            optionsList,
            showIndex,
            peopleList,
            itemClick,
            showUserinfo,
            showMore,
            detailInfo,
            showMoreTag,
        } = this.props;
    
        const {
            title,
            voters_num = 0,
            is_multiple
        } = detailInfo;

        const localLang = this.locale.getLang();

        const selectTag = localLang == 'zh-CN' ? require('@a/imgs/vote/vote-selected.png') :require('@a/imgs/vote/vote-selected-en.png');

        return (
            <div className={css.box}>
                <div className={css.header}>
                    <p>[{is_multiple == 1 ? this.locale('im_vote_multiple_choice') : this.locale('im_vote_single_choice')}] {title}</p>
                    <span>{localLang == 'zh-CN' ? `共${voters_num}人参与投票` : `${voters_num} votes`}</span>
                </div>
                <div className={css.content}>
                    {
                        optionsList.map((item, index) =>
                            <div className={css.item} key={item.id} onClick={()=>itemClick(item, index)}>
                                <div className={`${css.itemContent} ${item.votes_num?css.itemContentCursor:''}`}>
                                        <div className={css.optionsHeader}>
                                            <span>{item.map_name}</span>
                                            <div className={css.options}>
                                                {item.vote_flag == 1 && <img className={`${localLang == 'zh-CN' ? css.imgZh : css.imgEn}`} src={selectTag}/>}
                                                <span className={css.optionsTitle}>{item.content}</span>
                                            </div>
                                            {index != showIndex?
                                                <span className={`iconfont-yach yach-pctoupiao-zhankai ${css.optionsFont} ${item.votes_num ? '' : css.noOptionsFont}`}></span> 
                                                : <span className={`iconfont-yach yach-pctoupiao-shouqi ${css.optionsFont}`}></span> 
                                            }
                                        </div>
                                        <p className={css.votes}>{item.votes_num} {this.locale('im_vote_vote_s')}{localLang == 'zh-CN' ? '占比' : ''}{(item.votes_rate*100).toFixed(1)}%</p>
                                        <div>
                                            <Progress 
                                                percent={item.votes_rate * 100}
                                                strokeWidth={4}
                                                strokeColor='#447CF2'
                                                trailColor='#F0F3FA'
                                                showInfo={false} 
                                            />
                                        </div>
                                </div>
                                {(index == showIndex && peopleList.length>0) &&
                                    <div className={css.peopleList}>
                                        <div className={css.inner}>
                                            {peopleList.map(i =>  
                                                <div key={i.id}>
                                                    <img
                                                        src={i.pic}
                                                        onClick={e => showUserinfo(e, i.id)}
                                                    />
                                                    <span>{i.name}</span>
                                                </div>
                                            )}
                                        </div>
                                            {showMoreTag && <p className={css.showMore} onClick={e => showMore(e)}>{this.locale('im_view_more')}</p>}
                                    </div>
                               }
                                <p className={css.itemLine}></p>
                            </div>
                        )
                    }
                </div>
            </div>
        )
    }
}
