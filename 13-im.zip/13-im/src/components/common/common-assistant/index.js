/*
 * @Descripttion: 
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';

import { debounce } from 'lodash';

import Content from './components/content';
import ImageMedia from './components/imageMedia';
import MarkdownMsg from './components/markdownMsg';
import Status from './components/status';
import Title from './components/rightTitle';

import { assiatantTemplateSyncList } from './assistantync';
import { setWeekAssitantListR,setWeekAssitantPush,setWeekAssitantLast} from '@/redux/actions/assistant';

import * as util from "@/utils/util";
import { resolveOldRecordDataUrl } from './util';

import { IoWatcher } from './ioWatcher';

import css from './index.scss';
export class CommonIndex extends Component {

    constructor(props){
        super(props);  
        this.WrappedPageRef = React.createRef();
        this.state ={
            data:{},
        }
    }

    async componentDidMount(){
        await this.getData();
        this.wheelFn = debounce(this.wheelFn, 500);
        try{
            if(this.WrappedPageRef.current) this.WrappedPageRef.current.scrollTop = this.WrappedPageRef.current.scrollHeight;
            // 行高 = 40
            if(this.WrappedPageRef.current.scrollTop >40) this.intiateScrollObserver();
            document.getElementById('weekly_assient').addEventListener('wheel', this.wheelFn, { passive: false });
        }catch(e){}

        this.initIoWatch();
    }

    componentWillUnmount(){
        window.store.dispatch(setWeekAssitantPush(false));
        window.store.dispatch(setWeekAssitantListR([]));
        window.store.dispatch(setWeekAssitantLast({}));
        this.setState = (state,callback)=>{
            return;
        };

        this.ioWatcher && this.ioWatcher.destroy();
    }

    componentDidUpdate(preProps,preState){
        if(preProps.weekly_assistant_push){
            if(this.WrappedPageRef.current.scrollTop){ 
                return 
            }
            this.WrappedPageRef.current.scrollTop = this.WrappedPageRef.current.scrollHeight;
        }
        setTimeout(() => {
            this.ioWatcher && this.ioWatcher.refreshPartNodeList();
        }, 0);
    }

    componentDidCatch(err,info){
        console.log('助手组件产生了错误',err,info);
    }

    initIoWatch = () => {
        // 防止增加卡片曝光导致卡顿，在出现卡顿情况在 localStorage 中植入该参数来关闭曝光检测及上报
        const disabledIoWatch = util.yachLocalStorage.ls('disabledIoWatch') || false;
        if (disabledIoWatch) return;
        const sessionActive = window.store.getState().sessionActive || {};
        const assistName = sessionActive.showname || '未知助手';
        setTimeout(() => {
            this.ioWatcher = new IoWatcher({
                exposedTime: 0,
                callback: node => {
                    const { messageId = '0', sendTime = '0' } = node.dataset;
                    util.sensorsData.track('Expo_Chat_Element', {
                        pageName: '01-143',
                        $element_name: '01-279',
                        messageId,
                        sendTime,
                        assistName,
                    });
                },
                container: document.getElementById('weekly_assient'),
                proportion: 1,
                repeat: true, 
            });
        }, 0);
    }

    getData = async() => {
        // const { id } = this.props.sessionActive;
        const id = window.session_active.id;
        await assiatantTemplateSyncList(id);
    }

    wheelFn = event =>{
        if(this.props.weekly_assistant_last.nodata){
            if (event.deltaY <= 0 && event.target.scrollTop <= 0) {
                event.preventDefault();
            } 
            else{
                // 取出之前store中的数据
                const {weekly_assistant_last} = this.props;
                let msg_id = weekly_assistant_last.msg_id || '',
                msg_time = weekly_assistant_last.msg_time || '';

                window.store.dispatch(setWeekAssitantLast({msg_time, msg_id, nodata: false}));
            }
        }
        return false;
    }

    intiateScrollObserver = () => {
        const options = {
          root: document.getElementById('weekly_assient'),
          rootMargin: '0px 0px 20px 0px',
          threshold: [0.6]
        };
        this.observer = new IntersectionObserver(this.callback, options);
        this.observer.observe(document.querySelector("#reference"));
    }

    callback = (entries, observer) => {
        entries.forEach((entry, index) => {
          if (entry.isIntersecting) {  
               this.updateState();
          }          
        });
    }
    
    updateState = async ( ) => {
        let _tmeh = this.WrappedPageRef.current.scrollHeight;
        this.observer.unobserve(document.querySelector("#reference"));

        if(!this.props.weekly_assistant_last.nodata) await this.getData();

        this.WrappedPageRef.current.scrollTop = +this.WrappedPageRef.current.scrollHeight - _tmeh;
        this.intiateScrollObserver();
    }  
   
    handleGoInfoDetailBody = (clickFn, clickUrl, payload) =>{
        if(window.getSelection().toString()) return
        if(clickFn === 'doc'){
            let token = btoa(util.yachLocalStorage.ls('yach_usertoken'));
            let url = encodeURIComponent(util.yach.decodeUnicode(util.yach.urlSearch(clickUrl, 'url') || ''))
            util.electronipc.electronAddWebview({
                url: `${util.config.shimoHost}document/index?url=${url}&token=${token}`,
                name: payload.docTitle || '',
                disableClose: true
            })
        }else{
            window.open(resolveOldRecordDataUrl(clickUrl));
        }
    }

    showUserInfo = (app)=>{
        console.log('wenai-app', app)
        // if(this.props.sessionActive.id == 3010) {
        if(window.session_active.id == 3010){
            if(app.appId) {
                util.yach.showUserinfo({
                    id: app.appId,
                    width:272,
                    height:302
                });
            }
        }
    }

    showImg = (data) => {
        try {
            if(util.electron.isElectron()) {
                this.setState({
                    data:{
                        success: true,
                        data: [{
                            name: data.fileName,
                            url: data.fileOriginUrl, 
                            id: '', 
                            curr: true
                        }],
                        id: ''
                    }  
                }, ()=>{
                    util.electronipc.electronOpenImage(this.state.data, undefined, ()=>{});
                }); 
            } 
        } catch (error) {
            console.log('预览文件出错', error);
        }
    };

    genClassName = (type, isImage = false) => {
        const { session_active = {} } = window;
        const sessionActiveId   = session_active.id;

        let className = '';
        switch (type) {
            case 'right':
                className = `${css.rightOut} ${!isImage && css.rightOutWidth } ${sessionActiveId != 3007 && css.cursorPointer}`
                break;
            case 'msg':
                className = `${css.template_block_img} ${sessionActiveId == 3007 && css.cardRadius_img}`;
                break;
        }
        return className;
    }

    render() {
        const {
            weekly_assistant_list,
            weekly_assistant_loading,
            weekly_assistant_last,
        } = this.props;
        const   datalist    = weekly_assistant_list;
        const   loading     = weekly_assistant_loading;
        const  { nodata }   = weekly_assistant_last;

        // const { showimg }   = this.props.sessionActive || {};
        // const sessionActiveId = this.props.sessionActive.id;
        const { session_active = {} } = window;
        const showimg           = session_active.showimg;
        const sessionActiveId   = session_active.id;
            
        return (
            <div
                id="weekly_assient"
                className={css.box + util.style.getWinStyle(css, 'boxWin')}
                ref={this.WrappedPageRef}
            >
                <Status loading={loading} nodata={nodata} />
                {
                    !!datalist.length && datalist.map(item => {
                        // 兼容防止后端没有严格拦截，导致前端组件奔溃
                        if(!item.msg_body) return;

                        const {
                            // id,
                            clickFn,
                            bgColor,
                            head,
                            title,
                            content,
                            image,
                            buttons=[],
                            // fincallba,
                            app={},
                            clickUrl,
                            payload,
                            imageMedia,
                            linkCard
                        } = item.msg_body;

                        return (
                            <div
                                key={item.id}
                                className={css.itemOut}
                            >
                                <img
                                    className={css.imgheader}
                                    src={app.icon || showimg}
                                    alt=""
                                    data-watch-item
                                    data-send-time={item.date_time}
                                    data-message-id={item.chatbot_mid}
                                    onClick={() => this.showUserInfo(app)}
                                />
                                <div
                                    className={this.genClassName('right', imageMedia)} 
                                    onClick={() => {this.handleGoInfoDetailBody(clickFn, clickUrl, payload)}}
                                >
                                    <Title name={app.name} time={item.created_at} />
                                    <div
                                        className={this.genClassName('msg')}
                                        style={{background: bgColor}}
                                    >
                                        {sessionActiveId != 3007 ?
                                            <>
                                                {imageMedia ?
                                                    <ImageMedia
                                                        imageMedia={imageMedia}
                                                        showImg={this.showImg}
                                                    /> : 
                                                    <MarkdownMsg
                                                        head={head}
                                                        title={title}
                                                        image={image}
                                                        content={content}
                                                        buttons={buttons}
                                                        linkCard={linkCard}
                                                    />
                                                }
                                            </> :
                                            content ? <Content className={css.template_block} property={content} /> : null
                                        }
                                    </div>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        // sessionActive: state.sessionActive,
        weekly_assistant_list:state.assistant.weekly_assistant_list,
        weekly_assistant_loading: state.assistant.weekly_assistant_loading,
        weekly_assistant_push: state.assistant.weekly_assistant_push,
        weekly_assistant_last:state.assistant.weekly_assistant_last  
    }
}

export default connect(mapStateToProps, null)(CommonIndex);