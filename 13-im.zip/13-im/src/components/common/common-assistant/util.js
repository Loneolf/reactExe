import * as util from "@/utils/util";

/**
 * 处理周报周报老数据，转新链接
 * @param {*} clickUrl 
 */
export const resolveOldRecordDataUrl = clickUrl => {
  if (!clickUrl) return;

  let url = decodeURIComponent(clickUrl)
  let urldata = new URL(url)

  let webviewurl = urldata.searchParams.get('url')
  if (!webviewurl) return clickUrl

  webviewurl=decodeURIComponent(webviewurl);

  if (webviewurl.includes('/report/reportDetail')) {
    let webviewurldata = new URL(webviewurl)

    let id = webviewurldata.pathname.split('/').pop()

    let resweburl = encodeURIComponent(`${util.config.museDingUrl}weekly?wid=${id}`)

    return `yach://yach.zhiyinlou.com/session/webview?url=${resweburl}&pc_slide=true`
  }

  return clickUrl
}