import React from 'react';
import { Spin} from 'antd';

import * as util from "@/utils/util";

import css from '../index.scss';

const Status = ({
  loading,
  nodata
}) => {
  return (
    <>
      <div 
        id="reference"
        className={css.itemOut}
        style={!loading ? {"display": "block"} : {"display" : "none"}}
      />
      { loading && <div className={css.loadings}><Spin/></div>}
      { nodata  && <div className={css.nodata}>{util.locale('common_msg15')}</div>}
    </>
  )
}

export default Status;
