import path from 'path';
import React,{useEffect} from 'react';
import marked from '@c/common/markdown/marked';
import css from './common.scss';
import * as util from '@u/util.js';

export default function Content(props) {
    const {property={}}=props;
    let {contentType, content, contentPc}=property;

    useEffect(()=>{
        if(property.lineClamp){
            const arr=document.querySelectorAll('#assistant_content_out p');
            for(let i=0;i<arr.length;i++){
                arr[i].style['-webkit-line-clamp']=property.lineClamp;
            }
        }
    },[])

    const previewMarkdownImg = (url)=> {
        return new Promise((resolve, reject)=> {
            const name = path.basename(url)
            try{
                if (util.electron.isElectron()) {
                    util.electronipc.electronOpenImage({
                        success:true,
                        data:[{
                            name,
                            url,
                            curr:true
                        }]
                    }, undefined, (id) => {
                        resolve(true)
                    });
                }
            }catch(error){
                reject(error)
            }
        })
    }

    const onClickContent = e => {
        //处理markdown图片
        const target = e && e.target
        const nodeName = target && e.target.nodeName;
        if(nodeName == 'IMG' && target.src){
            e.stopPropagation();
            previewMarkdownImg(target.src)
        }

        if(nodeName == 'A' && target.href) {
            e.stopPropagation();
        }
    }
    

    const style={
        background : property.bgColor,
        color : property.textColor,
    }

    // escapeHtml={true}
    if(contentType===1){
       return (<div style={style} 
            className={`${css.contentOut} ${css.mkdown}`} 
            id='assistant_content_out'
            dangerouslySetInnerHTML={{__html: marked(contentPc || content)}}
            onClick={(e)=>{onClickContent(e)}}>
        </div>)

    }else if(contentType===2){
        return (<div id='assistant_content_out' className={css.contentOut} style={style} dangerouslySetInnerHTML = {{__html:contentPc || content}} />)
    }

}