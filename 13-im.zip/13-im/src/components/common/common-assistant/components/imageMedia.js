import React from 'react';

import css from '../index.scss';

function getImgScale (height, width) {  
  if (!width || !height) return;
  let WHFlag = width > height ? true : false,
      COMMON_SCALE_WH = 0.18, // (9 / 50)
      scaleWH = width / height,
      scaleHW = height / width,
      isSmallFlag = width <= 10 && height <= 10,
      imgSize = {};
      imgSize.typeNum = 0
  //宽高比例 几中情况: (高大于宽)
  // 1, scaleWH 介于 1:1 - 9:50 之间  
  if (!isSmallFlag && !WHFlag && (1 >= scaleWH >= COMMON_SCALE_WH) && width > 10) {
    // （height <= 200，是判断图片原始尺寸是否大于索要设置的 max-height= 2000）
    if (height <= 200) {    
      imgSize.width = width;
      imgSize.height = height;
    } else {
      imgSize.width = parseInt(width * 200.0 / height);
      imgSize.height = 200;
    }
  }  

  // 2，scaleWH 超过 9:50 (高度如果不大于 200px，max-height: 200px;width: 60px;)
  if(!isSmallFlag && !WHFlag && scaleWH < COMMON_SCALE_WH && height <= 200 || (width <= 10 && height > 10)) {
    imgSize.width = 60
    imgSize.height = parseInt(60.0 * height / width)
    imgSize.typeNum = 1
  }
  // 3，scaleWH 超过 9:50 (高度如果大于 200px,则从上截取200px,width: 60px;)
  if(!isSmallFlag && !WHFlag && scaleWH < COMMON_SCALE_WH && height > 200) {
    imgSize.width = 60;
    imgSize.height = parseInt(60.0 * height / width);
    imgSize.typeNum = 1
  }

  //高宽比例 几中情况: (高小于宽)   10 * 6
  // 5, scaleHW 介于 1:1 - 9:50 之间
  if (!isSmallFlag && WHFlag && (1 >= scaleHW >= COMMON_SCALE_WH) && height > 10) {
    if (width <= 324) {
      imgSize.width = width;
      imgSize.height = height;
    } else {
      imgSize.width = 324;
      imgSize.height = parseInt(height * 324.0 / width);
    }
  } 
  // 6，scaleHW 超过 9:50  （max-width: 324px, height: 60px;）
  if(!isSmallFlag && WHFlag && scaleHW < COMMON_SCALE_WH && width <= 324 || (height <= 10 && width > 10)) {
    imgSize.height = 60;
    imgSize.width = parseInt(width * 60.0 / height)
    if (imgSize.width >= 324) imgSize.typeNum = 2
  }
  // 7，scaleHW 超过 9:50  （max-width: 324px,中间截取 (width:324,height:60)）
  if(!isSmallFlag && WHFlag && scaleHW < COMMON_SCALE_WH && width > 324) {
    imgSize.height = 60;
    imgSize.width = parseInt(width * 60.0 / height)
    if (imgSize.width >= 324) imgSize.typeNum = 2
  }

  if (isSmallFlag) {
    imgSize.width = 60;
    imgSize.height = 60;
  }
  return imgSize;
}

const ImageMedia = ({
  imageMedia,
  showImg,
}) => {
  const {
    fileThumbnailUrl,
    fileOriginUrl,
    height: _height,
    width: _width,
  } = imageMedia;

  const imgSize = getImgScale(_height, _width);
  const { height, width, typeNum } = imgSize;

  const imgStyle = {
    width: `${width}px`,
    height: `${height <= 60 ? 60 : height}px`,
    position: 'relative',
    top: `0px`,
    left: `-${(width - 324) / 2}px`,
    borderRadius: '10px'
  };
  const normalImgStyle = {
    width: `${width}px` || 200,
    height: `${height}px` || '100%',
    borderRadius: '10px'
  }

  let a_box;
  switch (typeNum) {
    case 1:
      a_box = css.a_box_wh
      break;
    case 2:
      a_box = css.a_box_hw
      break;
    default:
      a_box = ''
      break;
  }

  return (
    <div>
      <a
        onClick={() => showImg(imageMedia)}
        className={a_box}
      >
        <img
          style={imgSize.typeNum === 2 ? imgStyle : normalImgStyle}
          src={fileThumbnailUrl || fileOriginUrl}
        />
      </a>
    </div>
  )
}

export default ImageMedia;