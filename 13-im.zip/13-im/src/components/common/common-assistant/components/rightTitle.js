import React from 'react';

import * as util from "@/utils/util";

import css from '../index.scss';

const Title = ({ name, time }) => {
  const { session_active = {} } = window;
  const sessionActiveId   = session_active.id;

  return (
    <div className={css.contentTitle}>
      {
        sessionActiveId == 3010 && <span className={css.name}>{name}</span>
      }
      <span className={css.time}>{util.formatDate.sessionDateFormat(1000 * time)}</span>
    </div>
  )
}

export default Title;