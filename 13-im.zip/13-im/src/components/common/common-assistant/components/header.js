import React from 'react';

// const Wrapper = styled.div`
//     border-radius:4px 4px 0 0;
//     background: ${p => p.bgColor};
//     font-size: ${p => p.fontSize+'px'};
//     padding: ${p => p.vPadding+'px '+p.hPadding+'px'};
//     color: ${p => p.textColor};
//     font-weight:${p => p.fontBold};
//     overflow: hidden;
//     white-space: nowrap;
//     text-overflow: ellipsis;
//     ${p => p.lineColor && `
//         border-bottom:1px solid ${p.lineColor}
//     `}
// `;

export default function Header(props) {
    const {property={}}=props;

    const style={
        borderRadius : '10px 10px 0 0',
        background : property.bgColor,
        fontSize : property.fontSize+'px',
        padding: `${property.vPadding}px ${property.hPadding}px`,
        color : property.textColor,
        fontWeight : property.fontBold,
        borderBottom:property.lineColor?`1px solid ${property.lineColor}`:'none',
    }
    return (
        <div style={style}>
            {property.content}
        </div>
    );
}
