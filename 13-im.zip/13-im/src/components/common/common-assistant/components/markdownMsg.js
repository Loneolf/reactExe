import React from 'react';

import LinkMessage from '@c/common/link-msg';
import Header from './header';
import Title from './title';
import Image from './image';
import Content from './content';
import Button from './button';

import { resolveOldRecordDataUrl } from '../util';

import css from '../index.scss';

const MarkdownMsg = ({
  head,
  title,
  image,
  content,
  buttons,
  linkCard,
}) => {
  const hasimage = (image && !!image.sourceUrl) ? true : false;

  const handleGoInfoButtonBody = (clickUrl, e)=>{
    console.log('wenai-clickUrl', clickUrl)
    e.stopPropagation()
    if (!clickUrl) return;
    window.open(resolveOldRecordDataUrl(clickUrl));
  }

  return (
    <>
      { head && <Header property={head} />}

      { title && <Title property={title} /> }

      { hasimage && <Image property={image} /> }

      { content && <Content property={content} /> }

      {!!buttons.length && Array.isArray(buttons[0]) && 
        buttons.map((citem, ind) =>
          <Button
            key={ind}
            property={citem}
            handleClick={handleGoInfoButtonBody}
          />
        )
      }

      { linkCard && <LinkMessage className={css.linkMsg} customData={linkCard} /> }
    </>
  )
}

export default MarkdownMsg;
