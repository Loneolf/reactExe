import React,{Fragment} from 'react';
import { message } from 'antd';
import css from './common.scss';

import * as util from "@/utils/util";
import { messageActioncardRequest } from '@s/robots';

export default function Button(props) {
    const { property: btns = [],  handleClick } = props;
    const messageAction = async (e, object) => {
        e.preventDefault();
        e.stopPropagation();
        try {
            let obj = await messageActioncardRequest(object);
            if(obj && obj.code !== 200) {
                message.error(obj.msg);
            }
        } catch (error) {
            console.log(error);
        }
    };

    return (
        <div className={css.buttonOut}>
            {btns.map((item,index)=>(
                item.btnType==2 ? 
                    <div
                        key={index}
                        className={css.buttonLink}
                        onClick={(e)=>messageAction(e,{url: new URLSearchParams(item.clickUrl.split("?")[1]).get('url')})}
                    >
                        <span>
                            {item.text ? item.text : util.locale('common_view_more1')}
                        </span>
                        <span className="iconfont-yach yach-quanju-xuanren-zuzhijiagoucehua" />
                    </div> :
                    item.btnType==1 ?
                        <div
                            key={index}
                            className={css.buttonLink}
                            onClick={(e)=>handleClick(item.clickUrl, e)}
                        >
                            <span>
                                {item.text ? item.text : util.locale('common_view_more1')}
                            </span>
                            <span className="iconfont-yach yach-quanju-xuanren-zuzhijiagoucehua" />
                        </div> :
                        <Fragment key={index}>
                            <div
                                className={css.buttonItem}
                                style={{background:item.bgColor,fontSize:item.fontSize,color:item.textColor}}
                                onClick={(e)=>handleClick(item.url, e)}
                                {...item}
                            >
                                {item.text}
                            </div>
                            <em/>
                        </Fragment>
            ))}
        </div>
    );
}