import React from 'react';

export default function Title(props) {
    const {property={}}=props;

    const style={
        fontSize:property.fontSize+'px',
        color:property.textColor,
        fontWeight:property.fontBold,
        padding: 14,
        paddingBottom:0,
        textDecoration: property.textDecoration,
        borderBottom:property.lineColor?`1px solid ${property.lineColor}`:'none',
    }

    return (
        <div style={style}>
            {property.content}
        </div>
    );
}
