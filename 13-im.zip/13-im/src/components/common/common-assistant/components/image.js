import React from 'react';
import css from './common.scss';



export default function Image(props) {
    const {sourceUrl}=props.property||{};
    return (
        <div className={css.imgOut}>
            <img className={css.temImg} src={sourceUrl} alt=""/>
        </div>
    );
}
