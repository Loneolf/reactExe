import React from 'react';
import { 
    setWeekAssitantList,
    setWeekAssitantLast,
    setWeekAssitantLoading,
    setWeekAssitantListR,
    setWeekAssitantPush
} from '@/redux/actions/assistant';

import { weekAssitentList } from "@/services/schedule/schedule";

/*
   在当前会话窗口如果是云信推送：清楚redux数据重新再填充。
   server:是否是服务端推送标志
*/

export const assiatantTemplateSyncList = async(accid, server=false)=>{
    if(!accid){
        console.log(`assistant template need sesssion id`);
        return null;
    }

    window.store.dispatch(setWeekAssitantLoading(true));

    // 服务端推送
    if(server){
        window.store.dispatch(setWeekAssitantListR([]));
        window.store.dispatch(setWeekAssitantLast({ msg_id:'', msg_time:''}));
    }

    try{
        // 从store中取数据
        const store = window.store.getState();
        const {weekly_assistant_last} = store.assistant;

        // 初始化字段数据
        let nodata,
            list = null,
            msg_id = weekly_assistant_last.msg_id || '',
            msg_time = weekly_assistant_last.msg_time || '';

        // 获取列表信息
        list = await weekAssitentList({
            msg_id,
            msg_time,
            aide_user_id: accid
       });

        const {code, msg, obj =[] } = list || {},
              objListLength = obj.length;

        // 赋值接口参数，用于下次发起请求
        msg_id = !objListLength ? msg_id : obj[0].id;
        msg_time = !objListLength ? msg_time : obj[0].created_at;

        if(objListLength){
            if( code !== 200 ) return console.error(`request has erro code ${code} and info ${msg}`);
            window.store.dispatch(setWeekAssitantList(obj));
            nodata = false;
        }else{
            nodata = true;
        }

        // 数据更新到store中
        window.store.dispatch(setWeekAssitantLast({msg_id, msg_time, nodata}));

        // 把云信推送的标志位 重置掉,防止再次页面中上拉加载的时候出发comdidupdate里面的条件，产生抖动感.
        if(server){
           setTimeout(()=>{
                window.store.dispatch(setWeekAssitantPush(false));
           },100);
        }

        window.store.dispatch(setWeekAssitantLoading(false));

        return obj;

    }catch(e){
        console.error(`assiatant template has error ${e.toString()}`);
    }
}