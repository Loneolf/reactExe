import 'intersection-observer';

export default class IoWatcher {
  exposedTime;

  callback;

  container;

  proportion;

  // 是否重复曝光，默认不重复曝光
  repeat;

  nodeList = [];

  // 保存已曝光的模块
  watchedModuleSet = new Set();

  // 保存进入可视区域的模块
  entryModuleMap = new Map();

  // 保存离开可视区域的模块
  outModuleMap = new Map();

  constructor({
    exposedTime = 1500,
    callback = () => {},
    container = null,
    proportion = 0.1,
    repeat = false,
  }) {
    this.exposedTime = parseInt(exposedTime);
    this.callback = callback;
    this.container = container;
    this.repeat = repeat;
    this.validateProportion(proportion);

    // 在需要曝光的模块上添加 data-watch-item 属性
    this.nodeList = [...document.querySelectorAll('[data-watch-item]')];
    // 初始化 IntersectionObserver 实例
    this.observer = this.initObserver();
    this.nodeList.forEach(node => {
      this.observer.observe(node);
    });
  }

  validateProportion(proportion) {
    let pro = parseFloat(proportion);
    if (proportion >= 1) pro = 0.99;
    if (proportion <= 0) pro = 0.01;
    this.proportion = pro;
  }

  initObserver() {
    const {
      container,
      exposedTime,
      proportion,
      repeat,
      entryModuleMap,
      outModuleMap,
      watchedModuleSet,
    } = this;
    let timerId = null;
    return new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        const {
          isIntersecting,
          target,
        } = entry;

        if (isIntersecting) {
          // 将进入可视区域的元素(模块) set 进 entryModuleMap
          entryModuleMap.set(target, entry);
          if (outModuleMap.has(target)) outModuleMap.delete(target);
        } else {
          // 将不在可视区域的元素(模块) set 进 outModuleMap
          outModuleMap.set(target, entry);
          if (entryModuleMap.has(target)) {
            // 离开可视区域时需要进行判断, 之前进入的时间和离开的时间是否超过了曝光时间, 如果超过了, 则需要曝光
            if (outModuleMap.get(target).time - entryModuleMap.get(target).time >= exposedTime) {
                watchedModuleSet.add(target);
                // 解除该元素的监听
                if (!repeat) observer.unobserve(target);
                outModuleMap.delete(target);
                // 回调函数处理曝光逻辑
                this.callback(target);
            }
            entryModuleMap.delete(target);
          }
        }
        if (timerId) clearTimeout(timerId);
        // 当页面停止滚动时, 对当前 可视区域 中的元素进行处理, 即处理 entryModuleMap 中的元素
        timerId = setTimeout(() => {
          // 如果进入的组件没有出去, 则说明还停留在可视区域, 直接曝光
          [...entryModuleMap].forEach(([node]) => {
              watchedModuleSet.add(node);
              // 解除该元素的监听
              if (!repeat) observer.unobserve(node);
              entryModuleMap.delete(node);
              // 回调函数处理曝光逻辑
              this.callback(node);
          });
        }, exposedTime);
      });
    }, {
      root: container,
      threshold: [proportion],
    });
  }

  /**
   * 重置已曝光的某个 Dom 节点的 Watcher 到当前状态
   * @param {*} node 
   */
  refreshNodeWatcher(node) {
    const {
      watchedModuleSet,
    } = this;
    if (watchedModuleSet.has(node)) {
      watchedModuleSet.delete(node);
      this.observer.observe(node);
    }
  }

  /**
   * 监听通过 JS 动态生成的 nodeList
   * @param {*} nodeList 
   */
  addNodelistWatcher(nodeList) {
    const {
      watchedModuleSet,
    } = this;
    nodeList.forEach(node => {
      if (!watchedModuleSet.has(node)) {
        this.observer.observe(node);
      }
    });
  }

  /**
   * 移除 nodeList 监听
   * @param {*} nodeList 
   */
  removeNodelistWatcher(nodeList) {
    nodeList.forEach(node => {
      this.observer.unobserve(node);
      this.entryModuleMap.delete(node);
      this.outModuleMap.delete(node);
      this.watchedModuleSet.delete(node);
    });
  }

  refreshPartNodeList() {
    // console.log('wenai',this.watchedModuleSet, this.entryModuleMap, this.outModuleMap);
    this.nodeList = [...document.querySelectorAll('[data-watch-item]')];
    this.nodeList.forEach(node => {
      if (!this.watchedModuleSet.has(node)) {
        this.observer.observe(node);
      }
    });
  }

  /**
   * 重置 nodeList.
   * 可能调用改函数的情形: 通过 JS 动态添加了需要监听的元素(模块)
   */
  refreshNodeList() {
    this.clear();
    this.nodeList.forEach(node => {
      this.observer.unobserve(node);
    });

    // 重新绑定监听器
    this.nodeList = [...document.querySelectorAll('[data-watch-item]')];
    this.nodeList.forEach(node => {
      this.observer.observe(node);
    });
  }

  /**
   * 重置 Watcher 到初始状态
   */
  refreshWatcher() {
    this.clear();
    this.nodeList.forEach(node => {
      this.observer.unobserve(node);
    });

    // 重新 observe
    this.nodeList.forEach(node => {
      this.observer.observe(node);
    });
  }

  /**
   * 销毁生成的 IoWatcher 实例
   */
  destroy() {
    this.clear();
    this.observer.disconnect();
  }

  clear() {
    const {
      entryModuleMap,
      outModuleMap,
      watchedModuleSet,
    } = this;

    entryModuleMap.clear();
    outModuleMap.clear();
    watchedModuleSet.clear();
  }
}
export { IoWatcher };