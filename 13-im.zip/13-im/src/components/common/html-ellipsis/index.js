/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-05-12 22:04:46
 * @LastEditors: olei<wangzheng_jzb@100tal.com>
 * @LastEditTime: 2020-09-24 15:51:32
 */
import React, { Component } from 'react'
import { textFiltering, urlRegExp } from '@/utils/yach';
import * as util from '@u/util.js';
import css from './index.scss'

export default class HtmlEllipsis extends Component {
  constructor(props) {
    super(props)
    const { maxLine, lineHeight } = this.props
    this.state = {
      text: this.props.text,
      html: this.atHigh(this.props.text),
      isShowSuffix: false
    }
    this.base = 21
    this.html = this.props.text
    this.maxHeight = maxLine * lineHeight
  }
  
  componentDidUpdate(pre) {
    if (this.html !== pre.text) {
      this.html = pre.text
      this.setState({
        text: pre.text,
        html: this.atHigh(pre.text),
        isShowSuffix: false
      })
    }
    if (pre.text) this.resetText()
  }

  // 高亮AT
  atHigh = text => {
    const at_users = [...this.props.atUsers]
    let _html = text
    if (at_users.length) {
      at_users.forEach(v => {
          if (!/^@/.test(v.atName))  v.atName = '@' + v.atName
          v.id = v.user_id
      });
      const opt = {
          atHighlighted: at_users
      }
      _html = util.yach.atHighlighted_at(_html, JSON.stringify(opt))
      _html = util.yach.convertExpression(util.yach.textFiltering(_html), '20px', '20px');
    } else _html = util.yach.textFiltering(_html);
    return _html
  }
  
  /**
   * @msg: 二次校验
   */
  resetText() {
    this.offsetHeight = this.refs.sText.offsetHeight
    // 超出高度执行
    if (this.offsetHeight > this.maxHeight && !this.isAddSize) {
      !this.isOverflow && (this.isOverflow = true)
      // 设置查看全文后缀
      this.setState({
        isShowSuffix: true
      })
      // 执行截字
      this.strSize()
    } else if (this.isOverflow && this.offsetHeight < (this.maxHeight - this.props.lineHeight)) {
      this.addSize()
    } else delete this.isOverflow
  }

  addSize() {
    const len = 2 // *常量必须小于等于2
    const tLen = this.state.text.replace(/[\r\n\s]+/ig, '').length
    if (tLen < len) return
    this.isAddSize = true
    this.setState({
      text: (this.state.text + this.html.substr(this.state.text.length, len))
    })
  }

  /**
   * @msg: 截字
   */
  strSize() {
    // const { maxLine, lineHeight } = this.props
    const textLen = this.state.text.replace(/[\r\n\s]+/ig, '').length
    // 基本阈值
    // this.base = parseInt((this.offsetHeight - this.maxHeight) / lineHeight * 21)

    // 获取准确阈值
    const threshold = this.getSize(textLen, this.base)
    const lastStr = textLen > threshold ? this.state.text.substring(textLen - threshold) : this.state.text
    let size
    if (lastStr) size = this.strLen(lastStr)
    if (size) {
      const n = size < textLen ? size : 0
      const text = this.state.text.substring(0, textLen - n)
      this.setState({
        text
      })
    }
  }
  
  /**
   * @msg: 获取准确阈值
   */
  getSize(len, threshold) {
    if (len < 2) return 0
    if (len > threshold) return threshold 
    return len - 1
  }

  /**
   * @msg: 返回删除字数量
   */
  strLen(str) {
    if (!str) return 0
    if (/\n$/.test(str)) return 1
    return str.length
  }
  
  /**
   * @msg: 超链接替换
   */ 
  replaceLink(commentHTML, shortComment) {
    if (!commentHTML || !shortComment) return ''
    const links = commentHTML.match(urlRegExp())
    
    let base = -2
    return shortComment.replace(urlRegExp(true), link => {
      base += 2
      if (links[base]) return `href="${links[base]}"`
    })
  }

  render() {
    const { onAll } = this.props
    const html = this.replaceLink(this.state.html, this.atHigh(this.state.text))
    return (
      <div className={css.commentBox}>
        <pre className={css.sText} ref="sText" style={{display: 'inline'}}
          dangerouslySetInnerHTML={{
            __html: this.state.isShowSuffix ? (html.replace(/.{5}(<\/a>)?$/, '$1').replace(/[\r\n]$/, '') + '...') : html
            // __html: html
          }}
        />
        {
        this.state.isShowSuffix ? <span className={css.suffix} style={{cursor: 'pointer', color: '#4577BE'}} onClick={onAll}>{this.locale('common_full_text')}</span> : null
        }
      </div>
    )
  }
}
