import React from 'react';
import { Button } from 'antd';
import './index.scss';
import * as nimMsg from "@u/nim/container/nim-msg.js";
import * as util from "@/utils/util";

import { openNotification, closeNotification } from './common-notification';

const openServiceNotification = async (data, from) => {
  const {
    title,
    sub_title: subTitle,
    id,
    content,
    btn_url,
  } = data;

  const message = <div><span/><em>{title}</em></div>;

  const description = (
    <div className='tipContent'>
      {subTitle && <div className="title">{subTitle}</div>}
      <div>
        <span className='iconfont-yach yach-quanju-tongzhi-zhuti-moren icon' />
        {content}
      </div>
    </div>
  );

  const btnElement = _createElement();

  function _createElement() {
    const dealLater = <Button key="0" onClick={(e)=>{
        e.stopPropagation();
        _onClickOpreation(0);
    }}>{util.locale('common_deal')}</Button>
  
    const viewNow = <Button key="1" className="view-now" onClick={(e)=>{
      e.stopPropagation();
      _onClickOpreation(1);
    }}>{util.locale('common_view_more1')}</Button>
  
    return (
      <div>
        {dealLater}{viewNow}
      </div>
    );
  }
  
  function _onClickOpreation(type) {
    if (type === 0) {
      // 关闭弹窗
      closeNotification({type: 'service', id});
      return;
    }
    if (type === 1) {
      // 立即查看内容，关闭弹窗，跳转对应的会话框，打开内容
      _viewDetail();
      closeNotification({type: 'service', id});
      return;
    }
  }
  
  function _viewDetail() {
    const sessionInfo = {
      sessionType: 'p2p',
      sessionId: from,
    }
    nimMsg.jumpToMsgView(sessionInfo);
    if (btn_url) {
      window.location.href = btn_url;
    }
  }

  const notificationParams = {
    message,
    description,
    btn: btnElement,
    className: 'serviceTip',
    onClick: _viewDetail
  }

  openNotification({type: 'service', id}, notificationParams);
}

const closeServiceNotification = obj => {
  const id = obj.id;
  closeNotification({type: 'service', id});
}

export {
  openServiceNotification,
  closeServiceNotification
}