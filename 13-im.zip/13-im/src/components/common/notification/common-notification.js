/**
 * 提醒、公告公用提醒弹框
 */

import { Button, notification, Tooltip, Menu, Dropdown} from 'antd';

const notificationTypeMap = new Map([
  // ['schedule', 'scheduleMap'],
  ['remind', 'remindMap'],
  ['service', 'serviceMap'],
])

/**
 * 
 * @param {
 *  type: 提醒类型，schedule | remind | service
 *  id: 提醒消息 id
 * } param0 
 * @param {*} config 
 */
const openNotification = ({ 
    type,
    id,
  },
  config
) => {
  let key = '';
  for (let [k, value] of window[notificationTypeMap.get(type)]) {
    if(k.id === id){
      // 存在，需要替换
      key = value;
      window[notificationTypeMap.get(type)].delete(k);
      window[notificationTypeMap.get(type)].set({id},value);
      break;
    }
  }
  if(!key){
    // 不存在，需要新建
    key = id;
    window[notificationTypeMap.get(type)].set({id},key);
  }

  notification.open({
    duration: null,
    key,
    onClose: () => notification.close(key),
    ...config
  });
}

const closeNotification = ({
  type,
  id,
}) => {
  let key = '';
  for (let [k, value] of window[notificationTypeMap.get(type)]) {
    if(k.id === id){
      // 存在，需要替换
      key = value;
      window[notificationTypeMap.get(type)].delete(k);
      break;
    }
  }
  if(key){
    notification.close(key);
  }
}

export {
  openNotification,
  closeNotification
}