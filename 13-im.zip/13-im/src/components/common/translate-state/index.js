import React, { memo } from 'react';

import * as _ from 'lodash';

import css from './index.scss';

// imgs
import center from '@a/imgs/translate/translate-code.png';
import rotating from '@a/imgs/translate/translate-turn.png';
import translate from '@a/imgs/translate/translate-done.png';

function TranslateState(props) {
    const {translating, translateAndReduction} = props;
    return (
        <div className={css.translateState}>
            {translating ?
                <div className={css.centerImg} onClick={translateAndReduction}>
                    <img className={css.rotating} src={rotating}/>
                    <img src={center}/>
                </div> :
                <img className={css.translateDone} src={translate} onClick={translateAndReduction}/>
            }
        </div>
    );
}

function arePropsEqual(prevProps, nextProps) {
    return _.isEqual(prevProps, nextProps);
}

export default memo(TranslateState, arePropsEqual);
