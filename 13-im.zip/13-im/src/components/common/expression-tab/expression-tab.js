// react
import React from 'react';
// css
import css from './index.scss';
import { Tooltip } from 'antd';
import EmojiModalContainer from '@c/common/emoji-modal/emoji-modal-container';

import ExpressionModalContainer from '@c/common/expression-modal/expression-modal-container';
import * as util from '@u/util.js';

export default React.memo(({tabIndex, tabList, currentTab, tabClickHandle, clickEmojiItem}) => {

    
    return (
        //1.给每个tab标题添加一个点击事件，
        //2.在state中，存一个默认tab下标
        //3.在点击事件中，将下标传递过去，并且更新state中的下标
        //4.tabContent部分，有几个tab 放几个坑，通过当前下标去判断显示哪一个
        <div className={css.box} id='expression'>
            {
                <div className={css.tabWrapper}>
                    {tabList.map((item, index) => {
                        return(
                            <div key={item.tabId} className={`tabContent ${currentTab === index+1 ? css.show : css.hide}`}>
                                {index === 0 ? 
                                <EmojiModalContainer clickEmojiItem={clickEmojiItem} isTab = {true}/>
                                : <ExpressionModalContainer expressionList = {item.expressionList} clickEmojiItem={data => clickEmojiItem(data, item)}/>
                                }
                            </div>
                        )
                    })}
                    <ul className={css.tabUrl}>
                        {
                            tabIndex.map((item, index) => {
                                return <Tooltip
                                            placement='top'
                                            title={item.tabName}
                                            key={`tab${item.tabId}`}
                                        >
                                            <li className={`${css.tabLi} ${currentTab === index+1 ? css.avtive : ''}`} onClick={() => { tabClickHandle(index+1) }}>
                                                <img src={item.tabIcon}/>
                                            </li>
                                        </Tooltip>
                            })
                        }
                    </ul>
                </div>
            }
        </div>
    )
})

// export default class ExpressionTab extends React.Component {
//     constructor(props) {
//         super(props);
//     }

//     // toolTip = (item)=>{
//     //     if(item.tabId === 2) {
//     //         return util.locale('im_icon_gif_hoverTab')
//     //     }
//     //     return util.locale('im_icon_emoji_hoverTab')
//     // }

//     render() {
//         const { tabIndex, tabList, currentTab, tabClickHandle, clickEmojiItem } = this.props;
//         return (
//             //1.给每个tab标题添加一个点击事件，
//             //2.在state中，存一个默认tab下标
//             //3.在点击事件中，将下标传递过去，并且更新state中的下标
//             //4.tabContent部分，有几个tab 放几个坑，通过当前下标去判断显示哪一个
//             <div className={css.box} id='expression'>
//                 {
//                     <div className={css.tabWrapper}>
//                         {tabList.map((item, index) => {
//                             return(
//                                 <div key={item.tabId} className={`tabContent ${currentTab === index+1 ? css.show : css.hide}`}>
//                                     {currentTab == 1 ? <EmojiModalContainer clickEmojiItem={clickEmojiItem} isTab = {true}/>
//                                     : <ExpressionModalContainer expressionList = {item.expressionList} clickEmojiItem={data => clickEmojiItem(data, item)}/>}
//                                 </div>
//                             )
//                         })}
//                         <ul className={css.tabUrl}>
//                             {
//                                 tabIndex.map((item, index) => {
//                                     return <Tooltip
//                                                 placement='top'
//                                                 title={item.tabName}
//                                                 key={`tab${item.tabId}`}
//                                             >
//                                                 <li className={`${css.tabLi} ${currentTab === index+1 ? css.avtive : ''}`} onClick={() => { tabClickHandle(index+1) }}>
//                                                     <img src={item.tabIcon}/>
//                                                 </li>
//                                             </Tooltip>
//                                 })
//                             }
//                         </ul>
//                     </div>
//                 }
//             </div>
//         )
//     }
// }
