// react
import React from 'react';
import * as util from '@u/util.js';
import ExpressionTab from './expression-tab';

import { connect } from 'react-redux';

import { message } from 'antd';

// redux
import { add, replace } from '@r/actions/messageList';

// emoji-modal-container
class ExpressionTabContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state = {
        tabIndex: [],
        tabList: [],
        userId: `${util.yach.getAccount()}`,
        currentTab:  1
    }

    componentDidMount() {
        const {userId} = this.state;
        this.setState({currentTab: (util.yachLocalStorage.ls('gif_tab') && util.yachLocalStorage.ls('gif_tab')[userId]) || 1});
        this.initData();
    }

    initData = async() => {
        let data = util.yachLocalStorage.ls('expression');
        let {obj} = data || {};

        if(!data || !obj){
            data = await util.yach.getExpression();
            let {code, msg} = data;
            obj = data.obj;

            if(code != 200 || !obj) return message.error(msg);
        }
        
        const {tabIndex, tabList} = obj;
        this.setState({tabIndex, tabList});
    }
    
    tabClickHandle = (i) => {
        const {userId} = this.state;
        this.setState({ currentTab: i});
        util.yachLocalStorage.ls('gif_tab', {...util.yachLocalStorage.ls('gif_tab'), [userId]: i});
    }

    clickEmojiItem = (data, item) => {
        const {type} = data;
        if(type == 'expression') {
            const {expressionUrl, expressionName, expressionName_en, expressionId,isClick} = data
            this.assemblyData({expressionUrl, expressionName, expressionName_en, expressionId, isClick});
            this.props.handleVisibleChange(false);
            util.sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name:'01-126', expression_type: '01-102', expression_name:data.expressionName,expression_id:data.expressionId});
            return;
        }
        this.props.clickEmojiItem(data);
        util.sensorsData.track('Click_Chat_Element', { pageName: '135',$element_name:'01-126', expression_type: '01-101', expression_name:data});
    }

    assemblyData = data => {
        // const { userInfo, sessionActive } = this.props;
        
        const sessionActive = window.session_active;
        if (!sessionActive) return message.error('gif表情发送失败');

        const { userInfo } = this.props;
        const { name, name_nick } = userInfo;
        const custom = {
            type: 25,
            data,
        };
        const apns = {
            forcePush: false,
        };
        let pushContent = '',
            pushPayload = {};
        if (sessionActive.type == 'team') {
            pushContent = `${name}${name_nick ? '(' + name_nick + ')' : ''}: [${util.locale('Emoji')}]`;
            pushPayload = {
                pushTitle: util.yach.decodeUnicode(sessionActive.showname),
                sessionType:1
            };
        } else {
            pushContent = `[${util.locale('Emoji')}]`;
            pushPayload = {
                pushTitle: util.yach.decodeUnicode(name_nick || name),
                sessionType:0
            };
        }
        pushPayload.sessionID = sessionActive.id
        pushPayload = util.yach.handlePushPayload({ pushPayload,apns}) || pushPayload 
        this.sendCustomMsg(custom, pushContent, pushPayload, apns);
    }

    sendCustomMsg = async (custom, pushContent, pushPayload, apns = {}) => {
        // const { sessionActive } = this.props;
        const sessionActive = window.session_active;

        let customMsg;
        try {
            customMsg = await util.nim.sendCustomMsg(
                sessionActive.type,
                sessionActive.id,
                JSON.stringify(custom),
                apns,
                pushContent,
                '',
                pushContent,
                pushPayload,
                async (msg) => {
                    const obj = await util.nim.genMsgItem(msg);
                    if (msg.to == sessionActive.id) this.props.dispatch(add(obj));
                }
            );
        } catch (error) {
            customMsg = error.msg;
        }

        util.yach.msgUploadCloud(customMsg);

        if (customMsg.to == sessionActive.id) this.pushMessage(customMsg, 2);

        util.yach.refreshConnect(customMsg);
    };

    async pushMessage(item, type) {
        let obj;
        
        if (item.status == 'fail') {
            obj = Object.assign(item, { msg: item });
            this.props.dispatch(replace(obj));
            return;
        }

        obj = await util.nim.genMsgItem(item);
        let sessionActive = window.session_active;
        if (sessionActive && sessionActive.type == 'team') {
            const teamMembers = await util.nimUtil.getTeamMembers(sessionActive.id);
            obj = Object.assign(obj, { read: 0, unread: teamMembers.members.length - 1 });
        }
        if (type == 2) this.props.dispatch(replace(obj));
    }

    tabCallback = (key) => {
        console.log(key);
    }
    
    render() {
        const {tabList, currentTab, tabIndex} = this.state;
        return (
            <ExpressionTab
                tabIndex = {tabIndex}
                tabList = {tabList}
                currentTab = {currentTab}
                tabClickHandle = {this.tabClickHandle}
                clickEmojiItem = {this.clickEmojiItem}
            />
        );
    }
}

const mapStateToProps = (state) => {
    return {
        // sessionActive: state.sessionActive,
        userInfo: state.userInfo
    };
};

export default connect(mapStateToProps, null)(ExpressionTabContainer);
