// react
import React from 'react';
import css from "./index.scss";

import * as util from '@u/util.js';

export default function Index(props) {
    const {
        content = '',
        title = '',
        type = 'confirm', 
        close, 
        callback, 
        visible
    } = props;

    return <div>
        {
            visible ? <div className={css.out} onMouseDown={(e) => e.stopPropagation()}>
                <div className={css.mask}/>
                <div className={css.container}>
                    {title &&
                        <div className={css.title}>
                            {title}
                        </div>
                    }
                    <div className={css.content}>{content}</div>
                    <div className={css.btn}>
                        {
                            type === 'confirm' ?
                        <div className={css.confirm}><span onClick={close}>{util.locale('common_cancel')}</span><em/><span
                                onClick={callback}>{util.locale('common_make_sure')}</span></div> :
                                <div className={css.tip}><span onClick={close}>{util.locale('common_getit')}</span></div>
                        }
                    </div>
                </div>
            </div> : null
        }
    </div>

}


