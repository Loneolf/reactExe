import React from 'react';
import {withRouter} from 'react-router';
import {connect} from 'react-redux';
import css from './index.scss';
import { Input, Button, message } from 'antd';
import * as util from '@/utils/util';
import {videoSessionlHide} from '@/redux/actions/commonModal';
import { agoraRTMChannelListen } from '@u/lib/agora/agora-rtm-listen.js';
import debounce from 'lodash/debounce';

import { ucenterZoomMeetingCreate } from '@s/ucenter/ucenter-user.js';
import {  meetingGroupUserJoin, meetingGroupUserLeave, meetingHeart } from '@/services/meeting/meeting.js';
import { handleJoinFail, cancelAllCall} from '@u/lib/zoom/zoomFn';

let reportState = {
    userid:'', //当前账号对应的zoom userid
    event_duration:0, //说话时长
    talk_start: 0,
    end_talk: 0,
    notalk_start: 0
};
let heartTimer = null;
const loopfntime = 30000;
class VideoSessione extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            textInputValue: '',
            loading: false,
            onlineMeetingId:null,
            sourceType:null,
            sourceId:null,
            leave: false,
            os: util.electron.isMac() ? 'mac' : 'windows',
            isvideooff: false, // 默认开启
            isaudiooff: false,
            isStartSession: false,
        }
    }

    componentWillMount() {
        this.startSession = debounce(this.startSession, 300)
        this.initData();
    }

    initData = () => {
        const {nickName='', title=''} =  this.props.videoSessioneModal;
        const newNickName = nickName.length>0 ? this.cutstr(nickName, 50 - util.yach.getStrCharLength(title)) : '';
        this.setState({
            textInputValue : util.locale.getLang() === 'en-US' ? `${title} ${newNickName}` : `${newNickName} ${title}`
        });
    }

    closeCard = () => {
        util.log('panghaojie', 'video-session-container.js', 'closeCard', this.state.loading);
        if(this.state.loading) message.warning(util.locale('common_msg27'));
        this.props.dispatch(videoSessionlHide());
        if(this.props.isShowVideoSession) this.props.isShowVideoSession();
    };

    textareaValue = data => {
        const value = data.target.value;
        if(util.yach.getStrCharLength(value)>50) return;
        this.setState({ textInputValue: value});
    };

    cutstr = (str, len) => {
        let ranges = [
            '\ud83c[\udf00-\udfff]', 
            '\ud83d[\udc00-\ude4f]', 
            '\ud83d[\ude80-\udeff]'
        ];
        // title 过滤表情
        let resultStr = str.replace(new RegExp(ranges.join('|'), 'g'), '');
        let str_length = 0;
        let str_len = 0;
        let str_cut = new String();
        str_len = resultStr.length;
        for(let i = 0; i < str_len; i++) {
            let a = resultStr.charAt(i);
            str_length++;
            if(escape(a).length > 4){
                //中文字符的长度经编码之后大于4
                str_length++;
            }
            str_cut = str_cut.concat(a);
            if(str_length>=len){
                // str_cut = str_cut.concat("...");
                return str_cut;
            }
        }
        //如果给定字符串小于指定长度，则返回源字符串；
        if(str_length < len){
            return resultStr;
        }
    }

    setVideoOff = () =>{
        if(this.state.isStartSession) return;
        if(this.state.isvideooff){
            this.setState({isvideooff:false})
        }else{
            this.setState({isvideooff:true})
        }
    }

    setAudioOff = () =>{
        if(this.state.isStartSession) return;
        if(this.state.isaudiooff){
            this.setState({isaudiooff:false})
        }else{
            this.setState({isaudiooff:true})
        }
    }

    startSession = () => {
        util.log('panghaojie', 'video-session-container.js', 'startSession');
        //先清除选人组件参数，避免异常离开会议没有清除掉
        util.yachLocalStorage.ls('inviteGroupInfo', null);
        const {textInputValue,isvideooff,isaudiooff} = this.state
        // const { teamType, sessionActive } = this.props
        // const { type } = sessionActive;
        const { teamType } = this.props;
        const sessionActive = window.session_active;
        const type = sessionActive.type;
        this.setState({
            loading: true,
            isStartSession: true,
        });
        util.log('panghaojie', 'video-session-container.js', 'startSession',type, teamType == 'schedule');
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-101', $element_name: '01-135'});
        if(type == 'team'||teamType === 'schedule') {
            this.setState({
                loading: false,
                isStartSession: false
            });
            util.log('panghaojie', 'video-session-container.js', 'judge-onlineOffice',!!this.props.onlineOffice);
            if(this.props.onlineOffice) this.props.onlineOffice(textInputValue,isvideooff,isaudiooff);
            return
        }
        //单聊视频会议
        this.zoomMeetingCreate();
    }

    zoomMeetingCreate = async () => {
        util.log('panghaojie', 'video-session-container.js', 'zoomMeetingCreate');
        let startTimer = new Date().getTime();
        const { textInputValue, os } = this.state;
        // const { sessionActive } = this.props;
        const sessionActive = window.session_active;
        const { type, id } = sessionActive;
        
        const params ={
            push_type: type == 'p2p' ? 'personal' : 'group',
            personal_id: type == 'p2p' ? id : '',
            tid: type == 'p2p' ? '' : id,
            title: textInputValue,
            source_id: id,
            source_type: type == 'p2p' ? 1 : 2,//1:私聊、 2:群聊、3:日程、   4:办公室、5:周报、6:文档
            os
        }
        let data = await ucenterZoomMeetingCreate(params);
        util.log('panghaojie', 'video-session-container.js', 'ucenterZoomMeetingCreate', !!data);
        if(data && data.code == 200){
            this.setState({
                onlineMeetingId: data.obj.online_meeting_id,
                sourceType: type == 'p2p' ? 1 : 2,
                sourceId: id,
            },() => {
                this.zoomStartUnlogin(data.obj,startTimer);
                //this.addMeetingListen(data.obj);
            });
        } else {
            this.setState({loading: false});
            message.error(data.msg);
            util.sensorsData.track('Error_Chat', {
                error_code: 1001,
                submodule: '01-101'
            });
        }
        this.setState({isStartSession: false});
    }

    // zoom创建会议
    zoomStartUnlogin = (data,startTimer) => {
        const {nickName=''} =  this.props.videoSessioneModal;
        let userid = data.zoom_user_id;
        let zoomaccesstoken = data.zak;
        let username = nickName;
        let usertoken = data.token;
        let meetingnum = data.meeting_id;
        let {onlineMeetingId: online_meeting_id, sourceId: source_id, sourceType: source_type, os,isvideooff,isaudiooff} = this.state;
        util.log('panghaojie', 'video-session-container.js', 'zoomStartUnlogin', online_meeting_id,source_id,source_type,os);
        if (util.electron.isMac()) {
            // mac端屏蔽zoom会议里点击邀请按钮后的默认弹框，必须进入会议之前处理
            // win端sdk里处理没有问题，mac端需要特殊处理
            util.electronipc.electronZoomCallFn('disableToolbarInviteButtonClickOriginAction', true, res => {
                util.log('panghaojie', 'video-session-container.js', 'disableToolbarInviteButtonClickOriginAction', res);
                if (res == 7) {
                    message.info(util.locale('im_video_conferencing_component_initializes_exception'));
                    util.yach.platformConfigGetFun();
                }
            });
        }
        util.electronipc.electronZoomCallFn('startunlogin', {
            isvideooff,
            isaudiooff,
            userid,
            zoomaccesstoken,
            username,
            usertoken,
            meetingnum
        },status => {
            util.log('panghaojie', 'video-session-container.js', 'startunlogin', status);
            this.props.dispatch(videoSessionlHide());
            if(this.props.isShowVideoSession) this.props.isShowVideoSession()
            
            if(status == 0 || !status) {
                //存储会议id，供会议列表，呼叫，邀请弹窗使用
                util.yachLocalStorage.ls('inviteMeetingId',{
                    online_meeting_id,
                    meeting_id: meetingnum
                })
                this.setState({loading: false}, ()=>{
                    this.closeCard();
                });
                this.setState({leave:false});
                this.addMeetingListen(data, startTimer);
                // 摄像头开关统计
                this.reportVideoChange()
            } else if(status ==2){
                this.setState({loading: false}, ()=>{
                    this.closeCard();
                });
                util.electronipc.electronZoomCallFn('joinChannelByToken');
            } else {
                util.sensorsData.track('Error_Chat', {
                    error_code: 1003,
                    submodule: '01-101'
                });
                //加入失败处理
                handleJoinFail({ online_meeting_id })
            }
            this.setState({loading: false});
        }) // api 调用结果，0为成功
    }

    // 进入会议总时长  埋点
    endTimerSensorsDataInit = (startTimer = 0) => {
        let endTimer = new Date().getTime();
        let sizeTimer =  (endTimer-startTimer) / 1000;
        console.log("kjkjkjkjkjkjkjkjk",+sizeTimer.toFixed(2));
        // 进入会议成功 埋点
        util.sensorsData.track('PageView_Chat', {
            pageName: '01-118',
            cost_time: +sizeTimer.toFixed(2)
        });
    }

    loginSuccessful = (data) => {
        util.log('panghaojie', 'video-session-container.js', 'loginSuccessful');
        let { meeting_id: meetingnum, online_meeting_id } = data
        util.yachLocalStorage.ls('zoom_login', {
            startTime: (new Date()).getTime(),
            meetingNum: meetingnum,
            meetingName: this.state.textInputValue
        })
        util.sensorsData.track('PageView_Chat', {
            pageName: '01-103',
            source: '01-101',
            meeting_type: '01-103',
            meeting_id: meetingnum,
            meeting_name: this.state.textInputValue,
            submodule: '01-101'
        })
        const { teamType } = this.props
        //进入会议成功就初始化频道，保持会议中频道畅通
        agoraRTMChannelListen(`${online_meeting_id || ''}`);
        if(teamType && teamType.type == 9){
            //通过群进入会议，默认弹出选人组件弹窗
            window.setTimeout(() => {
                util.log('panghaojie', 'video-session-container.js', 'setTimeout', !heartTimer);
                if(!heartTimer) return
                util.electronipc.electronOpenZoomInvite();
            },2000)
        }

        //心跳计时器,30s上报一次,会议结束，计时器停止
        window.clearInterval(heartTimer)
        heartTimer = null
        util.log('panghaojie', 'video-session-container.js', 'setInterval');
        const { os } = this.state;
        heartTimer = window.setInterval(async() => {
            util.log('panghaojie', 'video-session-container.js', 'heartTimer');
            let res = await meetingHeart({
                online_meeting_id,
                os
            })
        },loopfntime)
    }

    reportVideoChange = () => {
        let userId, videoStatus;
        util.electronipc.electronChannelListen('zoomapivideostatuschangecb', obj => {
            if (!userId) {
                userId = obj.userId
            }
            if (userId === obj.userId && videoStatus !== obj.videoStatus) {
                const zoomInfo = util.yachLocalStorage.ls('zoom_login');
                // 摄像头打开
                try {
                    util.sensorsData.track('Click_Chat_Element', {
                        pageName: '01-103',
                        $element_name: '01-104',
                        OperateType: obj.videoStatus ? '01-101' : '01-102',
                        meeting_id: zoomInfo.meetingNum,
                        meeting_name: zoomInfo.meetingName
                    });
                } catch (error) {
                } finally {
                    videoStatus = obj.videoStatus
                }
            }
        })
    }
    
    addMeetingListen = (data, startTimer=0) => {
        util.log('panghaojie', 'video-session-container.js', 'addMeetingListen');
        util.electronipc.electronChannelListen('zoomapimeetingstatuscb', obj => {
            const {result , status} = obj;
            util.log('panghaojie', 'video-session-container.js', 'zoomapimeetingstatuscb', result,status);
            if(status == 4 && result == 0){
                //结束会议
                if(util.yachLocalStorage.ls('inviteUserNum') && util.yachLocalStorage.ls('inviteUserNum').len > 0){
                    //自己呼叫的有人
                    cancelAllCall({online_meeting_id: data.online_meeting_id})
                }
            }
            if(status == 7 && result == 0){ // 主动离开
                this.leaveMeeting();
            }
            if(status == 7 && result == 2){ // 主持人结束
                this.leaveMeeting();
            }
            if(status == 7 && result == 1){
                message.warning(util.locale('common_warn_msg16'));
            }
            if(status == 3 && result == 0){
                this.loginSuccessful(data);
                this.endTimerSensorsDataInit(startTimer);
            }
            if(status == 0 || status == 6 || status == 7){ //参考zoom/setting.js ZoomMeetingStatus
                util.log('panghaojie', 'video-session-container.js', 'clearInterval');
                //清除心跳计时器
                window.clearInterval(heartTimer)
                heartTimer = null
                this.leaveFeedback();
            }
        });
    }

    leaveFeedback = async() => {//离开会议室通知后台
        const {os, leave} = this.state;
        util.log('panghaojie', 'video-session-container.js', 'meetingGroupUserLeave', leave);
        const online_meeting_id = util.yachLocalStorage.ls('inviteMeetingId').online_meeting_id
        if(online_meeting_id && !leave){
            await meetingGroupUserLeave({
                online_meeting_id,
                os
            });
            //离开接口成功后，离开频道
            util.log('panghaojie','video-session-container.js','agoraRtmClearChannel')
            util.electronipc.agoraRtmClearChannel({channelId: `meeting_${online_meeting_id || ''}`})
            this.setState({leave:true});
        }
    }

    leaveMeeting = () => {
        const zoomInfo = util.yachLocalStorage.ls('zoom_login');
        util.log('panghaojie', 'video-session-container.js', 'leaveMeeting',zoomInfo);
        if(!zoomInfo) return;
        const {startTime, meetingNum, meetingName} = zoomInfo;
        const {userid, event_duration} = reportState;
        util.log('panghaojie', 'video-session-container.js', 'leaveMeeting',startTime, meetingNum, meetingName);
        if(!startTime || !meetingNum) return;
        try {
            util.sensorsData.track('PageClose_Chat', {
                pageName: '01-103',
                meeting_type: '01-103',
                event_duration: ((new Date()).getTime()-startTime)/1000,
                meeting_id: meetingNum,
                meeting_name: meetingName
            });
            if(event_duration){
                util.log('panghaojie', 'video-session-container.js', 'event_duration',userid,event_duration);
                util.sensorsData.track('EventContinue_Chat', {
                    event_duration,
                    submodule: '01-101',
                    meeting_type: '01-103',
                    meeting_id: meetingNum,
                    meeting_name: meetingName
                });
                reportState = {talk_start : 0, notalk_start:0, end_talk: 0, userid:''};
            }
        } catch (error) {
            util.log('panghaojie', 'video-session-container.js', 'leaveMeeting-catch',error);
        }
        util.yachLocalStorage.ls('zoom_login', '');
    }

    render() {
        return (
            this.props.videoSessioneModal.show ? (
                <div
                    className={css.mask}
                    onClick={this.closeCard}
                    onMouseDown={e => {
                        e.nativeEvent.stopImmediatePropagation();
                    }}
                >
                    <div className={css.box} onClick={e => e.stopPropagation()}>
                        <div className={css.close} onClick={this.closeCard}>
                            <span className="iconfont iconguanbi"/>
                        </div>
                        <div className={css.content}>
                            {/* <span className="iconfont iconchuangjianmianbanicon"/> */}
                            <Input
                                className={css.txt}
                                autoFocus={true}
                                value={this.state.textInputValue}
                                onChange={this.textareaValue}
                                // disabled={(this.props.sessionActive.type==='team'&&this.props.teamType.type!=0&&this.props.teamType.type!=1001)|| this.props.teamType === 'schedule'?true:false}
                                disabled={(window.session_active.type==='team'&&this.props.teamType.type!=0&&this.props.teamType.type!=1001)|| this.props.teamType === 'schedule'?true:false}
                             />
                            <Button type="primary" disabled={!this.state.textInputValue} onClick={this.startSession} loading={this.state.loading}>{util.locale('common_team_msg37')}</Button>
                            <div className={css.media}>
                              <span className={this.state.isaudiooff?css.yuyinquxiao:css.yuyin} onClick={this.setAudioOff}>
                                <span className={this.state.isaudiooff?`iconfont-yach yach-faqihuiyi_yuyinquxiao ${css.yuyinquxiaohandle}`
                                    :`iconfont-yach yach-faqihuiyi_yuyin ${css.yuyinhandle}`}></span>
                              </span>
                              <span className={this.state.isvideooff?css.shipinquxiao:css.shipin} onClick={this.setVideoOff}>
                                  <span className={this.state.isvideooff?`iconfont-yach yach-faqihuiyi_shipinquxiao ${css.shipinquxiaohandle}`
                                      :`iconfont-yach yach-faqihuiyi_shipin ${css.shipinhandle}`}></span>
                              </span>
                            </div>
                        </div>
                    </div>
                </div>
            ):null  
        );
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
        videoSessioneModal: state.videoSessioneModal,
        // sessionActive: state.sessionActive
    };
};

export default connect(
    mapStateToProps,
    null
)(withRouter(VideoSessione));
