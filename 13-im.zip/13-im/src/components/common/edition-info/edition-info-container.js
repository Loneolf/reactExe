import React from 'react';
import {withRouter} from 'react-router';
import {connect} from 'react-redux';
import {edtionInfohide} from '@r/actions/edition';
import css from './index.scss';
import * as util from '@u/util.js';

// services
import { checkVersion } from '@s/admin/admin-check.js';
import { message } from 'antd';

// debounce
import debounce from 'lodash/debounce';

class EditionInfo extends React.Component {
    constructor(props) {
        super(props);

        this.state = {version: '0.0.1', link: null};
    }

    componentDidMount(){
        this.clickCheckVersion = debounce(this.clickCheckVersion, 300);
        util.electronipc.getVersion(async (v) => {
            this.checkVersionFn(v);
        });
    }

    checkVersionFn = async(v, tag) => {
        let clientType = 3;
        if(util.electron.isElectron() && util.electron.isMac()) clientType = 3;
        if(util.electron.isElectron() && util.electron.isWin()) clientType = 4;
        if(util.electron.isElectron() && util.electron.isLinux()) clientType = 5;
        this.setState({version: v});

        let s = await checkVersion({version: v, client_type: clientType});
        if(!s || s.code != 200) return;

        if (s.obj && s.obj.version) {
            if (s.obj.isUpdate) {
                this.setState({link: s.obj.link});
                const parms = {
                    detail: s.obj.content,
                    forcedUpgrade: false,
                    link: s.obj.link,
                    version: s.obj.version,
                    isIncre: s.obj.isIncre,
                    diff_package_link: s.obj.diff_package_link,
                }
                !!tag && util.electronipc.electronVersionWindowOpen(parms);
            } else {
                !!tag && message.info({ content: util.locale('common_info'), key: 'checkVersionFn'});
            }
            // tag?s.data.forcedUpgrade?util.electronipc.electronVersionWindowOpen(parms):'':'';
        }
    }

    closeCard = () => {
        this.props.dispatch(edtionInfohide());
    };

    download = () => {
        window.open(this.state.link);
    };

    clickCheckVersion = () => {
        const{version, link} = this.state;
        // if(link) {
        //     this.download();
        // }else{
        //     this.checkVersionFn(version, 1);
        // }
        this.checkVersionFn(version, 1);
    }
    render() {
        const {version, link} = this.state
        const downloadDiv =
            <div className={css.btn}>
                <span className={util.locale.getLang() === 'en-US' ? css.usWidth : ''} onClick={this.clickCheckVersion}>
                    {link ? util.locale('common_info1') : util.locale('common_info2')}
                </span>
            </div>;

        return (
            <div
                className={css.mask}
                onClick={this.closeCard}
                onMouseDown={e => {
                    e.nativeEvent.stopImmediatePropagation();
                }}
            >
                <div
                    className={css.box}
                    onClick={e => e.stopPropagation()}
                >
                    <div className={css.close} onClick={this.closeCard}>
                        <span className="iconfont iconguanbi"/>
                    </div>
                    <div className={css.body}>
                        <img src={require('@a/imgs/editioninfo-logo.png')} alt=""/>
                        <p>{util.locale("common_yach")}</p>
                        <div className={css.editionNum}>{util.locale("common_info3")}：<span>{version}</span></div>
                        { downloadDiv }
                        <div className={css.bottom}>
                            <span>
                                <a href="https://yach.zhiyinlou.com/version" target="_blank">{util.locale("common_topic12")}</a>
                            </span>
                            <span>
                                <a href={util.config.agreement} target="_blank">{util.locale("common_info5")}</a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

        );
    }
}

const mapStateToProps = state => {
    return {
        userPanel: state.userPanel
    };
};

export default connect(
    mapStateToProps,
    null
)(withRouter(EditionInfo));
