/*
 * @Descripttion: @人模型
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-08-04 13:43:58
 * @LastEditors: olei<wangzheng_jzb@100tal.com>
 * @LastEditTime: 2020-08-11 10:45:57
 */
import React, { Component } from 'react';

// util
import * as util from '@u/util.js';
// debounce
import debounce from 'lodash/debounce';
// @人
import UserAdd from '@c/common/user-add/user-add-container';

import { message } from 'antd';

export default class AtPeople extends Component {
  constructor(props) {
    super(props)
    this.state = {
      // 选人组件开关
      showForwardModal: false
    }
    this.clearAllName = debounce(this.clearAllName, 100, {
      'leading': true,
      'trailing': false
    });
    // this.modifyIndex = debounce(this.modifyIndex, 0);
  }
  
  componentDidMount () {
    this.pTextArea = document.querySelector(`#${this.props.areaId}`)
    // ----------------  @人 获取焦点  -----------------
    this.pTextArea.addEventListener('click', this.handlerMoveAt)
    this.pTextArea.addEventListener('keydown', e => {
      this.isDeleteTextAreaValue = e.keyCode === 8
      delete this.saveIndex
    })
    const keys = [38, 39, 40]
    this.pTextArea.addEventListener('keyup', e => {
      if (e.keyCode === 37) {
        this.handlerMoveAt(e, true)
      } else if (keys.includes(e.keyCode)) this.handlerMoveAt(e)
    })
  }

  componentDidUpdate (pre) {
    if (!this.props.commentText.trim()) {
      delete this.usersInfo
    }
    if (pre.commentText != this.props.commentText) {
      this.diffContent(pre.commentText, this.props.commentText);
    }
  }

  // --------------  选人 start --------------------

  textareaFocus() {
    this.pTextArea && this.pTextArea.focus()
  }

  // 焦点移出@人
  handlerMoveAt = (e, direction = false) => {
    if (!this.usersInfo || !this.usersInfo.length) return
    const posit = this.getCursorPosition()
    this.usersInfo.forEach(user => {
      const i = [user.index, user.index + user.name.length + 1]
      if (posit <= i[1] && posit > i[0]) {
        this.setCursorPosition(direction ? user.index : (user.index + user.name.length + 2), e)
      }
      delete user.oldIndex
    })
  }

  //监听变化后做diff算法
  diffContent = (_old, _new) => {
    let insertAt = false;
    let diffArr = util.diff(_old, _new);

    if (_new == '@') {
        insertAt = 'insert';
    }

    if (diffArr && diffArr.length) {
        if (diffArr.find((v) => v[0] == util.diff.INSERT && v[1].trim(' ') == '@')) {
            insertAt = 'insert';
        }
        if (diffArr.find((v) => v[0] == util.diff.DELETE && v[1].trim(' ') == '@')) {
            insertAt = 'delete';
        }
        this.dataAll = diffArr;
    }
    if (this.isDeleteTextAreaValue || (_old.length - _new.length > 0)) {
      this.clearInpUser(_old, _new)
    } else this.modifyIndex(_old, _new)
    // console.log('wangzheng -----> 0', _old.length - _new.length)

    if (insertAt == 'insert' && this.props.disabledids.length < 50) {
      this.closegetUser(true)
    } else if (insertAt == 'insert') {
      message.error(util.locale('circle_at_exceeded'))
    }
  };
  // 增加文字修改下标

  modifyIndex = (_old, _new, stop) => {
    const posit = this.getCursorPosition()
    let Len = _new.length - _old.length
    if (!this.usersInfo || !this.usersInfo.length) {
      if (stop) return
      setTimeout(() => {
        this.modifyIndex(_old, _new, true)
      }, 0)
      return
    }
    this.usersInfo.forEach(user => {
      const i = [user.index, user.index + user.name.length]
      // 计算位置 开始
      if (i[0] >= (this.saveIndex || posit) - Len && user.isAfter) {
        user.index += Len
      }
      user.isAfter = true
      // 计算位置 结束
    })
  }

  // 清除全名
  clearAllName = (s, e) => {
    const text = this.props.commentText
    const value = text.substr(0, s) + text.substr(e + 1)
    this.props.handleInputChange({ target: { value } })
    this.setCursorPosition(s)
  }

  // 清除@人
  clearInpUser = (_old, _new) => {
    const posit = this.getCursorPosition()
    const delLen = _old.length - _new.length
    const delUsers = []
    let allNameLen = 0
    this.usersInfo ? this.usersInfo.forEach(user => {
      const i = [user.index, user.index + user.name.length + 1]
      if (posit <= i[1] && posit >= i[0] || posit + delLen > i[0] && posit <= i[0]) {
        delUsers.push(user.id)
        // TODO 清除全名定位有问题
        if (delLen > 1) return
        this.clearAllName(i[0], posit - delLen)
        allNameLen = (posit - delLen - i[0]) + 1
      }
      // 计算位置
      if (i[0] >= posit + delLen) {
        user.index -= (delLen + allNameLen)
      }
    }) : this.props.handlerAtDisabledids([])

    if (delUsers.length) {
      this.usersInfo = this.usersInfo.filter(user => !delUsers.includes(user.id))
      const ids = this.usersInfo.map(user => user.id)
      // this.disabledids = this.props.disabledids.filter(id => ids.includes(id))
      this.props.handlerAtDisabledids(this.props.disabledids.filter(id => ids.includes(+id)))
      this.props.handlerUserInfo(this.usersInfo)
    }
  }

  // 获取光标位置
  getCursorPosition = () => {
    if (!this.pTextArea) return 0
    try {
      let cursurPosition = -1
      if (this.pTextArea.selectionStart) {
        // 非IE浏览器
        cursurPosition = this.pTextArea.selectionStart
      } else {
        // IE
        let range = document.selection.createRange()
        range.moveStart('character', -this.pTextArea.value.length)
        cursurPosition = range.text.length
      }
      return cursurPosition
    } catch(e) {
      return 0
    }
  }

  // 设置光标位置
  setCursorPosition = (index, elem) => {
    let val = elem ? elem.target.value : this.pTextArea.value
    let len = val.length
    if (len < index) return
    setTimeout(() => {
      elem ? elem.target.setSelectionRange(index, index) : this.pTextArea.setSelectionRange(index, index)
    }, 0)
}

  // 获取所选用户
  getUsers = (value) => {
    // Array.prototype.push.apply(this.disabledids, value.users.map(user => user.id))
    const users = util.yach.orderUser(value.users, value.allDataUsers)
    this.props.handlerAtDisabledids(this.props.disabledids.concat(users.map(user => user.id + '')))
    this.closegetUser(false)
    this.addUsers([...users], this.getCursorPosition())
  }

  // 添加@人
  addUsers = (users, posit) => {
    if (!users.length) return
    this.setUserIndex(users, posit)
    let membersStr = '', len = 0
    users.forEach((x, i) => {
      membersStr += (!!i ? '@' : '') + x.name + ' '
      len = membersStr.length
    })
    this.saveIndex = posit + len
    const isAdd = this.props.handleInputChange({ target: { value: this.props.commentText.slice(0, posit) + membersStr + this.props.commentText.slice(posit) } })
    if (!isAdd) return
    this.textareaFocus()
    this.setCursorPosition(posit + len)
    if (!this.usersInfo) this.usersInfo = [...users]
    else Array.prototype.push.apply(this.usersInfo, users)
    this.props.handlerUserInfo(this.usersInfo)
  }

  // 获取用户下标
  setUserIndex = (users, posit) => {
    if (!users.length) return
    posit--
    users.forEach(user => {
      user.index = posit
      posit += user.name.length + 2
    })
  }

  // 关闭选人组件
  closegetUser = (stauts) => {
    this.setState({showForwardModal: stauts})
  }

  // --------------  选人 end --------------------

  render() {
    const forwardMsgProps = {
      show: this.state.showForwardModal,
      onOk: this.getUsers,
      onClose: () => { this.closegetUser(false) },
      title: util.locale('common_team_msg26'),
      rightTitle: util.locale('media_recent_chat'),
      showButtonNumber: true,
      disabledids: this.props.disabledids,
      maxLength: 50
    };
    return (
      <>
        <UserAdd {...forwardMsgProps} />
      </>
    )
  }
}
