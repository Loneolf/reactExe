import React from 'react';
import {connect} from 'react-redux';

import DefalutAccepters from './defalut-accepters';
import {getDefaultAccept, getDefaultAcceptWindow} from '@s/record/record-write';
import {logDetailGet} from '@s/record/record-read'

class DefalutAcceptersContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            defaultAcceptersList:[],
            updateList:[],
            leader:[],
            lower:[],
            level:[],
            core:[],
            spinning:true,//优化增加Spin加载中loading 状态
        };

    }
    componentDidMount() {
        //this.setUsersList();
        //this.callback = debounce(this.callback, 500);
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.show != this.props.show) {
            this.clear();
            console.log("this.props.recordWriteModifyid",this.props.recordWriteModifyid)
            if ( this.props.show && this.props.recordWriteModifyid) {
                //修改
                this.getRecordDetail(this.props.recordWriteModifyid)

            }else{
                //新写周报
                this.props.show && this.getDefaultAcceptersList()
            }

        }
    }
    getRecordDetail = async id => {
        if (!id) return false
        let data = await logDetailGet({ log_id: id })
        if (data && data.code == 200) {
            //updateList
            this.setState({
                defaultAcceptersList:data.obj.report_user_infos,
                updateList: data.obj.report_user_infos,
                core:data.obj.default_receive_user_info,
                spinning:false
            });

        }
    }
    //打开用户面板
    openUserPanel = user => {
        let userData = {
            type: 'user-panel',
            user
        }
        window.parent.postMessage(userData, '*')
    };
    // 打开用户窗口
    openAcceptUser = (chat, v) => {
        chat.id = chat.id || chat.user_id
        this.openUserPanel(chat)
    }
    //获取默认接受人
    getDefaultAcceptersList = async() =>{
        let defaultAcceptersLists = await getDefaultAcceptWindow();
        if (defaultAcceptersLists && defaultAcceptersLists.code == 200) {
            this.setState({
                defaultAcceptersList:defaultAcceptersLists.obj.higher_user_info,
                leader: defaultAcceptersLists.obj.higher_user_info,
                lower: defaultAcceptersLists.obj.my_report_employee_user_info,
                level: defaultAcceptersLists.obj.same_level_user_info,
                core: defaultAcceptersLists.obj.default_receive_user_info,
                spinning:false
            });
        }
    }
    //获取默认接受人
    getAcceptersList = (str,v) =>{
        switch(str) {
            case 'leader':
                this.setState({
                    defaultAcceptersList:this.state.leader
                });
                console.log("leader",this.state.defaultAcceptersList);
                break;
            case 'lower':
                this.setState({
                    defaultAcceptersList:this.state.lower
                });
                console.log("lower",this.state.defaultAcceptersList);
                break;
            case 'level':
                this.setState({
                    defaultAcceptersList:this.state.level
                });
                break;
            case 'core':
                this.setState({
                    defaultAcceptersList:v.receive_user_infos
                });
                break;
            case 'all':
                this.setState({
                    defaultAcceptersList:this.state.updateList
                });
                break;
            default:
                this.setState({
                    defaultAcceptersList:this.state.leader
                });
        }
    }
    //清除数据
    clear = () => {
        this.setState({
            currList: [],
            groupName: '',
            textareaValue: '',
            defaultAcceptersList:[],
            updateList:[],
            leader:[],
            lower:[],
            level:[],
            core:[],
            spinning:true,
        });
    };

    render() {
        const props = {
            ...this.state,
            closeFn: this.props.closeFn,
            getDefaultAcceptersList: this.getDefaultAcceptersList,
            getAcceptersList: this.getAcceptersList,
            openAcceptUser:this.openAcceptUser,
        };
        return this.props.show && <DefalutAccepters {...props} />;
    }
}

const mapStateToProps = state => ({
    sessionList: state.sessionList,
    recordWriteModifyid: state.recordWriteModifyid,
});

export default connect(mapStateToProps)(DefalutAcceptersContainer);
