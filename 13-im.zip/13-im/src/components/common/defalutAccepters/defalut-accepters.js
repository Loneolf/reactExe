import React from 'react'

import styles from './index.scss'
import {Menu, Spin} from 'antd'

import * as util from '@u/util.js'
export default props => (
    <div className={styles.defaultAcceptersBox}>
        <Spin tip="Loading..." spinning={ props.spinning}>
            <div className={styles.close} onClick={props.closeFn}>
                <span className={styles.iconCss+ ' ' + 'iconfont iconguanbi3'}></span>
            </div>

            <div className={styles.header}>{util.locale('common_accepter1')}</div>
            <div className={styles.line}></div>

            <div className={styles.content}>
                <div className={styles.contentleft}>
                    <Menu theme="light" mode="inline" defaultSelectedKeys={['1']}>
                        { props.updateList.length >0 &&
                        <Menu.Item key="1" onClick={()=>{props.getAcceptersList('all')}}>
                            <span className={styles.menuTitle}>{util.locale('common_accepter2')}</span>
                            <span className={`iconfont iconyoujiantou ${styles.iconCss}`}></span>
                        </Menu.Item>
                        }
                        { props.leader.length >0 &&
                        <Menu.Item key="1" onClick={()=>{props.getAcceptersList('leader')}}>
                            <span className={styles.menuTitle}>{util.locale('common_accepter5')}</span>
                            <span className={`iconfont iconyoujiantou ${styles.iconCss}`}></span>
                        </Menu.Item>
                        }

                        {props.lower.length > 0 &&
                        <Menu.Item key="2" onClick={() => {props.getAcceptersList('lower')}}>
                            <span className={styles.menuTitle}>{util.locale('common_accepter4')}</span>
                            <span className={styles.iconCss+ ' ' + 'iconfont iconyoujiantou'}></span>
                        </Menu.Item>
                        }
                        {props.level.length > 0 &&
                        <Menu.Item key="3" onClick={() => {props.getAcceptersList('level')}}>
                            <span className={styles.menuTitle}>{util.locale('common_accepter3')}</span>
                            <span className={styles.iconCss+ ' ' + 'iconfont iconyoujiantou'}></span>
                        </Menu.Item>
                        }

                        {props.core.length > 0 && props.core.map((v,index) => (
                            <Menu.Item key={v.rule_name} onClick={() => {props.getAcceptersList('core',v)}}>
                                <span className={styles.menuTitle}>{v.rule_name}</span>
                                <span className={styles.iconCss+ ' ' + 'iconfont iconyoujiantou'}></span>
                            </Menu.Item>
                        ))
                        }

                    </Menu>

                </div>
                <div className={styles.contentmiddle}>

                    <div className={styles.accept}>
                        {props.defaultAcceptersList && props.defaultAcceptersList.length ? (
                            <>
                                <div className={styles.userlist}>
                                    <div className={styles.list}>
                                        <div className={styles.listcontainer} ref={props.getAcceptRef}>
                                            {props.defaultAcceptersList.map(v => (
                                                <div  key={v.id} className={styles.item} onClick={props.openAcceptUser.bind(null, v)}>
                                                    <img src={v.pic} alt="" />
                                                    <span className={styles.name}>{v.name}</span>
                                                    <span></span>
                                                </div>
                                            ))}

                                        </div>
                                    </div>

                                </div>
                                <div>
                                </div>
                            </>
                        ) : null}


                    </div>
                    <div className={styles.tipshows}>
                        <span className={styles.titleTips}> {util.locale('common_accepter6')}</span>                        
                    </div>

                </div>
            </div>

        </Spin>



    </div>
)

