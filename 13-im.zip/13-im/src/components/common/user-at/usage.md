
# 该组件用于弹出 @ 某人列表


# 1. 引入

    import UserAt from '@c/common/user-at/user-at-container';

    <UserAt />


# 2. 参数

    input: 输入框的文本内容（string）

    id: 群id，不传则查全部

    callback: 回调，接收user对象


# 3. 例子

    <UserAt
        id={this.groupId}
        input={this.textInputValue}
        callback={this.getClickUser}
    />