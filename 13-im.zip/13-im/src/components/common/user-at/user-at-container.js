import React from 'react';
import {connect} from 'react-redux';

import * as util from '@u/util.js';

import UserAt from './user-at';

import {searchGpinusersearch, searchUserSearch} from '@s/search/search.js';
import {groupInfoGet} from '@s/group/group-info.js';
import debounce from 'lodash/debounce';

class UserAtContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            list: [],
            currIndex: 0
        };
        this.getUsersList = debounce(this.getUsersList, 200);
        this.userRefs = []
        this.getUserRef = (index, ref) => this.userRefs[index] = ref
        this.getUlRef = ref => this.ulRef = ref
    }
    windowClick = (event) => {
        const sendBox = document.querySelector('#sendBox');
        if(sendBox && !sendBox.contains(event.target)){
            this.closeUserList()  
        }
    }
    componentDidMount() {
        window.addEventListener('click', this.windowClick);
        window.addEventListener('keydown', this.keyDownHandle);
    }
    componentWillUnmount() {
        window.removeEventListener('click', this.windowClick);
        window.removeEventListener('keydown', this.keyDownHandle)
    }
    componentDidUpdate(prev) {
        if (prev.show != this.props.show) {
            if (this.props.show) {
                this.groupInfoGet();
                this.getUsersList(this.props.input);
            }
        }
        if (prev.input != this.props.input) {
            this.getUsersList(this.props.input)
        }
    }
    //按下按键
    keyDownHandle = e => {
        if (!this.props.show) return false
        let code = e.keyCode
        if (code == '38') {
            this.chooseLastUser()
        }
        if (code == '40') {
            this.chooseNextUser()
        }
        if (code == '13') {
            this.chooseCurrUser()
        }
    }
    //选择上一个用户
    chooseLastUser = () => {
        let length = this.state.list.length
        let currIndex = this.state.currIndex
        if (this.state.currIndex) {
            currIndex --
        } else {
            currIndex = length - 1
        }
        this.setState({ currIndex })
        let userDom = this.userRefs[currIndex]
        !this.checkDomIsView(userDom) && userDom.scrollIntoView(true)
    }
    //选择下一个用户
    chooseNextUser = () => {
        let length = this.state.list.length
        let currIndex = this.state.currIndex
        if (this.state.currIndex < length - 1) {
            currIndex ++
        } else {
            currIndex = 0
        }
        this.setState({ currIndex })
        let userDom = this.userRefs[currIndex]
        !this.checkDomIsView(userDom) && userDom.scrollIntoView(false)
    }
    //选择当前用户
    chooseCurrUser = e => {
        let currIndex = this.state.currIndex
        let user = this.state.list[currIndex]
        this.chooseUser(user)
    }
    //检查dom是否在可视区域
    checkDomIsView = dom => {
        if (!this.ulRef) return true
        let allHeight = this.ulRef.offsetHeight
        let scrollTop = this.ulRef.scrollTop
        let userTop = dom.offsetTop
        let userHeight = dom.offsetHeight
        if ((userTop + userHeight - scrollTop) > allHeight) {
            return false
        }
        if (userTop < scrollTop) {
            return false
        }
        return true
    }
    //获取群信息
    groupInfoGet = async() => {
        let GroupInfoGet = await groupInfoGet({
            // tid: this.props.sessionActive.id
            tid: window.session_active.id
        });
        if(GroupInfoGet.code == 200 && GroupInfoGet.obj) {
            this.setState({groupInfo: GroupInfoGet.obj});
            return;
        }
    }
    //获取权限
    getConfigEdite = () => {
        const { groupInfo } = this.state;
        if(groupInfo && groupInfo.config_at_all && groupInfo.config_at_all < 2){
            return groupInfo.user_type < 2;
        }
        if(groupInfo && groupInfo.config_at_all && groupInfo.config_at_all == 2) return true;
        return false;
    }

    //获取用户列表
    getUsersList = async q => {
        let data = null;
        if (this.props.id) {
            data = await this.searchGpinusersearch(q);
        } else {
            data = await this.getAllUsersList(q);
        }

        if (data && data.length>0) {
            data = data.map(v => ({
                id: v.id || v.user_id,
                name: v.name || v.user_name,
                pic: v.pic || v.user_pic,
                nick: v.name_nick,
                user_type: v.user_type
            }));
            if(this.props.atAll && this.getConfigEdite() && !q) {
                data.unshift({
                    id: '-1',
                    name: util.locale('common_all_people'),
                    pic: 'https://yach-static.zhiyinlou.com/web_static/all-people.png'
                })
            }
            this.setState({ list: data });
            this.props.showUserCB(true);
        } else {
            //this.clearUserList();
            //this.props.showUserCB(false);
            // 反正目前线上也是搜不到就searching false不触发at框了，那干脆关了呗
            // this.closeUserList()
            this.props.showUserCB(false);
        }
    };

    //查询所有用户
    getAllUsersList = async q => {
        let data = await searchUserSearch({
            querystr: q,
            page: 1,
            pagesize: 200,
            all: 'all',
            is_robot: 1
        });
        if (data && data.code == 200) {
            if (data.obj.list && data.obj.list.length) {
                return data.obj.list;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    };

    //查询群组用户
    searchGpinusersearch = async q => {
        let data = await searchGpinusersearch({ is_robot: 1, groupid: this.props.id, querystr:q, page:1, pagesize:1000  });
        if (data && data.code == 200) {
            if (data.obj.list) {
                let arr = [];
                arr = data.obj.list.filter(item => {
                    return item.id != this.props.userInfo.id;
                });
                return arr;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    };
    
    //关闭用户列表
    closeUserList = () => {
        this.clearUserList();
        this.props.close();
    };
    //清除用户列表
    clearUserList = () => {
        this.setState({
            list: [],
            currIndex: 0
        });
    };
    //选择用户后回调
    chooseUser = user => {
        this.props.callback(user, this.state.list);
        this.closeUserList();
    };
    render() {
        const props = {
            getUlRef: this.getUlRef,
            getUserRef: this.getUserRef,
            userAtList: this.state.list,
            currIndex: this.state.currIndex,
            chooseUser: this.chooseUser
        };
        return this.props.show ? <UserAt {...props} /> : null;
    }
}

const mapStateToProps = state => ({
    userInfo: state.userInfo,
    // sessionActive: state.sessionActive
});

export default connect(mapStateToProps)(UserAtContainer);
