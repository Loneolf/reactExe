import React from 'react';
import css from './index.scss';

// win7下按下左键文本框里光标会变，所以win7下改为mousedown(NT6包括vista，win7， win8；NT10包括win10；没有NT7)
const isWin7 = window.navigator.userAgent.indexOf("Windows NT 6") != -1

export default props => !!props.userAtList.length && (
    <div className={css.box}>
        <ul ref={props.getUlRef}>
            {props.userAtList.map((user, index) => (
                <li
                    ref={props.getUserRef.bind(null, index)}
                    key={user.id}
                    onMouseDown={isWin7 ? props.chooseUser.bind(null,user) : () => {}}
                    onClick={!isWin7 ? props.chooseUser.bind(null,user) : () => {}}
                    className={`${props.currIndex == index ? css.active : '' } ${props.userAtList.length > 7 ? css.liScroll : ''}`}
                >
                    <img src={user.pic} alt="" />
                    <span>
                        {user.name}
                        {!!user.nick && '(' + user.nick + ')'}
                    </span>
                </li>
            ))}
        </ul>
    </div>
)
