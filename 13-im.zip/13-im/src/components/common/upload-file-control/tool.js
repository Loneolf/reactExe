import {fileInfoSave} from '@s/file/file-info';
import { fileUpdateRevoke } from '@s/file/file-update';
import { robotMessageAPI } from '@s/robots';

import * as util from '@u/util.js';
export const getType = ext => {
    if(ext == 'doc' || ext == 'docx') {
        return 'word';
    }
    else if (/msword|vnd.openxmlformats-officedocument.wordprocessingml.document/i.test(ext)) {
       return 'word';
    }
    if(ext == 'xls' || ext == 'xlsx') {
        return 'excel';
    }
    else if(/spreadsheet|x-excel|vnd.ms-excel|vnd.openxmlformats-officedocument.spreadsheetml.sheet/i.test(ext)) {
        return 'excel';
    }
    if(ext == 'ppt' || ext == 'pptx') {
        return 'ppt';
    }
    else if(/powerpoint|ms-powerpoint|vnd.openxmlformats-officedocument.presentationml.presentation|vnd.openxmlformats-officedocument.presentationml.slideshow/i.test(ext)) {
        return 'ppt';
    }
    if(/pdf/i.test(ext)) {
        return 'pdf';
    }
    if(/png|jpg|bmp|jpeg|gif|svg|wmf|jpe|ico|pic|tiff|pjpeg|jfif|pjp/i.test(ext)) {
        return 'image';
    }
    if(/wmv|asf|asx|rm|rmvb|mp4|3gp|mov|m4v|avi|dat|mkv|flv|vob|rn-realmedia|mid/i.test(ext)) {
        return 'video';
    }
    return 'other';
}

// 获取push内容
export const getPushObj = (fileText, sessionActive) => {
    const { userInfo } = window.store.getState()
    const { name, name_nick } = userInfo;
    if (!sessionActive) return;
    let pushContent = '',
        pushPayload = {};
    if (sessionActive.type == 'team') {
        pushContent = `${name}${name_nick ? '(' + name_nick + ')' : ''}: ${fileText}`;
        pushPayload = {
            pushTitle: util.yach.decodeUnicode(sessionActive.showname),
            sessionType: 1,
            sessionID: sessionActive.id,
        };
    } else {
        pushContent = `${fileText}`;
        pushPayload = {
            pushTitle: util.yach.decodeUnicode(name_nick || name),
            sessionType: 0,
            sessionID: sessionActive.id,
        };
    }
    return { pushContent, pushPayload };
};

export const saveFileData = async(data)=>{
    const {fileurl, type, filename, size, sessionActive, groupFileUpload} = data
    const ext = fileurl.slice(fileurl.lastIndexOf('.') + 1);
    let mime = ''
    if(type == 'image'){
        mime = 'image/' + ext
    }else if(type == 'video'){
        mime = 'video/' + ext
    }else{
        mime = 'file/' + ext
    }
    let params = {
        file_url: fileurl,
        file_name: filename,
        file_size: size,
        file_mime: type === 'dir'? 'file/folder':mime,
        file_extension: type === 'dir'? 'folder':ext,
        source: sessionActive.type == 'team' ? 'group' : 'person',
        receive_type: sessionActive.type == 'team' ? 0 : 1,
        receive_id: sessionActive.id,
        is_dir:type === 'dir'? 1:0,
        type: 1,
    }
    if(groupFileUpload){
        //群文件上传逻辑处理
        const { parent_relation_id, is_send_msg} = data
        params.type = 2;
        params.parent_relation_id = parent_relation_id;
        params.is_send_msg = is_send_msg
    }
    if(data.ext) params.ext = JSON.stringify(data.ext)
    if(data.hasOwnProperty('processMedia')) params.processMedia = data.processMedia
    if(data.hasOwnProperty('duration')) params.duration = data.duration
    if(data.hasOwnProperty('width')) params.width = data.width
    if(data.hasOwnProperty('height')) params.height = data.height
    const savedata = await fileInfoSave(params)
    return savedata;
}

export  const updateRelationId = (relation_id, msg_id,type) =>{
    let is_dir = type == 26 ?1 :0;
    fileUpdateRevoke({relation_id, msg_id,is_dir});
}

export const robotMessage = async(type, sessionActive, sendCustomMsgData) => {
    if(sessionActive.type != 'p2p' || !window.store.getState().chatRobot) return;

    const content = util.nimUtil.getJson(sendCustomMsgData.content);
    const { data = {} } = content;
    
    let originName = null;
    let contentValue = null;

    if(type == "image" || type == "file"){
        contentValue = data.fileOriginUrl;
        originName = data.fileName;
    } 
    if(type == "video") {
        // content = sendCustomMsgData.file ? sendCustomMsgData.file.url :null;
        contentValue = data.url;
        originName = data.fileName;
    }

    util.log('zhangpeng', 'box-send-fn', '私聊发送图片');

    if(contentValue) {
        await robotMessageAPI({
            msgtype: type, //image video file
            content: contentValue,
            create_at: sendCustomMsgData.time,
            conversation_type: 1,
            conversation_id: sendCustomMsgData.to,
            corp_id: window.store.getState().userInfo.cp_id || 1,
            msg_id: sendCustomMsgData.idServer,
            origin_name: originName,
        })
    }
}
export const yunxinSendFile = ({
    scene, 
    to, 
    file, 
    pushPayload,
    yunxinBeginupload,
    yunxinUploadprogress,
    yunxinUploaddone,
    yunxinBeforesend
    }) => {
    const { userInfo } = window.store.getState();
    let type = 'video',
        sendObjFile = {},
        sendObj = {},
        pushContent = '',
        pushContentText = `[${util.locale('common_video')}]`;
        sendObjFile = {
            blob: file
        }
        if (scene == 'team') {
            pushContent = `${userInfo.name}: ${pushContentText}`;
        } else {
            pushContent = pushContentText;
        }
    sendObj = Object.assign(sendObjFile, {
        needMsgReceipt: scene == 'team',
        scene: scene,
        to: to,
        type: type,
        pushContent: pushContent || '',
        needPushNick: false,
        isPushable: to == util.yach.getAccount() ? false : true,
        pushPayload: JSON.stringify(util.yach.handlePushPayload({pushPayload}) || {})
    })
    return new Promise(function (resolve, reject) {
        window.nim.sendFile(Object.assign(sendObj, {
            beginupload: yunxinBeginupload,
            uploadprogress: yunxinUploadprogress,
            uploaddone: yunxinUploaddone,
            beforesend: yunxinBeforesend,
            done: function (err, msg) {
                return err ? reject(err) : resolve(msg);
            }
        }));
    });
}