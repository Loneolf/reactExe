import React from 'react';
import { connect } from 'react-redux';

//util
import * as util from '@u/util.js';
import {
    getPushObj,
    saveFileData,
    updateRelationId,
    robotMessage,
    yunxinSendFile,
} from './tool';
import {batchForward} from '@u/lib/tools/file-forward.js'


import * as fileRedux from '@/redux/actions/file';
//redux
import * as messageListAction from '@r/actions/messageList';
import * as messageUploadAction from '@r/actions/messageListUploadState';
import * as sessionUploadFileAction from '@r/actions/sessionUploadFile';

//antd
import { message } from 'antd';

//components
export class UploadFileControlContainer extends React.Component {
    constructor(props) {
        super(props);
    }
    componentDidMount = () => {
        //initIndexedDB();
    }
    componentDidUpdate = (pre) => {
        const { uploadFileState, sessionUploadFile} = this.props;
        const { needUploadArray } = uploadFileState;
        //会话中上传文件
        if (needUploadArray.length > pre.uploadFileState.needUploadArray.length) {
            const array = [...needUploadArray];
            const msg = uploadFileState[array.pop()];
            if (msg && msg.status == 'uploadStart') {
                this.upload(msg);
            }
        }
        // 会话文件列表上传文件
        this.checkSessionUploadFileState(sessionUploadFile, pre)
    };

    checkSessionUploadFileState = (sessionUploadFile, pre) => {
        const {uploadArray} = sessionUploadFile
        const {uploadArray: preUploadArray} = pre.sessionUploadFile
        
        if(uploadArray.num > preUploadArray.num){
            const  array = [...uploadArray.list]
            const {sessionId, id} = array.pop()
            const msg = sessionUploadFile[sessionId][id]
            if(msg && ['uploadStart', ''].includes(msg.status)) this.upload(msg, id);
        }
    }
    upload = async (params, id) => {
        // console.log('upload-log', 'uploadstart', params, this.props.sessionActive.id);
        const { sessionActive, custom } = params.actionData;
        const { idClient,foldRelationId } = params;
        const { data: fileinfo } = custom;

        if (!util.yach.getSwitchState() && fileinfo.type === 'video') return this.uploadAndSendByYunXin(params);

        let uploadParm = {
            filepath: fileinfo.path,
            filename: fileinfo.name,
            filebase64: fileinfo.base64,
            //costype: fileinfo.type == 'image' ? 'image' : fileinfo.type == 'video' ? 'file' : 'security',
            costype: fileinfo.type === 'image' || fileinfo.type === 'video' ? 'image' : 'security',
            project: sessionActive.type == 'team' ? 'group' : 'person',
            filetype: fileinfo.type,
            size: fileinfo.size || 0,
            foldRelationId
        };

        let limitBase64 = await util.imageDealer.resetImageLimitBase64(fileinfo.path, 5000);
        if (limitBase64) uploadParm.filebase64 = limitBase64;
        if (fileinfo.type == 'dir') {
            uploadParm = { ...uploadParm, size: fileinfo.size || 0 };
        }

        util.electronipc.electronFileUpload(
            uploadParm,
            async (res) => {
                // console.log('upload-log', 'res', this.props.sessionActive.id, res);
                //util.log('upload-log','res',this.props.sessionActive.id);
                const { error, errobj } = res;
                if (fileinfo.type === 'dir' && errobj && errobj.code == 'ENOENT') {
                    message.error(this.locale('im_file_uoliad_dir_file_deleted').replace('[xxx]', errobj.name));
                }
                // 上傳失敗
                if (res.error) {
                    message.error(this.locale('im_uploading_error_text_0') + error);
                }
                this.uploadSuccess(res, params, id);
                util.log('qiuyanlong', 'yach-im', 'upload:success', idClient, id);
            },
            (res) => {
                this.progress(res, params, id);
            }
        );
    };
    updateSessionUploadFile = ({id, sessionActive, data, status}) => {
        this.props.sessionUploadFileUpdate({
            operation: 'update',
            id,
            sessionActive,
            data:{
                [id]:{
                    status,
                    ...data
                }
            }
        })
    }
    sessionUploadFileSucess = async({id, sessionActive, data, isSession}) => {
        const {fileData} = data
        if(fileData.error){
            this.updateSessionUploadFile({id, sessionActive, status:'uploadFail', data:{}})  
            return
        }
        if(fileData.abort){
            this.updateSessionUploadFile({id, sessionActive, status:'uploadAbort', data:{}})
            return
        }
        if(this.props.sessionUploadFile[sessionActive.id] && this.props.sessionUploadFile[sessionActive.id][id] && !isSession){
            const groupFileUploadData = this.props.sessionUploadFile[sessionActive.id][id]
            const {needBell, foldRelationId} = groupFileUploadData
            //数据上传组件里处理过的，可以直接使用
            const { type, size,dur,width,height } = groupFileUploadData.actionData.custom.data;
            //发送消息的逻辑
            const saveFileDataParams = {
                fileurl: fileData.fileurl,
                type: type,
                filename: fileData.filename,
                size: size,
                sessionActive: sessionActive,
                groupFileUpload: true,
                parent_relation_id: foldRelationId || 0,
                is_send_msg: (!isSession && needBell) ? 1 : 0
            };
            const groupFileType = groupFileUploadData.actionData.custom.type
            if (groupFileType == 30) {
                saveFileDataParams.duration = dur || 0;
                saveFileDataParams.processMedia = 1;
                saveFileDataParams.processMediaId = 20;
                saveFileDataParams.width = width || 0;
                saveFileDataParams.height = height || 0;
            }
            if(groupFileType == 8) {
                saveFileDataParams.ext = {
                    width:  width || 0,
                    height: height || 0
                }
            }
            const saveFileDataRes = await saveFileData(saveFileDataParams);
            if(saveFileDataRes && saveFileDataRes.code == 200 && saveFileDataRes.obj){
                const { move_to_root } = saveFileDataRes.obj
                if(move_to_root){
                    message.warning(this.locale('im_group_file_input_upload_deleted').replace('[xxx]',sessionActive.showname || '').replace('[yyy]',fileData.filename || ''));
                }

                // 发送消息逻辑
                if(!isSession && needBell){
                    // videoInfo: videoPic,transformation,duration,
                    const {receive_id,relation_id,file_info:{file_name,file_size,file_id,file_url,file_extension},videoInfo={}}=saveFileDataRes.obj;
                    await batchForward({
                        targetObj:{
                            teams:[{group_tid:receive_id}],
                            teamids:[receive_id]
                        },
                        fileObj:{
                            size:file_size, fileUrl:file_url, relation_id, file_extension ,file_name,
                            width,height,
                            ...videoInfo
                        },
                        type:'message',
                        shareObj:{
                            group:[{file_name,file_id,relation_id,receive_id}]
                        }
                    });
                }
            }
        }
        this.props.sessionUploadFileUpdate({
            operation: 'success',
            sessionActive,
            id,
            data
        })
        //刷新当前列表数据
        util.eventBus.emit('group-file-list-refresh');
    }
    uploadSuccess = (res, params, id) => {
        // console.log(
        //     'upload-log',
        //     'uploadSuccess',
        //     this.props.sessionActive.id,
        //     res,
        //     params,
        //     this.props.uploadFileState
        // );
        const {sessionActive} = params.actionData;
        let fileData = { ...res };
        if(id){//会话文件列表
            this.sessionUploadFileSucess({id, sessionActive, data:{fileData}})
            
            return;
        } 
        if (!this.props.uploadFileState[params.idClient]) {
            console.log('upload-log', 'uploadSuccess', 1);
            return;
        }
        if (res.error) {
            this.uploadFail(params.idClient);
            this.updateSessionUploadFile({id: params.idClient, sessionActive, status:'uploadFail', data:{}})  
            fileData = null;
            return;
        }
        this.uploadUpdate({ idClient: params.idClient, status: 'uploadSuccess', data: { fileData } });
        //更新会话文件列表
        this.sessionUploadFileSucess({id: params.idClient, sessionActive, data:{fileData},isSession: true})
        //this.updateSessionUploadFile({id: params.idClient, sessionActive, status:'uploadSuccess', data:{fileData}})  
        if (fileData) {
            console.log('upload-log', 'uploadSuccess', 2);
            this.sendMessage(params, res);
        }
    };

    progress = (res, params, id) => {
        const { sessionActive } = params.actionData;
        const {idClient} = params;
        const progress = {
            ...res.processdata,
            channelid: res.channelid,
        };
        !id && this.uploadUpdate({ idClient, status: 'uploading', data: { progress } });
        this.updateSessionUploadFile({id: id || idClient, upadteExisted:true, sessionActive, status:'uploading', data:{progress}})  

    };

    uploadFail = (idClient) => {
        this.props.updateState({
            operation: 'update',
            idClient,
            data: {
                status: 'uploadFail',
            },
        });
    };
    uploadUpdate = ({ idClient, status, data }) => {
        //console.log('upload-log','uploadUpdate 修改上传文件数据',idClient, status, data);
        this.props.updateState({
            operation: 'update',
            idClient: idClient,
            data: {
                status,
                ...data,
            },
        });
    };

    deleteLocalCustomMessage = (params) => {
        //console.log('upload-log','开始删除本地消息拉',this.props.sessionActive.id, params);
        this.props.delLocalMessage(params);
    };

    getSendContent = async (filedata) => {
        let result = {},
            pushtext;
        //获取relationId
        const saveFileDataParams = {
            fileurl: filedata.fileurl,
            type: filedata.data.type,
            filename: filedata.filename,
            size: filedata.size || filedata.data.size,
            sessionActive: filedata.sessionActive,
        };
        if (filedata.type == 30) {
            const { filename, data = {} } = filedata;
            const ext = (filename && filename.substring(filename.lastIndexOf('.') + 1).toLowerCase()) || '';
            saveFileDataParams.duration = data.dur || 0;
            //processMedia为1，需要转码，即其他格式的视频，转码为mp4格式，使video标签能够播放
            //群文件中，列表数据的转发依赖转码结果，而会话里上传视频和群文件列表数据是绑定的，故必须转码；
            if(util.yach.getGroupFileStatus()){
                saveFileDataParams.processMedia = 1;
            }else{
                saveFileDataParams.processMedia =
                filedata.data && filedata.data.codeh264 && ['mp4', 'ogg', 'webm', 'mov'].includes(ext) ? 0 : 1;
            }
            saveFileDataParams.width = data.width || 0;
            saveFileDataParams.height = data.height || 0;
        }
        if(filedata.type == 8) {
            saveFileDataParams.ext = {
                width: filedata.data.width,
                height: filedata.data.height
            }
        }
        const savedata = await saveFileData(saveFileDataParams);
        console.log('phj-saveFileData', savedata);
        if (!savedata || savedata.code != 200 || !savedata.obj) {
            //接口请求失败
            this.uploadFail(filedata.idClient);
            return null;
        }

        filedata.relation_id = savedata.obj.relation_id;
        filedata.file_id = savedata.obj.file_info.file_id;
        
        // if (filedata.type === 26) {
        //     filedata.filename = savedata.obj.file_info.file_name;
        //     filedata.data.name = savedata.obj.file_info.file_name;
        // }

        filedata.filename = savedata.obj.file_info.file_name;
        filedata.data.name = savedata.obj.file_info.file_name;

        const { path, base64 } = filedata.data;
        if (filedata.type == 8) {
            const imginfo = await util.imageDealer.getImageInfo(path || base64); //用本地图片算宽高
            const thumbimginfo = await util.imageDealer.getThumbImageInfo(
                filedata.fileurl,
                imginfo.width,
                imginfo.height,
                filedata.size
            );
            pushtext = `[${util.locale('im_image')}]`;
            result = {
                messageType: 'image',
                relation_id: filedata.relation_id,
                pushtext,
                pushobj: getPushObj(pushtext, filedata.sessionActive),
                apns: { forcePush: false },
                custom: {
                    type: 8,
                    data: {
                        fileName: filedata.filename,
                        fileSize: filedata.size || (filedata.data && filedata.data.size),
                        fileOriginUrl: filedata.fileurl,
                        fileThumbnailUrl: thumbimginfo.thumbUrl,
                        thumbWidth: thumbimginfo.thumbWidth,
                        thumbHeight: thumbimginfo.thumbHeight,
                        width: imginfo.width,
                        height: imginfo.height,
                        id: filedata.file_id,
                        relationId: filedata.relation_id,
                    },
                },
            };
        }
        // 视频
        else if (filedata.type == 30) {
            console.log('phj-filedata', filedata);
            let videoPicWH = {};
            if (savedata.obj.videoInfo && savedata.obj.videoInfo.videoPic) {
                try {
                    videoPicWH = await util.imageDealer.getImageInfo(savedata.obj.videoInfo.videoPic);
                } catch (error) {}
            }
            pushtext = `[${util.locale('im_video')}]`;
            result = {
                messageType: 'video',
                relation_id: filedata.relation_id,
                pushtext,
                pushobj: getPushObj(pushtext, filedata.sessionActive),
                apns: { forcePush: false },
                custom: {
                    type: filedata.type,
                    data: {
                        fileName: filedata.filename,
                        name: filedata.filename, //兼容老版本字段
                        fileSize: filedata.size || (filedata.data && filedata.data.size),
                        size: filedata.size || (filedata.data && filedata.data.size), //兼容老版本字段
                        fileUrl: filedata.fileurl,
                        url: filedata.fileurl, //兼容老版本字段
                        id: filedata.file_id,
                        relationId: filedata.relation_id,
                        width: videoPicWH.width || filedata.data.width,
                        height: videoPicWH.height || filedata.data.height,
                        dur: filedata.data.dur,
                        ext: util.videoUtil.getFileExtendingName(filedata.fileurl), //兼容老版本字段
                        codeh264: filedata.data.codeh264,
                        coverUrl: savedata.obj.videoInfo && savedata.obj.videoInfo.videoPic,
                        taskId: savedata.obj.videoInfo && savedata.obj.videoInfo.taskId,
                    },
                },
            };
        } else {
            pushtext = `[${util.locale('im_files')}]`;
            result = {
                messageType: 'file',
                relation_id: filedata.relation_id,
                pushtext,
                pushobj: getPushObj(pushtext, filedata.sessionActive),
                apns: { forcePush: false },
                custom: {
                    type: filedata.type,
                    data: {
                        fileName: filedata.filename,
                        fileSize: filedata.size || (filedata.data && filedata.data.size),
                        fileOriginUrl: filedata.fileurl,
                        fileUrl: filedata.fileurl,
                        id: filedata.file_id,
                        relationId: filedata.relation_id,
                    },
                },
            };
        }
        return result;
    };
    sendMessage = async (data, fileData) => {
        // 先删除db 数据
        try {
            util.nimUtil.deleteLocalMsg(data.msg);
        } catch (e) {}

        const { actionData, idClient } = data;
        const { custom: fileinfo, sessionActive } = actionData;
        const contentData = await this.getSendContent({ ...fileData, ...fileinfo, sessionActive, idClient });

        if (!contentData) return;
        //发送消息
        try {
            const customMsg = await util.nim.sendCustomMsg(
                sessionActive.type,
                sessionActive.id,
                JSON.stringify(contentData.custom),
                contentData.apns,
                contentData.pushobj.pushContent,
                '',
                contentData.pushobj.pushContent,
                contentData.pushobj.pushPayload,
                async (msg) => {
                    const obj = await util.nim.genMsgItem(msg);
                    // if (msg.to == sessionActive.id) {
                    // }
                    if(window.session_active.id == msg.to){
                        this.props.replaceByIdClient(obj, idClient);
                    }

                    // 删除占位信息等
                    this.deleteLocalCustomMessage({ ...data, progress: null });

                    if (fileinfo.type && fileinfo.type === 26) {
                        this.props.fileStatusUpdate(msg.idClient, {
                            id: msg.idClient,
                            isDownloaded: true,
                            downloadedPath: fileinfo.data && fileinfo.data.path,
                        });
                        util.nimUtil.updateLocalMsg(msg.idClient, { isDownloadFlag: true, path: fileinfo.data.path });
                    }
                }
            );
            util.yach.msgUploadCloud(customMsg);
            this.pushMessage(customMsg, 2);
            this.uploadSensorsData(customMsg);
            util.yach.refreshConnect(customMsg);

            if (contentData.messageType == 'image' || contentData.messageType == 'file' || contentData.messageType == 'video') robotMessage(contentData.messageType, sessionActive, customMsg);
            if (contentData.messageType !== 'image' && customMsg.status === 'success')
                message.success(
                    util
                        .locale('im_file_uoliad_dir_common_msg19')
                        .replace('[xxx]', (fileinfo.data && fileinfo.data.name) || '')
                );
            updateRelationId(contentData.relation_id, customMsg.idClient, fileinfo.type);
        } catch (err) {
            if (err.code == 'serverError') return message.error(util.locale('im_network_abnormal_upload_failed'));
            message.error(err.message);
            util.log('wangwenjie', 'sendMessage-error', JSON.stringify(err));
        }
    };
    //----------云信发送区---仅video------------
    yunxinAbort = (params) => {
        if (!params) return;
        const { progress } = params;
        if (progress && progress.yunxinHandler) progress.yunxinHandler.abort();
    };
    yunxinBeginupload = ({ uploader, params }) => {
        const { idClient } = params;
        this.uploadUpdate({
            idClient,
            status: 'uploading',
            data: {
                progress: {
                    yunxinHandler: uploader,
                    speed: 0,
                    percent: 0,
                },
            },
        });
    };
    yunxinUploadprogress = ({ obj, params }) => {
        const { idClient } = params;
        if (!this.props.uploadFileState[idClient]) return;
        const { progress } = this.props.uploadFileState[idClient];
        let speed = 0,
            startTime = progress.startTime || Date.now();
        let endTime = Date.now();
        speed = endTime - startTime < 5 ? 0 : obj.loaded / ((endTime - startTime) / 1000);
        const progressObj = {
            ...progress,
            percent: obj.percentage / 100,
            speed,
            startTime,
        };
        this.uploadUpdate({ idClient, status: 'uploading', data: { progress: progressObj } });
    };
    yunxinUploaddone = ({ error, file, params }) => {
        const fileState = this.props.uploadFileState[params.idClient];
        if (!fileState) {
            return;
        }
        if (error) {
            this.uploadFail(fileState.idClient);
            this.yunxinAbort(fileState);
            return;
        }
        this.uploadUpdate({ idClient: params.idClient, status: 'uploadSuccess', data: {} });
    };
    yunxinBeforesend = async ({ msg, params }) => {
        //console.log('wangwenjie', 'yunxinBeforesend', msg)
        const { idClient } = params;
        const fileState = this.props.uploadFileState[idClient];
        if (!fileState || fileState.status == 'uploadFail') {
            return;
        }
        if (window.session_active.id == msg.to) {
            await this.pushMessage(msg, 1, idClient);
            //删除占位消息、 状态列表、消息列表
            this.deleteLocalCustomMessage({ ...params, progress: null });
        }
    };
    uploadAndSendByYunXin = async (params) => {
        const { sessionActive, custom } = params.actionData;
        const { data: fileinfo } = custom;
        const { path, name } = fileinfo;
        const { type: scene, id: to } = sessionActive;
        if (!path) {
            this.deleteLocalCustomMessage(params);
            return;
        }
        const fs = require('fs');
        const buffer = fs.readFileSync(path);
        let blob = new Blob([buffer]);
        let ext = name.slice(name.lastIndexOf('.') + 1);
        let mime = 'video/' + ext;
        let file = new window.File([blob], name, { type: mime });
        let { pushPayload } = getPushObj(`[${util.locale('im_files')}]`, sessionActive);

        let obj = await yunxinSendFile({
            scene,
            to,
            file,
            pushPayload,
            yunxinBeginupload: (uploader) => {
                this.yunxinBeginupload({ uploader, params });
            },
            yunxinUploadprogress: (_obj) => {
                this.yunxinUploadprogress({ _obj, params });
            },
            yunxinUploaddone: (error, file) => {
                this.yunxinUploaddone({ error, file, params });
            },
            yunxinBeforesend: (msg) => {
                this.yunxinBeforesend({ msg, params });
            },
        });
        if (obj) {
            util.yach.msgUploadCloud(obj);
            // if (obj.to == this.props.sessionActive.id) this.pushMessage(obj, 2);
            if(window.session_active.id == obj.to) this.pushMessage(obj, 2);
            this.uploadSensorsData(obj);
            util.yach.refreshConnect(obj);
            //机器人的
            robotMessage('video', sessionActive, obj);
        }
    };
    //------over---------
    uploadSensorsData = (obj) => {
        let fileType = 104;
        if (obj.type == 'image') {
            fileType = 102;
        } else if (obj.type == 'audio') {
            fileType = 103;
        } else if (obj.type == 'video') {
            fileType = 105;
        } else if (obj.type == 'custom' && JSON.parse(obj.content).type == 8) {
            fileType = 102;
        }
        util.yach.sendMessageSensorsData(fileType);
    };

    pushMessage = async (item, type, idClient) => {
        // console.log('upload-log', 'pushMessage:', type, idClient, this.props.sessionActive.id, item);
        if (item.status == 'fail') {
            let obj = Object.assign(item, { msg: item });
            this.props.replaceMessage(obj);
        }

        let obj = await util.nim.genMsgItem(item);
        // if (this.props.sessionActive.type == 'team') {
        // }
        if(window.session_active.type == 'team'){
            const teamMembers = await util.nimUtil.getTeamMembers(window.session_active.id);
            obj = Object.assign(obj, { read: 0, unread: teamMembers.members.length - 1 });
        }

        if (type == 1) {
            // 对应的action:  MESSAGELISTREPLACEBYIDCLIENT
            this.props.replaceByIdClient(obj, idClient);
        } else {
            // 对应的action message-list-replace  云信的发送之前
            // this.props.replaceMessage(obj);
            // console.log('upload-log', 'pushmessage:updateMessage', this.props.sessionActive.id);
            // if (item.to == this.props.sessionActive.id) this.props.updateMessage([obj]);
            if(window.session_active.id == item.to) this.props.updateMessage([obj]);
        }
    };
    render() {
        return <></>;
    }
}

const mapDispatchToProps = {
    updateState: messageUploadAction.update,
    delLocalMessage: messageUploadAction.delLocalMessage,
    replaceMessage: messageListAction.replace,
    updateMessage: messageListAction.update,
    replaceByIdClient: messageListAction.replaceByIdClient,
    fileStatusUpdate: fileRedux.fileStatusUpdate,
    fileDownloadProgressRemove: fileRedux.fileDownloadProgressRemove,
    successIdclient: messageUploadAction.successIdclient,
    //fakeMsgIdclient: messageUploadAction.fakeMsgIdclient,
    sessionUploadFileUpdate: sessionUploadFileAction.sessionUploadFileUpdate
};
const mapStateToProps = (state) => {
    return {
        uploadFileState: state.uploadFile,
        // sessionActive: state.sessionActive,
        fileDownloadProgress: state.fileDownloadProgress,
        sessionUploadFile: state.sessionUploadFile
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(UploadFileControlContainer);
