import { Modal, Button } from 'antd';

// css
import css from './index.scss';

// react
import React from 'react';

export default class CreateGroupModal extends React.Component {
    render() {
        const {
            okText = this.locale('common_ok'),
            cancelText = this.locale('common_cancel'),
            modalTile,
            modalVisible,
            setOKModal,
            setonCancelModal,
            okButtonProps,
            cancelButtonProps,
            wrapClassName,
            fileModalKeyDown
        } = this.props;
        return (
                <div onKeyDown={fileModalKeyDown}>
                    <Modal
                        okText={okText}
                        cancelText={cancelText}
                        className="common-modal"
                        title={modalTile}
                        centered
                        visible={modalVisible}
                        onOk={setOKModal}
                        onCancel={setonCancelModal}
                        okButtonProps={okButtonProps}
                        cancelButtonProps={cancelButtonProps}
                        closable={false}
                        wrapClassName={wrapClassName}
                        autoFocusButton={'ok'}
                        maskClosable={false}
                    >
                        {this.props.modalContent}
                        {this.props.children}
                    </Modal> 
                </div>                   
        );
    }
}
