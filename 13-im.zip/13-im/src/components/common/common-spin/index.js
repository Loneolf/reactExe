import React from 'react';
import { Spin } from 'antd';
import css from './index.scss';

export default function CommonSpin(props) {
    const {text}=props;
    return (
        <div className={css.out}>
            <Spin tip={text} size="large" />
        </div>
    );
}
