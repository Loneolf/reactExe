import React from 'react';
import css from './index.scss';
import * as nimMsg from "@u/nim/container/nim-msg.js"
import * as util from '@u/util.js';

// imgs
import center from '@a/imgs/loading/center.png';
import rotating from '@a/imgs/loading/rotating.png';

export default class Loading extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidMount(){
    }
    
    componentWillUnmount(){
        this.schemeOpenSession();
        util.yach.fetchGuideList();
    }

    async schemeOpenSession() {
        //let sessionInfo = util.electronipc.getGlobalData('schemeOpenSessionInfo');
        let sessionInfo = await util.electronipc.getGlobalData('schemeOpenSessionInfo')
        const { sessionId } = sessionInfo || {};
        if (!sessionId) return; 
        if (sessionInfo.sessionType === 'p2p') {
            const [userId] = await util.yach.transThirdIdstoUserids([sessionId]);
            if (!userId) return;
            sessionInfo.sessionId = userId
        }
        if (sessionInfo.sessionType === 'team') {
            let teamInfo;
            let isUserInTeam;
            try {
                // console.log('use nim getuser or getteam xx00');
                teamInfo = await util.nimUtil.getTeam(sessionId);
                await util.nimUtil.getTeamMembers(sessionId);
                isUserInTeam = true;
            } catch(err) {
                teamInfo = null
                isUserInTeam = false;
            }
            if (!teamInfo || !isUserInTeam) return;
        }
        nimMsg.jumpToMsgView(sessionInfo);
        util.electronipc.setGlobalData({key: 'schemeOpenSessionInfo', value: null});
    }

    render() {
        return (
            <div className={css.box}>
                <div className={css.centerImg}>
                    <img src={center}/>
                    <img src={rotating}/>
                </div>
            </div>
        );
    }
}
