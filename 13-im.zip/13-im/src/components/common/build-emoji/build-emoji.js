// React
import React from 'react';

// util
import * as util from '@u/util.js';

// AutoLink
export default function BuildEmoji({ text }) {
    // 用于找 emoji 的正则表达式
    const re = /\[([^\]\[]*)\]/g;
    return (
        <React.Fragment>
            {text.split(re).map((word, index) => {
                var matches = text.match(re) || [];
                if (matches && util.emoji.emoji[matches[index]]) {
                    let url = matches[0];
                    return (
                        <img
                            className="emoji"
                            key={index}
                            src={`imgs/emoji/${
                                util.emoji.emoji[matches[index]].file
                            }`}
                        />
                    );
                }
                return word;
            })}
        </React.Fragment>
    );
}
