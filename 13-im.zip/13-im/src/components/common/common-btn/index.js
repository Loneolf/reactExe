import React from 'react';
import css from './index.scss';
import {Button} from 'antd';

export default function CommonBtn(props) {
    const {onClick,text,style,disabled,loading}=props;
    return (
        <Button type='primary' loading={loading} className={css.btn} disabled={disabled} style={style} onClick={onClick}>{loading?'':text}</Button>
    );
}
