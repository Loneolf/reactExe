// react
import React from 'react';
// css
import css from './index.scss';
// components
import BoxManagement from '../../home/container/im/im-box/box-management/box-management-container';
import BoxSetting from '../../home/container/im/im-box/box-setting/box-setting-container';
import BoxSquadSetting from '../../home/container/im/im-box/box-squad-setting/box-squad-setting-container';
import BoxOperation from '../../home/container/im/im-box/box-operation/box-operation-container';
import BoxConfiguration from '../../home/container/im/im-box/box-configuration/box-configuration-container';
import BoxGroupDatabaseContainer from '../../home/container/im/im-box/box-group-database/box-group-database-container';
import BoxRecordContainer from '../../home/container/im/im-box/box-record/box-record-container';
import BoxLink from '../../home/container/im/im-box/box-link/box-link-container';
import ScheduleSetting from '@/components/home/container/coordination/schedule/schedule-setting/schedule-setting-container';
import ScheduleInfo from '@/components/home/container/coordination/schedule/schedule-info/schedule-info-container';
import BoxHistoricalRecordContainer from '@/components/home/container/im/im-box/box-historical-record/box-historical-record-container';
import RemindInfo from '@/components/home/container/coordination/remind/remind-info/remind-info-container';
import RobotSettings from '@/components/home/container/im/im-box/box-setting/setting-bottom/robots-settings/robots-settings-container';
import GroupManagement from '@/components/home/container/im/im-box/box-setting/setting-bottom/group-management/group-management-container';
import SettingAdming from '@/components/home/container/im/im-box/box-setting/setting-bottom/setting-admin/setting-admin-container';
import TeamDetailsContainer from '@/components/home/container/team-circle/team-details/team-details-container';
import SingleSettingContainer from '@/components/home/container/im/im-box/box-setting/single-setting/single-setting-container';
import BoxGroupDocumentContainer from '@/components/home/container/im/im-box/box-group-document/box-group-document-container';
import UserPanelContainer from '../user-panel-group-setting/index-container';
import VoteCreate from '../vote/vote-create/index-container';
import VoteDetails from '../vote/vote-details/vote-details-container';
import FilePreview from '@/components/home/container/im/im-box/box-search-file/file-preview';
import BoxGroupFile from '@/components/home/container/im/im-box/box-group-file-wrap/box-group-file-wrap';
// util
import * as util from '@u/util.js';
// Box
export default class SlideModal extends React.Component {
    render() {
        const { handlePropagation, hiddenModal, slideModal = {},mask } = this.props;
        let title = '',
            component = null,
            tag = 0,
            showMask=mask,
            customName = '';
        switch (slideModal.kind) {
            // olei
            case 'setting':
                tag = 1;
                title = this.locale('common_team_msg29');
                customName = 'setting';
                component = <BoxSetting type="setting" />;
                break;
            case 'operation':
                tag = 2;
                title = this.locale('common_group_notice');
                component = <BoxOperation />;
                break;
            case 'management':
                tag = 3;
                title = this.locale('common_team_msg31');
                component = <BoxManagement />;
                break;
            case 'configuration':
                tag = 4;
                title = this.locale('common_team_msg32');
                component = <BoxConfiguration />;
                break;
            case 'groupDatabase':
                tag = 6;
                // title = groupName;
                customName = 'groupDatabase';
                component = <BoxGroupDatabaseContainer slideModal={slideModal} />;
                break;
            case 'record':
                tag = 7;
                title = this.locale('common_team_msg33');
                customName = 'record';
                component = <BoxRecordContainer />;
                break;
            case 'scheduleSetting':
                tag = 8;
                title = this.locale('common_team_msg34').replace('[xxx]', slideModal.name);
                component = <ScheduleSetting />;
                break;
            case 'scheduleInfo':
                tag = 9;
                title = false;
                customName = 'scheduleInfo';
                showMask=true;
                component = <ScheduleInfo slideModal={slideModal} />;
                break;
            case 'historicalRecord':
                tag = 10;
                title = slideModal.name;
                customName = 'historicalRecord';
                component = <BoxHistoricalRecordContainer />;
                break;
            case 'remindInfo':
                tag = 11;
                title = false;
                customName = 'remindInfo';
                showMask=true;
                component = <RemindInfo slideModal={slideModal} />;
                break;
            case 'teamDetails':
                tag = 12;
                title = slideModal.title;
                component = <TeamDetailsContainer slideModal={slideModal} />;
                break;
            case 'link':
                tag = 13;
                title = slideModal.title;
                customName = 'boxLink';
                component = <BoxLink url={slideModal.url} slideModal={slideModal} />;
                break;
            case 'squad':
                tag = 14;
                title = this.locale('common_team_setting');
                component = <BoxSetting type="squad" />;
                break;
            case 'robots':
                tag = 15;
                title = this.locale('common_team_helper');
                customName = 'robots';
                component = <RobotSettings />;
                break;
            case 'groupManagement':
                tag = 16;
                title = this.locale('common_team_circle_msg1');
                customName = 'groupManagement';
                component = <GroupManagement />;
                break;
            case 'settingAdmin':
                tag = 17;
                title = this.locale('common_team_circle_msg1');
                customName = 'settingAdmin';
                component = <SettingAdming />;
                break;
            case 'singleSetting':
                tag = 18;
                title = this.locale('im_single_settings');
                component = <SingleSettingContainer slideModal={slideModal} />;
                break;
            case 'groupDocument':
                tag = 19;
                title = this.locale('im_group_doc_title');
                component = <BoxGroupDocumentContainer slideModal={slideModal} />;
                break;
            case 'userPanelGroupSetting':
                tag = 20;
                title = this.locale('im_userpanle_setting_title');
                component = <UserPanelContainer id={slideModal.id} hiddenModal={hiddenModal} />;
                break;
            case 'voteCreate':
                tag = 21;
                title = this.locale('im_vote_create');
                component = <VoteCreate id={slideModal.id} hiddenModal={hiddenModal} />;
                break;
            case 'VoteDetails':
                tag = 22;
                title = this.locale('im_vote_info');
                component = <VoteDetails {...slideModal} hiddenModal={hiddenModal} />;
                break;
            case 'filePreview':
                tag = 23;
                title = this.locale('im_group_file_preview_title');
                component = <FilePreview {...slideModal} hiddenModal={hiddenModal} />;
                break;
            case 'groupFile':
                tag = 24;
                // title = this.locale('im_group_file');
                customName = 'groupFile';
                component = <BoxGroupFile slideModal={slideModal} />;
                break;
            default:
                title = '';
                component = null;
                break;
        }

        return (
            <>
                {
                    showMask&&<div className={css.mask} onClick={() => hiddenModal(tag)} />
                }
                <div
                    onMouseDown={handlePropagation}
                    onClick={(e) => util.yach.handleShowInfo(e)}
                    className={`${css.out} ${slideModal.kind ? css.show : ''} ${css[customName]} `}
                >
                    {slideModal.kind == 'scheduleInfo' ? (
                        <div className={css.scheduletitle}>
                            <p>{title}</p>
                            <div className={css.closebtn}>
                                <span
                                    className={`iconfont-yach yach-0428-rili-richengxiangqing-guanbixiangqing  ${css.scheduleclose}`}
                                    onClick={() => hiddenModal(tag)}
                                />
                            </div>
                        </div>
                    ) : (
                        <div className={css.title}>
                            <p>{title}</p>
                            <span
                                className={`iconfont-yach yach-quanju-qunshezhi-guanbiqunshezhi`}
                                onClick={() => hiddenModal(tag)}
                            />
                        </div>
                    )}

                    <div className={css.content}>{component}</div>
                    <div id="slideModal" />
                </div>
            </>
        );
    }
}
