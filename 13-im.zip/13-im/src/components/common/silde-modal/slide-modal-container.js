/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-16 14:36:32
 * @LastEditors: olei<wangzheng_jzb@100tal.com>
 * @LastEditTime: 2020-06-08 13:29:06
 */
// react
import React from 'react';
import { connect } from 'react-redux';
// action
import { hideSlideModal, showSlideModal } from '@r/actions/commonModal';
import { closeAllPanel } from '@r/actions/slidePanel';
// component
import SlideModal from './slide-modal';
// util
import * as util from '@u/util.js';

// BoxContainer
class SlideModalContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state = {
        historiKind: ''
    };

    componentDidMount() {
        window.addEventListener('mousedown', this.hiddenModal);
        const slidePanel = document.getElementById('slidePanel');
        slidePanel && slidePanel.addEventListener('mousedown', this.handleStopPropagation);
        document.getElementById('slideModal').addEventListener('mousedown', this.handleStopPropagation);
    }
    
    handleStopPropagation = e => {
        e.stopPropagation();
    };
    
    componentWillUnmount() {
        window.removeEventListener('mousedown', this.hiddenModal);
        const slidePanel = document.getElementById('slidePanel');
        slidePanel && slidePanel.removeEventListener('mousedown', this.handleStopPropagation);
        document.getElementById('slideModal').removeEventListener('mousedown', this.handleStopPropagation);
    }
    
    componentDidUpdate(prevProps, preState) {
        if (prevProps && prevProps.slideModal) {
            const { slideModal } = prevProps;
            const { historiKind } = preState;
            if (historiKind.kind != slideModal.kind) {
                if (slideModal.kind == 'historicalRecord') {
                    this.setState({ historiKind: slideModal });
                } else {
                    if (historiKind.kind) this.setState({ historiKind: '' });
                }
            }
        }
    }

    // 判断鼠标点击位置，是否是点击的侧边栏位置还是侧边栏之外的位置
    judgePosition = (e) => {
        if(!e || e.type != 'mousedown') return false
        let type = this.props.slideModal.kind
        if(!type) return false
        // 对应侧边栏的宽度
        let arr = {historicalRecord:450,record:540,scheduleInfo:400,remindInfo:430}
        let left = document.documentElement.clientWidth - e.x
        if(arr[type] && left < arr[type] || (!arr[type] && left < 332)) return true
        return false
    } 

    hiddenModal = tag => {
        const {alert, confirm} = window.store.getState();
        if(alert.visible || confirm.visible) return;
        // 打开侧边栏时，如果右键打开了复制弹框，侧边栏不消失
        if(util.yachLocalStorage.ls('isSelectText') && this.judgePosition(tag)) return
        const { historiKind } = this.state;
        if ([3, 15].includes(tag)) {
            this.props.dispatch(showSlideModal('setting'));
        } else if (tag === 16) {
            this.props.dispatch(showSlideModal('squad'));
        } else if (tag === 17) {
            this.props.dispatch(showSlideModal('groupManagement'));
        } else if (tag === 4) {
            this.props.dispatch(showSlideModal('management'));
        } else if (tag === 7 && historiKind.kind) {
            this.props.dispatch(showSlideModal(historiKind.kind, historiKind));
            this.setState({ historiKind: '' });
        } else {
            this.props.dispatch(hideSlideModal());
        }
        if (this.props.slideModal.kind == 'scheduleInfo') {
            util.sensorsData.track('Click_Schedule_Element', {
                pageName: 116,
                $element_name: 148
            });
        }
        this.props.dispatch(closeAllPanel());
    };

    render() {
        // const sessionActive = window.session_active;

        return (
            <SlideModal
                hiddenModal         ={this.hiddenModal}
                slideModal          ={this.props.slideModal}
                handlePropagation   ={this.handleStopPropagation}
                // groupName={sessionActive && sessionActive.showname}
            />
        );
    }
}

const mapStateToProps = state => {
    return {
        slideModal: state.slideModal,
        // sessionActive: state.sessionActive
    };
};

export default connect(mapStateToProps, null)(SlideModalContainer);
