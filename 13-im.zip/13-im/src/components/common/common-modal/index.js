import { Modal } from 'antd';

// css
import css from './common-modal.scss';

// react
import React from 'react';

export default class CommonModal extends React.Component {
    render() {
        const {
            okText = this.locale('common_ok'),
            cancelText = this.locale('common_cancel'),
            modalTile,
            modalVisible,
            setOKModal,
            setonCancelModal,
            okButtonProps,
            cancelButtonProps,
            confirmLoading = false,
            closable = true,
            footer,
            titleIcon,
            noTitleIcon,
            className,
            maskClosable
        } = this.props;
        const titleDom = (
            <span className={css.titleTips}>
                {!noTitleIcon && <span className={`${css[titleIcon || 'title_icon']}`} />}
                <span>{modalTile}</span>
            </span>
        );
        const closeDom = <span className={`${css.close_icon} iconfont-yach yach-quanju-dankuang-guanbi-moren`}></span>;
        return (
            <Modal
                okText={okText}
                cancelText={cancelText}
                className={className ? `${css[className]} common-modal`: modalTile ? 'common-modal' : `${css.no_title_body} common-modal`}
                title={modalTile ? titleDom : null}
                centered
                visible={modalVisible}
                onOk={setOKModal}
                onCancel={setonCancelModal}
                okButtonProps={okButtonProps}
                cancelButtonProps={cancelButtonProps}
                closable={modalTile ? closable : false}
                closeIcon={closable ? closeDom : null}
                confirmLoading={confirmLoading}
                footer = {footer}
                maskClosable={maskClosable}
            >
                {this.props.modalContent}
                {this.props.children}
            </Modal>
        );
    }
}
