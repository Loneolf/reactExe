// react
import React from 'react';
import { connect } from 'react-redux';

// css
import css from './index.scss';

// util
import * as util from '@u/util.js';

// redux
import { remoteLoginHide } from '@r/actions/remoteLogin';

// antd
import { Modal, Button } from 'antd';

// RemoteLoginContainer
class RemoteLoginContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    handleOk = () => {
        window.store.dispatch(remoteLoginHide());
        util.yachLocalStorage.ls('RemoteLoginTime', null);
    }

    warning = (time) => {
        let remoteLoginTime = util.yachLocalStorage.ls('RemoteLoginTime');

        let warining = Modal.warning({
          title: util.locale('common_remote_login_tip'),
          okText:util.locale('common_remote_login_ok'),
          className:css.modalWarning,
          onOk:this.handleOk,
          content:(
            <div className={css.content}>
                <span className={`${css.cancelIcon} iconfont-yach yach-lujing`} onClick={()=>{this.handleOk();warining.destroy()}}></span>
                {remoteLoginTime && (
                    remoteLoginTime !== 'phoneLogout' 
                    ?
                        <p>
                            { util.locale('common_alert_login_front') + time + util.locale('common_alert_login_behind')  }
                            { util.locale('common_client_out') }
                        </p>
                    :
                        <p>{ util.locale('common_alert_login1') } </p>
                )}
                <span className={css.splitLine}></span>
            </div>
          ),
        });

        util.yachLocalStorage.ls('RemoteLoginTime', null);
      }


    render() {
        const curTime = util.formatDate.formatDateLine(new Date().getTime())
        const kickTime = util.yachLocalStorage.ls('RemoteLoginTime')
        let time = ''
        if(curTime && kickTime) {
            time = curTime.split(' ')[0] !== kickTime.split(' ')[0] ? kickTime : kickTime.split(' ')[1]
            time = time.slice(0,-3) // 不保留秒
        }
        return (
            <div>
                {
                    this.props.remoteLogin && this.warning(time) 
                }
            </div>
        );
    }
}

const mapStateToProps = state => ({
    remoteLogin:state.remoteLogin
});

export default connect(
    mapStateToProps,
    null
)(RemoteLoginContainer);
