import React from 'react'

import FileDownloadProgress from './filedownload-progress'

class FileDownloadProgressContainer extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        const props = {
            record: this.props.record,
            percent: this.props.percent,
            speed: this.props.speed,
            cancel: this.props.cancel
        }
        return <FileDownloadProgress {...props} />
    }
}

export default FileDownloadProgressContainer
