import React from 'react'
import { Tooltip } from 'antd'
import * as util from '@u/util.js'
import css from './index.scss'

export default props => (
    <div className={css.box}>
        <div className={`${css.bar} ${props.record === 'historicalRecord' ? css.isHistoryPage : ''} `}>
            <span style={{width: props.percent + '%'}}></span>
        </div>
        {/* <div className={css.speed}>{props.speed}</div> */}
        <Tooltip placement="left" title={util.locale('im_file_download_cancel')}>
            <span className="iconfont iconshanchucanyuren" onClick={props.cancel}></span>
        </Tooltip>
    </div>
)

