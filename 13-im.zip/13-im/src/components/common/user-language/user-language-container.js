import React from 'react';

import css from './index.scss';

import {Select, Icon} from 'antd';

class UserLanguage extends React.Component {
    constructor(props){
        super(props);
    }
    render () {
        const {language, className, size, languageChange} = this.props;
        return (
            <div className = {`${css.select} ${css[className]}`} ref = "container">
                <Select suffixIcon = {<Icon type="caret-down" />} 
                defaultValue={language} 
                size = {size}
                getPopupContainer = {triggerNode => triggerNode.parentNode}
                onChange= {languageChange}>
                    <Select.Option value="zh-CN"> 简体中文 </Select.Option>
                    <Select.Option value="en-US"> English </Select.Option>
                </Select>                
            </div>

        )
    }
}
export default UserLanguage;