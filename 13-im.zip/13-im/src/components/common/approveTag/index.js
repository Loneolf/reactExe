/*
 * @Descripttion: 审批群图标组件
 * @Author: panghaojie
 * @Email: pang_hao_jie@163.com
 * @Date: 2020-05-28 18:20:38
 * @LastEditTime: 2020-05-28 18:21:18
 */ 
import css from './index.scss';

// react
import React from 'react';

export default class ApproveTag extends React.Component {
    render() {
        
        return (
            <img src={require('@a/imgs/approve.png')} alt="" className={css.tag}/>                
        );
    }
}
