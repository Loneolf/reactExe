// react
import React from 'react';

// css
import css from './index.scss';

import { Input, Button, Progress  } from 'antd';
import * as util from '@/utils/util';

const { TextArea } = Input;

// Im
export default class ReleaseTopic extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        const {
            showWin,
            closeWin,
            handleInputChange,
            inputText,
            videoPlay,
            handleFileDelete,
            showImg,
            files,
            filetype,
            maxfilenum,
            handleFile,
            sendContent,
            sending,
            uploading,
            getInputTextRef,
            imgInput,
        } = this.props;
        let sendButtonStyle =
            (inputText || (files && files.length > 0)) && !sending && !uploading ? css.buttonActive : css.buttonDisable;

        let inputaccept = '';

        if (filetype.includes('image')) inputaccept += '.png,.jpg,.jpeg,.gif,';
        if (filetype.includes('video')) inputaccept += '.wmv,.rmvb,.mp4,.3gp,.mov,.m4v,.avi,.mkv,.flv,';

        return (
            <div
                style={{ display: showWin.show ? '' : 'none' }}
                className={css.boxall}
                onMouseDown={(e) => e.stopPropagation()}
            >
                {/* mask */}
                <div className={css.mask}></div>
                {/* box */}
                <div className={css.box}>
                    {/* title */}
                    <div className={css.title}>
                        <span>{util.locale('common_topic')}</span>
                        <span className={css.close + ' iconfont iconguanbi'} onClick={closeWin}></span>
                    </div>
                    {/* main */}
                    <div className={css.main}>
                        <TextArea
                            id="topicTextArea"
                            maxLength={10000}
                            autoFocus={true}
                            value={inputText}
                            className={css.textContent}
                            placeholder={util.locale('common_place3')}
                            onChange={handleInputChange}
                            ref={(el) => {
                                getInputTextRef(el);
                            }}
                        />
                        <p className={css.imgTitle}>
                            {util.locale('common_topic24')}
                            <span>{util.locale('common_topic25')}</span>
                        </p>
                        <div className={css.imgContent}>
                            {files.map((item) => {
                                const { file, thumbFile, videoprogress, videopic, fileid } = item;
                                const defaultimg = item.type == 'image' ? util.config.nim.showimg : ''
                                return (
                                    <div className={css.fileItem} key={fileid || file}>
                                        <div
                                            className={css.fileitemcontent}
                                            style={{
                                                borderRadius: '4px',
                                                background: `url(${
                                                    videopic || file || defaultimg
                                                }) no-repeat center center / 100% 100%`,
                                            }}
                                        >
                                            {item.type == 'image' && (
                                                <div
                                                    onClick={() =>
                                                        showImg(
                                                            file,
                                                            files.map((item) => ({ file: item.file }))
                                                        )
                                                    }
                                                >
                                                    <img
                                                        className={css.pics}
                                                        src={thumbFile || defaultimg}
                                                    />
                                                </div>
                                            )}
                                            {item.type == 'video' && (
                                                <div onClick={() => {}}>
                                                    {!!videopic && <img className={css.pics} src={videopic} />}
                                                    {videoprogress < 100 && (
                                                        <div className={css.videoprogress}>
                                                            <Progress type="circle" percent={Math.floor(videoprogress)} width={21} strokeWidth={10} trailColor="#CCCDCF" strokeColor="#fff" />
                                                            <span>{Math.floor(videoprogress)}%</span>
                                                        </div>
                                                    )}
                                                    {videoprogress >= 100 && (
                                                        <div className={css.videoplay} onClick={videoPlay.bind(null, item)}></div>
                                                    )}
                                                </div>
                                            )}
                                            <i
                                                className={css.deleteIcon}
                                                onClick={(e) => {
                                                    handleFileDelete(file, e);
                                                }}
                                            >
                                                <img src={require('@a/imgs/schedule/delete-icon.png')} alt="" />
                                            </i>
                                        </div>
                                    </div>
                                );
                            })}
                            {files.length < maxfilenum ? (
                                <label className={css.fileAdd}>
                                    <div
                                        className={`iconfont-yach yach-xiaozu-fabuhuati-tianjiatupian ${
                                            files && files.length > 0 && css.addImg
                                        }`}
                                    />
                                    <input type="file" accept={inputaccept} onChange={handleFile} ref={imgInput} />
                                </label>
                            ) : null}
                        </div>
                        <div className={css.btn_item} onClick={sendContent}>
                            <Button className={sendButtonStyle} loading={sending}>
                                {util.locale('common_publish')}
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
