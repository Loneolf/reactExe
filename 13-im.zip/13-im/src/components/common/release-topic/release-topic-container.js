// react
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import { message } from 'antd';
import * as util from '@/utils/util';
import ReleaseTopic from './release-topic';
import TipModal from '@/components/common/tip-modal';

// import {fileInfoUpload} from '@s/file/file-info';

import { squadInsDoc } from '@s/squad/squad';
import { fileInfoSave } from '@s/file/file-info';
import debounce from 'lodash/debounce';

import At from '@c/common/at';

// ImContainer
class ReleaseTopicContainer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            inputText: '',
            filetype: ['image', 'video'],
            maxfilenum: 9,
            files: [],
            tipShow: false,
            sending: false,
            isOnline: true,
            uploadingId: '',
        };
        this.imgInput = React.createRef();
    }

    componentDidMount() {
        this.disabledids = [];
        this.isAddress = !!location.pathname.match(/\/address-list/);
        this.sendContent = debounce(this.sendContent, 500);
        window.addEventListener('online', this.updateOnlineStatus);
        window.addEventListener('offline', this.updateOnlineStatus);
    }

    componentWillUnmount() {
        this.handleCancelUpload()
        window.removeEventListener('online', this.updateOnlineStatus);
        window.removeEventListener('online', this.updateOnlineStatus);
    }

    componentDidUpdate(prevProps, prevState) {
        const { inputText } = prevState;
        const { files } = this.state;

        if (prevState.files != this.state.files) {
            !this.state.files.length && this.changeToImageAndVideo();
        }

        if (files && !files.length && !inputText) return this.cursorSelectionRange();
        if (this.props.showWin && !this.props.showWin.show) this.clearAt();
    }

    updateOnlineStatus = () => {
        let status = navigator.onLine ? 'online' : 'offline';
        this.setState({ isOnline: status === 'online' ? true : false });
        if (status == 'offline') {
            message.destroy();
        }
    };

    cursorSelectionRange = () => {
        const node = ReactDOM.findDOMNode(this.inputTextRef);
        const strLength = this.state.inputText.length;
        util.yach.setSelectionRange(node, strLength, strLength);
    };

    getInputTextRef = (ref) => {
        this.inputTextRef = ref;
    };

    reset = () => {
        this.setState({
            inputText: '',
            files: [],
            tipShow: false,
        });
    };

    closeWin = () => {
        const { inputText, files } = this.state;
        if (inputText || (files && files.length > 0)) return this.setState({ tipShow: true });
        this.handleCancelUpload();
        this.props.createTopic();
    };

    handleInputChange = (e) => {
        this.setState({
            inputText: e.target.value,
        });
        return true;
    };

    handleFileDelete = (file, e) => {
        e.stopPropagation();
        this.handleCancelUpload();
        this.setState((prv) => {
            const arr = prv.files;
            return {
                files: arr.filter((item) => item.file !== file),
            };
        });
    };

    showImg = (currid, attachments) => {
        const arr = attachments.map((item) => {
            const { id = item.file, file } = item;
            const newItem = { id, url: file };
            if (id === currid) newItem.curr = true;
            return newItem;
        });
        util.electronipc.electronOpenImage({
            success: true,
            data: arr,
        });
    };

    // 切换到上传图片和视频模式
    changeToImageAndVideo = () => {
        this.setState({
            filetype: ['image', 'video'],
            maxfilenum: 9,
        });
    };

    // 切换到只上传图片模式
    changeToImageOnly = () => {
        this.setState({
            filetype: ['image'],
            maxfilenum: 9,
        });
    };

    // 切换到只上传视频模式
    changeToVideoOnly = () => {
        this.setState({
            filetype: ['video'],
            maxfilenum: 1,
        });
    };

    // 关闭取消上传
    handleCancelUpload = () => {
        const { uploadingId } = this.state;
        uploadingId && util.electronipc.electronFileUploadDestory({ channelid: uploadingId });
        message.destroy();
        this.setState({
            uploadingId: '',
        });
        this.imgInput.current && (this.imgInput.current.value = null)
    };

    // 检测选择了图片
    checkChooseImage = (type) => {
        return /gif|jpg|jpeg|png|bmp|BMP|GIF|JPG|PNG$/.test(type);
    };

    // 检测选择了视频
    checkChooseVideo = (type) => {
        return /wmv|rmvb|mp4|3gp|mov|m4v|avi|mkv|flv|quicktime|rn-realmedia-vbr$/.test(type);
    };

    // 获取视频时长
    getVideoDur = async mypath => {
        return new Promise(resolve => {
            util.electronipc.getVideoInfo({ paths: [mypath] }, res => {
                if (res.code != 0) resolve(0)
                resolve(Math.floor(res.data[0].mpeginfo.duration) * 1000)
            })
        })
    }

    // 相同文件上传问题
    handleFile = async (event) => {
        const type = event.target.files[0] && event.target.files[0].type;

        let isimage = this.checkChooseImage(type);
        let isvideo = this.checkChooseVideo(type);

        if (!isimage && !isvideo) {
            return message.error(util.locale('common_msg17'))
        }

        if (!this.state.filetype.includes('image') && isimage) {
            return message.error(util.locale('common_topic20'));
        }

        if (!this.state.filetype.includes('video') && isvideo) {
            return message.error(util.locale('common_topic22'));
        }

        if (!this.state.isOnline) return;

        const file = event.target.files[0];
        const { name, path, size } = file;

        let videodur = 0
        if (isvideo) {
            videodur = await this.getVideoDur(path)
            if (videodur > 5 * 60 * 1000) return message.error(util.locale('common_topic23'))
        }

        let imgData = null;
        let fileid = Math.random().toString(36).slice(2);

        if (isimage) {
            this.changeToImageOnly();
            message.loading(`${util.locale('common_msg18')}..`, 0);

            let imageinfo = (await util.imageDealer.getImageInfoFromClient(path)) || {};

            if (imageinfo.width * imageinfo.height > 9999 * 9999) {
                message.destroy();
                return message.warn(this.locale('im_send_img_maxsize_limit'));
            }
            imgData = await util.imageDealer.ImageFileEXIF(path);
        }

        if (isvideo) {
            this.changeToVideoOnly();
            this.videotarget = file;
            message.loading(`${util.locale('common_topic21')}..`, 0);
            let allfiles = this.state.files;
            let newvideo = { type: 'video', file: '', videopic: '', videoprogress: 0, fileid };
            this.setState({
                files: [...allfiles, newvideo],
            });
        }

        this.setState({ uploading: true });

        util.electronipc.electronFileUpload(
            {
                filepath: imgData ? imgData.path : path,
                filename: name,
                filebase64: imgData ? imgData.base : undefined,
                costype: 'image',
                project: '',
                filetype: isvideo ? 'video' : 'image',
                size: size,
            },
            async (res) => {
                message.destroy();
                const { error } = res;
                // 上傳失敗
                if (res.error) {
                    message.error(this.locale('im_uploading_error_text_0') + error);
                }
                message.success(util.locale('common_msg19'));
                const url = res.fileurl;

                if (isimage) {
                    this.imgInput.current.value = null;
                    this.setState((prv) => ({
                        files: [
                            ...prv.files,
                            { type: 'image', file: url, thumbFile: url + '?imageView2/1/w/220/h/220' },
                        ],
                        uploadingId: '',
                    }));
                }

                if (isvideo) {
                    await this.handleVideoSet(fileid, res.fileurl, res.filename, videodur);
                }
                
                this.setState({ uploading: false });
            },
            (res) => {
                // res 上传进度
                this.setState({
                    uploadingId: res.channelid,
                });

                this.setCurrUploadingFile(fileid, {
                    videoprogress: res.processdata && res.processdata.percent * 100,
                });
            }
        );
    };

    // 设置当前上传中的文件数据
    setCurrUploadingFile = (id, data) => {
        let allfiles = [...this.state.files];
        let index = allfiles.findIndex((v) => v.fileid == id);
        if (index != -1) {
            Object.assign(allfiles[index], data);
            this.setState({ files: allfiles });
        }
    };

    // 视频转码
    handleVideoSet = async (id, url, name, videodur) => {
        let videoinfo = await fileInfoSave({
            file_url: url,
            file_name: name,
            file_size: this.videotarget.size,
            file_mime: this.videotarget.type,
            file_extension: url.slice(url.lastIndexOf('.') + 1),
            source: 'Squad',
            receive_type: 2,
            receive_id: this.props.userInfo.id,
            is_dir: 0,
            processMedia: 1,
            duration: videodur,
            processMediaId: 100040
        });
        if (videoinfo && videoinfo.code == 200) {
            this.setCurrUploadingFile(id, {
                file: url,
                videoprogress: 100,
                videopic: videoinfo.obj.videoInfo.videoPic,
                relation_id: videoinfo.obj.relation_id,
                file_info: videoinfo.obj.file_info,
                video_info: videoinfo.obj.videoInfo,
            });
        }
    };

    // 视频播放
    videoPlay = (item) => {
        util.electronipc.electronOpenVideoPreview({
            relationId: item.relation_id,
            needTranscoding: true,
        });
    };

    // 清除@
    clearAt = () => {
        delete this.usersInfo;
        this.disabledids = [util.yach.getAccount()];
    };

    // 发送消息
    sendContent = async () => {
        if (!this.state.isOnline || this.state.sending || this.state.uploading) return;
        const { inputText, files = [] } = this.state;
        if (!inputText && files && !files.length) return;
        message.loading(util.locale('common_msg21'), 0);
        this.setState({ sending: true });
        const { showWin, createTopic, sessionTelYoung } = this.props;
        const squad_id = this.isAddress ? sessionTelYoung.id : showWin.id;

        let images = [];
        let videos = [];
        files.forEach((v) => {
            v.type == 'image' && images.push(v.file);
            v.type == 'video' &&
                videos.push({
                    relation_id: v.relation_id,
                    file_info: {...v.file_info, file_url: v.file},
                    videoInfo: v.video_info
                });
        });

        const opt = {
            squad_id,
            text: inputText,
            img: images,
            video: videos,
        };
        if (this.usersInfo && this.usersInfo.length) {
            const at_users = [];
            this.usersInfo.forEach((user) => {
                at_users.push({
                    type: 'mention',
                    index: user.index,
                    user_id: user.id,
                    atName: '@' + user.name,
                    text: '',
                });
            });
            opt.at_users = JSON.stringify(at_users);
        }
        
        // 并行操作， 获取到 图片的 宽高
        let isGetImageInfoSuccess = true
        await Promise.all(opt.img.map(x=>util.imageDealer.getImageInfo(x))).then((res) => {
            opt.images = res.map((v, i) => ({...v, url: opt.img[i]}))
            opt.images && (opt.images = JSON.stringify(opt.images))
        }, () => {
            console.log('获取失败')  // 只要有一个结果失败  就全失败
            message.success(util.locale('common_msg20'));
            isGetImageInfoSuccess = false
        })
        // 获取图片信息失败 重新发布
        if (!isGetImageInfoSuccess) return

        const data = await squadInsDoc(opt);
        const { code, msg } = data || {};
        message.destroy();
        if (code === 200) {
            this.clearAt();
            message.success(util.locale('common_msg22'));
            this.reset();
            this.handleCancelUpload();
            createTopic();
        } else {
            message.error(msg);
        }
        this.setState({ sending: false });
        util.sensorsData.track('Click_Chat_Element', {
            pageName: '01-126',
            $element_name: '01-160',
            submodule: '01-103',
        });
    };

    //关闭弹框
    tipClose = () => {
        this.setState({
            tipShow: false,
        });
    };

    // 弹框回调
    tipAffirm = () => {
        this.tipClose();
        this.reset();
        this.handleCancelUpload();
        this.props.createTopic();
    };

    // --------- At ----------
    handlerUserInfo = (userInfo) => {
        this.usersInfo = userInfo;
    };

    handlerAtDisabledids = (val) => {
        this.disabledids = val;
    };

    render() {
        const { inputText, files, tipShow, sending, uploading, filetype, maxfilenum } = this.state;
        const tipModalProps = {
            title: '',
            visible: tipShow,
            content: util.locale('common_msg23'),
            callback: this.tipAffirm,
            close: this.tipClose,
        };
        return (
            <div onMouseDown={(e) => e.stopPropagation()}>
                <ReleaseTopic
                    {...this.props}
                    files={files}
                    filetype={filetype}
                    maxfilenum={maxfilenum}
                    sending={sending}
                    uploading={uploading}
                    inputText={inputText}
                    showImg={this.showImg}
                    closeWin={this.closeWin}
                    handleFile={this.handleFile}
                    handleFileDelete={this.handleFileDelete}
                    handleInputChange={this.handleInputChange}
                    sendContent={this.sendContent}
                    getInputTextRef={this.getInputTextRef}
                    imgInput={this.imgInput}
                    videoPlay={this.videoPlay}
                />
                <TipModal {...tipModalProps} />
                <At
                    areaId={'topicTextArea'}
                    commentText={this.state.inputText}
                    handleInputChange={this.handleInputChange}
                    handlerUserInfo={this.handlerUserInfo}
                    disabledids={this.disabledids}
                    handlerAtDisabledids={this.handlerAtDisabledids}
                />
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        userInfo: state.userInfo,
        // sessionActive: state.sessionActive,
    };
};

export default connect(mapStateToProps, null)(ReleaseTopicContainer);
