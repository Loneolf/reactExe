import React, { memo } from 'react';
import * as _ from 'lodash';

import * as util from '@u/util.js';

import css from './index.scss';
function ReplyEmots(props) {
    const { target, idClient, time, flow } = props;
    const emots = props.emots;
    let newEmots = [];
    for (let i = 0; i < emots.length; i++) {
        const el = emots[i];
        let userList = util.yach.arrayUnique2(el.userList, 'userId');
        let obj = {
            userList: userList,
            emoji: el.emoji,
        };
        newEmots.push(obj);
    }

    return (
        <div className={css.emots}>
            {newEmots.map((item, index) => {
                let _html = util.yach.convertExpression(item.emoji, '18px', '18px');
                return (<div className={`${css.emotsItem} ${flow === 'out' ? css.emotsOut : ''} ${ props.isNotice ? css.noticeEmot : ''}`} key={index}>
                    <span
                        className={css.emoji}
                        onClick={() => props.clickEmot(item, target, idClient, time)}
                        dangerouslySetInnerHTML={{
                            __html: _html,
                        }}
                    />
                    {item.userList.map((i, index) => (
                        <React.Fragment key={index}>
                            <span className={css.userName}>
                                {i.userName}
                                {index != item.userList.length - 1 && <span>、</span>}
                            </span>
                        </React.Fragment>
                    ))}
                </div>)
            })}
        </div>
    );
}
function arePropsEqual(prevProps, nextProps) {
    return _.isEqual(prevProps, nextProps);
}

export default memo(ReplyEmots, arePropsEqual);
