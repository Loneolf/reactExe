import css from './index.scss';

// react
import React from 'react';

export default class DepartTag extends React.Component {
    render() {
        
        return (
            <img src={require('@a/imgs/department.png')} alt="" className={css.tag}/>                
        );
    }
}
