
// css
import style from './index.scss';

// react
import React from 'react';

export default class LinkMessage extends React.Component {
    constructor(props) {
        super(props);
        this.openLink = this.openLink.bind(this);
    }
    openLink() {
        const { customData } = this.props;
        window.open(customData.messageUrl);
    }
    render() {
        const { className, children, customData } = this.props;
        return (
            <div className={` ${children ? style.hasEmoji : ''} ${this.isSelf ? style.isSelf : ''}`}>
                <div
                    className={`link-msg ${style['link-msg-container']} ${className} ${style.full}`}
                >
                    <div className={style.innerCard}>
                        {(
                            <React.Fragment>
                                <a onClick={this.openLink} className={style.parserContent}>
                                    <div className={style.title}>{customData.title}</div>
                                    <div className={style.body}>
                                        <div className={`${style.desc} ${style['truncate-overflow']}`}>
                                            {customData.text}
                                        </div>
                                        <div className={style.logo}>
                                            <img
                                                onError={this.addDefaultSrc}
                                                style={{ objectFit: 'cover', minWidth: '48px', minHeight: '48px' }}
                                                width="48"
                                                height="48"
                                                src={customData.picUrl}
                                                alt=""
                                            />
                                        </div>
                                    </div>
                                </a>
                                <div className={style.seperator}></div>
                            </React.Fragment>
                        )}
                    </div>
                    {children && <div className={style.others}>{children}</div>}
                </div>
            </div>
        );
    }
}
