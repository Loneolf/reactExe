import React, { memo,useMemo}from 'react';
import { message } from 'antd';
import marked from './marked';
import path from 'path';

import * as util from '@u/util.js';

import Image from '@c/common/common-assistant/components/image';
import ReplyEmots from '@c/common/reply-emots';

import { add, replace } from '@r/actions/messageList';

import { robotMessageAPI } from '@s/robots';
import { messageActioncardRequest } from '@s/robots';

import css from './index.scss';

const MarkdownMsg = ({title,image,content,buttons = [],cardUrl = '',showEmots = false,props,fType=''}) => {
  /**
   * title 样式
   */
  const titleStyle = title ? {
    color: title.textColor,
    fontSize: title.fontSize,
    padding: `${title.hPadding} ${title.vPadding}`,
    bold: title.fontBold,
    borderBottom: title.lineColor && `1px solid ${title.lineColor}`,
  } : null;

  /**
   * 内容样式
   */
  const contentStyle = content ? { backgroundColor: content.bgColor} : null;

  /**
   * 按钮列表
   * 二维数组，第一层:有几排按钮 第二层:一排有几个按钮
   */
  const buttonList = !!buttons.length && buttons.map(v =>
    v.map(item => ({
      style: {
        backgroundColor: item.bgColor,
        color: item.textColor,
        fontSize: item.fontSize
      },
      text: item.text,
      clickUrl: item.clickUrl,
      btnType:item.btnType,
      iconUrl: item.iconUrl
    }))
  );

  /**
   * 操作类型：按钮样式，操作为链接跳转
   * btnType: 0
   * 0: 展示图标
   * @param {
   *  clickUrl
   *  btnType
   *  text
   *  style
   * } item 
   * @param {number} index 
   */
  const btnTypeLink = (item, index, length) => {
    const { clickUrl, btnType, text, style, iconUrl } = item;
    return (
      <div
        key={index}
        // style={style}
        className={`${css.isLink} ${length === 1 ? css.isOne : ''}`}
        onClick={ e => onClickButton(e, { clickUrl, btnType })}
      >
        {!!iconUrl && <img className={css.icon} src={iconUrl}/>}
        <span className={css.text} style={style}>{text}</span>
      </div>
    )
  }

  /**
   * 操作类型：链接
   * btnType: 1
   * 存在箭头，不展示图标
   * @param {*} item 
   * @param {*} index 
   * @param {*} length 
   */
  const btnTypeLinkArrow = (item, index, length) => {
    const { clickUrl, btnType, text, style, iconUrl } = item;
    return (
      <div
        key={index}
        // style={style}
        className={`${css.isLinkArrow} ${length === 1 ? css.isOne : ''}`}
        onClick={ e => onClickButton(e, { clickUrl, btnType })}
      >
        {!!iconUrl && length > 1 && <img className={css.icon} src={iconUrl}/>}
        <span className={css.text}>{text}</span>
        {length === 1 ? <span className={`iconfont-yach yach-quanju-xuanren-zuzhijiagoucehua ${css.iconArrow}`} /> : null}
      </div>
    )
  }

  /**
   * 操作类型：按钮
   * btnType: 2 | 3
   * @param {
   *  clickUrl
   *  btnType
   *  text
   *  style
   * } item 
   * @param {number} index 
   */
  const btnTypeButton = (item, index) => {
    const { clickUrl, btnType, text, style, iconUrl } = item;
    return (
      <div
        key={index}
        // style={style}
        className={css.isButton}
        onClick={ e => onClickButton(e, { clickUrl, btnType })}
      >
        {!!iconUrl && <img className={css.icon} src={iconUrl}/>}
        <span className={css.text} style={style}>{text}</span>
      </div>
    )
  }

  /**
   * markdown 点击按钮
   * @param {*} e 
   * @param {
   *  btnType
   *  clickUrl
   * } item 
   */
  const onClickButton = async (e, { btnType, clickUrl }) => {
    e.stopPropagation();

    if (btnType == 0 || btnType == 1) {
      window.open(clickUrl);
      return;
    }

    const searchParams = parseSchemeUrl(clickUrl).searchParams;
    if (!searchParams) return;

    if (btnType == 2) {
      const url = searchParams.get('url');
      try {
        const result = await messageActioncardRequest({ url });
        if(result && result.code !== 200) {
          message.error(result.msg);
        }
      } catch (error) {
        util.log('wenai', 'box-content-message-custom', '京东机器人 messageActioncardRequest 出错', 'error', error);
      }
      return;
    }
    if (btnType == 3) {
      const msgtype = searchParams.get('type');
      invokeRobotMessage({
        msgtype,
        content: clickUrl,
        extra: clickUrl.slice(clickUrl.indexOf('?') + 1)
      });
    }
  }

  /**
   * 点击消息卡片内容
   * @param {*} e 
   */
  const onClickContent = async e => {
    const { target = {} } = e;
    const nodeName = target.nodeName;
    
    // 处理 markdown 图片
    if(nodeName === 'IMG' && target.src){
      e.stopPropagation();
      previewMarkdownImg(target.src);
    }

    // 消息卡片内容中的链接
    if (nodeName === 'A' && target.href) {
      e.stopPropagation();
      const href = target.getAttribute('href') || '';
      if (!href || !href.startsWith('yach://yach.zhiyinlou.com/session/robot')) return;

      const searchParams = parseSchemeUrl(href).searchParams;
      if (!searchParams || !searchParams.get) return;

      // 京东客服评价需求
      const msgtype = searchParams.get('type');
      if (msgtype) {
        invokeRobotMessage({
          msgtype,
          content: href,
          extra: href.slice(href.indexOf('?') + 1)
        });
      }
      // markdown 链接点击支持回显
      const replyValue = searchParams.get('reply');
      if (replyValue) {
        replayValue(replyValue);
        return;
      }
    }
  }

  /**
   * 点击 markdown 内容链接，进行回显
   * @param {*} text 
   */
  const replayValue = async (text) => {
    const { userInfo, sessionActive } = props;
    if (!sessionActive) return;

    let apns = {
      forcePush: false,
    },
    pushContent = '',
    pushName = '',
    pushPayload = {},
    sessionType = 0;

    const { type, id, showname } = sessionActive;
    const { name, name_nick } = userInfo;

    if (type === 'team') {
      sessionType = 1;
      pushContent = `${name}${name_nick ? '(' + name_nick + ')' : ''}: ${text.substr(0, 100)}`;
      pushName = showname;
    } else {
      sessionType = 0;
      pushContent = text.substr(0, 100);
      pushName = name_nick || name;
    }
    pushPayload = {
      pushTitle: util.yach.decodeUnicode(pushName),
      sessionType: sessionType,
      sessionID: id,
    };

    let seedMsg = {};
    try {
      seedMsg = await util.nim.sendText(
        type,
        id,
        text,
        apns,
        {},
        pushContent,
        pushPayload,
        async (msg) => {
          const obj = await util.nim.genMsgItem(msg);
          props.dispatch(add(obj));
          const {status, idClient, fromNick, to} = obj;
          util.log('wenai', 'local:markdown sendTextMsg:id:status:idClient:fromNick:to',id, status, idClient, fromNick, to);
        }
      );
      const {status, idClient, fromNick, to} = seedMsg;
      util.log('wenai', 'net:markdown sendTextMsg:id:status:idClient:fromNick:to',id, status, idClient, fromNick, to);
    } catch (error) {
      console.log('markdown sendTextMsg:error', error);
      seedMsg = error.msg;
    }

    if (seedMsg && seedMsg.to == window.store.getState().sessionActive.id) pushMessage(seedMsg, 2);
    util.yach.refreshConnect(seedMsg || {});
  }

  const pushMessage = async (item, type) => {
    util.log('wenai', 'markdown pushMessage:status:idClient:', item.status, item.idClient, item.time, type);
    if (item.status == 'fail') {
      let failResult = Object.assign(item, { msg: item });
      props.dispatch(replace(failResult));
    }
    let result = await util.nim.genMsgItem(item);
    if (props.sessionActive.type === 'team') {
      const teamMembers = await util.yach.isreadMsgReadInit(props.sessionActive.id, item.idServer);
      const { unreadAccounts } = teamMembers;
      result = Object.assign(result, { read: 0, unread: unreadAccounts.length});
    }
    if (type == 1) {
      props.dispatch(add(result));
    } else {
      props.dispatch(replace(result));
    }
  }

  /**
   * 查看消息卡片内容中图片
   * @param {string} url 
   */
  const previewMarkdownImg = url => {
    return new Promise((resolve, reject)=> {
      const name = path.basename(url)
      try{
        if (util.electron.isElectron()) {
          util.electronipc.electronOpenImage({
            success:true,
            data:[{
              name,
              url,
              curr:true
            }]
          }, undefined, (id) => {
            resolve(true)
          });
        }
      } catch(error){
        reject(error)
      }
    });
  }

  /**
   * 解析 scheme 链接
   * @param {string} url 
   */
  const parseSchemeUrl = url => {
    if (!url.includes('yach://')) return {};

    try {
      return new URL(url);
    } catch(err) {
      console.log('wenai, 链接解析失败', err)
      return {};
    }
  }

  /**
   * 调用 robotMessage 接口
   * @param {*} params 
   */
  const invokeRobotMessage = async params => {
    const {scene, from, time, idServer} = props;
    const { sessionActive = {}, userInfo = {} } = window.store.getState();

    try {
      const result = await robotMessageAPI({
        create_at: time,
        conversation_type: scene == 'team' ? 2 : 1,
        conversation_id: sessionActive.id,
        corp_id: userInfo.cp_id || 1,
        msg_id: idServer,
        chatbot_uid : scene == 'team' ? from : undefined,
        ...params
      });
      if (!result || result.code !== 200) {
        util.log('wenai', 'box-content-message-custom', '京东机器人 robotMessage 出错', 'result', result);
      }
    } catch(err) {
      util.log('wenai', 'box-content-message-custom', '京东机器人 robotMessage 出错', 'err', err);
    }
  }
  
  const onClickCard = () => {
    if (!cardUrl) return;
    window.open(cardUrl);
  }

 const getReactMarkdown  = useMemo(()=>()=>{
    // if(marked) return <ReactMarkdown source={content.contentPc || content.content} transformLinkUri={null} linkTarget="_blank"/> 
    // return <div>{content.content}</div>

   // return <ReactMarkdown source={content.contentPc || content.content} transformLinkUri={null} linkTarget="_blank"/> 
   return marked(content.contentPc || content.content);
    
 },[props.idClient])

  return (
    <a className={css.markdown} onClick={onClickCard}>
      {titleStyle && 
        <div className={css.title} style={titleStyle}>
          {title.content}
        </div>
      }
      {image && <Image property={image} style={{ marginBottom: 0 }} />}

      {contentStyle && 
        <div className={css.content} 
          style={contentStyle}
          dangerouslySetInnerHTML={{__html: getReactMarkdown()}}
          onClick={e => onClickContent(e)}
        />
      }
      {buttonList && !!buttonList.length &&
        <div className={css.buttons}>
          {buttonList.map((v, index) =>
            <div className={css.button} key={index}>
              {v.map((item, i) => {
                if (item.btnType == 0) return btnTypeLink(item, i, v.length)
                if (item.btnType == 1) return btnTypeLinkArrow(item, i, v.length)
                if (item.btnType == 2 || item.btnType == 3) return btnTypeButton(item, i)
              })}
            </div>
          )}
        </div>
      }
      <div className={fType!='reply'&&showEmots ? css.other : ''}>
        {fType!='reply'&&showEmots && <ReplyEmots {...props} />}
      </div>
    </a>
  )
}

// return true组件不发生重新渲染；反之，组件重新渲染。主要用于性能优化，
export default memo(MarkdownMsg,(prevProps, nextProps) => {
  // const cont = util.nimUtil.getJson(prevProps.content);
  return _.isEqual(prevProps, nextProps)
});
