import React, {useState} from 'react';
import { connect } from 'react-redux';
import Webview from '../webview';
import { toggleWebviewModal } from '@r/actions/webviewModal';
import * as util from '@u/util.js';
//const { remote } = require('electron')

import { electronipc } from '@u/util';
import css from './index.scss';

function webviewModalContainer(props) {
  const { isShowWebviewModal, webviewModalData } = props;
  const [preloadPath, setPreloadPath] = useState('')

  const onClose = () => {
    props.dispatch(toggleWebviewModal(false));
  };

  !preloadPath && util.electronipc.getGlobalData('APP_CLIENT_STATUS').then(res => {
    setPreloadPath(res && res.PRELOAD)
  })

  const webviewProps = {
    ...webviewModalData,
    //preloadPath: remote.getGlobal('APP_CLIENT_STATUS')['PRELOAD']
  }
  return (
    <>
      {
        isShowWebviewModal && 
        <div id="webviewModal" className={css.webviewModal}>
          <div className={css.mask} />
          <div className={css.box}>
            <div className={css.webview}>
              <Webview {...webviewProps} preloadPath={preloadPath} />
            </div>
            <span className={`iconfont-yach yach-145-icon_toast-cuowu ${css.close}`} onClick={onClose} />
          </div>
        </div>
      }
    </>
  )
}

const mapStateToProps = state => ({
  webviewModalData: state.webviewModalData,
  isShowWebviewModal: state.isShowWebviewModal,
})

export default connect(mapStateToProps, null)(webviewModalContainer);