// react
import React from 'react';

import { closeAlert } from '@r/actions/alert';

import { setAlertData, cleanAlertData} from '@r/actions/alertData'


import { connect } from 'react-redux';

import { electronipc } from '@u/util'

import CommonModal from '../common-modal';

const { handlePostMessage } = electronipc;
const alert = props => {
    const {alert:{visible,message,buttonName}}=props;

    function closeHandle (){
        window.store.dispatch(closeAlert({title: '',message: '' ,visible: false}));
        let {msgId, containerId} = window.store.getState().alertData;
        handlePostMessage({
            containerId,
            msgdata:{
                type:'response',
                msgId, 
                code:'0'
            }
        });
       window.store.dispatch(cleanAlertData({ msgId: '', containerId: '', message: ''}));
    }

    return  <CommonModal
                modalTile={''}
                modalVisible={visible}
                setOKModal={closeHandle}
                setonCancelModal={closeHandle}
                modalContent={message}
                cancelButtonProps={{ style: {backgroundColor: ' #326FEF', color: '#FFFFFF'} }}
                okButtonProps={{ style: { display: 'none' } }}
                cancelText={buttonName}
                maskClosable={true}
            />
}
const mapStateToProps = state => {
    return {
        alert:state.alert
    };
};
export default connect(mapStateToProps)(alert);