// react
import React from 'react';

import { closeConfirm } from '@r/actions/confirm';

import { setConfirmData, cleanConfirmData} from '@r/actions/confirmData'

import {electronipc} from '@u/util';

import CommonModal from '../common-modal';

import { connect } from 'react-redux';

const { handlePostMessage } = electronipc;
const confirm =  props => {
    const {confirm:{title,visible,message,buttonLabels}}=props;

    function closeHandle (e, index){
        window.store.dispatch(closeConfirm({title: '',message: '',buttonLabels: [],visible: false}));
        let {containerId, msgId} = window.store.getState().confirmData
        if(e.target.tagName == 'DIV') {
            handlePostMessage({
                containerId,
                msgdata:{
                    type:'response',
                    msgId, 
                    code:'-1',
                }
            });
        }else{
            handlePostMessage({
                containerId,
                msgdata:{
                    type:'response',
                    msgId, 
                    code:'0',
                    data:{
                        buttonIndex: index
                    }
                }
            });
        }
       window.store.dispatch(cleanConfirmData({msgId: '', containerId: '', message: ''}));
}

    return  <CommonModal
                closable={false}
                cancelButtonProps = {false}
                modalVisible={visible}
                setOKModal={(e)=>closeHandle(e, 1)}
                setonCancelModal={(e)=>closeHandle(e, 0)}
                modalContent={message}
                okText={buttonLabels[1]}
                cancelText={buttonLabels[0]}
                maskClosable={true}
            />
}

const mapStateToProps = state => {
    return {
        confirm:state.confirm
    };
};
export default connect(mapStateToProps)(confirm);