import React from 'react';
import css from './index.scss';

class ResizeBoxY extends React.Component {
    componentDidMount() {
        this.line.addEventListener('mousedown', this.go);
        const bottomEl = this.bottom;
        const topEl = this.top;
        topEl.style.height = `calc(100% - ${bottomEl.offsetHeight}px)`;
    }

    go = event => {
        const { min, max } = this.props;
        const bottomEl = this.bottom;
        const topEl = this.top;

        document.onmousemove = (e)=> {
            let iT=document.body.offsetHeight-e.pageY;
            iT > max && (iT = max);
            iT < min && (iT = min);
            bottomEl.style.height = iT + 'px';
            topEl.style.height = `calc(100% - ${iT}px)`;
            return false;
        };
        document.onmouseup = function() {
            document.onmousemove = null;
            document.onmouseup = null;
        };
    };

    componentWillUnmount() {
        this.line.removeEventListener('mousedown', this.go);
    }

    render() {
        const {resize}=this.props;
        const Top = this.props.children[0] || null;
        const Bottom = this.props.children[1] || null;
        return (
            <div className={css.vertial}>
                <div className={css.bottom} style={resize?{height:180}:{}} ref={el => (this.bottom = el)}>
                    {Bottom}
                    <div className={`${css.line} ${resize?"":css.no}`} ref={el => (this.line = el)} />
                </div>
                <div className={css.top} ref={el => (this.top = el)} >{Top}</div>
            </div>
        );
    }
}

export default ResizeBoxY;
