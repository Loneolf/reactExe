import React, { memo } from 'react';
import * as _ from 'lodash';

import * as util from '@u/util.js';

import css from './index.scss';

function Translate(props) {
    const { translating, translateText, flow, isCustom } = props;
    const flowStyle = flow == 'in' ? css.in : css.out;
    return (
        <div className={css.translate}>
            <div className={`${flowStyle} ${isCustom ? css.custom : ''}`}>
                {translating ? (
                    <div className={css.translating}>{util.locale('im_translating')}</div>
                ) : (
                    <span
                        style={{ display: 'inline' }}
                        className={css.translationDone}
                        dangerouslySetInnerHTML={{ __html: translateText }}
                    />
                )}
            </div>
        </div>
    );
}
function arePropsEqual(prevProps, nextProps) {
    return _.isEqual(prevProps, nextProps);
}

export default memo(Translate, arePropsEqual);
