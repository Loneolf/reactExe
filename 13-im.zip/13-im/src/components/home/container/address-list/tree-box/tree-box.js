// react
import React, {Fragment} from 'react';
import css from './index.scss';
import {setPageNumber} from "@/redux/actions/messageListState";
import * as util from "@/utils/util";
import CreateGroupModal from '@c/common/create-group-modal';
import {message} from 'antd';
import { connect } from 'react-redux';
import { groupInfoCreate } from '@s/group/group-info.js';
import {withRouter} from 'react-router';
import debounce from 'lodash/debounce';
import {isDepartment, isNotDepartment} from '@r/actions/isDepart.js';
import {cleanUserData} from '@r/actions/getUserData.js'

// AddresslistContainer
class TreeBox extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            modalShow: false,
            children: <div>
                <div style={{position:'relative',top: '10px', right: '-320px',cursor:'pointer'}} onClick={this.handleClickModalClose}>
                    <span className="iconfont iconguanbi"/>
                </div>
        <div style={{height:'22px',fontSize:'16px',fontFamily:'PingFangSC-Medium,PingFang SC',fontWeight:'500',color:'rgba(47,50,56,1)',lineHeight:'22px',marginLeft:'-28px',marginTop:'-5px'}}>{util.locale('office_tree_sure_create_department')}</div>
        <div style={{width:'352px',height:'40px',fontSize:'14px',fontFfamily:'PingFangSC-Regular,PingFang SC',fontWeight:'400',color:'rgba(47,50,56,1)',lineHeight:'20px',marginTop:'10px',marginLeft:'-28px'}}>{util.locale('office_tree_created_tip')}</div>
            </div>
        }
    }

    componentDidMount() {
        this.addWatermarkPower();
        window.addEventListener('resize', this.resizeWatermarkPower)
        this.handleClickModalOk = debounce(this.handleClickModalOk, 800);
    }

    componentWillUnmount(){
        this.removeWatermarkPower();
        window.removeEventListener('resize', this.resizeWatermarkPower)
        window.store.dispatch(isNotDepartment())
        window.store.dispatch(cleanUserData());
    }
    
    //添加水印
    addWatermarkPower = () => {
        let parentId = 'tree-box'
        util.yach.addWatermarkPower(parentId)
    }

    //移除水印
    removeWatermarkPower = () => {
        let parentId = 'tree-box'
        util.yach.removeWatermarkPower(parentId)
    }

    //重绘水印
    resizeWatermarkPower = () => {
        this.removeWatermarkPower()
        this.addWatermarkPower()
    }

    // 创建部门群
    handleCreateGroup = () => {
        if(this.props.getUserData.total_user_num >2000) {
            message.error(util.locale('common_team_msg41'));
            return;
        } else if(this.props.getUserData.has_group == 1) {
            message.error(util.locale('common_team_msg40'));
            return;
        }
        else{
            this.setState({
                modalShow: true
            })
        } 
    }
    // 加群
    handleClickModalOk = async () => {
        let obj = await groupInfoCreate({
            source: '1',
            dept_id: this.props.getUserData.id
        })
        if(obj && obj.code == 200) {
            this.props.history.replace('/im');
            let id = obj.obj.tid;
            setTimeout(util.nim.activeRow('team', id),0)
            this.setState({modalShow: false});
        }
    }
    // 关闭
    handleClickModalClose = () =>{
        this.setState({modalShow: false});
    }

    render() {
        const {
            onPersonClick,
            ogList,
            userList,
            getDeptList,
            rootList,
            manager
        } = this.props;
        return (
            <>
            <div className={css.box} id="tree-box">
                <div className={css.create}>
                    <div className={css.top} ref={el=>this.top=el}>{
                        rootList.length === 1 ?
                            <div className={css.root} key={rootList[0].og_id}>{rootList[0].og_name}</div> :
                            rootList.map((item, index) => {
                                const {og_id, og_name} = item;
                                if (index === rootList.length - 1) {
                                    return <div className={css.disabled} key={og_id}>{og_name}</div>
                                }
                                return <div key={og_id} onClick={getDeptList.bind(this, og_id)}>{og_name} <span>/</span>
                                </div>
                            })
                    }
                        {this.props.isDepartment && this.props.getUserData && this.props.getUserData.current_user_privilege == 1 &&  this.props.getUserData && this.props.getUserData.has_group == 0 && (this.props.getUserData && this.props.getUserData.total_user_num < 2000 || this.props.getUserData && this.props.getUserData.total_user_num == 2000) && <div className={css.createDept} onClick={this.handleCreateGroup}>
                            <div>
                                {util.locale('common_team_msg39')}
                            </div>
                        </div>}
                        {this.props.isDepartment && this.props.getUserData && this.props.getUserData && this.props.getUserData.current_user_privilege == 1 && (this.props.getUserData && this.props.getUserData.total_user_num >2000  ||  this.props.getUserData && this.props.getUserData.has_group == 1) && <div className={css.createDept1} onClick={this.handleCreateGroup}>
                            <div>
                                {util.locale('common_team_msg39')}
                            </div>
                        </div>}
                    </div>
                </div>
                <div className={css.content} ref={el=>this.content=el}>
                    {
                        ogList.map(item => {
                            const {deptName, deptId, userNum} = item;
                            return (
                                <div
                                    key={deptId}
                                    onClick={() =>
                                        getDeptList(deptId)}
                                    className={css.deptItem}
                                >
                                    <div>
                                        {deptName}
                                        <span>({userNum})</span>
                                    </div>
                                    <em className='iconfont-yach yach-pc-weilairen-zuzhijiagouyindaojiantou'/>
                                </div>
                            )
                        })
                    }
                    {
                        manager.map(item => {
                            const {id, name, pic, user_sign = ''} = item;
                            return (
                                <div
                                    onClick={onPersonClick.bind(this, id, 103)}
                                    key={id}
                                    className={`${css.item} ${css.manager}`}
                                >
                                    <img src={pic} alt=""/>
                                    <div>
                                        <p>{name}<em>「{util.locale('common_profile7')}」</em></p>
                                        <span>{user_sign}</span>
                                    </div>
                                </div>
                            );
                        })
                    }
                    {
                        userList.map(item => {
                            const {id, name, pic, user_sign = ''} = item;
                            return (
                                <div
                                    onClick={onPersonClick.bind(this, id, 103)}
                                    key={id}
                                    className={css.item}
                                >
                                    <img src={pic} alt=""/>
                                    <div>
                                        <p>{name}</p>
                                        <span>{user_sign}</span>
                                    </div>
                                </div>
                            );
                        })
                    }
                </div>
            </div>
            <CreateGroupModal 
                modalTile={''}
                modalVisible={this.state.modalShow}
                setOKModal={this.handleClickModalOk}
                setonCancelModal={this.handleClickModalClose}
                modalContent={ this.state.children }
                wrapClassName={'createGroupModal'}
            />
            </>
        );
    }
}
const mapStateToProps = state => ({
    isDepartment: state.isDepartment,
    getUserData: state.getUserData,
});

export default connect(
    mapStateToProps,
    null
)(withRouter(TreeBox));