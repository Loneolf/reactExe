/*
 * @Descripttion:
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-07-27 13:57:43
 * @LastEditors: olei<wangzheng_jzb@100tal.com>
 * @LastEditTime: 2020-09-16 18:09:22
 */
// react
import React from 'react';
// css
import cssBox from './index.scss';
import Webview from '@c/common/webview/index';
// util
import * as util from '@u/util.js';
// const { remote } = require('electron')
// components

// AddresslistContainer
export default class Box extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            preloadPath: '',
        };
    }

    componentDidMount() {
        util.sensorsData.track('Click_Chat_Element', { pageName: '101', $element_name: '01-192' });
        util.electronipc.getGlobalData('APP_CLIENT_STATUS').then((res) => {
            this.setState({
                preloadPath: res.PRELOAD,
            });
        });
    }

    getClient = () => {
        return util.electron.isWin();
    };

    render() {
        // util.config.young
        // http://0.0.0.0:8080
        const webviewProps = {
            id: '12345678',
            url: util.config.young,
            text: '',
            preloadPath: this.state.preloadPath,
        };

        return (
            this.state.preloadPath && (
                <div className={cssBox.content}>
                    {!this.getClient() && <div className={cssBox.dragStyl}></div>}
                    <Webview {...webviewProps} />
                    {/* <iframe className={cssBox.contentIframe} id="yach_webview.12345678" src='http://192.168.0.105:8080'/> */}
                </div>
            )
        );
    }
}
