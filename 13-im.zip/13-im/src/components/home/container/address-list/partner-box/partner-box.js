/*
 * @Des: 我的伙伴组件
 */

// react
import React, {Fragment} from 'react';
// css
import css from './index.scss';
import * as util from "@/utils/util";
import {Button, Tooltip, Spin} from 'antd';
import InfiniteScroll from 'react-infinite-scroller';
// components
export default class PartnerBox extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
  }

  render() {
    const {
      teamObj,
      teamMemberList,
      onPersonClick,
      DelTeamMember,
      openAddTeamMember,
      DelTeamInfo,
      EditTeamInfo,
      openRightWeb,
      handleInfiniteOnLoad,
      moreLoading,
      hasMore,
      total,
      delContent,
      link,
      listLoading,
    } = this.props;
    const list = teamMemberList.length>0 && teamMemberList.map(item => {
      const {id, name, pic, dept_full_name} = item;
      return (
          <div onClick={onPersonClick.bind(this, id, 104)} className={css.item} key={id}>
            <img src={pic} className={css.name} alt=""/>
            <div>
              <p>{name}</p>
              <span>{name}{dept_full_name ? `(${dept_full_name})` : dept_full_name}</span>
            </div>
            {teamObj.type !== 0 ?
                <Tooltip title={util.locale('im_delete_msg')} mouseEnterDelay={1} placement='bottom'>
                  <span onClick={(e)=>DelTeamMember(e,teamObj.id,id)}
                        className={`${css.delMember} iconfont-yach yach-weilairen-wodehuoban-wodeguanzhuliebiao-shanchu`} />
                </Tooltip> : null}
          </div>
      );
    });
    //  系统分组-一次性完成，我的关注,用户自定义分组-新加入的成员在上面，获取数据时进行分页加载，单页20条数据，滚动加载更多
    return (
        <div className={css.box}>
          { delContent ? null :
            <div className={css.top}>
              <span className={css.userName}>
                <span>{teamObj.name}</span>
                <span className={css.userCount}>{total}人</span>
              </span>
              {
                teamObj.type !== 0 ?
                    ( teamObj.type === 2 ?
                            <span className={css.handle}>
                              <Tooltip title={util.locale('common_warn_msg8')} mouseEnterDelay={1} placement='bottom'>
                                <span onClick={openAddTeamMember}
                                      className={`${css.icon} iconfont-yach yach-weilairen-wodehuoban-tianjiachengyuan`} />
                              </Tooltip>
                              <Tooltip title={util.locale('common_accepter15')} mouseEnterDelay={1} placement='bottom'>
                                <span onClick={()=>EditTeamInfo(true,teamObj.id,teamObj.name)}
                                      className={`${css.icon} iconfont-yach yach-weilairen-wodehuoban-zhongmingmingfenzu`} />
                              </Tooltip>
                              <Tooltip title={util.locale('common_accepter22')} mouseEnterDelay={1} placement='bottom'>
                                <span onClick={()=>DelTeamInfo(teamObj.id,teamObj.name)}
                                      className={`${css.icon} iconfont-yach yach-weilairen-wodehuoban-shanchufenzu`}/>
                              </Tooltip>
                            </span>
                        : <Tooltip title={util.locale('common_warn_msg8')} mouseEnterDelay={1} placement='bottom'>
                            <span onClick={openAddTeamMember}
                                  className={`${css.handle} ${css.icon} iconfont-yach yach-weilairen-wodehuoban-tianjiachengyuan`} />
                          </Tooltip> )
                    : link.trim().length === 0 ? null : <span onClick={(e)=>openRightWeb(e)} className={`${css.line}`}>{util.locale('common_accepter13')}</span>
              }
            </div>
          }
          <div className={css.content}>
            {
              teamMemberList.length > 0 ?
                  teamObj.type === 0 ? list :
                      <InfiniteScroll
                          initialLoad={false}
                          pageStart={0}
                          loadMore={handleInfiniteOnLoad}
                          hasMore={!moreLoading && hasMore}
                          useWindow={false}>
                        { list }
                        { moreLoading && hasMore && (
                            <div className={css.loading} >
                              <Spin/>
                            </div>
                        )}
                      </InfiniteScroll>
                  : teamObj.type === 0 || delContent ? null :
                  <div className={css.add}>
                    <img className={css.addImg} src={require('@a/imgs/address/adduser.png')}/>
                    <Button className={css.addBut} onClick={openAddTeamMember}>{util.locale('common_warn_msg6')}</Button>
                  </div>
            }
            { listLoading && (
                <div className={css.listLoading} >
                  <Spin/>
                </div>
            )}
          </div>
        </div>
    );
  }
}
