import React, { Component } from 'react';

import GroupBox from './group-box/group-box';
import SquadBox from './squad-box/squad-box';

import { Tabs } from 'antd';
import * as util from '@u/util.js';

import css from './index.scss'
const { TabPane } = Tabs;



class GroupSquad extends Component {

    constructor(props) {
        super(props);
        this.state = {
            activeKey: 1
        }
    }


    tapChange = (key) => {
        console.log('tapChange', key);
        this.setState({activeKey: key});
    }

    render() {
        const {activeKey} = this.state
        return (
            <div className={css.groupSquadBox}>
                <Tabs 
                    defaultActiveKey='1' 
                    onTabClick={(type = (activeKey == 1 ? '1' : '2')) => {this.tapChange(type)}} 
                    tabBarGutte='1' 
                    activeKey={activeKey+''}
                >
                    <TabPane tab={util.locale("im_team")} key='1'>
                        {activeKey == 1 && <SquadBox handleSingleClick={this.props.handleSingleClick} />}
                    </TabPane>
                    <TabPane tab={util.locale("im_group_chat")} key='2'>
                        {activeKey == 2 && <GroupBox handleGorupClick={this.props.handleGorupClick}/>}
                    </TabPane>
                </Tabs>
            </div>
        );
    }
}

export default GroupSquad;