// react
import React, {Fragment} from 'react';
import { squadHasList } from '@s/squad/squad';
// css
import css from '../../../address-list/itemIndex.scss';
import * as util from "@/utils/util";
import {message} from 'antd';

export default class SquadBox extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: []
        }
    }

    async componentDidMount() {
        const s = await this.getData();
        const {data} = s || {};
        this.setState({data});
        util.sensorsData.track('PageView_Chat', { pageName: '01-122', submodule: '01-103'});
    }

    getData = async (page) => {
        const datas = await squadHasList();
        const {code, obj = {}, msg} = datas || {};
        let data = [];
        if (code === 200) {
            data= await util.yach.base64ImgArrGetTmp(obj.data,'squad_pic');
        }else{
            message.error(msg);
        }
        return { data }
    }

    render() {
        const {data} = this.state;
        const {handleSingleClick} = this.props;
        return (
            <div className={css.box}>
                {/* <div className={css.top}>{util.locale('common_team_msg38')}</div> */}
                <div className={css.content}>
                    {data.map(item => {
                        const {
                            squad_id,
                            squad_name,
                            squad_pic,
                            ex
                        } = item;
                        return (
                            <div
                                onClick={handleSingleClick.bind(
                                    this,
                                    squad_id,
                                    squad_name
                                )}
                                key={squad_id}
                                className={css.item}
                            >
                                <img src={squad_pic||util.config.nim.showimg} className={css.name} alt=""/>
                                <div>
                                    <p style={{float:'left'}}>{squad_name}</p>
                                <span style={{float:'left'}}>{ex.user_total}{util.locale('common_persion')}</span>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    }
}
