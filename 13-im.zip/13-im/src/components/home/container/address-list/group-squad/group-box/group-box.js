// react
import React, {Fragment} from 'react';
import {Spin} from 'antd';
import InfiniteScroll from 'react-infinite-scroller';
import {groupUsersEnterGet} from '@s/group/group-user';
// css
import css from '../../../address-list/itemIndex.scss';
import * as util from "@/utils/util";
import DepartTag from '@c/common/departmentTag/index.js'
import ApproveTag from '@c/common/approveTag/index.js'


export default class GroupBox extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            loading: false,
            hasMore: true,
            total: 0,
            getDataLoading:true
        }
    }

    async componentDidMount() {
        const s = await this.getData(1);
        const {data, total} = s || {};
        this.setState({
            data,
            total,
            getDataLoading:false
        });
        util.sensorsData.track('Expo_AddressBook_MyGroupList');
    }

    getData = async (page) => {
        const datas = await groupUsersEnterGet({page, rows: 300, top_session: 1});
        const {code, obj = {}} = datas || {};
        let data = [],
            total = 0,
            top = [];
        if (code === 200) {
            const list=obj.list||[];
            top = obj.top || [];
            data = await util.yach.base64ImgArrGetTmp(list,'pic');
            top = await util.yach.base64ImgArrGetTmp(top,'pic');
            total = obj.total;
        }
        top = await util.yach.getSortGroup(this.reorganizationData(top || []), 1);

        data = await util.yach.getSortGroup(this.reorganizationData(data || []), 2);
        data = top.concat(data); 

        // 数据问题，加一层判断去重
        data = util.yach.handleGroupRepeat(data);
        return {
            data,
            total,
            top,
        }
    }

    reorganizationData = (arr) => {
        return arr.map(i=>(Object.assign(i, {id: i.tid + "-team-"})));
    }

    handleInfiniteOnLoad = async () => {
        // let {data, total, currentPage} = this.state;
        // this.setState({
        //     loading: true,
        // });
        // if (data.length >= total) {
        //     this.setState({
        //         hasMore: false,
        //         loading: false,
        //     });
        //     return;
        // }
        // const s = await this.getData(currentPage + 1);

        // this.setState({
        //     data: data.concat(s.data),
        //     total: s.total,
        //     currentPage: s.currentPage,
        //     loading: false,
        // });

        // if(s.data.length==0){
        //     this.setState({
        //         hasMore: false,
        //     });
        // }
    }

    render() {
        const {data, loading, hasMore,getDataLoading} = this.state;
        const {
            handleGorupClick
        } = this.props;
        return (
            <div className={css.box}>
                {
                    getDataLoading 
                    ? <div className={css.spinBox}><Spin tip={util.locale("calendar_create_adduser_loading")}/></div>
                    : <div className={css.content}>
                        {
                            data.length > 0 ? <>
                                {data.map(item => {
                                    const {
                                        tid,
                                        id,
                                        name,
                                        pic,
                                        group_users_count,
                                        source
                                    } = item;
                                    return (
                                        <div
                                            onClick={handleGorupClick.bind(
                                                this,
                                                tid
                                            )}
                                            key={id}
                                            className={css.item}
                                        >
                                            <img src={pic} className={css.name} alt=""/>
                                            <div>
                                                <p style={{float:'left'}}>{name}</p>
                                                {source == 1 && <div className={css.tag}><DepartTag/></div>}
                                                {source == 3 && <div className={css.tag}><ApproveTag/></div>}
                                            <span style={{float:'left'}}>{group_users_count}{util.locale('common_persion')}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                                {loading && hasMore && (
                                    <div className={css.loading}>
                                        <Spin/>
                                    </div>
                                )}
                            </> : <p>{util.locale('common_team_msg36')}</p>
                        }
                    </div>
                }
                
            </div>
        );
    }
}
