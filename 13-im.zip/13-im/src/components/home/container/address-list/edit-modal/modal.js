/*
 * @Des: 编辑弹窗
 */

import React, {Component} from 'react';
import {Form,Input,Modal,Button} from "antd";
// util
import * as util from '@u/util.js';
// css
import css from './index.scss';

class Modals extends Component {
  constructor(props){
    super(props)
    this.state = { isDisabled: true }
  }

  componentDidMount() {
    this.props.form.validateFields();
  }

  validFunction = (rule, value, callback) => {
    value = value.replace(/\s/g,"")
    if (value.length > 0) this.setState({ isDisabled: false });
    else this.setState({ isDisabled: true });
    // 编辑规则
    if(this.props.idEditTeam && value === this.props.editObj.name) callback();
    // 创建规则
    this.props.partnerList.map(item => {
      if (value === item.name) {
        if(value === '我的上级和平级' || value === '我的下级' || (util.locale.getLang() === 'zh-CN' && value === '我的关注')
            || (util.locale.getLang() === 'en-US' && value === 'VIP')) callback(util.locale('common_accepter17'));
        else callback(util.locale('common_accepter16'));
      }
    });
    // 字数校验
    let len = value.match(/[^ -~]/g) === null ? value.length : value.length + value.match(/[^ -~]/g).length;
    if (len > 20) callback(util.locale('common_accepter18'))
    // 校验通过
    callback();
  };

  // 自动聚焦
  handleInput = (el) => {
    if (el != null) {
      el.focus();
    }
  };

  handleSubmit = e => {
    const {form,confirmEditTeamInfo,editObj,idEditTeam} = this.props;
    e.preventDefault();
    form.validateFields((err, values) => {
      if (!err) {
        confirmEditTeamInfo(idEditTeam,editObj.id,values)
      }
    });
  };

  render() {
    const {form,cancelEditTeamInfo,editObj,idEditTeam} = this.props;
    const { getFieldDecorator } = form;
    return (
        <Modal
            wrapClassName={css.editmodal}
            visible={true}
            title={idEditTeam ? util.locale('common_accepter15') : util.locale('common_accepter14')}
            closable={false}
            centered={true}
            maskClosable={false}
        >
          <Form layout="vertical" onSubmit={this.handleSubmit}>
            <Form.Item>
              {getFieldDecorator('name', {
                rules: [{ validator: this.validFunction },],
                initialValue: editObj.name
              })(
                  <Input placeholder={util.locale('common_accepter19')} ref={(el) => {this.handleInput(el)}}/>
              )}
            </Form.Item>
            <Form.Item>
              <Button type="default" htmlType="button" onClick={()=>cancelEditTeamInfo()}>{util.locale('calendar_button_cancel')}</Button>
              <Button type="primary" htmlType="submit" disabled={this.state.isDisabled}>{util.locale('calendar_button_ok')}</Button>
            </Form.Item>
          </Form>
        </Modal>
    );
  }
}

export default Form.create()(Modals)
