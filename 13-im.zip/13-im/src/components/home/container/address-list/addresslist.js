/*
 * @Descripttion:
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-06-01 00:23:40
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-11-05 17:17:06
 */
// react
import React from 'react';
// css
import css from './index.scss';

// components
import List from './list/list.js';
import Box from './address-box/box';
import PartnerBox from './partner-box/partner-box';
import TreeBox from './tree-box/tree-box';
// import GroupBox from './group-box/group-box';
// import SquadBox from './squad-box/squad-box';
import GroupSquad from './group-squad/group-squad';
import ImBox from '../im/im-box/im-box-container.js';
import YoungBox from './young-box/box';
import RobotBox from './robot-box/robot';
import UserAdd from '@c/common/user-add/user-add-container';
import Modals from './edit-modal/modal';

class Index extends React.Component {
    render() {
        const {
            groupActiveId,groupList,boxList,onLeftListClick,onPersonClick,DelTeamMember,openAddTeamMember,DelTeamInfo,
            organList,partnerList,ogList,userList,getDeptList,rootList,manager,handleGorupClick,
            handleSingleClick,itemClick,teamMemberList,EditTeamInfo,userAddProps,openRightWeb,handleInfiniteOnLoad,
            moreLoading, hasMore,showEditModal,cancelEditTeamInfo,confirmEditTeamInfo,editObj, idEditTeam, teamObj,
            total,delContent,isClickPar,link,listLoading,
        } = this.props;

        const modalProps = {cancelEditTeamInfo,confirmEditTeamInfo,editObj,idEditTeam,partnerList};

        const listProps = {groupActiveId,groupList,onLeftListClick,organList,partnerList,itemClick,EditTeamInfo,teamObj,isClickPar};

        const partnerBoxProps = {
            teamMemberList,onPersonClick,DelTeamMember,openAddTeamMember, DelTeamInfo,EditTeamInfo,openRightWeb,
            handleInfiniteOnLoad, moreLoading, hasMore, teamObj,total,delContent,link,listLoading,
        };
        const boxProps = {boxList,onPersonClick};
        const treeBoxProps = {rootList,onPersonClick,ogList,userList,getDeptList,manager}
        const singleBoxProps = {handleSingleClick}

        let contentBox = null;
        if (groupActiveId === '') {
            contentBox = <div className={css.empty}><img src={require('@a/imgs/empty.png')} alt=""/></div>;
        } else if (groupActiveId === 'contacts') {
            // contentBox = <Box {...boxProps} />;
            contentBox = <PartnerBox {...boxProps} />;
        } else if (groupActiveId === 'group') {
            contentBox = <GroupSquad handleGorupClick={handleGorupClick} handleSingleClick={handleSingleClick}/>
        } else if (groupActiveId === 'squad') {
            contentBox = <SquadBox {...singleBoxProps}/>
        } 
        // else if (!isNaN(groupActiveId) && +groupActiveId === +sessionTelYoung.id) {
        //     // contentBox = <ImBox telYoung={sessionTelYoung} />
        //     contentBox = <YoungBox />
        // }
        else if(groupActiveId === 'young'){
            contentBox = <YoungBox />
        }else if(groupActiveId === 'robot'){
            contentBox = <RobotBox />
        }else if(groupActiveId === 'partner'){
            contentBox = <PartnerBox {...partnerBoxProps} />;
        }else {
            contentBox = <TreeBox {...treeBoxProps}/>;
        }
        return (
            <div className={css.box}>
                <List {...listProps} />
                { contentBox }
                <UserAdd {...userAddProps} />
                { showEditModal  &&  <Modals {...modalProps}/>}
            </div>
        );
    }
}

export default Index;
