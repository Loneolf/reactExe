// react
import React, {Fragment} from 'react';

// css
import css from './index.scss';
import * as util from "@/utils/util";

// components

// AddresslistContainer
export default class Box extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        util.sensorsData.track('Expo_AddressBook_FrequentContacts');
    }

    render() {
        const {
            boxList,
            onPersonClick
        } = this.props;
        return (
            <div className={css.box}>
                <div className={css.top}>{this.locale('common_accepter9')}</div>
                <div className={css.content}>
                    {
                        boxList.length > 0 ? boxList.map(item => {
                            const {
                                id,
                                name,
                                pic,
                                dept_name,
                                name_nick
                            } = item;
                            return (
                                <div
                                    onClick={onPersonClick.bind(
                                        this,
                                        id,
                                        104
                                    )}
                                    key={id}
                                    className={css.item}
                                >
                                    <img src={pic} className={css.name} alt=""/>
                                    <div>
                                        <p>{name_nick || name}</p>
                                        <span>{name}{dept_name?'('+dept_name+')':''}</span>
                                    </div>
                                </div>
                            );
                        }) : <p>{this.locale('common_accepter11')}</p>
                    }
                </div>
            </div>
        );
    }
}
