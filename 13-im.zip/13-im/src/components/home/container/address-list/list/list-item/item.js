// react
import React, {useEffect} from 'react';
import {connect} from 'react-redux';
import {Menu, Icon, Tooltip} from 'antd';
// css
import css from './index.scss';
import {unreadYoungTabChange} from '@r/actions/unreadYoungChange';
//util
import * as util from '@u/util.js';
import {electronipc} from '@u/util';
const { handlePostMessage } = electronipc;
const { SubMenu } = Menu;
// AddresslistContainer
function Item(props) {
    const { groupActiveId, onGroupClick, itemClick, EditTeamInfo, id, type, name,organList=[],partnerList=[],teamObj} = props;
    let iconName;
    if(props.iconName.includes('yach')){
        iconName = 'iconfont-yach ' + props.iconName;
    }else {
        iconName = 'icon iconfont ' + props.iconName;
    }
    const topKey=organList[0]&&organList[0][0]&&organList[0][0].deptId;
    useEffect(() => {
        //console.log('componentDidMount: 组件加载后')
        return () => {
          //console.log('componentWillUnmount: 组件卸载， 做一些清理工作')
        }
    }, []);
    let el=null;
    if(id==='tree'){
        el=<Menu
            className={css.tree}
            defaultOpenKeys={['sub1']}
            mode='inline'
            expandIcon={<span className={css.expandIcon} />}
            selectedKeys={[groupActiveId]}
            onClick={onGroupClick}
        >
            <SubMenu
                key="sub1"
                title={<div><em className={css.orgIcon} /><span>{util.locale('common_topic4.1')}</span></div>}
            >
                <Menu.Item key={topKey}><em className={css.itemIcon}/><span className={css.treeText}>{util.locale('common_organization')}</span></Menu.Item>
                {
                    organList.map(i=>{
                        const item=i.slice(-1)[0];
                        return <Menu.Item key={item.deptId}><em className={css.itemIcon}/><span className={css.treeText}>{item.name}</span></Menu.Item>
                    })
                }
            </SubMenu>
        </Menu>
    } else if (id==='trees') {
        el=<Menu
            className={css.trees}
            defaultOpenKeys={['sub2']}
            mode='inline'
            expandIcon={<span className={css.expandIcon} />}
            selectedKeys={[teamObj && teamObj.id && teamObj.id.toString()]}
            onClick={(e)=>onGroupClick(e,'partner')}
        >
            <Menu.ItemGroup
                key="sub2"
                title={
                    <div className={`${css.title}`}>
                        <img className={css.parIcon} src={require('@a/imgs/address/parIcon.png')} alt=""/>
                        <span>{util.locale('common_accepter12')}</span>
                        <Tooltip title={util.locale('common_accepter24')} mouseEnterDelay={1} placement='bottom'>
                            <span onClick={() => EditTeamInfo(false)} className={`${css.adduser} iconfont-yach yach-weilairen-wodehuoban-tianjiafenzu`} />
                        </Tooltip>
                    </div>
                }
            >
                {
                    partnerList.map(item=>{
                        return <Menu.Item key={item.id} obj={item}>
                            <em className={`${css.itemIcons} iconfont-yach yach-pcweilairen-wodehuoban-fenzuyindao`}/>
                            <span className={css.treeText}>{item.name}</span>
                        </Menu.Item>
                    })
                }
            </Menu.ItemGroup>
        </Menu>
    } else {
        el=<div
            onClick={() => {
                if (props.type === 'p2p') {
                    itemClick({id, type})
                } else onGroupClick(id);
                if(id==='young') {
                    if(util.yachLocalStorage.ls('newyoungcount') && util.yachLocalStorage.ls('newyoungcount')['firstTab']) {
                        window.store.dispatch(unreadYoungTabChange(props.unreadYoungTab));
                        util.yachLocalStorage.ls('newyoungcount', {...util.yachLocalStorage.ls('newyoungcount'), firstTab: false})
                    }
                    handlePostMessage({
                        containerId: '12345678',
                        msgdata:{
                            type:'youngMsgList',
                            data: '1'
                        }
                    });
                }
            }}
            className={`${css.box} ${groupActiveId === id ? css.active : ''}`}
        >
            <div className={`${css.icon} ${css[props.iconName]}`}>
                {
                    props.pic ? <img src={props.pic} /> : <span className={iconName} />
                }
            </div>
            <div className={css.text}>{name}</div>
            {
               (id==='young' && props.unreadYoungTab) ? 
                <em className={css.hong}>
                    <i className={css.unreadNum}>
                        {props.unreadYoungTab>99?'99+':props.unreadYoungTab}
                    </i>
                </em>
                :
                (
                    id==='young' && props.unreadYoungTabFeed ? <p className={css.hongdian}></p> : null
                )
            }
        </div>
    }
    return el;
}

const mapStateToProps = state => {
    return {
        unreadYoungTab: state.unreadYoungTab,
        unreadYoungTabFeed: state.unreadYoungTabFeed
    };
};

export default connect(
    mapStateToProps,
)(Item);
