/*
 * @Descripttion:
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-06-01 00:23:40
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-11-05 17:17:40
 */
// react
import React from 'react';

// css
import css from './index.scss';

// components
import ImItem from './list-item/item.js';
import TopSearch from '@c/home/container/im/im-list/search/top-search/top-search-container.js';
import TopSearchModal from '@c/home/container/im/im-list/search/top-search-modal/top-search-modal-container';

// img
import grow from '@a/imgs/address/grow.png'
import OKR from '@a/imgs/address/OKR.png'
import weekly from '@a/imgs/address/weekly.png'

import * as util from '@u/util.js';

// AddresslistContainer
export default class List extends React.Component {

    constructor(props){
        super(props)
        this.state={
            active:''
        }
    }

    otherEntryClick = (value)=>{
        switch (value) {
            case 'grow':
                let config = util.yachLocalStorage.ls('platformConfig')
                if(config && config['100000007']){
                    window.location.href = config['100000007']
                    util.sensorsData.track('Click_Chat_Element', { pageName: '101', $element_name: '01-150'});
                }
                break;
            case 'weekly':
                util.electronipc.electronOpenWorkbench({id: util.config.openMuseId,url:`${util.config.openMuseHost}weekly?common_future=weekly`,title:"MUSE"});
                util.sensorsData.track('Click_Chat_Element', { pageName: '101', $element_name: '01-187'});
                break;
            case 'OKR':
                util.electronipc.electronOpenWorkbench({id: util.config.openMuseId,url:`${util.config.openMuseHost}myinfo/myokr?common_future=okr`,title:"MUSE"});
                util.sensorsData.track('Click_Chat_Element', { pageName: '101', $element_name: '01-188'});
                break;
            default:
                break;
        }
        this.setState({active:value})
    }

    render() {
        const { groupActiveId, groupList, onLeftListClick,organList,partnerList,itemClick,EditTeamInfo,teamObj,isClickPar } = this.props;
        return (
            <div className={css.addressListbox}>
                <div className={css.topSearchBox}>
                    <TopSearch come='address' />
                    <TopSearchModal />
                </div>
                <div className={css.otherEntry} onBlur = { this.otherEntryBlur } >
                    <div className={`${css.grow} ${css.entryItem}`}>
                        <div className={css.iconBox} onClick={ ()=>this.otherEntryClick('grow')} >
                            <img src={grow} />
                        </div>
                        <span className={css.entryfont}>{util.locale('im_grow')}</span>
                    </div>
                    <div className={`${css.weekly} ${css.entryItem}`}>
                        <div className={css.iconBox} onClick={ ()=>this.otherEntryClick('weekly') }>
                            <img src={weekly} />
                        </div>
                        <span className={css.entryfont}>{util.locale('im_weekly')}</span>
                    </div>
                    <div className={`${css.okr} ${css.entryItem}`}>
                        <div className={css.iconBox} onClick={ ()=>this.otherEntryClick('OKR') }>
                            <img src={OKR} />
                        </div>
                        <span className={css.entryfont}>OKR</span>
                    </div>
                    {/* <div className={`${css.document} ${css.entryItem}`}>
                        <div className={css.iconBox} onClick={ ()=>this.otherEntryClick('doc') }>
                            <img src={active === 'doc' ? docClick : doc} />
                        </div>
                        <span className={css.entryfont}>{util.locale('im_doc')}</span>
                    </div> */}
                </div>
                {groupList.map(item => (
                    <ImItem
                        key={item.id}
                        {...item}
                        onGroupClick={onLeftListClick}
                        groupActiveId={groupActiveId}
                        organList={organList}
                        partnerList={partnerList}
                        itemClick={itemClick}
                        EditTeamInfo={EditTeamInfo}
                        teamObj={teamObj}
                        isClickPar={isClickPar}
                    />
                ))}
            </div>
        );
    }
}
