// react
import React from 'react';
import {connect} from 'react-redux';
// util
import * as util from '@u/util.js';
// css
import css from './index.scss';
// components
import AddressList from './addresslist';
// services
import {ucenterUserConnectList} from '@/services/ucenter/ucenter-user';
import {organInfoPerson,organInfoDeptNextList} from '@/services/organ/organ-info';
import {teamInfoLists,teamMemberLists,teamMemberAdd,teamInfoDel,teamInfoUpdate,teamMemberDel,teamInfoCreate} from '@/services/team/team';
import { postTopic } from '@/services/squad/squad';
import {isDepartment, isNotDepartment} from '@r/actions/isDepart.js';
import {getUserData} from '@r/actions/getUserData.js';
// young
import { youngNewSquad } from '@s/young/young.js';
import { setTelYoung } from '@r/actions/session';

import { message, Modal,Input } from 'antd';
const { confirm } = Modal;

import {openSlideLinkWebview} from '@u/yach';
import * as ReactDOM from "draft-js/lib/DraftEditor.react";

// AddresslistContainer
class AddresslistContainer extends React.Component {
    state = {
        groupList: [
            {name: util.locale('common_team_msg35'), iconName: 'yach-pcweilairen-wodequnzu', id: 'group'},
            // {name: util.locale('im_robot'), iconName: 'yach-pc-weilairen-jiqiren', id: 'robot'},
            {name: util.locale('common_organization'), iconName: 'yach-gongsilogo', id: 'tree'},
            // {name: util.locale('common_accepter9'), iconName: 'yach-pc-weilairen-lianxiren', id: 'contacts'}
            {name: util.locale('common_accepter12'), iconName: 'yach-pc-weilairen-lianxiren', id: 'trees'}
        ],
        groupActiveId: '',
        boxList: [],
        organList: [],
        ogList:[],   // 部门列表
        userList:[], // 用户列表
        rootList:[], // 节点
        manager:[], // 负责人
        partnerList: [], // 分组列表
        teamMemberList: [], // 分组成员列表
        teamObj:{},
        userAddShow: false,
        loading: true, // 选人组件loading
        moreLoading: false,
        hasMore: true,
        listLoading: false,
        total: 0,
        currentPage: 1,
        total_page: 1,
        showEditModal: false,
        editObj: {},
        idEditTeam: false,
        link: '',
        delContent: false,
        hasSelected:[],
        max_team: 0 , // 自定义最大小组数
        isClickPar: false
    };

    async componentDidMount() {
        this.getTelYoung()
        organInfoPerson().then(datas => {
            const {code, obj = []} = datas || {};
            if (code === 200) {
                this.setState({
                    organList: obj,
                });
            }
        });
        this.getTeamInfoLists();

        util.eventBus.addListener('getDeptList', value => this.handleLeftListClick(value));
        util.sensorsData.track('PageView_MainPage',{pageName: 101});
        util.sensorsData.track('PageView_Chat',{pageName: '01-122',submodule:'01-103'});
    }

    componentWillUnmount(){
        util.eventBus.removeListener('getDeptList');
    }

    // 获取未来样
    getTelYoung = async () => {
        const groupList = this.state.groupList.slice();
        if (groupList.find(item => item.id === 'young')) return this.itemClick({id: 'young'});
        let youngShow = await youngNewSquad();
        if(!(youngShow.obj && youngShow.obj.id)) return;
        const data = {
            showname: '未来样儿 ᴛᴀʟ ʏᴏᴜɴɢ',
            showimg: require("@/assets/imgs/talyoung.jpg")
        }

        this.props.setTelYoung(data)

        // if (!groupList.find(item => item.id === id)) {
            groupList.unshift({
                id: 'young',
                name: data.showname,
                pic: data.showimg,
                iconName: '',
            })
            this.setState({
                groupList
            })
        // }
        this.itemClick({id: 'young'})
    }

    // 进入未来样
    itemClick = ({id}) => {
        util.log('qiaowenbin', 'session load', 'active row', id)
        // let youngWindow = document.getElementById('yach_webview.12345678')
        // if(youngWindow) {
        //     window.youngWindow = youngWindow
        //     console.log(window.youngWindow.contentWindow)
        // }
        this.setState({
            groupActiveId: id
        })
    }


    handleLeftListClick = (value,val) => {
        let id = '';
        if (typeof value === 'object') id = value.key;
        else id = value;
        if(val) id = val;

        this.setState(
            {
                total: 0,
                currentPage: 1,
                hasMore: true,
                moreLoading: false,
                delContent: false,
                groupActiveId: id,
                teamObj: value.item && value.item.props.obj,
                isClickPar: id === 'partner' ? true : false,
            },
            () => {
                if (id === 'young') {
                    window.store.dispatch(isNotDepartment())
                    this.getConnectList();
                }else if (id === 'contacts') {
                    window.store.dispatch(isNotDepartment())
                    this.getConnectList();
                    util.sensorsData.track('Click_AddressBook_Element',{pageName: 101, $element_name: 106});
                }else if(id === 'group'){
                    window.store.dispatch(isNotDepartment())
                    util.sensorsData.track('Click_AddressBook_Element',{pageName: 101, $element_name: 107});
                }else if(id !== 'squad' && id !== 'partner'){
                    if(id == 1){
                        util.sensorsData.track('Click_AddressBook_Element',{pageName: 101, $element_name: 109});
                    } else{
                        util.sensorsData.track('Click_AddressBook_Element',{pageName: 101, $element_name: 108});
                    }
                    window.store.dispatch(isDepartment())
                    this.getDeptNextList(id);
                }else if(id === 'partner'){
                    this.getTeamMemberLists(value.key,value.item.props.obj.type)
                    util.sensorsData.track('Click_Chat_Element', {
                        pageName: '101',
                        $element_name: '01-210',
                        partner_name: value.item.props.obj.name
                    });
                }
            }
        );
        util.sensorsData.track('Click_AddressBook_Element', { pageName: '101', $element_name: '06-101'});
    };

    // 常用联系人
    getConnectList = async () => {
        const datas = await ucenterUserConnectList({type: 0});
        const {code, obj = {}} = datas || {};
        const list=obj.list||[];
        const arr= await util.yach.base64ImgArrGetTmp(list,'pic');
        if (code === 200) {
            this.setState({
                boxList: arr,
            });
        }
    };

    getDeptNextList= async (id) => {
        const datas = await organInfoDeptNextList({department_id:id});
        const {code, obj = {}} = datas || {};
        const {ogList=[],userList=[],root:{full=[],manager={}}, total_user_num, has_group, current_user_privilege}=obj;
        const userListDate = await util.yach.base64ImgArrGetTmp(userList,'pic');
        manager && (manager.pic = await util.yach.base64ImgGetTmp(manager.pic));
        if (code === 200) {
            this.setState({
                ogList,
                userList:userListDate,
                rootList:full,
                manager:manager?[manager]:[]
            });
            let object ={
                total_user_num,
                has_group,
                current_user_privilege,
                id,
                show: true
            }
            window.store.dispatch(getUserData(object));
        }
    };

    // 具体到人点击事件
    handlePersonClick = (id, source) => {
        util.yach.showUserinfo(id, source);
        util.sensorsData.track('Click_AddressBook_Element',{pageName: 106, $element_name: 110});
    };

    handleGorupClick= id=>{
        this.props.history.replace('/im');
        util.nim.activeRow('team',id);
        // console.log('%c群聊','font-size:30px;color:green;')
        util.sensorsData.track('PageView_ChatWindow', {ChatListType: 102, chat_id:id});
        util.sensorsData.track('Click_AddressBook_Element',{pageName: 107, $element_name: 111});
    }

    handleSingleClick = (id, name) => {
        // if (id != util.config.talyoung) this.props.history.replace('/im');
        // else {
        //     this.getTelYoung()
        // }
        this.props.history.replace('/im');
        util.nim.activeRow('p2p',id);
        // util.sensorsData.track('Click_ChatList', { ChatListType: '107', chat_id: `${id}`, chat_name:name});
    };

    // 获取用户的分组列表
    getTeamInfoLists = async() => {
      const datas = await teamInfoLists();
      const {code, obj} = datas || {};
      const {list,max_team} = obj
      if (code === 200) {
          this.setState({
              partnerList: list.sort((a,b) => a.type-b.type),// 排序type 0>1>2
              max_team
          })
      }
    };

    // 删除分组
    DelTeamInfo = async(teamId,name) => {
        const that=this;
        confirm({
            className: css.delConfirm,
            centered: true,
            content: <div>{util.locale('common_accepter21')}{name}? </div>,
            zIndex: 1011,
            onCancel() {},
            onOk() {
                teamInfoDel({team_id:teamId}).then(datas => {
                    const {code, obj = []} = datas || {};
                    if (code === 200) {
                        that.getTeamInfoLists();
                        that.setState({
                            teamObj:[],
                            teamMemberList:[],
                            delContent: true
                        })
                    }
                })
            },
            okText: util.locale('calendar_button_ok'),
            cancelText: util.locale('calendar_button_cancel'),
        });
    };

    // 编辑分组
    EditTeamInfo = (idEdit,teamId,teamName) => {
        const  {partnerList,max_team} = this.state;
        const partnerListCount = partnerList.filter(item => item.type === 2);
        if(!idEdit && partnerListCount.length>=max_team) {
            message.error(util.locale('common_accepter20'));
            return;
        }
        this.setState({
            showEditModal: true,
            idEditTeam: idEdit,
            editObj: {
                id:teamId,
                name:teamName
            }
        })
        // 埋点
        util.sensorsData.track('Click_Chat_Element', {
            pageName: '101',
            $element_name: '01-208'
        });
    };

    // 取消编辑分组
    cancelEditTeamInfo = () => {
        this.setState({
            showEditModal: false
        })
    };

    // 确定编辑分组
    confirmEditTeamInfo = (idEdit,teamId,value) => {
        if (idEdit) this.UpdateTeamInfo(teamId,value);
        else this.CreateTeamInfo(value)
    };

    // 创建分组
    CreateTeamInfo = async(name) => {
        const datas = await teamInfoCreate(name);
        const {code, obj = []} = datas || {};
        if (code === 200) {
            this.getTeamInfoLists();
            this.setState({
                showEditModal: false
            })
        }
        // 埋点
        util.sensorsData.track('Click_Chat_Element', {
            pageName: '101',
            $element_name: '01-209'
        });
    };

    // 重命名分组
    UpdateTeamInfo = async(teamId,name) => {
        const datas = await teamInfoUpdate({team_id:teamId,name:name.name});
        const {code, obj = []} = datas || {};
        if (code === 200) {
            this.getTeamInfoLists().then(()=>{
                const {partnerList} = this.state;
                const teamObjItem = partnerList.filter(item => item.id === teamId);
                this.setState({
                    showEditModal: false,
                    teamObj: teamObjItem[0]
                })
            });
        }
    };

    // 获取分组成员列表
    getTeamMemberLists = async (teamId,type) => {
        this.setState({listLoading: true});
        let params = {};
        if(type) params = {team_id:teamId, page: 1};
        else params = {team_id:teamId,all:1};

        const datas = await teamMemberLists(params);
        const {code, obj = []} = datas || {};
        const {user_list,link,total,current_page,total_page} = obj;
        if (code === 200) {
            this.setState({
                listLoading: false,
                teamMemberList: user_list,
                currentPage: current_page,
                total_page,
                total,
                link,
            })
        }
    };

    // 加载更多
    handleInfiniteOnLoad = async() => {
        this.setState({ moreLoading: true });
        const { teamMemberList, currentPage, teamObj } = this.state;
        if (teamMemberList.length >= this.state.total || currentPage>=this.state.total_page) {
            this.setState({
                hasMore: false,
                moreLoading: false,
            });
            return;
        }

        const datas = await teamMemberLists({ team_id:teamObj.id, page: currentPage+1 });
        const {code, obj = []} = datas || {};
        const {user_list,current_page} = obj;
        if (code === 200) {
            this.setState({
                moreLoading: false,
                teamMemberList: teamMemberList.concat(user_list),
                currentPage: current_page,
            })
        }
        if(user_list.length === 0) this.setState({ hasMore: false });
    };

    //打开选人组件
    openAddTeamMember = () => {
        this.setState({
            userAddShow: true,
            loading: false,
            hasSelected: [this.state.teamMemberList]
        });
    };

    //关闭选人组件
    closeAddTeamMember = () => {
        this.setState({
            userAddShow: false,
            loading: false,
        });
    };

    // 添加分组成员
    AddTeamMember = (e) => {
        const {teamObj} = this.state;
        let uid = [];
        if(e.users.length>0) e.users.map(item => uid.push(item.id));
        else  e.allDataUsers.map(item => uid.push(item.id));
        // 加载选人组件
        this.setState({ loading: true });
        teamMemberAdd({team_id:teamObj.id,uid:uid.join('|')}).then(datas => {
            if (datas.code === 200) {
                this.closeAddTeamMember();
                this.getTeamMemberLists(teamObj.id,teamObj.type);
                this.setState({
                    hasMore: true,
                    moreLoading: false,
                })
            }
        })
    };

    // 移除分组成员
    DelTeamMember = async(e,teamId,uid) => {
        const {teamMemberList,total} = this.state;
        e.stopPropagation();
        const datas = await teamMemberDel({team_id:teamId,uid});
        const {code, obj = []} = datas || {};
        if (code === 200) {
            this.setState({
                teamMemberList: teamMemberList.filter(item => item.id !== uid),
                total: total-1,
            })
        }
    };

    // 汇报线不准
    openRightWeb = (e) => {
        e.nativeEvent.stopImmediatePropagation();
        window.location.href = this.state.link;
        // openSlideLinkWebview({url:this.state.link})
    };

    render() {
        const {
            groupActiveId, groupList, boxList,organList,ogList,userList,rootList,manager,partnerList,teamMemberList,
            userAddShow,loading, moreLoading, hasMore,showEditModal,editObj, idEditTeam,teamObj,total,delContent,
            isClickPar, link,listLoading,
        } = this.state;

        let disabledids = [];
        disabledids.push(teamObj && teamObj.id && teamObj.id.toString());
        teamMemberList.map(item => disabledids.push(item.id.toString()));

        const userAddProps = {
            type: 'creatGroup',
            loading: loading,
            show: userAddShow,
            onOk: this.AddTeamMember,
            onClose: this.closeAddTeamMember,
            disabledids: disabledids,
            // checkedids:  hasSelected,
            leftTitle: util.locale("im_new_members"),
            title: util.locale("im_add_new_member"),
            rightTitle: util.locale("im_choose_group_member"),
            maxLength: 1000,
            squadMax: 1000
        };
        const Props = {
            manager,
            rootList,
            organList,
            groupActiveId,
            groupList,
            boxList,
            ogList,
            userList,
            partnerList,
            teamMemberList,
            userAddProps,
            moreLoading,
            hasMore,
            showEditModal,
            editObj,
            idEditTeam,
            teamObj,
            total,
            delContent,
            isClickPar,
            link,
            listLoading,
            //sessionTelYoung: this.props.sessionTelYoung,
            onLeftListClick: this.handleLeftListClick,
            onPersonClick: this.handlePersonClick,
            getDeptList: this.getDeptNextList,
            handleGorupClick: this.handleGorupClick,
            handleSingleClick: this.handleSingleClick,
            itemClick: this.itemClick,
            DelTeamMember:this.DelTeamMember,
            DelTeamInfo:this.DelTeamInfo,
            EditTeamInfo:this.EditTeamInfo,
            openAddTeamMember:this.openAddTeamMember,
            openRightWeb:this.openRightWeb,
            handleInfiniteOnLoad:this.handleInfiniteOnLoad,
            cancelEditTeamInfo:this.cancelEditTeamInfo,
            confirmEditTeamInfo:this.confirmEditTeamInfo,
        };

        return <AddressList {...Props} />;
    }
}

const mapStateToProps = state => {
    return {
        sessionList: state.sessionList
    };
};

const mapDispatchToProps = {
    setTelYoung
}

export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(AddresslistContainer);
