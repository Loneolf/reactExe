import React, { Component } from 'react';
import { robotUserList } from '@s/robots';
import css from './index.scss'

class robot extends Component {
    constructor(props) {
        super(props);
        this.state={
            loading:false,
            list:[]
        }
    }

    async componentDidMount() {
        let data = await robotUserList({type:'1'})
        console.log('aaa','我挂载了',data)
    }

    render() {
        return (
            <div>
                我是机器人
            </div>
        );
    }
}

export default robot;