import React, {useEffect, useState} from 'react';
import { connect } from 'react-redux';
import * as util from '@u/util.js';
import Im from './im';
import {hideSlideModal, hideTopSearchModal} from "@/redux/actions/commonModal";
import {isNotDepartment} from '@r/actions/isDepart.js';

// services
import { meetingGetTime } from '@s/meeting/meeting'

// 用hook方式简化代码
const ImContainer = ({dispatch, sessionActive}) => {

    const [maxed, setMaxed] = useState(false)

    function close(){
        util.electronipc.hide();
    }

    function max(){
        util.electronipc.max();
        setMaxed(!maxed)
    }
    function min(){
        util.electronipc.min();
    }

    const handleMeetingGetTime = async() => {
        let serverTime = 0,
            localTime = 0,
            serverLocalTimeDiff = 0;
        const data = await meetingGetTime();
        const {code, obj} = data || {}
        if (code === 200) {
            serverTime = obj && obj.time;
        }

        localTime = new Date().getTime();

        serverLocalTimeDiff = serverTime * 1000 - localTime;

        util.yachLocalStorage.ls('serverLocalTimeDiff', serverLocalTimeDiff);
    }

    // 注销快捷键 Cmd+R 快捷键
    const handleOffKey = () => {
        // 快捷键默认配置
        let shortCutInfo = util.yachLocalStorage.ls('systemset_shortcut') || {}

        // 兼容老版本 如果有用户之前设置了 Cmd+R 的快捷键，则把Cmd+R快捷键注销掉。(后期如果设置强升的话，此代码可以删掉)
        for (const key in shortCutInfo) {
            if (shortCutInfo.hasOwnProperty(key)) {
                const element = shortCutInfo[key];
                if (element && element.cmd == 'Cmd+R') {
                    util.electronipc.electronSystemsetUnregister('Cmd+R')
                }
                if (element && element.cmd == 'Ctrl+R') {
                    util.electronipc.electronSystemsetUnregister('Ctrl+R')
                }
            }
        }
    }

    useEffect(() => {
        handleMeetingGetTime();
        util.sensorsData.track('PageView_MainPage',{pageName: 103});
        window.store.dispatch(isNotDepartment());
        handleOffKey();
        return () => {
            dispatch(hideSlideModal());
            dispatch(hideTopSearchModal());
        };
    }, []);
    const hasSessionActive = sessionActive && Object.keys(sessionActive).length;

    return <Im hasSessionActive={hasSessionActive} maxed={maxed} min={min} max={max} close={close} />;
}

export default connect(({sessionActive}) => ({sessionActive}))(ImContainer)