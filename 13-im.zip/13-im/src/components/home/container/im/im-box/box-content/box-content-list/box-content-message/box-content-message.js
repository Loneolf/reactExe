// react
import React from 'react';

// css
import css from './index.scss';

import moment from 'moment';

import { Menu, Dropdown, Spin, Icon, Popover, Tooltip } from 'antd';

// util
import * as util from '@u/util.js';
import * as linkMsgHandler from '@u/nim/container/link-msg-handler.js';

import VoiceRead from './box-content-message-audio/box-content-message-audio';
import EmojiModalContainer from '@c/common/emoji-modal/emoji-modal-container';
import ReplyEmots from '@c/common/reply-emots';
import redEnvelopeImg from '@a/imgs/redEnvelope/red-envelope.png';
import loadingIcon from '@a/imgs/message-loading.gif';
import warningIcon from '@a/imgs/warning.png';

//components
import BoxContentMessageUploadContainer from './box-content-message-upload';
import FileDownloadProgress from '@c/common/filedownload-progress/filedownload-progress-container.js';
import BoxContentMessageCustomContainer from './box-content-message-custom/box-content-message-custom-container';
import BoxContentMessageTextContainer from './box-content-message-text/box-content-message-text-container';

// BoxContentMessage
export default class BoxContentMessage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            contextMenu: false,
            isShowTip: false,
        };
    }

    // 显示右键菜单
    showtextMenu = () => {
        if (!util.yachLocalStorage.ls('isSelectText')) this.setState({ contextMenu: true });
    };

    // 展示提醒函数
    setRemind = (data) => {
        if (data.type === 'text') return true;
        if (!data.msg || !data.msg.content) return false;
        const info = JSON.parse(data.msg.content);
        if (info.type === 6 || info.type === 23) return true;
        return false;
    };

    filterText = (text) => {
        text = util.yach.textFiltering(text);
        text = util.yach.convertExpression(text, '34px', '34px');
        return <span style={{ display: 'inline' }} dangerouslySetInnerHTML={{ __html: text }} />;
    };

    /**
     * 文本消息
     */
    textMessage = () => {
        const {
            text,
            messageExtraData,
            custom,
            flow,
            isTeam,
            target,
            idClient,
            time,
            emots,
            type,
            content,
            isInAt,
            atHighlighted,
            clickEmot,
            replyMsg,
            translating,
            translateAndReduction,
            isOriginal,
            translateText,
        } = this.props;

        const textProps = {
            text,
            messageExtraData,
            custom,
            flow,
            isTeam,
            target,
            idClient,
            time,
            emots,
            type,
            content,
            isInAt,
            atHighlighted,
            clickEmot,
            replyMsg,
            translating,
            translateAndReduction,
            isOriginal,
            translateText,
            filterText: this.filterText,
        };
        return <BoxContentMessageTextContainer {...textProps} />;
    };

    emojiContent() {
        const { target, idClient, time } = this.props;
        return (
            <EmojiModalContainer
                clickEmojiItem={(emojiName) => this.props.clickEmojiItem(emojiName, target, idClient, time)}
                back="true"
            />
        );
    }

    // no date message
    noDateMessage() {
        return <pre className={css.content}>【 {util.locale('im_unsupported_message_types')} 】</pre>;
    }

    // notification message
    notificationMessage() {
        let { type, custom, editTip, idClient, content, fromNick, yachNick, isSelf, text: propsText, scene } = this.props;
        let newTime = 0,
            timeDiff = 0,
            TIME = 120 * 1000,
            time = 0,
            text = '',
            html = '',
            isShowEdit = false;
        //let content = this.props && this.props.content;
        content = util.nimUtil.getJson(content) || {};
        const cdata = content.data || {};
        const ctype = content.type || ''
        const isMetting = ctype == 18;
        const isTeamAutoReply = this.isTeamAutoReply(ctype, scene);


        if (!propsText && !isMetting && !isTeamAutoReply) return null;

        if (type == 'tip' && custom) {
            try {
                const customObj = JSON.parse(custom);
                time = customObj.newTime || 0;
                text = customObj.text || '';
            } catch (error) {}
            newTime = new Date().getTime();
            timeDiff = newTime - time;
            isShowEdit = timeDiff < TIME;
        }

        if (isMetting) {
            text = cdata.text;
        }
        if(isTeamAutoReply){// 群聊 -> 个人状态-自动回复
            const _content = cdata.content;
            html = _content.reply_content;
            let atUsers = _content.at_users || [];
            if(typeof atUsers === 'string'){// 发现有时候是字符串....
                atUsers = util.nimUtil.getJson(atUsers, [])
            }
            if (Array.isArray(atUsers) && atUsers.length) {
                html = util.yach.atStr(html, atUsers);
            }

            html = `[${isSelf ? util.locale('im_auto_reply_my') : util.locale('im_auto_reply_other').replace('[xxx]', cdata.at_nickName || yachNick || fromNick)}]${html}`
        }

        if (isShowEdit && type == 'tip' && custom) {
            setTimeout(() => {
                const elem = document.getElementById(idClient + 'edit');
                if (!elem) return;
                elem.style.display = 'none';
            }, TIME - timeDiff);
        }
        return (
            <div className={css.notificationMessage}>
                {isMetting && <pre className={css.notificationContent}>{text}</pre>}
                {!isMetting && (
                    <pre
                        className={css.notificationContent + ` ${html && css.autoReply}`}
                        dangerouslySetInnerHTML={{
                            __html: html || this.props.text,
                        }}
                    ></pre>
                )}
                {type == 'tip' && isShowEdit && (
                    <span id={idClient + 'edit'} className={css.reedit} onClick={() => editTip(text,idClient)}>
                        {util.locale('im_re_edit')}
                    </span>
                )}
            </div>
        );
    }

    // redEnvelopenotification
    redEnvelopenotification(title) {
        if (!title) return null;
        return (
            <div className={css.redEnvelopenotification}>
                <div className={css.content}>
                    <img src={redEnvelopeImg} />
                    {this.locale.getLang() === 'zh-CN' ? (
                        <>
                            {title.substring(0, title.length - 2)}
                            <span className={css.redPacket}>{title.substr(-2)}</span>
                        </>
                    ) : (
                        <p
                            dangerouslySetInnerHTML={{
                                __html: title ? title.replace('red packet', '<span>red packet</span>') : '',
                            }}
                        ></p>
                    )}
                </div>
            </div>
        );
    }

    meetingSummaryGuidance() {
        return (
            <div className={css.meetingSummaryGuidanceWrap}>
                <div className={css.content}>
                    <span>
                        {this.locale('calendar_create_edit_meeting_summary_guidance1')}
                        <span className={css.createDoc} onClick={() => this.props.createMeetingSummary()}>
                            {this.locale('calendar_create_edit_meeting_summary_guidance2')}
                        </span>
                        {this.locale('calendar_create_edit_meeting_summary_guidance3')}
                    </span>
                </div>
            </div>
        );
    }

    // meetingModelGuidance
    meetingModelGuidance() {
        return (
            <div className={this.locale.getLang() === 'zh-CN' ? css.meetingModelGuidances : css.meetingModelGuidance}>
                <div className={css.title}>{this.locale('calendar_meeting_guidance_title')}</div>
                <ul className={css.content}>
                    <li>{this.locale('calendar_meeting_guidance_content1')}</li>
                    <li>{this.locale('calendar_meeting_guidance_content2')}</li>
                    <li>{this.locale('calendar_meeting_guidance_content3')}</li>
                    <li>{this.locale('calendar_meeting_guidance_content4')}</li>
                </ul>
            </div>
        );
    }

    // fileMessage
    fileMessage(iconFontClass, jcontent, jext) {
        const { file, idClient, isDownload, openFile, fileDownload } = this.props;

        // flag
        let iscosVideo = false;
        jcontent && (iscosVideo = true);

        const  relationId=iscosVideo ? jcontent.data.relationId : file.relationId;
        const downloadPath=util.cosfiles.fileDownloadStatusGet(relationId);

        const imgAddress = require(`@a/imgs/modelFileType/${iconFontClass}.svg`);
        let isDownloadFlag = false;

        if (downloadPath) isDownloadFlag = true;
        // if (this.props.againDownload) {
        //     isDownloadFlag = false
        // }
        let downloadstatus = this.props.fileDownloadProgress.find((v) => v.id == idClient);
        let filestatus = this.props.fileStatus.find((v) => v.id == idClient);
        if (filestatus) isDownloadFlag = !!filestatus.isDownloaded;

        const filePath =
            (filestatus && filestatus.downloadedPath) ||downloadPath;

        // arg
        let fileUrl = iscosVideo ? jcontent.data.fileUrl : file && file.url ? file.url : '';
        let csize = iscosVideo ? jcontent.data.fileSize : file.size;
        let fileName = iscosVideo ? jcontent.data.fileName : file.name;
        let fileExt = iscosVideo ? jext : file.ext;


        // message flow
        let fileBg = '',
            flowBg = '';
        if (this.props.emots && !!this.props.emots.length) {
            fileBg = css.fileBg;
            if (this.props.flow == 'in') {
                flowBg = css.inBg;
            } else if (this.props.flow == 'out') {
                flowBg = css.outBg;
            }
        }

        return (
            <div>
                <div className={`${fileBg} ${flowBg}`}>
                    <div className={css.contentFile}>
                        <div className={css.svgContent}>
                            <img src={imgAddress} className={css.file_svg} />
                        </div>
                        <div className={css.fileContent}>
                            <span className={css.fileName}>{fileName}</span>
                            <span className={css.fileSize}>
                                {util.yach.getFileSize(csize)}
                                {!!downloadstatus && <span></span>}
                                {!!downloadstatus && downloadstatus.speed}
                            </span>
                        </div>
                        <div className={css.operate}>
                            <Tooltip
                                placement="top"
                                title={isDownloadFlag ? util.locale('im_open') : util.locale('im_download')}
                            >
                                {isDownloadFlag ? (
                                    <a onClick={() => openFile({path:filePath, idClient,relation_id:relationId})}>
                                        <span
                                            className={`${css.download} iconfont-yach yach-zaixianwendang-dakaiwendangicon`}
                                        />
                                    </a>
                                ) : (
                                    <a
                                        className={downloadstatus ? css.downloading : ''}
                                        onClick={() =>
                                            fileDownload(fileUrl, idClient, fileName, fileExt, !!downloadstatus,relationId)
                                        }
                                    >
                                        <span
                                            className={`${css.download} iconfont-yach yach-kapian-wenjian-xiazai-moren`}
                                        />
                                    </a>
                                )}
                            </Tooltip>
                        </div>
                    </div>
                    {this.props.emots && !!this.props.emots.length && <ReplyEmots {...this.props} />}
                </div>
                {downloadstatus && (
                    <FileDownloadProgress
                        percent={downloadstatus.percent}
                        speed={downloadstatus.speed}
                        cancel={this.props.fileDownloadCancel.bind(null, idClient)}
                    />
                )}
            </div>
        );
    }
    /**
     *
     * @param {*} iconFontClass
     * @param {*} jcontent
     * @param {*} jext
     * 视频消息解析 添加注释和上传的cos功能
     */
    fileMessageVideo(iconFontClass, jcontent, jext) {
        // flag
        let iscosVideo = false;
        jcontent && (iscosVideo = true);

        // bg pic
        //const imgAddress = require(`@a/imgs/modelFileType/${iconFontClass}.svg`)
        let pic = this.props.avatar;
        let newPic = this.props.sessitonActivePic && this.props.sessitonActivePic[this.props.id];
        if (newPic && newPic !== this.props.avatar) pic = newPic;

        // arg
        const { file, idClient, clickVideo } = this.props;
        let fileUrl = iscosVideo ? jcontent.data.fileUrl : file && file.url ? file.url : '';
        let csize = iscosVideo ? jcontent.data.fileSize : file.size;
        let cdur = iscosVideo ? jcontent.data.dur : file.dur;
        let fileName = iscosVideo ? jcontent.data.fileName : file.name;
        let fileExt = iscosVideo ? jext : file.ext;
        let coverUrl = iscosVideo ? jcontent.data.coverUrl : file.coverUrl;
        let taskId = iscosVideo ? jcontent.data.taskId : file.taskId;
        let relationId = iscosVideo ? jcontent.data.relationId : file.relationId;

        const downloadPath=util.cosfiles.fileDownloadStatusGet(relationId);

        // download
        let isDownloadFlag = false;
        if (downloadPath) isDownloadFlag = true;
        let downloadstatus = this.props.fileDownloadProgress.find((v) => v.id == idClient);
        let filestatus = this.props.fileStatus.find((v) => v.id == idClient);
        if (filestatus) isDownloadFlag = !!filestatus.isDownloaded;
        const filePath =
            (filestatus && filestatus.downloadedPath) ||downloadPath

        // msg flow
        let fileBg = '',
            flowBg = '';
        if (this.props.emots && !!this.props.emots.length) {
            fileBg = css.fileBg;
            if (this.props.flow == 'in') {
                flowBg = css.inBg;
            } else if (this.props.flow == 'out') {
                flowBg = css.outBg;
            }
        }

        // style
        const videoWrapStyle = util.videoUtil.getStyle(iscosVideo ? jcontent.data : file);
        const thisStyle = util.videoUtil.getStyle(iscosVideo ? jcontent.data : file);
        if (videoWrapStyle.width < 140) videoWrapStyle.width = 140;
        if (videoWrapStyle.height < 140) videoWrapStyle.height = 140;
        const videoNoRadius = videoWrapStyle.width != thisStyle.width || videoWrapStyle.height != thisStyle.height;

        return (
            <div>
                <div className={`${fileBg} ${flowBg}`}>
                    <div
                        className={`${css.contentFile} ${css.videoWrap} ${coverUrl ? css.videoWrapBackground : ''}`}
                        style={videoWrapStyle}
                    >
                        {coverUrl ? (
                            <img src={coverUrl} alt="" className={css.coverUrl} />
                        ) : (
                            <div className={css.videPosition} style={thisStyle}>
                                <video
                                    className={`${css.video} ${videoNoRadius ? css.videoNoRadius : ''}`}
                                    preload="meta"
                                    style={thisStyle}
                                >
                                    <source src={fileUrl} type="video/mp4" />
                                </video>
                            </div>
                        )}
                        <div className={css.videoFileContent}>
                            <span>{util.yach.getFileSize(csize)}</span>
                            <span className={css.videoTime}>{util.videoUtil.getVideoTime(cdur)}</span>
                        </div>
                        <div
                            className={css.videoPlayWrap}
                            onClick={() =>
                                clickVideo({
                                    fileUrl,
                                    idClient,
                                    fileName,
                                    fileExt,
                                    isdownloading: !!downloadstatus,
                                    fileSize: util.yach.getFileSize(csize),
                                    filePath,
                                    fileDur: cdur,
                                    msg: this.props.msg,
                                    isDownloadFlag,
                                    pic,
                                    taskId,
                                    relationId,
                                    coverUrl,
                                    csize,
                                    width: util.videoUtil.getWH(iscosVideo ? jcontent.data : file).width,
                                    height: util.videoUtil.getWH(iscosVideo ? jcontent.data : file).height,
                                })
                            }
                        >
                            <p className={css.videoPlayInner}></p>
                        </div>
                    </div>
                    {this.props.emots && !!this.props.emots.length && <ReplyEmots {...this.props} />}
                </div>
                {downloadstatus && (
                    <FileDownloadProgress
                        percent={downloadstatus.percent}
                        speed={downloadstatus.speed}
                        cancel={this.props.fileDownloadCancel.bind(null, idClient)}
                    />
                )}
            </div>
        );
    }

    // officeMessage
    officeMessage() {
        const { file } = this.props;
        const fileUrl = file && file.url ? file.url : '';
        const fileName = file && file.name ? file.name : '';
        return (
            <div className={css.office}>
                <div className={css.fileContent}>
                    <div className={css.iconImg}>
                        <span className={css.icon} className="icon iconfont iconpdf" />
                    </div>
                    <div className={css.fileInfo}>
                        <span className={css.fileName}>{file.name}</span>
                        <span className={css.fileSize}>{util.yach.getFileSize(file.size)}</span>
                    </div>
                </div>
                <div className={css.download}>
                    <a onClick={() => this.props.showOffice(fileUrl, fileName)}>
                        <span className={css.icon} className="icon iconfont iconyulan" />
                        <span>预览</span>
                    </a>
                    <a
                        href={
                            fileUrl.indexOf('?') > 0
                                ? file.url + '&download=' + encodeURIComponent(file.name)
                                : file.url + '?download=' + encodeURIComponent(file.name) + '.' + file.ext
                        }
                        target="_blank"
                    >
                        <span className={css.icon} className="icon iconfont iconxiazai" />
                        <span>{util.locale('im_download')}</span>
                    </a>
                </div>
                {this.props.emots && !!this.props.emots.length && <ReplyEmots {...this.props} />}
            </div>
        );
    }

    // imgMessage
    imgMessage() {
        const url =
            this.props.file.url.indexOf('createTime') > 0
                ? this.props.file.url + '&imageView'
                : this.props.file.url + '?imageView&createTime=' + this.props.time;

        return (
            <div className={css.content}>
                <a onClick={() => this.props.showImg(url, this.props)}>
                    <img
                        style={{
                            width:
                                this.props.getImgScale(this.props.file.h, this.props.file.w) * this.props.file.w ||
                                '200px',
                            height:
                                this.props.getImgScale(this.props.file.h, this.props.file.w) * this.props.file.h ||
                                '100%',
                        }}
                        src={this.props.file.url}
                        alt={util.locale('im_image_lost')}
                        onContextMenu={(e) => e.preventDefault()}
                    />
                </a>
                {this.props.emots && !!this.props.emots.length && <ReplyEmots {...this.props} />}
            </div>
        );
    }

    // customMessage
    customMessage() {
        return <BoxContentMessageCustomContainer {...this.props} />;
    }

    // 计算语音长度
    computedAudioLength = (duration) => {
        let time = parseInt(duration);
        let minLength = 170;
        let maxLength = 322;
        time = Math.min(duration, 59);
        let length = minLength + ((time - 1) * (maxLength - minLength)) / 58;
        return length;
    };

    // audio
    audioMessage() {
        let flowAudio = '',
            isEmots = '';

        if (this.props.emots && !!this.props.emots.length) isEmots = css.isEmots;
        if (this.props.flow == 'in') {
            flowAudio = css.inAudio;
        } else if (this.props.flow == 'out') {
            flowAudio = css.outAudio;
        }
        let audioLength = this.computedAudioLength(this.props.file.dur / 1000) + 'px';

        let { messageExtraData = {}, idClient, isTeam, from, to } = this.props;
        let cvs = messageExtraData['call_voice'] || {};
        let { msgId = '', count, isListen } = cvs;
        return (
            <div
                ref={(el) => {
                    this.props.setVoiceReadRef(el);
                }}
                className={`${flowAudio} ${isEmots}`}
            >
                {flowAudio === css.inAudio && from !== to && !isListen && <span className={css.addioRedDot}></span>}
                <VoiceRead
                    flow={this.props.flow}
                    isTeam={isTeam}
                    audioText={this.props.audioText}
                    isShowAudioText={this.props.isShowAudioText}
                    audioUrl={this.props.file.mp3Url}
                    audioLength={audioLength}
                    audioDur={this.props.file.dur / 1000}
                    idClient={idClient}
                    msg={this.props.msg}
                    messageExtraData={messageExtraData}
                    //teamInfo={this.props.teamInfo}
                    robotNum={this.props.robotNum}
                />
                {this.props.emots && !!this.props.emots.length && <ReplyEmots {...this.props} />}
            </div>
        );
    }

    isMsgType(type){
        try {
            const _custom = util.nimUtil.getJson(this.props.content);
            return _custom.type == type;
        } catch (error) {
            return false;
        }

    }

    messageIn = () => {
        const inMessageType = ['text', 'image', 'audio', 'custom', 'video', 'file'];
        const inReplyType = [
            'text',
            'image',
            'audio',
            'file',
            'video',
            'replyAudio',
            '5',
            '6',
            '8',
            '10',
            '16',
            '25',
            '15',
            '26',
            '30',
            '31',
            '32',
            '38',
        ];
        const type = this.props.getCustomType();
        const box = this.props.box;
        let { robot_user } = this.props;

       const workStatus = util.yach.getP2pStatus(this.props.id)

        const isLinkMsg = linkMsgHandler.isLinkMsg(this.props);


        let pic = this.props.avatar;
        let newPic = this.props.sessitonActivePic[this.props.id];
        if (newPic && newPic !== this.props.avatar) pic = newPic;

        // const toolsEmel =  this.props.isTeam && ![7, 12, 14, 16, 19, 27, 28].includes(type);
        const toolsEmel =
            this.props.isTeam && util.customEnum.emoteType.includes(type);
            
        const toolsReply = this.checkVoteReplay() && (inReplyType.includes(type) || isLinkMsg);
        const toolsMore = type != 4;
        const { fromNick, yachNick, time, isTeam, id, showUserinfo, handleAtMember } = this.props;
        return (
            <div id={this.props.idClient}>
                <div className={css.other}>
                    <img
                        className={css.userImgIn}
                        src={pic}
                        style={id == 3004 ? { cursor: 'default' } : {}}
                        onClick={id != 3004 ? showUserinfo : null}
                    />
                    <div className={`${css.message} ${isTeam ? '' : css.p2pMessage}`}>
                        <div className={css.contentTitle}>
                            {isTeam && (
                                <span
                                    className={css.name}
                                    onClick={() => handleAtMember({ id, fromNick, yachNick, robot_user })}
                                >
                                    <span className={css.sign}>@</span>
                                    {fromNick}
                                    {!!yachNick && `(${yachNick})`}
                                </span>
                            )}
                            {(workStatus.isShow && this.props.isTeam) && 
                                <div className={css.statusBox}>
                                    <img className={css.statusIcon} src={workStatus.emojiSrc}></img>
                                    <span className={`${css.statusText}`}>
                                        {workStatus.statusText}
                                    </span>
                                </div>
                            }
                            {robot_user && (
                                <img
                                    src={require('@a/imgs/robotIcon.png')}
                                    style={{ width: '40px', height: '16px', marginRight: '5px' }}
                                />
                            )}
                            <span className={css.time}>{util.formatDate.sessionDateFormat(time)}</span>
                        </div>
                        <div className={css.contentItem}>
                            <Dropdown
                                overlay={this.inMenu()}
                                trigger={['contextMenu']}
                                getPopupContainer={() => box}
                                visible={this.state.contextMenu}
                                onContextMenu={this.showtextMenu}
                            >
                                <div>{this.renderContent()}</div>
                            </Dropdown>
                            {inMessageType.includes(this.props.type) && this.props.showTools && (
                                <React.Fragment>
                                    {!this.props.showCheckbox && (
                                        <div className={css.inTools}>
                                            {toolsEmel && (
                                                <Popover
                                                    className={`${css.tools} ${
                                                        !toolsMore && !toolsReply ? css.oneTools : ''
                                                    }`}
                                                    content={this.emojiContent()}
                                                    trigger="click"
                                                    onVisibleChange={this.props.handleVisibleChange}
                                                    visible={this.props.emojiVisible}
                                                >
                                                    <span
                                                        onClick={() => this.props.setActive(5)}
                                                        className={`${
                                                            css.tool_icon
                                                        } iconfont-yach yach-goutong-qipaogongnengqu-biaoqingicon-moren ${
                                                            5 == this.props.toolItemActive
                                                                ? css.toolItemActive
                                                                : css.toolItemDefault
                                                        }`}
                                                    />
                                                </Popover>
                                            )}
                                            {toolsReply && (
                                                <div
                                                    className={`${css.tools} ${
                                                        !toolsMore && !toolsEmel ? css.oneTools : ''
                                                    }`}
                                                >
                                                    <Tooltip placement="top" title={util.locale('im_reply')}>
                                                        <span
                                                            onClick={() => {
                                                                this.props.setActive(6);
                                                                this.props.replyMsg();
                                                            }}
                                                            className={`${
                                                                css.tool_icon
                                                            } iconfont-yach yach-goutong-qipaogongnengqu-huifuicon-moren ${
                                                                6 == this.props.toolItemActive
                                                                    ? css.toolItemActive
                                                                    : css.toolItemDefault
                                                            }`}
                                                        />
                                                    </Tooltip>
                                                </div>
                                            )}
                                            {toolsMore && (
                                                <Dropdown
                                                    overlay={this.inMenu()}
                                                    placement="topCenter"
                                                    trigger={['click']}
                                                    getPopupContainer={() =>
                                                        document.getElementById(this.props.idClient)
                                                    }
                                                >
                                                    <div
                                                        className={`${css.tools} ${
                                                            !toolsEmel && !toolsReply ? css.oneTools : ''
                                                        }`}
                                                        onClick={() => {
                                                            this.setState({ isShowTip: false });
                                                        }}
                                                        onMouseOver={() => {
                                                            this.setState({ isShowTip: true });
                                                        }}
                                                        onMouseOut={() => {
                                                            this.setState({ isShowTip: false });
                                                        }}
                                                    >
                                                        <Tooltip
                                                            placement="top"
                                                            title={util.locale('im_more_function')}
                                                            visible={this.state.isShowTip}
                                                        >
                                                            <span
                                                                onClick={() => this.props.setActive(7)}
                                                                className={`${
                                                                    css.tool_icon
                                                                } iconfont-yach yach-goutong-qipaogongnengqu-gengduoicon-moren ${
                                                                    7 == this.props.toolItemActive
                                                                        ? css.toolItemActive
                                                                        : css.toolItemDefault
                                                                }`}
                                                            />
                                                        </Tooltip>
                                                    </div>
                                                </Dropdown>
                                            )}
                                        </div>
                                    )}
                                </React.Fragment>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    messageOut() {
        const outReplyType = [
            'text',
            'image',
            'audio',
            'file',
            'video',
            'replyAudio',
            '5',
            '6',
            '8',
            '10',
            '16',
            '25',
            '26',
            '30',
            '31',
            '32',
            '38'
        ];
        const isRead = this.setRemind(this.props);
        const { remind, showUnreadPersion, time, target } = this.props;
        const type = this.props.getCustomType();
        const box = this.props.box;
        const sendLoading = <img className={css.messageLoading} src={loadingIcon} />;
        const isLinkMsg = linkMsgHandler.isLinkMsg(this.props);
        const isPlaceholderLink =
            isLinkMsg.status == linkMsgHandler.status.PLACEHOLDER || isLinkMsg.status == linkMsgHandler.status.FAIL; //本地 link 假消息状态
        let pic = this.props.avatar;
        if (this.props.avatar !== this.props.userInfo.pic) pic = this.props.userInfo.pic;

        // const toolsEmel =
        //     this.props.isTeam &&
        //     type != 14 &&
        //     type != 16 &&
        //     type != 7 &&
        //     type != 12 &&
        //     type != 19 &&
        //     type != 27 &&
        //     type != 28;

        const toolsEmel =
            this.props.isTeam && util.customEnum.emoteType.includes(type);
        const toolsReply = this.checkVoteReplay() && (outReplyType.includes(type) || isLinkMsg) && target != '3002';
        const toolsMore = true;

        const globalState = window.store.getState();

        const isP2pReadStatusShow = !this.props.isTeam && 
                                    !globalState.chatRobot && 
                                    //type != 38 && // 自动回复
                                    this.props.status == 'success';
        const isTeamReadStatusShow = this.props.isTeam &&
                                    this.props.status == 'success' &&
                                    //type != 38 && // 自动回复
                                    (this.props.memberNum - this.props.robotNum <= 2000);


        return (
            <div id={this.props.idClient}>
                <div className={css.messageOut}>
                    <div className={css.self}>
                        <img className={css.userImgOut} src={pic} onClick={this.props.showUserinfo} />
                        <div className={css.contentTitle}>
                            <span className={css.time}>{util.formatDate.sessionDateFormat(time)}</span>
                        </div>
                        {this.isUploadFile() ? (
                            <BoxContentMessageUploadContainer {...this.props} />
                        ) : (
                            <div className={css.contentItem}>
                                <div
                                    className={`${
                                        this.props.status == 'success' ? css.contentBox : css.contentBoxFail
                                    }`}
                                >
                                    {this.props.status == 'sending' && (
                                        <Spin indicator={sendLoading} style={{ fontSize: 18, marginRight: 8 }} />
                                    )}
                                    {this.props.status == 'success' && this.props.showTools && !isPlaceholderLink && (
                                        <React.Fragment>
                                            {!this.props.showCheckbox && (
                                                <div className={css.outTools}>
                                                    {toolsEmel && (
                                                        <Popover
                                                            className={`${css.tools} ${
                                                                !toolsMore && !toolsReply ? css.oneTools : ''
                                                            }`}
                                                            content={this.emojiContent()}
                                                            trigger="click"
                                                            placement="rightTop"
                                                            onVisibleChange={this.props.handleVisibleChange}
                                                            visible={this.props.emojiVisible}
                                                        >
                                                            <span
                                                                onClick={() => this.props.setActive(3)}
                                                                className={`${
                                                                    css.tool_icon
                                                                } iconfont-yach yach-goutong-qipaogongnengqu-biaoqingicon-moren ${
                                                                    3 == this.props.toolItemActive
                                                                        ? css.toolItemActive
                                                                        : css.toolItemDefault
                                                                }`}
                                                            />
                                                        </Popover>
                                                    )}

                                                    {toolsReply && (
                                                        <div
                                                            className={`${css.tools} ${
                                                                !toolsMore && !toolsEmel ? css.oneTools : ''
                                                            }`}
                                                        >
                                                            <Tooltip placement="top" title={util.locale('im_reply')}>
                                                                <span
                                                                    onClick={() => {
                                                                        this.props.setActive(2);
                                                                        this.props.replyMsg();
                                                                    }}
                                                                    className={`${
                                                                        css.tool_icon
                                                                    } iconfont-yach yach-goutong-qipaogongnengqu-huifuicon-moren ${
                                                                        2 == this.props.toolItemActive
                                                                            ? css.toolItemActive
                                                                            : css.toolItemDefault
                                                                    }`}
                                                                />
                                                            </Tooltip>
                                                        </div>
                                                    )}
                                                    {toolsMore && (
                                                        <Dropdown
                                                            getPopupContainer={() =>
                                                                document.getElementById(this.props.idClient)
                                                            }
                                                            overlay={this.outMenu()}
                                                            placement="topCenter"
                                                            trigger={['click']}
                                                        >
                                                            <div
                                                                className={`${css.tools} ${
                                                                    !toolsEmel && !toolsReply ? css.oneTools : ''
                                                                }`}
                                                                onClick={() => {
                                                                    this.setState({ isShowTip: false });
                                                                }}
                                                                onMouseOver={() => {
                                                                    this.setState({ isShowTip: true });
                                                                }}
                                                                onMouseOut={() => {
                                                                    this.setState({ isShowTip: false });
                                                                }}
                                                            >
                                                                <Tooltip
                                                                    placement="top"
                                                                    title={util.locale('im_more_function')}
                                                                    visible={this.state.isShowTip}
                                                                >
                                                                    <span
                                                                        onClick={() => this.props.setActive(1)}
                                                                        className={`${
                                                                            css.tool_icon
                                                                        } iconfont-yach yach-goutong-qipaogongnengqu-gengduoicon-moren ${
                                                                            1 == this.props.toolItemActive
                                                                                ? css.toolItemActive
                                                                                : css.toolItemDefault
                                                                        }`}
                                                                    />
                                                                </Tooltip>
                                                            </div>
                                                        </Dropdown>
                                                    )}
                                                </div>
                                            )}
                                        </React.Fragment>
                                    )}
                                    {this.props.status == 'fail' && (
                                        <img
                                            onClick={this.props.resendMsg}
                                            className={css.messageFail}
                                            src={warningIcon}
                                        />
                                    )}
                                    {!isPlaceholderLink && !this.props.showCheckbox ? (
                                        <Dropdown
                                            overlay={this.outMenu()}
                                            trigger={['contextMenu']}
                                            getPopupContainer={() => box}
                                            onContextMenu={this.showtextMenu}
                                            visible={this.state.contextMenu}
                                        >
                                            <div>{this.renderContent()}</div>
                                        </Dropdown>
                                    ) : (
                                        this.renderContent()
                                    )}
                                </div>
                                <div className={css.contentFooter}>
                                    <div className={css.footerContent}>
                                        {/* 单聊 */}
                                        {isP2pReadStatusShow && (
                                                <div className={css.singleMessageState}>
                                                    {!this.props.target && <span>{util.locale('common_read')}</span>}
                                                    {this.props.mtime !== 'self' &&
                                                    this.props.target &&
                                                    this.props.target != 3002 &&
                                                    this.props.target != 3013 &&
                                                    type != 35 &&
                                                    type != 19 ? (
                                                        this.props.time <= this.props.mtime ? (
                                                            <span>{util.locale('common_read')}</span>
                                                        ) : isRead ? (
                                                            <span
                                                                style={{ color: '#298DFF', cursor: 'pointer' }}
                                                                onClick={remind}
                                                            >
                                                                {util.locale('common_unread')}
                                                            </span>
                                                        ) : (
                                                            <span style={{ color: '#298DFF' }}>
                                                                {util.locale('common_unread')}
                                                            </span>
                                                        )
                                                    ) : null}
                                                </div>
                                            )}
                                        {/* 群聊 */}
                                        {isTeamReadStatusShow && (
                                                <div className={css.groupMessageStateUnread}>
                                                    {this.props.showTeamMsg && this.props.unread != '' ? (
                                                        this.props.unread - this.props.robotNum <= 0 ? (
                                                            <span className={css.read}>
                                                                {util.locale('im_all_read')}
                                                            </span>
                                                        ) : (
                                                            <span
                                                                style={{ cursor: 'pointer' }}
                                                                onClick={(e) =>
                                                                    showUnreadPersion(
                                                                        this.props.unread,
                                                                        this.props.memberNum -
                                                                            this.props.robotNum -
                                                                            this.props.unread -
                                                                            1,
                                                                        {
                                                                            unread: this.props.unread,
                                                                            memberNum: this.props.memberNum,
                                                                            robotNum: this.props.robotNum,
                                                                        }
                                                                    )
                                                                }
                                                            >
                                                                {Math.max(0, this.props.unread - this.props.robotNum)}{' '}
                                                                {util.locale('im_unread')}
                                                            </span>
                                                        )
                                                    ) : (
                                                        <span></span>
                                                    )}
                                                </div>
                                            )}
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        );
    }

    noForwardMsgType = () => {
        return ['audio', '3', 'replyAudio', '4', '19', '27', '32','35'];
    };

    checkLaterMsgType = type => {
        let typearr = ['text', 'replyAudio', 'image', '8', 'video', '30', 'file', '16', 'audio', '7', '23', '6', '31', '15', '36', '5', '10', '11', '26', '25']
        return typearr.includes(type)
    }



    isUploadFile = () => {
        let { isLocal, type, msg } = this.props;
        isLocal = isLocal || (msg ? msg.isLocal : false);
        if (!isLocal || type !== 'custom') return false;
        const content = util.nimUtil.getJson(this.props.content);
        if (content.status == 'uploading') {
            return true;
        }
        return false;
    };

    checkVoteReplay = () => {
        return util.yach.checkVoteReplay();
    };

    fileDownloadFromMenu = () => {
        let idClient = this.props.idClient;
        let downloadstatus =
            this.props.fileDownloadProgress && this.props.fileDownloadProgress.find((v) => v.id == idClient);
        util.sensorsData.track('Click_ChatWindow_MessageOperate', { OperateType: '01-106' });
        if (this.props.type == 'custom') {
            let content = null;
            try {
                content = JSON.parse(this.props.content);
            } catch (err) {}
            if (!content) return false;

            let data = content.data || {};
            // return this.props.fileDownload(
            //     data.fileOriginUrl || data.fileUrl,
            //     idClient,
            //     data.fileName,
            //     data.ext,
            //     !!downloadstatus,
            // );
            return this.props.fileDownload(
                data.fileOriginUrl || data.fileUrl,
                idClient,
                data.fileName,
                data.ext,
                !!downloadstatus,
                data.relationId
            );
        } else {
            if (!this.props.file) return;

            let name = this.props.file.name || 'file';
            const ext = this.props.file.ext || 'mp4';

            if (this.props.file.md5 == name || this.props.file.md5 + '.' + ext == name) {
                name = `${util
                    .locale('common_msg42')
                    .replace('[xxx]', moment(parseInt(Date.now())).format('YYYY-MM-DD HH:mm'))}`;
                name = `${name}.${ext}`;
            }
            if (this.props.file && this.props.file.url) {
                // return this.props.fileDownload(this.props.file.url, idClient, name, ext, !!downloadstatus);
                return this.props.fileDownload(this.props.file.url, idClient, name, ext, !!downloadstatus,data.relationId);
            }
        }
    };

    inMenu() {
        const inMessageType = ['text', 'image'];
        const customMsgType = ['6', 'replyAudio', '8'];
        const replyType = [
            'text',
            'image',
            'audio',
            'file',
            'video',
            '5',
            '6',
            '8',
            '10',
            '15',
            '16',
            'replyAudio',
            '25',
            '26',
            '30',
            '31',
            '32',
            '38',
        ];
        const {
            isShowAudioText,
            type,
            toggleAudioText,
            remind,
            schedule,
            copyToClipboard,
            forwardMsg,
            ownerId,
            isTeam,
            deleteMsg,
            file,
            multiSelect,
            toDo,
            ismanager,
            isSelf,
            delSelfMsg,
            translateAndReduction,
            isOriginal,
            setLater,
        } = this.props;
        const customType = this.props.getCustomType();
        const isLinkMsg = customType == 23 || customType == 24;
        const admin = ismanager && !isSelf && isTeam; // 撤销是否在最下面排序
        const isRemind = type == 'text' || isLinkMsg || customType == 6 || customType == 32 || this.isMsgType(38);
        const isCopy = inMessageType.includes(type) || customMsgType.includes(customType) || isLinkMsg || this.isMsgType(38);
        return (
            <Menu>
                {isRemind && <Menu.Item onClick={remind}>{util.locale('calendar_top_tab_remind')}</Menu.Item>}
                {isCopy   && <Menu.Item onClick={() => copyToClipboard(type, customType)}>{util.locale('im_copy')}</Menu.Item>}
                {!this.noForwardMsgType().includes(this.props.getCustomType()) && (
                    <Menu.Item onClick={forwardMsg}>{util.locale('media_forwarding')}</Menu.Item>
                )}
                {this.checkVoteReplay() && (replyType.includes(type) || replyType.includes(customType) || isLinkMsg) && (
                    <Menu.Item
                        onClick={() => {
                            this.props.setActive(6);
                            this.props.replyMsg();
                        }}
                    >
                        {util.locale('im_reply')}
                    </Menu.Item>
                )}
                {this.checkLaterMsgType(customType) && (
                    <Menu.Item onClick={setLater}>{util.locale('im_later')}</Menu.Item>
                )}
                {(type === 'text' || customType === '6' || customType == '38' || customType === 'replyAudio') && this.props.showAutoTranslation && (
                    <Menu.Item onClick={translateAndReduction}>
                        {isOriginal ? util.locale('im_translate') : util.locale('im_hide_translation')}
                    </Menu.Item>
                )}
                {(type === 'video' ||
                    customType === '5' ||
                    customType === '8' ||
                    customType === '10' ||
                    customType === '30') && (
                    <Menu.Item onClick={this.fileDownloadFromMenu}>{util.locale('im_download')}</Menu.Item>
                )}
                {<Menu.Item onClick={multiSelect}>{util.locale('im_multi_select')}</Menu.Item>}
                {type == 'audio' && (
                    <Menu.Item onClick={() => toggleAudioText(file.url, this.props.idClient)}>
                        {isShowAudioText ? util.locale('im_put_text') : util.locale('im_turn_text')}
                    </Menu.Item>
                )}
                {<Menu.Item onClick={delSelfMsg}>{util.locale('im_delete_msg')}</Menu.Item>}
                {(type == 'text' || customType === '6' || customType == '38') && (
                    <Menu.Item className={css.menuItemBorderTop} onClick={schedule}>
                        {util.locale('calendar_top_tab_schecule')}
                    </Menu.Item>
                )}
                {(type === 'text' || customType === '6' || isLinkMsg || customType == '38') && (
                    <Menu.Item
                        className={type == 'text' || customType === '6' ? '' : css.menuItemBorderTop}
                        onClick={toDo}
                    >
                        {util.locale('im_todo')}
                    </Menu.Item>
                )}
                {isTeam && customType != '14' && customType != '26' && customType != '28' && customType != '19' && customType != '35' && admin && (
                    <Menu.Item className={css.menuItemBorderTop} onClick={deleteMsg}>
                        {util.locale('remind_add_tip_recall')}
                    </Menu.Item>
                )}
            </Menu>
        );
    }

    outMenu() {
        const outMessageType = ['text', 'image'];
        const customMsgType = ['6', 'replyAudio', '8'];
        const replyType = [
            'text',
            'image',
            'audio',
            'file',
            'video',
            '5',
            '6',
            '8',
            '10',
            '15',
            '16',
            'replyAudio',
            '25',
            '26',
            '30',
            '31',
            '32',
            '38',
        ];
        const {
            isShowAudioText,
            type,
            toggleAudioText,
            remind,
            schedule,
            copyToClipboard,
            forwardMsg,
            deleteMsg,
            file,
            multiSelect,
            toDo,
            content,
            time,
            ismanager,
            delSelfMsg,
            translateAndReduction,
            isOriginal,
            setLater,
        } = this.props;
        const customType = this.props.getCustomType();
        const isLinkMsg = customType == 23 || customType == 24;
        const isReplay = content && content.includes('"type":6');
        const localTime = new Date().getTime();
        const serverLocalTimeDiff = util.yachLocalStorage.ls('serverLocalTimeDiff');
        const serverTime = localTime + serverLocalTimeDiff;
        const isMore24Hours = ismanager || serverTime - time < 24 * 3600 * 1000;
        const isRemind = type == 'text' || isLinkMsg || isReplay || customType == 32 || this.isMsgType(38); // 个人状态 ->  自动回复
        const isCopy = outMessageType.includes(type) || customMsgType.includes(customType) || isLinkMsg || this.isMsgType(38);
        const isTranslate = (type === 'text' || customType === '6' || customType == '38' || customType === 'replyAudio') && this.props.showAutoTranslation;
        const isDownload = type === 'video' || customType === '5' || customType === '8' || customType === '10' || customType === '30';
        const isRecall = customType != '19' && customType != '35' && customType != '14' && customType != '28' && isMore24Hours && this.props.from !== this.props.to;
        
        return (
            <Menu>
                {isRemind && <Menu.Item onClick={remind}>{util.locale('calendar_top_tab_remind')}</Menu.Item>}
                {isCopy   && <Menu.Item onClick={() => copyToClipboard(type, customType)}>{util.locale('im_copy')}</Menu.Item>}
                {!this.noForwardMsgType().includes(this.props.getCustomType()) && (
                    <Menu.Item onClick={forwardMsg}>{util.locale('media_forwarding')}</Menu.Item>
                )}
                {this.checkVoteReplay() && (replyType.includes(type) || replyType.includes(customType)) && (
                    <Menu.Item
                        onClick={() => {
                            this.props.setActive(2);
                            this.props.replyMsg();
                        }}
                    >
                        {util.locale('im_reply')}
                    </Menu.Item>
                )}
                {this.checkLaterMsgType(customType) && (
                    <Menu.Item onClick={setLater}>{util.locale('im_later')}</Menu.Item>
                )}
                {isTranslate && (
                    <Menu.Item onClick={translateAndReduction} >
                        {isOriginal ? util.locale('im_translate') : util.locale('im_hide_translation')}
                    </Menu.Item>
                )}
                {isDownload && (
                    <Menu.Item onClick={this.fileDownloadFromMenu}>{util.locale('im_download')}</Menu.Item>
                )}
                {<Menu.Item onClick={multiSelect}>{util.locale('im_multi_select')}</Menu.Item>}
                {isRecall && (
                    <Menu.Item onClick={deleteMsg}>{util.locale('remind_add_tip_recall')}</Menu.Item>
                )}
                {type == 'audio' && (
                    <Menu.Item onClick={() => toggleAudioText(file.url, this.props.idClient)}>
                        {isShowAudioText ? util.locale('im_put_text') : util.locale('im_turn_text')}
                    </Menu.Item>
                )}
                {<Menu.Item onClick={delSelfMsg}>{util.locale('im_delete_msg')}</Menu.Item>}
                {(type == 'text' || customType === '6' || customType == '38') && (
                    <Menu.Item className={css.menuItemBorderTop} onClick={schedule}>
                        {util.locale('calendar_top_tab_schecule')}
                    </Menu.Item>
                )}
                {(type === 'text' || customType === '6' || isLinkMsg || customType == '38') && (
                    <Menu.Item onClick={toDo}>{util.locale('im_todo')}</Menu.Item>
                )}
            </Menu>
        );
    }

    renderContent() {
        const { type, file = {}, content } = this.props;
        switch (type) {
            case 'text': {
                return this.textMessage();
            }
            case 'image': {
                return this.imgMessage();
            }
            case 'file': {
                // return this.fileMessage('wenjian2');
                return this.fileMessage('_other');
            }
            case 'video': {
                if (file.coverUrl) return this.fileMessageVideo('_video');
                if (['mp4', 'ogg', 'webm', 'mov'].includes(`${file.ext || ''}`.toLowerCase())) {
                    return this.fileMessageVideo('_video');
                } else {
                    return this.fileMessage('_video');
                }
            }
            case 'word': {
                return this.officeMessage();
            }
            case 'pdf': {
                return this.officeMessage();
            }
            case 'audio': {
                return this.audioMessage();
            }
            /**
             * 视频cos需要兼容云信版本
             */
            case 'custom': {
                // ios 其他端神奇的类型 明明是对象  但是有些端的有些消息过来居然是 【空字符串】
                if (content) {
                    const jcontent = util.nimUtil.getJson(content);
                    if (jcontent && typeof jcontent === 'object' && jcontent.data && jcontent.type === 30) {
                        const jext = jcontent.data.ext || util.videoUtil.getFileExtendingName(jcontent.data.fileUrl);
                        if (jcontent.data.coverUrl) return this.fileMessageVideo('_video', jcontent, jext);
                        if (['mp4', 'ogg', 'webm', 'mov'].includes(jext.toLowerCase()))
                            return this.fileMessageVideo('_video', jcontent, jext);
                        return this.fileMessage('_video', jcontent, jext);
                    }
                }
                return this.customMessage();
            }
            default: {
                return this.noDateMessage();
            }
        }
    }

    isTeamAutoReply(type, scene){// 群聊 -> 自动回复
        return type == 39 && this.props.isTeam;
    }

    getItem = () => {
        let item;

        if (this.props.flow == 'in' && this.props.type != 'notification' && !this.props.isSelf) {
            // in 是收到
            item = this.messageIn();
        }
        if (
            (this.props.flow == 'out' && this.props.type != 'notification' && this.props.type != 'tip') ||
            this.props.isSelf
        ) {
            // out 是发出
            item = this.messageOut();
        }
        if (this.props.type == 'notification') item = this.notificationMessage();
        if (this.props.type == 'tip') {
            item = this.notificationMessage();
        }

        try {
            let content = this.props && this.props.content;

            content =  util.nimUtil.getJson(content) || {};
            const type = content.type || 888888;
            const cdata = content.data || {}
            if (this.props.type == 'custom' && this.isTeamAutoReply(type, this.props.scene)) {
                item = this.notificationMessage();
            }

            if (type == 13) {
                let modifyName = '';
                //let data = JSON.parse(content).data;
                const account = util.yach.getAccount();
                const { senderId, receiverId, receiverName, senderName } = cdata;
                if (account != senderId && account == receiverId) {
                    modifyName = util.locale('common_redpack1').replace('[xxx]', senderName); //`你领取了 ${senderName} 的红包`
                } else if (account == senderId && account != receiverId) {
                    modifyName = util.locale('common_redpack2').replace('[xxx]', receiverName); //`${receiverName} 领取了你的红包`
                }
                item = this.redEnvelopenotification(modifyName);
            }

            if (type == 29) {
                item = this.meetingSummaryGuidance();
            }

            if (type == 33) {
                item = this.meetingModelGuidance();
            }
        } catch (error) {
            console.log(error);
        }
        return item;
    };

    render() {
        let showCheckBoxStyle = this.props.showCheckbox ? css.showCheckBox : '';
        return (
            <div
                ref={(el) => this.props.getItemRef(el)}
                className={`${css.box} ${showCheckBoxStyle}`}
                onMouseOver={this.props.itemMouseOver}
                onMouseLeave={() => {
                    this.props.itemMouseOff();
                    this.setState({ contextMenu: false });
                }}
                onClick={() => {
                    this.setState({ contextMenu: false });
                }}
                onContextMenu={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                }}
            >
                {this.getItem()}
            </div>
        );
    }
}
