// react
import React from 'react';
// css
import css from './index.scss';
// util
import * as util from '@u/util.js';


export default (props) => {
    const { breadcrumbList = [], handleAnyFolder,handlePreFolder } = props;

    return (
        breadcrumbList.length > 0 && (
            <div className={css.breadcrumbWrap}>
                <span
                    className={`${css.returnBtn} iconfont-yach yach-fanhui`}
                    onClick={handlePreFolder}
                />
                <div key={-1}>
                    <span
                        onClick={() => handleAnyFolder(-1)}
                    >
                        {util.locale('im_group_doc_all')}
                    </span>
                    <em>/</em>
                </div>

                {breadcrumbList.map((item, index) => {
                    const { relation_id, name } = item;
                    return index == breadcrumbList.length - 1 ? (
                        <div key={index} className={css.lastSpan}>
                            {name}
                        </div>
                    ) : (
                        <div key={relation_id}>
                            <span
                                onClick={() => handleAnyFolder(index)}
                            >
                                {name}
                            </span>
                            <em>/</em>
                        </div>
                    );
                })}
            </div>
        )
    );
};
