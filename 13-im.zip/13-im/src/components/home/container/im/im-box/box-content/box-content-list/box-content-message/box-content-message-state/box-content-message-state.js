// react
import React from 'react';

// antd
import { Row, Col, Spin } from 'antd';

// css
import css from './index.scss';

import * as util from '@/utils/util';

// user img
import userImg from '@a/imgs/user.png';
import { groupUsersListGet } from '@/services/group/group-info';
import * as yach from '@/utils/yach';

export default class BoxContentMessageState extends React.Component {
    state = {
        readAccounts: [],
        unreadAccounts: [],
        loading:true,
    };
    async componentDidMount() {
        //请求已读未读人数
        const { idServer, target } = this.props;
        const datas = await groupUsersListGet({ tid: target });
        let arr = [],
            oldArr = [];
        if (datas.code === 200) {
            const list = datas.obj.list || [];
            oldArr = list.owner.concat(list.admin, list.normal);
            oldArr.forEach(item => {
                arr = [...arr, ...item.value];
            });
        }
        const obj1 = await util.nimUtil.getTeamMsgReadAccounts(target, idServer);
        const { readAccounts, unreadAccounts } = obj1;
        this.setState({
            readAccounts: arr.filter(item =>
                readAccounts.includes(item.id + '')
            ),
            unreadAccounts: arr.filter(item =>
                unreadAccounts.includes(item.id + '')
            ),
            loading: false,
        });
    }

    render() {
        const { readAccounts, unreadAccounts,loading } = this.state;
        return (
            <div className = {css.contentMessageState}>
                <div
                    className={css.mask}
                    onClick={e => this.props.showUnreadPersion(false)}
                />
                <div className={css.box}>
                    {
                        loading?<div className={css.loading}>
                            <Spin />
                        </div>:null
                    }

                    <div className={css.content}>
                        <div className={css.unread}>
                            <p>
                                <span>{unreadAccounts.length}</span>{util.locale('im_unread')} {/**人未读 */}
                            </p>
                            <Row type="flex" align="middle">
                                {unreadAccounts.map(item => {
                                    const { id, name, pic, name_nick } = item;
                                    return (
                                        <Col
                                            span={12}
                                            key={id}
                                            onClick={util.yach.showUserinfo.bind(this, id)}>
                                            <img className={css.userImg} src={pic}/>
                                            <span>{name_nick?name+'('+name_nick+')':name}</span>
                                        </Col>
                                    );
                                })}
                            </Row>
                        </div>
                        <div className={css.read}>
                            <p>
                                <span>{readAccounts.length}</span>{util.locale('im_read')} {/**人已读 */}
                            </p>
                            <Row type="flex">
                                {readAccounts.map(item => {
                                    const {id, name, pic, name_nick} = item;
                                    return (
                                        <Col
                                            span={12}
                                            key={id}
                                            onClick={util.yach.showUserinfo.bind(this, id)}>
                                            <img className={css.userImg} src={pic}/>
                                            <span>{name_nick?name+'('+name_nick+')':name}</span>
                                        </Col>
                                    );
                                })}
                            </Row>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
