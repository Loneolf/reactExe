import React from 'react'
import css from './index.scss'

export default props => {
    return (
    <div className={css.box}>
        <webview src={props.url} />
    </div>
)
}