import React from 'react';
// util
import * as util from '@u/util.js';
import css from './index.scss';
import InfiniteScroll from 'react-infinite-scroller';
//antd
import { Tooltip, Spin } from 'antd';
// components
import CommonModal from '@/components/common/common-modal';
import GroupDocInput from '../box-group-document/group-doc-input/group-doc-input-container';
import newdoc from '@a/imgs/doc_normal/word.png';
import mosheet from '@a/imgs/doc_normal/excel.png';
import folder from '@a/imgs/doc_normal/dir.png';
import form from '@a/imgs/doc_normal/form.png';
import mindmap from '@a/imgs/doc_normal/mind.png';
import slide from '@a/imgs/doc_normal/ppt.png';
import whiteImg from '@a/imgs/doc_normal/white.png';
import nodataImg from '@a/imgs/doc_normal/nodata.png';
import UserAdd from '@c/common/user-add/user-add-container';
const inconObj = { newdoc, mosheet, folder, form, mindmap, slide, whiteImg };

export default (props) => {
    const {
        currentGuid,
        showRenameInput,
        defaultValue,
        createPlaceholder,
        showNameInput,
        showImg,
        fileType,
        openFile,
        breadcrumbList,
        refreshList,
        refreshSearchList,
        isSearch,
        ismanager,
        userInfo,
        loading,
        handleCalcStrLen,
        handleWidth
    } = props;
    const renameProps = { currentGuid, showRenameInput, defaultValue, refreshList, refreshSearchList, isSearch };
    const createProps = { createPlaceholder, showImg, fileType, openFile, refreshList, breadcrumbList, isSearch };
    const hasBread = !!(breadcrumbList && breadcrumbList.length > 1);
    const listSession = (
        <div className={css.box}>
            {!isSearch && hasBread && (
                <div className={css.breadcrumbWrap}>
                    <span className={`${css.returnBtn} iconfont-yach yach-fanhui`} onClick={props.toPre}></span>
                    {props.breadcrumbList.map((item, index) =>
                        index != props.breadcrumbList.length - 1 ? (
                            <span key={index} className={css.nameBox}>
                                <span className={css.rightName} onClick={props.toCurrent.bind(null, item)}>
                                    {item.name}
                                </span>
                                <span className={css.rightLine}>/</span>
                            </span>
                        ) : index == 0 ? (
                            <span key={index} className={css.nameBox}>
                                <span className={css.allList} onClick={props.toFirst}>
                                    {util.locale('im_group_doc_all')}
                                </span>
                                <span className={css.line}>/</span>
                            </span>
                        ) : (
                            <span key={index} className={css.lastSpan}>
                                {item.name}
                            </span>
                        )
                    )}
                </div>
            )}
            {showNameInput ? <GroupDocInput {...createProps} isRename={false} /> : null}
            <div className={!hasBread ? css.listWrap : css.listWrap+ ' ' +css.breadWrap}>
                {loading ? (
                    <div className={css.spinBox}>
                        <Spin />
                    </div>
                ) : !!props.docList.length ? (
                    <InfiniteScroll
                        initialLoad={false}
                        pageStart={0}
                        loadMore={props.handleInfiniteOnLoad}
                        hasMore={props.hasMore}
                        useWindow={false}
                        threshold={100}
                    >
                        {props.docList.map((item) => (
                            <div key={item.guid} className={css.listItemWrap} onClick={props.openFile.bind(null, item)}>
                                {currentGuid === item.guid && showRenameInput ? (
                                    <GroupDocInput {...renameProps} showImg={inconObj[item.type]} isRename={true} />
                                ) : (
                                    <>
                                        <img src={inconObj[item.type]} className={css.itemImg} />
                                        <div className={css.textWrap}>
                                            {
                                                !!(handleCalcStrLen(item.name) >= 30) ? (
                                                    <Tooltip title={item.name} mouseLeaveDelay={0}>
                                                        <p
                                                            className={`${css.textTop} ${css[handleWidth(item)]}`}
                                                            dangerouslySetInnerHTML={{ __html: item.replaceName || item.name }}
                                                        ></p>
                                                    </Tooltip>
                                                ) : (
                                                    <p
                                                        className={`${css.textTop} ${css[handleWidth(item)]}`}
                                                        dangerouslySetInnerHTML={{ __html: item.replaceName || item.name }}
                                                    ></p>
                                                )
                                            }
                                            <p className={css.textBottom}>
                                                <span>{util.formatDate.dayTimeFormat(item.created_at * 1000)}</span>
                                                <span
                                                    className={css.userName}
                                                    dangerouslySetInnerHTML={{ __html: item.creator }}
                                                ></span>
                                            </p>
                                        </div>
                                        <div className={css.btns}>
                                            {item.type === 'folder' ? null : (
                                                <Tooltip
                                                    align={{ offset: [0, 20]  }}
                                                    mouseLeaveDelay={0}
                                                    overlayClassName={css.tooltip}
                                                    placement="top"
                                                    title={util.locale('im_group_doc_share')}
                                                >
                                                    <span
                                                        className={`iconfont-yach yach-fenxiang1`}
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            props.share(item);
                                                        }}
                                                    ></span>
                                                </Tooltip>
                                            )}
                                            {(ismanager || userInfo.id == item.creator_id) && (
                                                <>
                                                    <Tooltip   
                                                        align={{ offset: [0, 20]  }} 
                                                        mouseLeaveDelay={0}
                                                        overlayClassName="tooltip"
                                                        placement="top"
                                                        title={util.locale('im_group_doc_rename')}
                                                    >
                                                        <span
                                                            className={`iconfont-yach yach-zhongmingming`}
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                props.rename(item);
                                                            }}
                                                        ></span>
                                                    </Tooltip>
                                                    <Tooltip
                                                        align={{ offset: [0, 20]  }}
                                                        mouseLeaveDelay={0}
                                                        overlayClassName={css.tooltip}
                                                        placement="top"
                                                        title={util.locale('im_group_doc_del')}
                                                    >
                                                        <span
                                                            className={`iconfont-yach yach-shanchu1`}
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                props.delete(item);
                                                            }}
                                                        ></span>
                                                    </Tooltip>
                                                </>
                                            )}
                                        </div>
                                    </>
                                )}
                            </div>
                        ))}
                    </InfiniteScroll>
                ) : (
                    <div className={css.nodataWrap}>
                        <img src={nodataImg} className={css.nodataImg} />
                        <p className={css.nodataText}>{util.locale('im_group_doc_no_file')}</p>
                    </div>
                )}
            </div>
            <CommonModal
                closable={false}
                modalTile={util.locale('im_reminder')}
                okText={util.locale('common_ok')}
                modalVisible={props.modalVisible}
                setOKModal={props.setOKModal}
                setonCancelModal={props.setonCancelModal}
                modalContent={util.locale('im_group_doc_delete')}
            />
            <UserAdd {...props.shareProps} />
        </div>
    );
    return listSession;
};
