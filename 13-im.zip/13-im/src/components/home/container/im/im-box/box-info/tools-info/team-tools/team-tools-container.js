// react
import React from 'react';

// util
import { locale } from '@u/util.js';
import { getGroupFileStatus } from '@u/yach/lib/yach-group-file.js';

// css
import css from './index.scss';
import { Tooltip, Popover } from 'antd';

import ToolsContainer from '../common/tools';

// 
export default props => {
    const { 
        teamType,
        groupDocGuide,
        closeGroupDocTips,
        closeGroupFileTips,
        closeSearchHistoryTips,
        meetingSummaryClick,
        showRightModal,
        searchHistoryGuide,
        groupFileGuide
    } = props;

    const groupDocTips = (
        <div className={css.guideBox} onClick={() => {closeGroupDocTips(true)}}>
            <span>{locale('im_group_doc_guide')}</span>
            <span className={`${css.btnOk} iconfont-yach yach-lujing`}></span>
        </div>
    )

    const groupFileTips = (
        <div className={css.guideBox} onClick={() => {closeGroupFileTips(true)}}>
            <span>{locale('im_group_file_guide')}</span>
            <span className={`${css.btnOk} iconfont-yach yach-lujing`}></span>
        </div>
    )

    const groupFileStatus = getGroupFileStatus()

    return(
        <div className={css.tool} id='tools'>
            {/* 开关控制群文件的打开 */}
            {groupFileStatus ? 
                <Popover content={groupFileTips}
                    overlayClassName={`GroupFilePopoverBox ${locale.getLang() === 'en-US' ? 'GroupFilePopoverBox1' : ''}`}
                    getPopupContainer={()=> document.getElementById('tools')}
                    visible={groupFileGuide}
                    placement='bottom'
                >
                    <Tooltip title={locale('im_group_file')} mouseEnterDelay={1}>
                        <span
                            className={`${css.icon} iconfont-yach yach-149goutong-huihuachuangkou-qunwendangicon`}
                            onClick={() => {closeGroupFileTips()}}
                        />
                    </Tooltip>
                </Popover>
                :
                <Popover content={groupDocTips}
                    overlayClassName={`GroupDocPopoverBox ${locale.getLang() === 'en-US' ? 'GroupDocPopoverBox1' : ''}`}
                    getPopupContainer={()=> document.getElementById('tools')}
                    visible={groupDocGuide}
                    placement='bottom'
                >
                    <Tooltip title={locale('im_group_doc_title')} mouseEnterDelay={1}>
                        <span
                            className={`${css.icon} iconfont-yach yach-149goutong-huihuachuangkou-qunwendangicon`}
                            onClick={() => {closeGroupDocTips()}}
                        />
                    </Tooltip>
                </Popover>
            }
            { teamType.type === 9 &&
                <Tooltip title={locale('calendar_create_meeting_summary')} mouseEnterDelay={1}>
                    <span
                        className={`${css.icon} iconfont-yach yach-149goutong-huihuachuangkou-huiyijiyaoicon`}
                        onClick={meetingSummaryClick.bind(this)}
                    />
                </Tooltip>
            }
            <Tooltip title={locale('media_notice')} mouseEnterDelay={1}>
                <span
                    className={`${css.icon} iconfont-yach yach-149goutong-huihuachuangkou-gonggaoicon`}
                    onClick={showRightModal.bind(this, {type: 'operation'})}
                />
            </Tooltip>
            <ToolsContainer 
                toolName={'search'}
                domId={'tools'}
                closeSearchHistoryTips={closeSearchHistoryTips}
                searchHistoryGuide={searchHistoryGuide}
                curSession={'group'}
            />
            <ToolsContainer 
                toolName={'more'}
                showRightModal={showRightModal}
                rightModalParams={{type: 'setting'}}
            />
        </div>
    )
}
