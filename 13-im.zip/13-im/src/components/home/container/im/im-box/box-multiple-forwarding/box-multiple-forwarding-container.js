// react
import React from 'react';
import {connect} from 'react-redux';
// BoxSend
import BoxMultipleForwarding from './box-multiple-forwarding';
// actions
import {selectList as selectListAdd, showCheckbox} from '@r/actions/messageListState';
import {add} from '@r/actions/messageList';
import { sessionActiveSet } from '@r/actions/session';
// services
import {forwardMsgAdd} from '@/services/forward/forward';
import {groupDocumentBind} from '@s/group/group-doc';
import { audioBusMessageDel } from '@/services/session/session'
// util
import * as util from '@u/util.js';
import { deleteSelf } from '@r/actions/messageList';

import css from './index.scss'


import {message, Modal} from 'antd';
const { confirm } = Modal;

// BoxSendContainer
class BoxMultipleForwardingContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state = {
        showForwardModal: false,
        loading: false,
        modalVisible: false,
        warnVisible: false,
        modalContent: '',
        warnContent: '',
        selectUser: {},
        selectItem: [],
        screeningFilterList: [], // 从screeningList过滤后的消息列表 提取出来需要转发的数据
        screeningList: [],       // 转发的原来的消息列表 元数据
        deleteDialog: false,
    };

    componentDidMount() {
        document.addEventListener('keydown',this.handleKeyDown);
    }

    
    componentWillUnmount() {
        document.removeEventListener('keydown',this.handleKeyDown);
    }
    handleKeyDown = e => {
        let keyCode = e.which || e.keyCode;
        if(keyCode == 27) this.forwardingClose();
    }

    showConfirm = ( title, content, okText, centered=true ) => {
        confirm({
            className: css.forwardingConfirm,
            maskClosable: true,
            centered,
            getContainer: () => document.getElementById('boxMultipleForwarding'),
            title,
            icon: <span className={css.titleTips} />,
            content,
            okText,
            onOk:() => {
                this.setOKModal();
            },
            onCancel:() => {
                console.log('Cancel');
            },
        });
      }

    /*
       修改原因：放开转发10条转发的限制
    */
    forwarding = () => {
        const { selectList } = this.props.messageListState;
        if(!selectList || !selectList.length) return;
        util.sensorsData.track('Click_ChatWindow_MessageOperate',{OperateType: 109});
        const { noScreeningList, screeningFilterList } = this.getSendContent(selectList);

        if(screeningFilterList.length>100){
            return this.setState({warnVisible: true, warnContent: util.locale('media_try_again')});
        }

        if(!noScreeningList.length){
            this.setState({showForwardModal: true});
        } else if(noScreeningList.length == 1) {
            this.showConfirm(`${util.locale('media_reminder')}`, `${util.locale('im_selected_contains')}${noScreeningList[0]}${util.locale('im_no_merge_forwarding')}`, `${util.locale('media_continue')}`);
        } else if(noScreeningList.length > 1) {
            this.showConfirm(`${util.locale('media_reminder')}`, `${util.locale('media_no_merge')}`, `${util.locale('media_continue')}`);
        }
    };

    setOKModal = () => {
        // this.setState({showForwardModal: true, modalVisible: false});
        this.setState({showForwardModal: true});
    };

    setonCancelModal = () => {
        this.setState({modalVisible: false});
    };

    forwardingClose = () => {
        this.props.dispatch(showCheckbox(false));
    };

    // 多选转发 权限校验
    forwardVoteCheck = async (arr)=>{
       try{
          return await util.yach.msgForwardingVoteCheck(arr);
       }
       catch(e){
           console.log('forwardVoteCheck',e);
       }
    }

    getUsers = async (value) => {

        this.setState({loading: true});
        let id = '',scene = '',tname = '';
        if(value.teams && value.teams.length>0){
            scene = 'team';
            id = value.teams[0].group_tid;
            tname = value.teams[0].group_name;
            // 首选校验一下权限
            const v = await this.forwardVoteCheck(value.teams);
            if(!v){
                message.error(`${util.locale('media_banned')}`);
                this.setState({showForwardModal: false, loading: false});
                return;
            }

        } else if(value.allDataUsers && value.allDataUsers.length>0){
            scene = 'p2p';
            id = value.allDataUsers[0].id;
        }
        const { name, name_nick } = this.props.userInfo;
        const { textareaValue } = value;
        const { showname } = this.props.sessionActive;
        const messageScene = this.props.sessionActive.type;
        let space = util.locale.getLang() === 'en-US' ? ' ' : ''
        let sendMsg = null,
            sendText = null;
        let content = {
            type: 7,
            data: {
                name: messageScene == 'team' ? `${showname}${util.locale('media_chat_records')}` : `${showname}${space}${util.locale('im_and')}${space}${name}${space}${util.locale('media_chat_record')}`,
                content: this.state.screeningFilterList.length>3 ? this.state.screeningFilterList.slice(0,3):this.state.screeningFilterList,
                sessionType: messageScene,
                sessionID: this.props.sessionActive.id
            }
        };
        if(!this.state.screeningFilterList.length) {
            this.setState({showForwardModal: false, loading: false});
            this.props.dispatch(showCheckbox(false));
            this.props.dispatch(selectListAdd([]));
            if(!textareaValue){
                message.error(`${showname}${util.locale('media_no_forward')}`);
                return;
            }
        }else{
            try {
                const isUpload = await this.uploadForwardingData();
                // 新需求 多选转发不在需求进行文档的绑定了

                if( isUpload.obj && isUpload.obj.uniq){
                    let pushPayload = {};
                    let pushContent = '',
                        apns = '';
                    const uniq = isUpload.obj && isUpload.obj.uniq;

                    if(scene == 'p2p'){
                        pushPayload = {
                            pushTitle: util.yach.decodeUnicode(name_nick || name),
                            sessionType: 0,
                            sessionID: id,
                        }
                        pushContent = `[${util.locale('media_chat_record')}]${content.data.name}`;
                    } else {
                        pushPayload = {
                            pushTitle: util.yach.decodeUnicode(tname),
                            sessionType: 1,
                            sessionID: id,
                        }
                        pushContent = `${name}${name_nick?'('+name_nick+')':''}:[${util.locale('media_chat_records')}]${content.data.name}`;
                        apns = {
                            forcePush: false
                        }
                    }
                    content.data['uniq'] = uniq;
                    sendMsg = await util.nim.sendCustomMsg(scene, id, JSON.stringify(content), apns, '', '', pushContent, pushPayload);

                }
            } catch (error) {
                console.log('error', error);
                return message.error(`${util.locale('media_forward_failure')}`);
            }
            if(id == this.props.sessionActive.id) await this.addMessage(sendMsg);
        }
        if(textareaValue) {
            let pushPayloadText = {};
            let pushContentText = '',
                apnsText = '';

            if(scene == 'p2p'){
                pushPayloadText = {
                    pushTitle: util.yach.decodeUnicode(name_nick || name),
                    sessionType: 0,
                    sessionID: id
                }
                pushContentText = `${textareaValue}`;
            } else {
                pushPayloadText = {
                    pushTitle: util.yach.decodeUnicode(tname),
                    sessionType: 1,
                    sessionID: id
                }
                pushContentText = `${name}${name_nick?'('+name_nick+')':''}:${textareaValue}`;
                apnsText = {
                    forcePush: false
                }
            }

            sendText = await util.nim.sendText(scene, id, textareaValue, apnsText, '', pushContentText, pushPayloadText);
            if(id == this.props.sessionActive.id) await this.addMessage(sendText);
        }
        this.setState({showForwardModal: false, loading: false});
        if(!sendMsg && !sendText){
            message.error(`${util.locale('media_forward_failure')}`);
        } else {
            message.success(`${util.locale('media_forward_success')}`);
            util.yachLocalStorage.ls('message_id',{message_id:sendMsg.idClient,id:sendMsg.to})
            util.yach.sendMessageSensorsData(107);
            util.yachLocalStorage.ls('message_id',{message_id:sendMsg.idClient})
        }

        this.props.dispatch(showCheckbox(false));
        this.props.dispatch(selectListAdd([]));
        util.yach.getMultipleForwadSession(value.users, value.teams);
    };


    uploadForwardingData = async() => {
        let {screeningList} = this.state;
        if(!screeningList || !screeningList.length) return false;
        /**
         * 按时间排序
         */
        if(screeningList.length>1){
            screeningList.sort((a,b)=>{
                try{
                    a = JSON.parse(a);
                    b = JSON.parse(b);
                    return a.time - b.time;
                }catch(error){
                    console.log('转发数据排序异常',a,b);
                    return 0;
                }
            });
        }
        screeningList = screeningList.map(i=> {
            let obj;
            try {
                obj={...JSON.parse(i), avatar: ''}
                return JSON.stringify(obj);
            } catch (error) {
                console.log('转发数据排序异常',obj);
                return 0;
            }
        });
        const datas = await forwardMsgAdd({msgs: JSON.stringify(screeningList)});
        const {code} = datas || {};
        if (code === 200) {
            return datas;
        }
        return false;
    }

    addMessage = async(item) => {
        if(!item) return;
        let obj = await util.nim.genMsgItem(item);
        if(this.props.sessionActive.type == 'team'){
            const teamMembers = await util.nimUtil.getTeamMembers(this.props.sessionActive.id);
            obj = Object.assign(obj, {read: 0, unread: teamMembers.members.length-1});
        }
        this.props.dispatch(add(obj));
    }

    getSendContent = (selectList) => {
        let screening = [],
            noScreeningList = [],
            screeningFilter = [];
        for (let index = 0; index < selectList.length; index++) {
            if(selectList[index]){
                const element = JSON.parse(selectList[index]);
                let screeningObj = {
                    fromNick: element.fromNick,
                    idClient: element.idClient,
                    type: element.type,
                    time: element.time
                }
                let text,
                    customType,
                    docGuid,
                    docTitle,
                    docType,
                    docLink;
                if(element.status != 'success'){
                    noScreeningList.push(util.locale('media_not_a'));
                } else if(element.type == 'text'){
                    text = element.text.substr(0, 50);
                } else if(element.type == 'custom'){
                    let customContent = util.nimUtil.getJson(element.content);
                    if (customContent.type == 2){
                        text = `[${customContent.data.title}]`;
                        customType = 2;
                    } else if (customContent.type == 5) {
                        text = `[${util.locale('media_file')}]`;
                        customType = 5;
                    } else if(customContent.type == 6){
                        if(customContent.data.type == 'audio'){
                            noScreeningList.push(util.locale('media_voice'));
                        }else{
                            text = element.text.substr(0, 50);
                            customType = 6;
                        }
                    } else if(customContent.type == 3){
                        noScreeningList.push(util.locale('media_announcement'));
                    } else if(customContent.type == 7){
                        noScreeningList.push(util.locale('media_forwarding'));
                    } else if(customContent.type == 8){
                        text = `[${util.locale('media_image')}]`;
                        customType = 8;
                    } else if(customContent.type == 10 ) {
                        text = `[${util.locale('media_file')}]`;
                        customType = 10;
                    } else if(customContent.type == 16) {
                        text = `[${util.locale('media_online_document')}]`;
                        docGuid = customContent.data.guid;
                        docTitle = customContent.data.title;
                        docType = customContent.data.type;
                        docLink = customContent.data.link;
                        customType = 16;
                    } else if(customContent.type == 25){
                        text = `[${util.locale('Emoji')}]`;
                        customType = 25;
                    } 
                    else if(customContent.type == 26){
                        text = `[${util.locale('im_folder')}]`;
                        customType = 26;
                    } 
                    else if(customContent.type == 15) {
                        text = '[markdown]';
                        customType = 15;
                    }
                    // 尽量使用 ===
                    else if(customContent.type === 30){
                        text = `[${util.locale('media_video')}]`;
                        customType = 30;
                    } 
                    else if(customContent.type === 31){
                        text = `[${util.locale('im_location')}]`;
                        customType = 31;
                    }
                    else if(customContent.type === 38){// // 私聊 -> 个人状态 -> 自动回复  多选
                        try {
                            text = customContent.data.content.reply_content;
                        } catch (error) {
                            console.error('多选[自动回复]消息时出现异常：', error)
                        }
                        
                        customType = 38;
                    }
                    else {
                        noScreeningList.push(util.locale('im_special_message_types'));
                    }
                } else if(element.type == 'pdf'){
                    text = `[${util.locale('media_file')}]`;
                    customType = 5;
                } else if(element.type == 'image'){
                    text = `[${util.locale('media_image')}]`;
                } else if(element.type == 'video'){
                    text = `[${util.locale('media_video')}]`;
                } else if(element.type == 'file'){
                    text = `[${util.locale('media_file')}]`;
                } else if(element.type == 'audio'){
                    noScreeningList.push(util.locale('media_voice'));
                } 
                if(text) {
                    screeningFilter.push(Object.assign(screeningObj, {text, customType, docGuid, docTitle, docType, docLink}));
                    screening.push(selectList[index]);
                }
            }
        }
        screeningFilter = screeningFilter.sort((a, b) => {
            return a['time'] > b['time'] ? 1 : -1;
        });
        this.setState({screeningFilterList: screeningFilter});
        this.setState({screeningList: screening});
        return {
            noScreeningList: noScreeningList,
            screeningFilterList: screeningFilter
        };
    }

    closegetUser = async () => {
        this.setState({showForwardModal: false, loading: false})
    };

    warnCancelModal = () => {
        this.setState({warnVisible: false});
    }

    deleteSelectMsg = ()=>{
        const { selectList } = this.props.messageListState;
        if(!selectList || !selectList.length) return;
        this.setState({deleteDialog: true})
    }
    deleteSelectMsgOk = ()=>{
        const { selectList } = this.props.messageListState; 

        let deleteList = [];
        const account = util.yach.getAccount();
        selectList.forEach(item => {
            try {
                item = JSON.parse(item);
                if (item && item.msg) {
                    deleteList.push(item);
                    if (!item.msg.idServer) {
                        // 发送失败的消息，只需要删除本地消息
                        util.nimUtil.deleteLocalMsg(item.msg);
                    } else {
                        util.yach.handleDeleteMessage(item.msg, account);
                    }
                }
            } catch (error) {console.log(error)}
        })

        this.props.dispatch(selectListAdd([]));
        this.setState({deleteDialog: false});
        this.forwardingClose();
        
        this.props.dispatch(deleteSelf(deleteList));

        // audioBusMessageDel({ 
        //     clientId: deleteList.map(v => v.idClient).join(','), 
        //     idDel: 1
        // })
        util.yach.messageDelReport(deleteList.map(v => v.idClient).join(','))
    }

    deleteSelectMsgCan = ()=>{
        this.setState({
            deleteDialog: false
        })
    }

    render() {
        const forwardMsgProps = {
            type: "forward",
            check: 'radio',
            loading: this.state.loading,
            show: this.state.showForwardModal,
            onOk: this.getUsers,
            onClose: this.closegetUser,
            title: util.locale('media_forward_message'),
            rightTitle: util.locale('media_recent_chat'),
            showButtonNumber: true,
            disabledids: [-1, -2],
            maxLength: 1 + 2
        };
        return (
            <BoxMultipleForwarding
                forwarding = {this.forwarding}
                forwardingClose = {this.forwardingClose}
                forwardMsgProps = {forwardMsgProps}
                modalVisible = {this.state.modalVisible}
                setOKModal = {this.setOKModal}
                setonCancelModal = {this.setonCancelModal}
                modalContent = {this.state.modalContent}
                selectList = {this.props.messageListState.selectList}
                warnVisible = {this.state.warnVisible}
                warnContent = {this.state.warnContent}
                warnCancelModal = {this.warnCancelModal}
                deleteSelectMsg     = {this.deleteSelectMsg}
                deleteSelectMsgCan  = {this.deleteSelectMsgCan}
                deleteSelectMsgOk   = {this.deleteSelectMsgOk}
                deleteDialog        = {this.state.deleteDialog}
            />
        );
    }
}

const mapStateToProps = state => {
    return {
        sessionActive: state.sessionActive,
        messageListState: state.messageListState,
        userInfo: state.userInfo
    };
};

export default connect(mapStateToProps)(BoxMultipleForwardingContainer);
