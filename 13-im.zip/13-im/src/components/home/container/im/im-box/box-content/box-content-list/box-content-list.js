// react
import React from 'react';

// css
import css from './index.scss';

import BoxContentMessageContainer from './box-content-message/box-content-message-container';
// import moment from 'moment';


// component
import UserAdd from '@c/common/user-add/user-add-container';
//import BoxContentMessageStateContainer from './box-content-message/box-content-message-state/box-content-message-state-container';
import * as util from '@u/util.js';
import { Modal } from 'antd';


// BoxContentList 加个备注： 该组件是整个 messageList 的壳子
export default class BoxContentList extends React.Component {
    constructor(props) {
        super(props);
    }
    getEmotList = (emotList) => {
        let result = {};
        emotList = emotList || {};
        emotList = emotList.data || [];
        emotList.forEach((item)=>{
            result[item.msg_id] = item.emots;
        });
        return result;
    }

    showTime = (item,preItem)=>{
        if(preItem && (item.time - preItem.time < 60*1000*3)) return null
        try {
            let attach = item.msg.attach;
            let team = attach && attach.team && attach.team.serverCustom;
            let isEmotionReply = team && ~team.indexOf('emotion_reply')
            let isRed = false
            let content = util.nimUtil.getJson(item.content)
            if(content && content.type == 13){
                let account = util.yach.getAccount();
                if(content.data) {
                    let { senderId, receiverId } = content.data;
                    if (account != senderId && account != receiverId ) isRed = true
                }
            }
            if(isEmotionReply || isRed) return null
        } catch (error) {}
        let time = util.formatDate.sessionDateFormat(item.time)
        return (<div className={`${css.timeBox} ${this.props.showCheckbox ? css.checkTimeBox : ''}`}>{time}</div>)
    }

    isShowMultiCheck = (item) => {
        const isShowMultiCheck = this.props.showCheckbox && 
                                !item.isLocal && 
                                item.type != 'notification' && 
                                item.type != 'tip' && 
                                util.yach.getMsgType(item) != '39';// 群内的 自动回复

        return isShowMultiCheck;
    }
    

    render() {
        const emotList = this.getEmotList(this.props.emotList);

       
        
        return (
            <div className={css.box} onClick={(e) => util.yach.handleShowInfo(e)}>
                    {this.props.list.map((item,index) => (
                        <div 
                            key = {item.idClient} 
                            className={css.itemContent} 
                            id={`${item.idClient}boxBg`} 
                            style={{background: this.props.showCheckbox ? '' : 'transparent'}}
                        >
                            {this.showTime(item,index == 0 ? null : this.props.list[index-1])}
                            { this.isShowMultiCheck(item) &&
                                <div className={css.checkBoxDiv}>
                                    <input
                                        type="checkbox"
                                        className={`${css.checkBox} iconfont-yach yach-goutonghuihua-qietu-queding`}
                                        value={JSON.stringify(item)}
                                        onChange={e => this.props.onCheckboxChange(e, item)}
                                        id={`${item.idClient}box`}
                                    />
                                </div>
                            }
                            <div onClick={()=>this.props.labelClick(item)}>
                                <BoxContentMessageContainer
                                    {...item}
                                   // workStatus = {this.props.workStatus[`${item.id}`]}
                                    robot_user={this.props.robot_user[`${item.id}`]}
                                    emots = {emotList[item.idClient]||[]}
                                    box = {this.props.box}
                                    // key = {item.idClient}
                                    // idServer = {item.idServer}
                                    // idClient = {item.idClient}
                                    // flow = {item.flow}
                                    // status = {item.status}
                                    // text = {item.text}
                                    audioContent = {item.msg?item.msg.localCustom:''}
                                    // content = {item.content}
                                    // custom = {item.custom}
                                    // time = {item.time}
                                    // fromNick = {item.fromNick}
                                    // yachNick={item.yachNick}
                                    // avatar = {item.avatar}
                                    // type = {item.type}
                                    file = {item.file ? item.file : ''}
                                    isHiddenSessionType = {this.props.isHiddenSessionType}
                                    setVoiceReadHeigth = {this.props.setVoiceReadHeigth} 
                                    //shouldScroll = {this.props.shouldScroll}
                                    // firstActive={this.props.firstActive}
                                    remind = {() => this.props.remind(item)}
                                    schedule = {() => this.props.schedule(item)}
                                    multiSelect = {() => this.props.multiSelect(item)}
									deleteMsg = {() => this.props.deleteMsg(item.msg)}
                                    resendMsg = {() => this.props.resendMsg(item.msg)}
                                    forwardMsg = {(e, msg) => this.props.forwardMsg( msg || item.msg)}
                                    isInAt = {this.props.isInAt(item.msg)}
                                    replyMsg = {() => this.props.replyMsg({...item.msg,robot:this.props.robot_user})}
                                    showUnreadPersion = {(unread,read,option)=>this.props.showUnreadPersion(true, item.idServer, item.target, unread, read, item,option)}
                                    standbyMtime = {this.props.standbyMtime}
                                    toDo = {() => this.props.toDo(item)}
                                    msgObj = {item}
                                    messageExtraData = {this.props.messageExtraData[item.idClient]}
                                    //teamInfo = {this.props.teamInfo}
                                    delSelfMsg = {() => this.props.delSelfMsg(item.msg)}
                                    deleteDialog = {this.props.deleteDialog}
                                    isAutotranslation = {this.props.isAutotranslation}
                                   // targetLanguage = {this.props.targetLanguage}
                                />
                            </div>
                        </div>
                    ))}  
                <UserAdd {...this.props.forwardMsgProps} />
                <Modal
                    visible       = {this.props.deleteDialog}
                    onOk          = {this.props.deleteSelectMsgOk}
                    onCancel      = {this.props.deleteSelectMsgCan}
                    centered      = {true}
                    closable      = {!1}
                    maskClosable  = {!1}
                    bodyStyle     = {{fontSize:14, fontWeight:500, color:'#2F3238' }}
                    wrapClassName = {css.wrapClassName}
                    >
                    <p>{util.locale("im_message_action_delete_dialog")}</p>
                </Modal>
            </div>
        );
    }
}
