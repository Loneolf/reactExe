// react
import React from 'react';

// css
import css from './index.scss';

// antd
import { Spin } from 'antd';

import * as util from '@u/util.js';

import loadingIcon from '@a/imgs/loading.gif'

import _ from 'lodash';

// components
import BoxContentListContainer from './box-content-list/box-content-list-container';

// BoxContent
export default class BoxContent extends React.Component {
    constructor(props) {
        super(props);
        this.box = null;
        this.setBoxRef = element =>{
            this.box = element;
        }
    }

    loadingIcon(){
        return(<img className={css.loadingIcon}src={loadingIcon} alt="" />)
    }

    render() {
        const {emotList, 
                list, 
                showLoading, 
                setVoiceReadHeigth, 
                setBoxContentRef,
                showFullLayout,
                enterOnlineMeeting,
                groupType,
                hasJoinThisMeetingText, 
                isAutotranslation, 
               // targetLanguage, 
                goBackFooter, 
                backFooterInfo,
                goDingMsg, 
                dingMsgs,
                isFirstDingDone,
                receiptDone
            } = this.props;

        const  meetState =  showFullLayout();
        const  hasEnterMeeting = hasJoinThisMeetingText();
        const newMsg = backFooterInfo.type == 'new' ? css.newMsg : css.goFooter;

        const hasDingMsg = util.yach.gd('session-has-ding-msg') || false;
        const isShowDingFlag =hasDingMsg && receiptDone && dingMsgs && dingMsgs.length > 0;

        return (
            <div className={ css.boxall + util.style.getWinStyle(css, 'boxAllWin')} id="box-content"> 
                {
                   meetState.show && <div className={css.meetingState}>
                        <div className={css.leftA}>
                            {/* {  groupType !==1 &&  <span className={"iconfont-yach yach-pcduanxianshanghuiyishi-huiyizhuangtaizuocetubiao"+' '+css.headerimg}></span>} */}
                            {  groupType ===1 &&  <span className={"iconfont-yach yach-xianshangbangongshi-dingbutishilvtiaoicon"+' '+css.headerimg}></span>}

                            { groupType ===1  &&  <span className={css.title}> {util.locale('media_online_office')}</span> }
                            { groupType !==1  &&  <span className={css.title}> {util.locale('media_online_conference')}</span> }

                            <div className={css.imgbox}>
                            {
                                meetState.list.length && meetState.list.map(item=>{
                                        return <img src={item.user_pic} alt={item.user_name}  title ={item.user_name} key={item.user_pic} />
                                })
                            }
                            </div>
                        </div>
                        <a className={css.joinButton}  onClick={_.debounce(enterOnlineMeeting, 500)} >{
                            hasEnterMeeting ? `${util.locale('media_joined')}`:`${util.locale('media_join')}`
                        }</a>
                     </div>
                }
                {
                    isShowDingFlag && (
                        <div className={css.goDingMsg} onClick={goDingMsg.bind(this)}>
                            <span className={`iconfont-yach ${isFirstDingDone ? 'yach-xiaoshouxia' : 'yach-xiaoshoushang'}`}></span>
                            <span>{util.locale('im_effect_quick_Mentioned')}</span>
                        </div>
                    )
                }
                {
                    backFooterInfo.show && (
                        <div className={newMsg + ' ' + css.goBackCommon} onClick={goBackFooter.bind(this)}>
                            <span className="iconfont-yach yach-149_xiangxiajiantou" />
                            <span>{backFooterInfo.data}</span>
                        </div>
                    )
                }
                <div
                    className={css.box}
                    ref={el => {this.setBoxRef(el); setBoxContentRef(el);}}
                >
                    {(list && list.length > 0 && showLoading ) &&
                        <Spin className={css.spin} indicator={this.loadingIcon()} spinning={showLoading} />
                    }
                    <BoxContentListContainer
                        box = {this.box}
                        list={list}
                        //shouldScroll={shouldScroll}
                        // firstActive={firstActive}
                        setVoiceReadHeigth = {setVoiceReadHeigth}
                       // workStatus = {this.props.workStatus}
                        robot_user={this.props.robot_user}
                        emotList = {emotList}
                        //teamInfo = {this.props.teamInfo}
                        isAutotranslation = {isAutotranslation}
                       // targetLanguage = {targetLanguage}
                    />
                </div>

                {/* <div className={css.posTest}>
                    <button onClick={testPosition}>点击定位</button>
                </div> */}
            </div>
        );
    }
}
