// react
import React from 'react';

// util
// import { getSessionSateById, busyIconUrl } from '@/utils/yach';
import * as util from '@u/util.js';

// css
import css from './index.scss';
import { Tooltip } from 'antd';

// component
import DepartTag from '@c/common/departmentTag/index.js'
import ApproveTag from '@c/common/approveTag/index.js'

// 
export default props => {
    const { 
        id,
        messageType, 
        is_robot,
        showname,
        isHiddenSessionType,
        showNickName,
        yachNick,
        showsign,
        getUsermsgBoxRef,
        showDepart,
        // busyinfo
    } = props;

    function getStatusText(text, len = 10){
        len = util.locale.getLang() == 'en-US' ? 20 : 10;
        return text && text.length > len ? `${text.slice(0, len)}...` : text
    }

    //let {service_type, service_typeText} = getSessionSateById(id);

    let unUserSession = messageType == 'team' || id == 3002 || id == 3013 || is_robot
    let scheduleTyle = (id && `${id}`.length == 4) || isHiddenSessionType
    
    //let statusText =  messageType !== 'team' && !!service_type && service_type !== '999' && `[${service_typeText}]`
    const userStatue = util.yach.getP2pStatus(id);

    return(
        unUserSession
        ? 
            <div className={css.tip}>
                <div className={css.usernameteam}>
                    <div className={css.teamText}>{showname}</div>
                    { showDepart == 1 && <div className={css.departTagBox}><DepartTag/></div> }
                    { showDepart == 3 && <div className={css.departTagBox}><ApproveTag/></div> }
                </div>
            </div> 
        : 
            <div className={css.tip}>
                <div className={`${css.username} ${ scheduleTyle ? css.schedule : ''}`}>
                    <div className={css.userNameText}>
                        {getStatusText(showNickName && (yachNick || showname))}
                        {userStatue.isShow && 
                            <>
                                <img src={userStatue.emojiSrc} className={css.busy}/>
                                <Tooltip placement="bottom" title={userStatue.statusText}>
                                    <span className={css.status}>{getStatusText(userStatue.statusText)}</span>
                                </Tooltip>
                            </>
                        }
                    </div>
                </div>
                {(!isHiddenSessionType && showsign) &&
                    <div className={css.usermsg}>
                        <span ref={el => getUsermsgBoxRef(el)}>
                            {showsign}
                        </span>
                    </div>
                }
            </div>
    )
}