/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-19 11:14:25
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-08-04 20:14:47
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
// antd
import { message } from 'antd';
import * as util from '@/utils/util';

import css from './index.scss';

import UserAdd from '@c/common/user-add/user-add-container';
import CommonModal from '@/components/common/common-modal';
import { showUserinfo } from '@/utils/yach';
import { adminList, squadAdminDel, adminAdd } from '@/services/group/group-user';
import { sessionActiveSet } from '@r/actions/session.js';
import { hideSlideModal } from "@/redux/actions/commonModal";
import { setBol } from '@r/actions/dismissTeamModa';

import * as teamCircleAction from '@r/actions/teamCircle';

// 侧边栏容器
class SettingAdminContainer extends Component {
    constructor(props) {
        super(props);
        this.state = {
          delSquadAdminModal: false,
          list: [],
          squadAddShow: false,
          userAddDisids: [],
          user: {
            name: '',
            user_id: ''
          }
        }
    }
    componentDidMount() {
      // const { sessionActive} = this.props
      // this.squad_id =  sessionActive.id

      this.isAddress = location.pathname.match(/\/address-list/)

      this.squad_id = window.session_active.id;
      this.adminList(this.squad_id)
    }

    adminList = async squad_id => {
      try {
        const data = await adminList({squad_id})
        if (data.code === 200) {
          const list = data.obj.data.list
          this.setState({
            list
          })
          this.handlerCurrentChange(list.length)
        } else this.handlerQuitSquad(data)
      } catch(e) {
        message.warning(e)
      }
    }
    
    // 移除管理员
    squadAdminDel = async () => {
      try {
        const data = await squadAdminDel({squad_id: this.squad_id, user_ids: this.state.user.user_id})
        if (data.code === 200) {
          const list = this.state.list.filter(item => item.user_id !== this.state.user.user_id)
          this.setState({
            list
          })
          this.handlerCurrentChange(list.length)
        } else message.warning(data.msg)
      } catch(e) {
        message.warning(e)
      }
      this.openSquadModal(false)
    }

    // 修改管理员数量
    handlerCurrentChange = len => {
      const user_info = this.props.teamCircleAdmin.user_info
      user_info.current = len
      this.props.updateIni({...this.props.teamCircleAdmin, user_info})
    }

    openSquadModal = (status, user) => {
      const opt = {
        delSquadAdminModal: status
      }
      if (user) opt.user = user
      this.setState(opt)
    }

    // 添加窗口开关
    squadAddSwitch = status => {
      this.setState({
          squadAddShow: status
      })
    }

    ownerIni = async obj => {
      if (!obj.currList || !obj.currList.length) return
      try {
        const squad_id = this.squad_id
        const user_ids = obj.currList.map(item => item.user_id).join(',')
        const data = await adminAdd({squad_id, user_ids})
        if (data.code === 200) {
          this.adminList(squad_id)
        } else this.handlerQuitSquad(data)
      } catch(e) {
        message.warning(e)
      }
      this.squadAddSwitch(false)
    }

    // 退出小组
    handlerQuitSquad = data => {
      data.msg && message.warning(data.msg)
      if (+data.code === 40303 || +data.code === 40304) {
        this.props.hideSlideModal()
        // const {id, type} = this.props.sessionActive;
        // const nimId = util.nim.getNimId(type, id);

        const { nimId } = window.session_active;
        util.nim.deleteLocalSession(nimId)
        this.props.sessionActiveSet({})
        this.props.setBol(false)
      }
    }

    render() {
        return (
          <div className={css.adminbox}>
            <div className={css.bottom}>
              <p className={css.exit} onClick={() => {this.squadAddSwitch(true)}}>
                  <span>{util.locale("im_add_team_administrator")}</span>
                  <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
              </p>
            </div>
            <div className={css.scoller}>
            {
              Array.isArray(this.state.list) && this.state.list.length ? 
              this.state.list.map(item => {
                return (
                  <div className={css.users} key={item.user_id}>
                    <img onClick={() => {showUserinfo(item.user_id, 106)}} src={item.pic} className={css.head} />
                    <span onClick={() => {showUserinfo(item.user_id, 106)}} className={css.name}>{item.name}</span>
                    <span onClick={() => {this.openSquadModal(true, item)}} className={css.del}>{util.locale("im_remove")}</span>
                  </div>
                )
              }) : <div className={css.none}>{util.locale("im_please_add_administrator")}</div>
            }
            </div>
            <CommonModal
                modalVisible={this.state.delSquadAdminModal}
                setOKModal={this.squadAdminDel}
                setonCancelModal={() => {this.openSquadModal(false)}}
                modalContent={`${util.locale("im_whether_remove")}${this.state.user.name}${util.locale("im_administrator")}`}
            />
            <UserAdd
                typeMsg={{type: 'squad', value: util.locale("im_team")}}
                show={this.state.squadAddShow}
                onClose={() => {this.squadAddSwitch(false)}}
                disabledids={this.state.list.map(item => item.user_id)}
                leftTitle={util.locale("im_administrator")}
                title={util.locale("im_add_team_administrator")}
                listTitle={util.locale("im_select_group_leader")}
                type={'squad'}
                isAdmin={true}
                onOk={this.ownerIni}
                maxLength={Math.min(this.props.teamCircleAdmin.user_info.total - this.state.list.length, this.props.teamCircleAdmin.user_info.total) + this.state.list.length}
            />
          </div>
        );
    }
}

const mapStateToProps = state => {
  return {
      // sessionActive: state.sessionActive,
      teamCircleAdmin: state.teamCircleAdmin
  };
};

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
      sessionActiveSet: () => dispatch(sessionActiveSet({})),
      hideSlideModal: () => dispatch(hideSlideModal()),
      setBol: () => dispatch(setBol()),
      updateIni: data => dispatch(teamCircleAction.updateIni(data))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SettingAdminContainer);
