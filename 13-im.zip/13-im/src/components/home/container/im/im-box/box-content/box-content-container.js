// react
import React from 'react';
// BoxContent
import BoxContent from './box-content';
// util
import * as util from '@u/util.js';
// redux
import {connect} from 'react-redux';
// actions
import { sessitonActivePicSet } from '@r/actions/session.js';
import { setBackFooterTitle, setDingMsg } from '@r/actions/boxContent';
// debounce
import debounce from 'lodash/debounce';
// antd
import {message} from 'antd';

let isFirstDingDone = false;
import { setServerMode,setServerFirst } from '@r/actions/serverRender';


// BoxContentContainer
export class BoxContentContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showLoading: false,
            //shouldScroll: false,
            isClickMessage: false,
            oldScrollHeight: 0,
            // firstActive: true,
            idClient: null,
            // fristIn: false,
            // messageList : [],
           // workStatus: {},
            robot_user: {},
            //teamInfo: {},
            receiptDone: false,
        };
    }

    componentDidMount() {
        this.handleScroll = debounce(this.handleScroll, 300);
        this.goDingMsg    = debounce(this.goDingMsg, 500, {'leading': true,'trailing': false});
        this.box.addEventListener('scroll', this.handleScroll);
        util.eventBus.addListener('clickMessageId', value => this.ifHasAnchorJustScorll(value));
        // this.setState({firstActive: true});
        // this.setFirstActive();
        this.getLoadMoreUp();
        this.addWatermarkPower();
        window.addEventListener('resize', this.resizeWatermarkPoser)
        // this.getSessionInfo();
        this.props.dispatch(setBackFooterTitle({show: false, data: ''}));

        util.yach.sd('box-content-first-into', true);
        isFirstDingDone = false;

        util.yach.handleUnreadDingMsg();
        setTimeout(() => {this.setState({receiptDone: true})}, 600);
    }

    componentWillUnmount(){
        clearTimeout(this.setFirstTimer);
        this.box.removeEventListener('scroll', this.handleScroll);
        util.eventBus.removeListener('clickMessageId');
        this.removeWatermarkPower();
        window.removeEventListener('resize', this.resizeWatermarkPoser);
    }

    getLoadMoreUp = () => {
        // this.setState({fristIn: false})
        this.setFirstTimer = setTimeout(()=>{
            if(this.box && this.box.scrollTop == 0){
                this.loadMoreUp('loadmore');
            }
            // this.setState({firstActive: true, fristIn: false});
            // this.setFirstActive();
        }, 3000);
    }

     handleScroll =  e => {
        if(!this.box) return;
        const { scrollTop, scrollHeight } = this.box;
        if(this.state.isClickMessage) return this.ifHasAnchorJustScorll(this.state.idClient);
        if (e.target !== this.box) {
            return;
        }
        // this.setState({
        //     shouldScroll: (scrollHeight || 0) === clientHeight || scrollTop > (scrollHeight || 0) - clientHeight * 2
        // });
        if(scrollTop<50){
            this.setState({oldScrollHeight: scrollHeight});
            if(this.props.messageList && this.props.messageList.length>0){
                if(this.props.serverRenderMode) this.remoteLoadPre();
                else this.loadMoreUp('loadmore')
            } 
        }
        this.gotoFooterAndNewMessage();
        this.remoteLoadNext();
    }

    // 回到底部
    gotoFooterAndNewMessage = ()=>{
        // box-content 距离底部向上滚动的高度
        const scrollClientHeight = this.getScrollClientHeight();
        util.yach.sd('scroll-client-height-over', scrollClientHeight > 350? !0 :false);
        if (scrollClientHeight < 100) this.props.dispatch(setBackFooterTitle({show: false, data: ''}));
    }


    // nextpage
    remoteLoadNext = async ()=>{
        const scrollClientHeight = this.getScrollClientHeight();
        if( scrollClientHeight <= 700 && this.props.serverRenderMode && this.props.effectQuickPage){
            this.serverpos = this.box.scrollTop;
            this.props.dispatch(setServerFirst(false));
            await util.yach.loadMoreFromRemote(true,true);
            this.box.scrollTop =  this.serverpos;
        }
    }

    // prepage 
    remoteLoadPre = async () =>{
        if(this.props.messageList.length >= 30) this.setState({ showLoading: true });
        this.props.dispatch(setServerFirst(false));
        await util.yach.loadMoreFromRemote(0);
        this.setState({
            showLoading: false
        }, () => {
            this.box.scrollTop = (this.box && this.box.scrollHeight || 0) - this.state.oldScrollHeight-20;
        });
    }

    // 远端数据  loadmore
    // handleHasMore = ()=>{
    //     const { serverRenderMode,serverRenderHasmore } = this.props;
    //     return serverRenderMode && serverRenderHasmore;
    // }

    loadMoreUp = async(type) => {
        if(this.state.isClickMessage) return;
        if(this.props.messageList.length >= 30) this.setState({ showLoading: true });
        util.log('qiuyanlong','messageList load more',this.props.sessionActive.id);
        let obj = await util.nim.pushMessageList(
            this.props.sessionActive.type,
            this.props.sessionActive.id,
            this.props.messageList.length ? this.props.messageList[0].time : undefined,
            30,
            true,
            1
        );
        if(!obj || obj.lastMessageLength < 30){
                this.setValueFalse();
                return;
        }
        if(type == 'loadmore'){
            this.setState({
                showLoading: false
            }, () => {
                this.box.scrollTop = (this.box && this.box.scrollHeight || 0) - this.state.oldScrollHeight-20;
            });
        }else{
            this.setState({
                showLoading: false
            }, () => {
                this.box.scrollTop = 0;
            });
        }
    };

    setValueFalse = () =>{
        this.setState({showLoading: false});
    };

    setVoiceReadHeigth = (height) => {
        this.box.scrollTop += height;
    }

    getScrollClientHeight = () => {
        const {scrollTop, scrollHeight, clientHeight} = this.box;
        const scrollClientHeight = (scrollHeight || 0) - scrollTop - clientHeight;
        return scrollClientHeight
    }

    //滚动
    ifHasAnchorJustScorll = (value) => {
        if (!!value) {
            let anchorElement = document.getElementById(value);
            let boxAnchorElement = document.getElementById(`${value}boxBg`);
            if (anchorElement) {
                this.setState({isClickMessage: true, idClient: value});
                boxAnchorElement.scrollIntoView();

                anchorElement.classList.remove('itemAnimation');
                setTimeout(() => {
                    anchorElement.classList.add('itemAnimation');
                }, 0);

                const scrollClientHeight = this.getScrollClientHeight();
                util.yach.sd('scroll-client-height-over', scrollClientHeight > 350? !0 :false);
                
                if (scrollClientHeight > 350) {
                    this.props.dispatch(setBackFooterTitle({show: true, data: util.locale('im_effect_quick_back'), type: 'go'}));
                } else {
                    this.props.dispatch(setBackFooterTitle({show: false}));
                }
                
                this.time && clearTimeout(this.time)
                this.time = setTimeout(()=>{
                    clearTimeout(this.time)
                    this.setState({isClickMessage: false, idClient: null});
                },1000);
            } else {
                message.warning(util.locale('im_message_not_found'));
            }
        }
    }

    //添加水印
    addWatermarkPower = () => {
        let sessionActive = this.props.sessionActive
        let parentId = 'box-content'
        if (sessionActive.type == 'team') {
            util.yach.addWatermarkPower(parentId)
        }
    }

    //移除水印
    removeWatermarkPower = () => {
        let sessionActive = this.props.sessionActive
        let parentId = 'box-content'
        if (sessionActive.type == 'team') {
            util.yach.removeWatermarkPower(parentId)
        }
    }

    //重绘水印
    resizeWatermarkPoser = () => {
        this.removeWatermarkPower()
        this.addWatermarkPower()
    }

    setBoxContentRef = el => {
        this.box = el;
        this.props.setBoxContentRef(el);
    };

    /*
       @办公室横幅
    */
    showFullLayout = ()=>{
        const {id,type} = this.props.sessionActive;
        const {id:tid,list} = this.props.showMeetingState;

        if(type === 'p2p') return false;
        if(type === 'team'){
            if( tid && tid === id ){
                return { show:list.length>0?true:false,list};
            }
        }
        return { show:false,list: [] }
    }

    /*办公室横幅进入的方法 */
    enterOnlineMeeting = ()=>{
        util.eventBus.emit('enter-online-meeting');
    }

    /*
      获取工作状态
    */
    searchMembersState = async messageList => {
        // let workStatus={}, 
        let statusSet= new Set();
        let robot_user = {}
        messageList.map((item)=>{
           item.flow == 'in' && statusSet.add(item.id);
        })
        if(statusSet.size){
            const users = await util.nimUtil.getUsers([...statusSet]);
            users.map(( user )=>{
                const custom = user.custom ? JSON.parse(user.custom) : {};
               // workStatus[user.account] = custom.work_status || null;
                robot_user[user.account] = custom.identification || null;
            });
            this.setState({
               // workStatus,
                robot_user
            })
        }
    }

    /*
       会议室横幅 已加入 加入文案
    */
   hasJoinThisMeetingText  = ()=>{
        const { isInMeeting,sessionActive } = this.props;
        const {id,type } = sessionActive;
        const { es, id:isInId} = isInMeeting;
        if(type !=='team') return ;
        if(es && id === isInId ){
            return true
        }
        return false;
   }

    //更新信息列表
    // updateMessageList = (pre, nextP) =>{
    //     let that = this;

    //     // 解决串会话问题
    //     const {messageList} = nextP;
    //     if(this.compareMessageList(messageList, pre.messageList)){
    //         that.setState({
    //             messageList
    //         }, () => {
    //             if(messageList.length>0) that.calcTime();
    //         });
    //     }
    // }

    // calc time
    calcTime(){
        if(window.session_load_time.step == 3){
            window.session_load_time.step   = 4;
            window.session_load_time.time4  = Date.now();

            // times
            let obj = [{
                name    : 'session_load_time_1',
                explain : 'nim.js-activeRow',
                time    : window.session_load_time.time2 - window.session_load_time.time1
            },{
                name    : 'session_load_time_2',
                explain : 'nim.js-activePushMessage',
                time    : window.session_load_time.time3 - window.session_load_time.time2
            },{
                name    : 'session_load_time_3',
                explain : 'nim.js-pushMessageList',
                time    : window.session_load_time.time4 - window.session_load_time.time3
            },{
                name    : 'session_load_time_all',
                explain : '总耗时',
                time    : window.session_load_time.time4 - window.session_load_time.time1
            }];

            // console
            console.table(obj);

            // elk
            var load_time = window.session_load_time.time4 - window.session_load_time.time1;
            util.elk.uploadELKPageData('session_item_loaded', load_time);

            // log
            var res = [];
            for(var i=0; i<obj.length; i++){
                var item = obj[i];
                res.push(item.time);
            }
            util.log(
                'qiaowenbin',
                'session load time',
                window.session_load_time.step,
                JSON.stringify(res)
            );
        }

        // clear
        window.session_load_time.step   = 0;
        window.session_load_time.time1  = null;
        window.session_load_time.time2  = null;
        window.session_load_time.time3  = null;
        window.session_load_time.time4  = null;
    }

    compareMessageList(curr, pre){
        try {
            if(curr.length !== pre.length){
                return true;
            }
            if(curr.find((v, index) => v.id !== pre[index].id)){
                return true;
            }
        } catch (error) {}
        return false;
    }

    componentDidUpdate = (pre) => {
        const {sessionActive, messageList} = this.props;
       //  this.updateMessageList(pre, this.props);
        if(messageList.length>0) this.calcTime();

        if(sessionActive && sessionActive.type == 'team'){ //群组会话会更新工作状态
            if(this.compareMessageList(messageList, pre.messageList)){
                this.searchMembersState(messageList)
            }
        }

        if(messageList.length > 0 && messageList.length !== pre.messageList.length ){
            this.sessitonActivePicSave(messageList)
        }
    }

    sessitonActivePicSave(messageList){
        if(messageList.length === 0) return
        let newObj = {}
        messageList.forEach((item) => {
            newObj[item.id] = item.avatar
        });
        this.props.dispatch(sessitonActivePicSet(newObj))
    }

    async goBackFooter() { console.log('xxx','scroll','goBackFooter')
        await util.yach.switchLocalMsgMode();

        if(!this.box) return;
        const {scrollHeight, clientHeight} = this.box;
        this.box.scrollTop = scrollHeight - clientHeight;

        window.store.dispatch(setBackFooterTitle({show: false, data: ''}));
    }

    goDingMsg =() =>{
        let {dingMsgs} = this.props;
        if (!dingMsgs || !dingMsgs.length) return;

        // idClient
        const firstMsg = dingMsgs.pop();

        this.timer && clearTimeout(this.timer);
        // 定位第一个以后，如果还存在@ 我的，则小手朝下
        if (dingMsgs.length) {
            this.timer = setTimeout(() => {
                clearTimeout(this.timer);
                isFirstDingDone = true;
            }, 80);
        }
        //util.yach.handleMessageJump(firstMsg.time, firstMsg.idClient);
        util.yach.locationSessionUseIdClient(firstMsg.idClient,firstMsg.time,true,this.props.sessionActive.id,true,true);

        util.sensorsData.track('Click_Chat_Element', {
            pageName: 135,
            $element_name: '01-272'
        });
    }

    render() {
        let {emotList, sessionActive, translationList, targetLanguage, backFooterInfo} = this.props;
        emotList ={data:emotList[sessionActive.id]}|| {};

        let isAutotranslation = translationList.includes(`${sessionActive.id}`);
        return (
            <BoxContent
                list                = {this.props.messageList}
                getHeight           = {this.props.getHeight}
                setBoxContentRef    = {this.setBoxContentRef}
                showLoading         = {this.state.showLoading}
                setVoiceReadHeigth  = {this.setVoiceReadHeigth}
                //shouldScroll={this.state.shouldScroll}
                // firstActive={this.state.firstActive}
                replyShow           = {this.props.reply.replyShow}
                //fristIn = {this.state.fristIn}
                showFullLayout      = {this.showFullLayout}
                enterOnlineMeeting  = {this.enterOnlineMeeting}
               // workStatus          = {this.state.workStatus}
                groupType           = {this.props.groupType}
                hasJoinThisMeetingText = {this.hasJoinThisMeetingText}
                robot_user          = {this.state.robot_user}
                emotList            = {emotList}
                //teamInfo            = {this.state.teamInfo}
                isAutotranslation   = {isAutotranslation}
                targetLanguage      = {targetLanguage}
                goBackFooter        = {this.goBackFooter}
                backFooterInfo      = {backFooterInfo}
                goDingMsg           = {this.goDingMsg}  
                dingMsgs            = {this.props.dingMsgs}  
                isFirstDingDone     = {isFirstDingDone}  
                receiptDone         = {this.state.receiptDone}  
            />
        );
    }
}

const mapStateToProps = state => {
    return {
        sessionActive:          state.sessionActive,
        messageList:            state.messageList,
        messageListState:       state.messageListState,
        clickSearchHistory:     state.clickSearchHistory,
        reply:                  state.reply,
        showMeetingState:       state.calender.showMeetingState,
        isInMeeting:            state.calender.isInMeeting,
        emotList:               state.emotList,
        translationList:        state.translationList,
        targetLanguage:         state.targetLanguage,
        backFooterInfo:         state.backFooterInfo,
        serverRenderMode:       state.serverRender.mode,
        serverRenderFirst:      state.serverRender.firstEnter,
        serverRenderHasmore:    state.serverRender.hasmore,
        dingMsgs:               state.dingMsgs,
        effectQuickPage:        state.effectQuickPage
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxContentContainer);
