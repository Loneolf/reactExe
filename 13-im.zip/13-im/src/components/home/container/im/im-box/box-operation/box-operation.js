// react
import React from 'react';

// css
import css from './index.scss';

// antd
import { Button, Input } from 'antd';

// no notice img
import noNotice from '@a/imgs/no-notice.png';

// components
import CommonModal from '@c/common/common-modal';

// TextArea
const { TextArea } = Input;

// util
import * as util from '@u/util.js';

// BoxOperation
export default class BoxOperation extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className={css.box}>
                <div className={css.mask} onClick={this.props.maskClick}></div>
                {!this.props.creatOperation && !this.props.textAreaValue && (
                    <div className={css.noNotice}>
                        <div className={css.noNoticeContent}>
                            <img src={noNotice} alt="" />
                            <p>{util.locale('media_no_announcement')}</p>
                        </div>
                        {this.props.getConfigEdite() &&
                            <Button
                                onClick={this.props.creatOperationFn}
                                type="primary"
                                ghost
                                className={css.edit_btn}
                                >
                                {util.locale('media_edit_announcement')}
                            </Button>
                        }
                    </div>
                )}
                {this.props.creatOperation && (
                    <div className={css.creatNotice}>
                        <p>{util.locale('media_group_chat')}</p>
                        <div className={css.creatNoticeInput}>
                            <TextArea
                                // maxLength={1000}
                                ref={el => {
                                    this.props.messagesEnd(el);
                                }}
                                value={this.props.textEditAreaValue}
                                onChange={this.props.textareaValueFn}
                                style={{ height: '100%' }}
                            />
                        </div>
                        <div className={css.bottomButton}>
                            <Button
                                className={css.cancel}
                                onClick={this.props.creatCancel}
                            >
                            {util.locale('media_cancel')}
                            </Button>
                            <Button
                                className={css.release}
                                onClick={this.props.creatRelease}
                                type="primary"
                            >
                                {util.locale('media_issue')}
                            </Button>
                        </div>
                        <CommonModal
                            modalTile={util.locale('common_tip')}
                            modalVisible={this.props.modalVisible}
                            setOKModal={this.props.setOKModal}
                            setonCancelModal={this.props.setonCancelModal}
                            modalContent={this.props.editExit ? util.locale('im_editTip_exit') : util.locale('media_quit')}
                        />
                    </div>
                )}
                {!this.props.creatOperation && this.props.textAreaValue && (
                    <div className={css.lookNotice}>
                        <p>
                            {util.locale('media_update')} {this.props.udate} {this.props.uname}
                        </p>
                        <div className={css.lookNoticeInput}>
                            <pre
                                dangerouslySetInnerHTML={{
                                    __html: util.yach.textFiltering(this.props.textAreaValue)
                                }}
                            />
                            {/* <div className={css.notice_mask}></div> */}
                        </div>
                        {this.props.getConfigEdite() &&
                            <div className={css.buttonCenter}>
                                <Button
                                    onClick={this.props.creatOperationFn}
                                    type="primary"
                                    ghost
                                    className={css.edit_btn}
                                >
                                    {util.locale('media_edit_announcement')}
                                </Button>
                            </div>
                        }
                    </div>
                )}
            </div>
        );
    }
}
