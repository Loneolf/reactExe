import { message } from 'antd'
import * as util from '@u/util.js'
import { add, replace } from '@r/actions/messageList'
import { fileUpdateRevoke } from '@s/file/file-update'
import { robotMessageAPI } from '@s/robots';

// 当前会话在boxsend中已形成内存泄漏闭包，故此值为定值
let sessionActive = {}

let robotMessage = async(object) => {
    try {
        await robotMessageAPI(object);
    } catch (error) {
        console.log(error)
    }
}

// 检查大小
export const checkSize = size => {
    if ((size / 1024 / 1024).toFixed(1) > 2 * 1024) {
        message.warning(util.locale("im_send_file_size_cannot_exceed_2G"))  // "发送文件大小不能超过2G",
        return false
    }
    return true
}

// 获取文件类型
export const getType = ext => {
    if(ext == 'doc' || ext == 'docx') {
        return 'word';
    }
    else if (/msword|vnd.openxmlformats-officedocument.wordprocessingml.document/i.test(ext)) {
       return 'word';
    }
    if(ext == 'xls' || ext == 'xlsx') {
        return 'excel';
    }
    else if(/spreadsheet|x-excel|vnd.ms-excel|vnd.openxmlformats-officedocument.spreadsheetml.sheet/i.test(ext)) {
        return 'excel';
    }
    if(ext == 'ppt' || ext == 'pptx') {
        return 'ppt';
    }
    else if(/powerpoint|ms-powerpoint|vnd.openxmlformats-officedocument.presentationml.presentation|vnd.openxmlformats-officedocument.presentationml.slideshow/i.test(ext)) {
        return 'ppt';
    }
    if(/pdf/i.test(ext)) {
        return 'pdf';
    }
    if(/png|jpg|bmp|jpeg|gif|svg|wmf|jpe|ico|pic|tiff|pjpeg|jfif|pjp/i.test(ext)) {
        return 'image';
    }
    if(/wmv|asf|asx|rm|rmvb|mp4|ogg|webm|3gp|mov|m4v|avi|dat|mkv|flv|vob|rn-realmedia|mid/i.test(ext)) {
        return 'video';
    }
    if( ext === 'dir' ) return 'dir';
    return 'other';
}

// 获取push内容
export const getPushObj = (fileText) => {
    const { userInfo } = window.store.getState()
    const { name, name_nick } = userInfo;
    if (!sessionActive) return;
    let pushContent = '',
        pushPayload = {};
    if (sessionActive.type == 'team') {
        pushContent = `${name}${name_nick ? '(' + name_nick + ')' : ''}: ${fileText}`;
        pushPayload = {
            pushTitle: util.yach.decodeUnicode(sessionActive.showname),
            sessionType: 1,
            sessionID: sessionActive.id,
        };
    } else {
        pushContent = `${fileText}`;
        pushPayload = {
            pushTitle: util.yach.decodeUnicode(name_nick || name),
            sessionType: 0,
            sessionID: sessionActive.id,
        };
    }
    return { pushContent, pushPayload };
};

// 获取图片信息
export const getImageInfo = url => {
    return new Promise(resolve => {
        let img = new Image()
        let data = {}
        img.src = url
        img.onload = () => {
            data.width = img.width
            data.height = img.height
            resolve(data)
        }
        img.onerror = () => {
            resolve(data)
        }
    })
}

// 压缩图片
export const getThumbImageInfo = async (url, width, height, size) => {
    const maxWidth = 324
    const maxHeight = 324
    let radio = 0

    let isExceedSide = width > 29999 || height > 29999
    let isExceedPixe = width * height > 99999999
    let isExceedSize = size > 20 * 1000 * 1000

    if (isExceedSide || isExceedPixe || isExceedSize) return {
        thumbUrl: url,
        thumbWidth: width,
        thumbHeight: height
    } 

    if (width > maxWidth || height > maxHeight) {
        let longside = Math.max(width, height)
        radio = Math.floor(maxWidth / longside * 100)
    }

    if (!radio) return {
        thumbUrl: url,
        thumbWidth: width,
        thumbHeight: height
    }

    let thumbUrl = `${url}?imageMogr2/thumbnail/!${radio}p`
    let data =  await getImageInfo(thumbUrl)

    return {
        thumbUrl,
        thumbWidth: data.width,
        thumbHeight: data.height 
    }
}

// 发图片格式
export const sendImage = async filedata => {
    sessionActive = filedata.sessionActive
    const loading = message.loading(`${filedata.filename} ${util.locale("im_sending")}`, 0)
    const pushtext = `[${util.locale("im_image")}]`
    const pushobj = getPushObj(pushtext)
    const apns = { forcePush: false }
    const imginfo = await getImageInfo(filedata.fileurl)
    const thumbimginfo = await getThumbImageInfo(filedata.fileurl, imginfo.width, imginfo.height, filedata.size)
    const custom = {
        type: 8,
        data: {
            fileName: filedata.filename,
            fileSize: filedata.size,
            fileOriginUrl: filedata.fileurl,
            fileThumbnailUrl: thumbimginfo.thumbUrl,
            thumbWidth: thumbimginfo.thumbWidth,
            thumbHeight: thumbimginfo.thumbHeight,
            width: imginfo.width,
            height: imginfo.height,
            relationId: filedata.relation_id,
            id: filedata.file_id,
        },
    };
    const sendCustomMsgData = await sendCustomMsg(custom, pushobj.pushContent, pushobj.pushPayload, apns);
    const { idClient } = sendCustomMsgData;
    if(sessionActive.type == 'p2p' && window.store.getState().chatRobot) {
        if(sendCustomMsgData && sendCustomMsgData.content) {
            util.log('zhangpeng', 'box-send-fn', '私聊发送图片');
            let content = JSON.parse(sendCustomMsgData.content);
            if(content && content.data) {
                await robotMessage({
                    msgtype: 'image',
                    content: content.data.fileOriginUrl,
                    create_at: sendCustomMsgData.time,
                    conversation_type: 1,
                    conversation_id: sendCustomMsgData.to,
                    corp_id: window.store.getState().userInfo.cp_id || 1,
                    msg_id: sendCustomMsgData.idServer
                })
            }
        }
    }
    loading()
    changeMsgId(filedata.relation_id, idClient);
}

// 发送office格式
export const sendOffice = async filedata => {
    sessionActive = filedata.sessionActive
    const loading = message.loading(`${filedata.filename} ${util.locale("im_sending")}`, 0)
    const pushtext = `[${util.locale("im_files")}]`
    const pushobj = getPushObj(pushtext)
    const apns = { forcePush: false }
    const custom = {
        type: 5,
        data: {
            fileName: filedata.filename,
            fileSize: filedata.size,
            fileUrl: filedata.fileurl,
            id: filedata.file_id,
            relationId: filedata.relation_id,
        },
    };
    const sendCustomMsgData = await sendCustomMsg(custom, pushobj.pushContent, pushobj.pushPayload, apns);
    const { idClient } = sendCustomMsgData;
    loading()
    changeMsgId(filedata.relation_id, idClient);
};

// 发送默认格式
export const sendCustomize = async filedata => {
    sessionActive = filedata.sessionActive
    const loading = message.loading(`${filedata.filename} ${util.locale("im_sending")}`, 0)
    const pushtext = `[${util.locale("im_files")}]`
    const pushobj = getPushObj(pushtext)
    const apns = { forcePush: false }
    const custom = {
        type: 10,
        data: {
            fileName: filedata.filename,
            fileSize: filedata.size,
            relationId: filedata.relation_id,
            fileOriginUrl: filedata.fileurl,
            id: filedata.file_id,
        },
    };
    const sendCustomMsgData = await sendCustomMsg(custom, pushobj.pushContent, pushobj.pushPayload, apns);
    const { idClient } = sendCustomMsgData;
    loading()
    changeMsgId(filedata.relation_id, idClient);
};

// 发送消息 - 云信文件消息
export const sendYunxinFile = async (event, fileText, fileType, active) => {
    sessionActive = active
    const loading = message.loading(`${fileText} ${util.locale("im_sending")}`, 0)
    const { type, id } = sessionActive
    try {
        const { pushPayload } = getPushObj(fileText);
        let obj = null;
        if (fileType == 'node') {
            obj = await util.nim.sendFile(type, id, event, 'node', pushPayload);
        } else {
            obj = await util.nim.sendFile(type, id, event, 'blob', pushPayload);
        }
        if (obj) {
            if (obj.to == window.store.getState().sessionActive.id) pushMessage(obj, 1);
            uploadSensorsData(obj);
            if (obj) {
                if (obj.to == window.store.getState().sessionActive.id) pushMessage(obj, 1);
                uploadSensorsData(obj);
                if(sessionActive.type == 'p2p' && window.store.getState().chatRobot) {
                    if(obj && obj.file) {
                        util.log('zhangpeng', 'box-send-fn', '私聊发送视频');
                        await robotMessage({
                            msgtype: 'video',
                            content: obj.file.url,
                            create_at: obj.time,
                            conversation_type: 1,
                            conversation_id: obj.to,
                            corp_id: window.store.getState().userInfo.cp_id || 1,
                            msg_id: obj.idServer
                        })
                    }
                }
            }
        }
    } catch (err) {
        loading()
        if (err.code == 'serverError') return message.error(util.locale("im_network_abnormal_upload_failed"));
        message.error(err.message);
        console.log(err);
    }
    loading()
};

// 发送消息 - 自定义消息
export const sendCustomMsg = async (custom, pushContent, pushPayload, apns = {}) => {
    try {
        const customMsg = await util.nim.sendCustomMsg(
            sessionActive.type,
            sessionActive.id,
            JSON.stringify(custom),
            apns,
            pushContent,
            '',
            pushContent,
            pushPayload,
            async (msg) => {
                const obj = await util.nim.genMsgItem(msg);
                if (msg.to == window.store.getState().sessionActive.id) window.store.dispatch(add(obj));
            }
        );
        if (customMsg.to == window.store.getState().sessionActive.id) pushMessage(customMsg, 2);
        uploadSensorsData(customMsg);
        util.yach.refreshConnect(customMsg);
        return customMsg;
    } catch(err) {
        if (err.code == 'serverError') return message.error(util.locale("im_network_abnormal_upload_failed"));
        message.error(err.message);
        console.log(err);
    }
};

// 撤回
export const changeMsgId = (relation_id, msg_id) => {
    fileUpdateRevoke({ relation_id, msg_id });
}

// 推送到云信message
export const pushMessage = async (item, type) => {
    if (item.status == 'fail') {
        let obj = Object.assign(item, { msg: item });
        window.store.dispatch(replace(obj));
    }
    let obj = await util.nim.genMsgItem(item);
    if (window.store.getState().sessionActive.type == 'team') {
        const teamMembers = await util.nimUtil.getTeamMembers(window.store.getState().sessionActive.id);
        obj = Object.assign(obj, { read: 0, unread: teamMembers.members.length - 1 });
    }
    if (type == 1) {
        window.store.dispatch(add(obj));
    } else {
        window.store.dispatch(replace(obj));
    }
}

// 上传神策
export const uploadSensorsData = (obj) => {
    let fileType = 104;
    if (obj.type == 'image') {
        fileType = 102;
    } else if (obj.type == 'audio') {
        fileType = 103;
    } else if (obj.type == 'video') {
        fileType = 105;
    } else if (obj.type == 'custom' && JSON.parse(obj.content).type == 8) {
        fileType = 102;
    }
    util.yach.sendMessageSensorsData(fileType);
};