// react
import React from 'react';
// css
import css from './index.scss';

// antd
import { Switch } from 'antd';
import * as util from '@/utils/util';
//component
import CommonModal from '@/components/common/common-modal';
import UserAdd from '@c/common/user-add/user-add-container';

// BoxOperation
export default class BoxManagement extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        const {ismute,allShutUpFn} = this.props;
        
        return (
            <div className={css.box}>
                <div>
                <div className={css.bottom}>
                        <div>
                            <p className={util.locale.getLang() === 'zh-CN' ? '' : css.enUSTip }>{util.locale("im_only_the_administrator/admin_can_manage")}</p>
                            {
                                util.locale.getLang() === 'zh-CN' ? 
                                <p>({util.locale("im_group_name/member/announcement/profile_picture")})</p> :
                                null
                            }
                            {/* <p>({util.locale("im_group_name/member/announcement/profile_picture")})</p> */}
                        </div>
                        <Switch onChange={this.props.groupInfoSetting} checked={this.props.settingInfoChecked}/>
                    </div>
                    <div className={`${css.bottom} ${css.margins}`}>
                        <div>
                            <p className={util.locale.getLang() === 'zh-CN' ? '' : css.enUSTip}>{util.locale("im_only_group_administrator_and_admin_can_send_@_ALL_messages")}</p>
                            {
                                util.locale.getLang() === 'zh-CN' ? <p>{util.locale("im_if_enabled,_only_group_administrator_admin_can_send_@_ALL_messages")}</p> :
                                null
                            }
                            {/* <p>{util.locale("im_if_enabled,_only_group_administrator_admin_can_send_@_ALL_messages")}</p> */}
                        </div>
                        <Switch onChange={this.props.atSetting} checked={this.props.atSettingChecked}/>
                    </div>
                    <div className={`${css.bottom} ${css.margins} ${css.shutup}`}>
                        <div>
                            <p>{util.locale("im_total_silence")}</p>
                            <p>{util.locale("im_if_enabled_only_group_administrator_and_admin_can_talk")}</p>
                        </div>
                        <Switch onChange={e=>{allShutUpFn(e)}} checked={ismute}/>
                    </div>

                    <div className={css.gtoupRules} onClick={this.props.goConfig}>
                        <span>{util.locale("im_configuration_administrator")}</span>
                        <div className={css.right} >
                        <span className={`${css.jiantou_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`}/>
                        </div>
                    </div>
                    {this.props.userType == 0 &&
                        <div>
                            <div className={css.gtoupRules} onClick={this.props.transferTeam}>
                                <span>{util.locale("im_transfer_group_administration_to")}</span>
                                <div className={css.right} >
                                <span className={`${css.jiantou_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`}/>
                                </div>
                            </div>
                            <div className={css.dissolution} onClick={this.props.dissolution}>
                                {util.locale("im_dismiss_this_group")}
                            </div>
                        </div>
                    }
                </div>
                <UserAdd {...this.props.userAddProps} />
                <CommonModal
                    modalVisible={this.props.transferModalVisible}
                    setOKModal={this.props.setTransferOKModal}
                    setonCancelModal={this.props.setTransferCancelModal}
                    modalContent={util.locale("im_confirm_to_transfer_group_administration_to")+" "+this.props.selectUser.name}
                />
                <CommonModal
                    modalTile={util.locale("im_group_dismiss")}
                    okText={util.locale("im_dismiss_this_group")}
                    modalVisible={this.props.modalVisible}
                    setOKModal={this.props.setOKModal}
                    setonCancelModal={this.props.setonCancelModal}
                    modalContent={util.locale("im_group_dismiss_tip")}
                />
                <CommonModal
                    closable={false}
                    cancelButtonProps = {false}
                    modalVisible={this.props.delModalVisible}
                    setOKModal={this.props.delOKModal}
                    setonCancelModal={this.props.delCancelModal}
                    modalContent={util.locale("im_group_dismiss_tip_confirm")}
                />
            </div>
        );
    }
}
