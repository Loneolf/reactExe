// react
import React from 'react';
import ReactDOM from 'react-dom';
import * as util from '@u/util.js';
import { connect } from 'react-redux';

// ImBox
import CommonAssistant from '@c/common/common-assistant/index.js';
import ScheduleAssistant from '@c/home/container/coordination/schedule/schedule-assistant';
import {setMuteAll,setYouLevel} from '@r/actions/groupAll.js';
import TeamAssistant  from "@c/home/container/team-circle/team-main/team-main-container.js"
import {sessionUploadFileInit} from '@r/actions/sessionUploadFile.js'
import _yachDB from 'yach.util.indexeddb';
import ImBox from './im-box';
const yachDB = _yachDB('sessionUploadFile');
//import * as db from '@c/common/upload-file-control/db.js'
import { getGroupRobotsAPI } from '@s/robots';
import { setRobotList } from '@r/actions/getRobotNum.js';
// ImBoxContainer
class ImBoxContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isHiddenSessionType: false,
            componentNames: null,
           /*
                群组相关属性： 一个群可能是日程群，部门群，红包群等，因此该熟悉代表类型,后续如果开发到这些，烦请注释在下面
                日程群组:    type 9
                部门群 :     type 1
            */
           teamType:{
                type:0,  // 默认0
                attr:{}  // 相关熟悉
           },
           singleType: {
               type: 'p2p', // 会话类型
               identification: '' // 单聊会话类型细化
           }
        };
    }

     componentDidMount() {
        this.boxInitHandle();
        ReactDOM.findDOMNode(this.getImBox).addEventListener('drop', e=>{
            util.eventBus.emit('dropImBox', {'node':ReactDOM.findDOMNode(this.getImBox), event: e});
        });
        //初始化群文件--上传文件状态
        const sessionId = window.session_active['id']
            //根据sessionid 获取本地上传失败的数据
        yachDB.getItemByIndexCursor('sessionUploadStatus', [sessionId, ''], (result)=>{
            result && this.props.dispatch(sessionUploadFileInit({sessionActive: window.session_active, data: [result]})) 
        }) 
        // db.getFileUploadFail(sessionId, (result)=>{
        //    this.props.dispatch(sessionUploadFileInit({sessionActive: window.session_active, data: result})) 
        // })
        util.eventBus.addListener("set:activegroup:robot", this.getRobotList);
    }

    componentWillUnmount() {
        util.eventBus.removeListener('dropImBox');
        util.eventBus.removeListener("set:activegroup:robot");
        this.setState = (state, callback) => {
            return;
        };
    }

    // box init 权限
    boxInitHandle = async ()=>{
        const { id, type, custom } = window.session_active;
        this.getThisTeamStatus();
        if(type === 'p2p'){
            this.getUserDone({account: id,custom});
            this.props.dispatch(setMuteAll(false));
            this.props.dispatch(setYouLevel(false));
        }
        else{
            util.yach.setRobotNum(window.session_active);
            util.yach.noSpeakingAll(window.session_active);
            util.yach.voteCheck();
            this.getRobotList();
        }
    }

    // 进入群获取群机器人
    getRobotList = async ()=>{
        const {id,type} = window.session_active;
        if(!id || type !=='team') return;
        const list = await getGroupRobotsAPI({ group_tid: window.session_active.id,corp_id: 1});
        if(list.code !== 200) return util.yach.cout('群机器人','error',list.msg);
        const {notice_robot,chat_robot} = list.obj;
        const l_1 = [...notice_robot,...chat_robot].reduce(function(pre,nex){
            pre.push(nex.userid);
            return pre;
        },[]);
        window.store.dispatch(setRobotList(l_1));
    }
    
    scheduleAssent = () => {
        this.setState(state => ({
            isHiddenSessionType: true,
            componentNames: <ScheduleAssistant />
        }));
    };

    templateAssent =  () => {
        this.setState(state => ({
            isHiddenSessionType: true,
            componentNames: <CommonAssistant />
        }));
    };

    squadAssent = () => {
        this.setState(state => ({
            isHiddenSessionType: true,
            componentNames: <TeamAssistant/> // todo 引入小组主页组件
        }));
    }

    commonSession = () => {
        this.setState(state => ({
            isHiddenSessionType: false,
            componentNames: null
        }));
    };

    getUserDone = (user) => {
        if (!user.account) {
            this.commonSession();
            return null;
        }
        try {
            const { custom } = user;
            if (user.account && user.account === '3004') {
                return this.scheduleAssent();
            } else if (custom && custom === 'aide_user') {
                return this.templateAssent();
            } else if(custom){
                const userCustom = util.nimUtil.getJson(custom);
                if(userCustom && userCustom.identification == 'squad') return this.squadAssent();
            }
            return null;
        } catch (e) {
            console.error('获取用户信息方法执行报错了', e);
        }
    };

    setBoxReplyRef = el => {
        this.boxReplyRef = el;
    };

    setBoxContentRef = el => {
        this.boxContentRef = el;
    };

    getHeight = () => {
        if (!this.boxReplyRef && !this.boxContentRef) return;
        if (!this.boxReplyRef && this.boxContentRef) return this.boxContentRef.offsetHeight;
        return 353 - this.boxReplyRef.clientHeight;
    }

     /*
        获取当前这个群的状态  判断当前的群的类型 日程群 办公群 普通群
    */
     getThisTeamStatus = async ()=>{
        // const {type,id,custom,serverCustom} = this.props.sessionActive;
        const { type, custom, serverCustom} = window.session_active;
        if(type === 'p2p') {
            const nimInfo = { custom };
            if(nimInfo.custom){
                try {
                    const userCustom = util.nimUtil.getJson(nimInfo.custom);
                    if(userCustom.identification == 'squad') return this.setState(state=>({
                        singleType: {type, identification: userCustom.identification}
                    }))
                } catch (error) {
                    return false
                }
            }
            return false
        };
        if(type === 'team'){
            try{
                if (!serverCustom) return false;
                const serverCustomJson = util.nimUtil.getJson(serverCustom);
                const {type:t_type,schedule={},dept_id} = serverCustomJson;
                (t_type || dept_id) && this.setState(state=>({
                    teamType: {type: t_type,attr:schedule,dept_id}
                }))
            }
            catch(e){
                console.error('获取群信息出错：方法名称：getThisTeamStatus: >> '+e);
            }
        }  
   }
   render() {
    //    const id = this.props.sessionActive.id;
       const id = window.session_active.id;
       const { reply, messageListState, showRobotDialog } = this.props;
       const { isHiddenSessionType, componentNames, teamType, singleType } = this.state;
        return (
            <ImBox
                id={id}
                teamType = {teamType}
                singleType = {singleType}
                isHiddenSessionType= {isHiddenSessionType}
                componentNames = {componentNames}
                replyShow = {reply.replyShow}
                showCheckbox = {messageListState.showCheckbox}
                showRobotDialog = {showRobotDialog}
                setBoxContentRef = {this.setBoxContentRef} 
                getHeight = {this.getHeight}
                setBoxReplyRef = {this.setBoxReplyRef}
                ref = {child => this.getImBox = child}
            />
        );
    }
}

const mapStateToProps = state => {
    return {
        reply: state.reply,
        // sessionActive: state.sessionActive,
        messageListState: state.messageListState,
        showRobotDialog:state.robots.addWindowShow
    };
};

export default connect(mapStateToProps)(ImBoxContainer);
