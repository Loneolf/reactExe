// react
import React from 'react';

// css
import css from './index.scss';

import * as util from '@u/util.js';

export default (props) => {
    const {
        searchValue,
        handleInputChange,
        leftIconClick,
    } = props;

    return (
        <div className={css.inputContent}>
            {
                !!leftIconClick&&<span onClick={leftIconClick} className={`${css.leftIcon} iconfont-yach yach-zuojiantou`} />
            }
            <div className={css.inputOut}>
                <span className="icon iconfont iconsousuo" />
                <input 
                    id='fileSearchInput'
                    autoFocus={!!leftIconClick}
                    placeholder={util.locale('im_file_uoliad_dir_search_place')}
                    value={searchValue}
                    onChange={(e)=>handleInputChange(e.target.value)}
                />
                {
                    searchValue&&<em className={css.clear} onClick={()=>{handleInputChange('')}}/>
                }
            </div>
        </div>
    );
};
