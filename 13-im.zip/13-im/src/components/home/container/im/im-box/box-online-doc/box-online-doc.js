// react
import React from 'react';
import { Input, Spin } from 'antd';

// css
import css from './index.scss';

import InfiniteScroll from 'react-infinite-scroller';
import * as util from '@u/util.js';
// imgs
import wordImg from '@a/imgs/custom/word.png';
import excelImg from '@a/imgs/custom/excel.png';
import formsImg from '@a/imgs/custom/forms.png';
import mindMapImg from '@a/imgs/custom/mind-map.png';
import pptImg from '@a/imgs/custom/ppt.png';
import whiteBoardImg from '@a/imgs/custom/white-board.png';
import noImg from '@a/imgs/online-doc-no-data.png';

export default class BoxOnlineDoc extends React.Component{
    constructor(props){
        super(props)
    }

    render(){
        const { noData, docList, handleInfiniteOnLoad, loading, hasMore, goShimo, seachData } = this.props;
        return(
            <div className={css.box}>
                <div className={css.inputContent}>
                    <Input
                        placeholder={util.locale('media_search_document')}
                        allowClear
                        autoFocus
                        value={this.props.slideSearch}
                        onChange={seachData}
                        prefix={<span className="icon iconfont iconsousuo" style={{ color: 'rgba(0,0,0,.25)' }} />}
                    />
                </div>
                {!noData &&
                    <ul>
                        {docList && docList.length >0 &&
                            <InfiniteScroll
                                initialLoad={false}
                                pageStart={0}
                                loadMore={handleInfiniteOnLoad}
                                hasMore={!loading && hasMore}
                                useWindow={false}
                            >
                                {
                                    docList.map((item, index)=>(
                                        <li key={index} onClick={()=>goShimo(item)}>
                                            <div className={css.item}>
                                                <div className={css.info}>
                                                    {item.type == 'newdoc'&&<img src={wordImg} />}
                                                    {item.type == 'mosheet'&&<img src={excelImg} />}
                                                    {item.type == 'form'&&<img src={formsImg} />}
                                                    {item.type == 'mindmap'&&<img src={mindMapImg} />}
                                                    {item.type == 'slide'&&<img src={pptImg} />}
                                                    {item.type == 'board'&&<img src={whiteBoardImg} />}
                                                </div>
                                                <div>
                                                    <p>{item.title}</p>
                                                    <p>
                                                        <span className={css.userName}>{item.userName}</span>
                                                        <span>{item.time} {util.locale('media_send')}</span>
                                                    </p>
                                                </div>
                                            </div>
                                        </li>
                                    ))
                                }
                            </InfiniteScroll>
                        }
                    </ul>
                }
                {noData &&
                    <div className={css.noData}>
                        <img src={noImg}/>
                        <p>{noData}</p>
                    </div>
                }
            </div>
        )
    }
}
