// react
import React from 'react';
// connect
import { connect } from 'react-redux';
// server
//import { searchSessionFile } from '@s/file/file-list';
import { fileGroupList } from '@s/file/file-list';

import { debounce } from 'lodash';
import * as util from '@u/util.js';
import {showSlideModal} from '@/redux/actions/commonModal';


import FileSearch from '../../common/file-search';
import FileList from '../../common/file-list/container';

import css from './index.scss';

// 查询组件
class BoxSearchFileContainer extends React.Component {
    state = {
        searchValue: '',
        noData: 'ready_search',
        fileList: [],
        hasMore: false,
        currentPage: 0,
        loading: false,
    };

    componentDidMount() {
        window.addEventListener('keydown', this.closeSlideCard);
    }

    componentWillUnmount() {
        window.removeEventListener('keydown', this.closeSlideCard);
    }

    // 监听按键 esc
    closeSlideCard = (ev) => {
        let code = ev.keyCode;
        if (code === 27) {
            //触发esc
            if (this.state.searchValue) {
                this.setState({
                    searchValue: '',
                    noData: 'ready_search',
                    fileList: [],
                    hasMore: false,
                    currentPage: 0,
                    loading: false,
                });
            } else {
                // 退出搜索状态
                this.props.hanleGoList();
            }
        }
    };

    // 搜索结果高亮
    searchHighlighted = (searchData, searchKye) => {
        if (!searchKye) return searchData;
        const regExp = new RegExp(searchKye.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1'), 'ig');
        return searchData.map((item) => {
            item.showFileName = item.fileName.replace(regExp, `<span style="color:#286CFB;">${searchKye}</span>`);
            const showName = item.userInfo.name.replace(regExp, `<span style="color:#286CFB;">${searchKye}</span>`);
            item.userInfo = { ...item.userInfo, showName };
            return item;
        });
    };

    // 查询操作
    getFileList = async (loadMore = false) => {
        this.setState({ loading: true });
        // const { id, type } = this.props.sessionActive;
        const { id, type } = window.session_active;
        const { searchValue, currentPage, fileList } = this.state;
        const page=loadMore?currentPage+1:1;
        let formData = {
            group_tid: id,
            page,
            size: 20,
            type: 'file',
            receive_type: type === 'team' ? 0 : 1,
            searchWorld: searchValue,
        };

        const datas = await fileGroupList(formData);
        const { code, obj = [] } = datas || {};
        let resArr = [];
        if (code === 200) {
            resArr = util.cosfiles.fileDownloadStatusGetArr(obj);
            // 高亮匹配
            resArr = this.searchHighlighted(resArr, searchValue);
            // if (resArr.length !== 20) {
            //     if (loadMore) message.info(util.locale('im_all_files_loaded'));
            // }
        }
        const arr = loadMore ? [...fileList, ...resArr] : resArr;
        this.setState({
            fileList: arr,
            currentPage: page,
            loading: false,
            hasMore: resArr.length === 20,
            noData: arr.length ?"": 'not_find'
        });
    };

    handleLoadMore = () => {
        this.getFileList(true);
    };

    handleSearch = debounce(
        () => {
            this.getFileList();
        },
        150,
        { maxWait: 400 }
    );

    handleInputChange = (value) => {
        
        this.setState(
            {
                searchValue: value,
            },
            () => {
                if(!value){
                    // 清空搜索项，且保持聚焦
                    this.setState({
                        noData: 'ready_search',
                        fileList: [],
                        hasMore: false,
                        currentPage: 0,
                        loading: false,
                    })
                    document.getElementById('fileSearchInput').focus();
                }else if(value.trim()){
                    this.handleSearch();
                }else{
                    // 清空搜索项
                    this.setState({
                        noData: 'ready_search',
                        fileList: [],
                        hasMore: false,
                        currentPage: 0,
                        loading: false,
                    })
                }
            }
        );
    };

    // 重置msg状态
    resetLocalMsgState = ({relation_id, path}) => {
        const fileList = this.state.fileList.map((item) => {
            if (item.relation_id == relation_id) item.downloadPath = path;
            return item;
        });
        this.setState({
            fileList,
        });
        
        util.cosfiles.fileDownloadStatusUpdate({path,key:relation_id});
    };

    // 下一级
    handleNextFolder= async ({relation_id,fileName})=>{
        this.props.setshowListPage(false);
        await this.props.dispatch(showSlideModal('groupDatabase', {activeKey:'3',params:{relation_id,fileName}}));
        this.props.setshowListPage(true)
        this.props.hanleGoList();
    }

    render() {
        const { searchValue,noData,hasMore,loading,fileList } = this.state;
        const {hanleGoList}=this.props;
       
        const  FileSearchProps={
            searchValue,
            leftIconClick:hanleGoList,
            handleInputChange:this.handleInputChange
        }
        const FileListProps={
            noData,
            fileList,
            hasMore,
            loading,
            handleLoadMore:this.handleLoadMore,
            closedDownLoad:this.closedDownLoad,
            handleNextFolder:this.handleNextFolder,
            resetLocalMsgState:this.resetLocalMsgState,
        }
        return (
            <div className={css.box}>
                <FileSearch {...FileSearchProps}/> 
                <FileList {...FileListProps} />
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        // sessionActive: state.sessionActive,
    };
};

export default connect(mapStateToProps, null)(BoxSearchFileContainer);
