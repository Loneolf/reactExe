// react
import React from 'react';

// css
import css from './index.scss';
import ToolsContainer from '../common/tools';

// 
export default props => {
    const { showRightModal, rightModalParams } = props;

    return(
        <div className={css.tool}>
            <ToolsContainer 
                toolName={'more'}
                showRightModal={showRightModal}
                rightModalParams={rightModalParams}
            />
        </div>
    )
}
