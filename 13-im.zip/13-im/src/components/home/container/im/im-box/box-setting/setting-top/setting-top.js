/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-23 23:43:10
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-05-28 20:18:37
 */
// react
import React, { Fragment, useEffect, useState } from 'react';

// css
import css from './index.scss';

// antd
import { Input } from 'antd';
import * as util from '@u/util.js';
import DepartTag from '@c/common/departmentTag/index.js'
import ApproveTag from '@c/common/approveTag/index.js'

// BoxOperation
export default function SettingTop(props) {
    const [hidden, setHidden] = useState(0);
    useEffect(() => {
        try{ 
            // console.log('use nim getuser or getteam xx0000000');
            util.nimUtil.getTeam(props.tid.id).then((res)=>{
                const {serverCustom} = res;
                const serverCustomJson = JSON.parse(serverCustom);
                let type = serverCustomJson.type 
                if(type == 1) {
                    setHidden(1)
                } else if(type == 3) {
                    setHidden(3)
                } else{
                    setHidden(0)
                }
            });
        }
        catch(e){
            console.error('获取群信息出错误',e);
        }
    }, []);
    const {
        showname,
        showNameInput,
        onGroupNameblur,
        onEditCommon,
        portrait,
        getConfigEdite,
        handleKeyPress
    } = props;
    return (
        <>
        <div className={css.top}>
            <img src={portrait} className={css.portrait} alt="" />
            <div>
                {showNameInput ? (
                    <Input
                        onBlur={e => onGroupNameblur(e.target.value)}
                        autoFocus
                        defaultValue={showname}
                        type="text"
                        maxLength={20}
                        onKeyDown={handleKeyPress}
                    />
                ) : (
                    <div style={{display: "flex"}}>
                        <div  className={`${css.showname} ${!hidden ? css.hasPartment : ''}`} title={showname}>{showname}</div>
                        {hidden == 1 ? <div style={{marginLeft: '5px'}}><DepartTag/></div> : 
                            (hidden == 3 ? <div style={{marginLeft: '5px'}}><ApproveTag/></div> : null)
                        }
                    </div>  
                )}           
            </div>
            {getConfigEdite() && (!props.typeMsg || props.typeMsg.type !== 'squad') ?
                <div className={css.rightBox}>
                    {showNameInput ? null : (
                        <span
                            onClick={onEditCommon.bind(this, 'showNameInput')}
                            className="iconfont-yach yach-quanju-qunshezhi-bianjiqunmingcheng-changtai"
                        />
                    )}
                </div> : null
            }
        </div>
        </>
    );
}
