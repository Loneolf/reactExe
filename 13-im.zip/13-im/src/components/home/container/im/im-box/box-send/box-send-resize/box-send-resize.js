import React, { Component } from 'react';
import {connect} from 'react-redux';
import css from './index.scss'

// util
import { style } from '@u/util.js';

class BoxSendResize extends Component {
    componentDidMount() {
        this.line.addEventListener('mousedown', this.mouseHandler);
        // 获取输入框父元素节点
        this.textAreaContent = document.querySelector('#draft-content')
        // 整个输入框底部高度与输入框父元素节点的高度差
        this.hDif = this.line.parentElement.offsetHeight - this.textAreaContent.offsetHeight
        // 设置最小高度为当前默认高度
        // this.minHeight = this.textAreaContent.offsetHeight
        this.minHeight = 32
        // 设置最大高度1为当前文档高度的一半
        this.maxHeight = (document.documentElement.clientHeight) / 2 - this.hDif
        // 设置最大高度2为当前文档高度的80%
        // this.maxHeight = (document.documentElement.clientHeight) * 0.8
        // 当用户在输入的过程中更改了窗口尺寸，同样要更改最大高度
        window.addEventListener('resize', this.resizeHandle)
        this.textAreaContent.style.height = this.props.boxSendHeight.height +"px"

        // 获取滚动条盒子
        this.scrollBox = document.querySelector('#box-content').lastElementChild

    }

    componentWillUnmount() {
        // 组件卸载后移除监听事件
        this.line.removeEventListener('mousedown', this.mouseHandler);
        window.removeEventListener('resize', this.resizeHandle);
    }

    resizeHandle = ()=>{
        this.maxHeight = (document.documentElement.clientHeight) / 2 - this.hDif
        // 当更改窗口尺寸的时候，输入框当前的高度大于最大高度，要更改为当前最大高度
        if(this.textAreaContent.clientHeight > this.maxHeight || this.props.boxSendHeight.maxHeightFix){
            this.textAreaContent.style.height = this.maxHeight - this.line.clientHeight +"px"
            this.props.dispatch({type:"changeBoxSendHeight",item:{height:this.maxHeight,maxHeightFix:true}})
        }
    }


    mouseHandler=(e)=>{
        e.preventDefault()
        if(e.type==="mousedown"){
            // document.elem=this.line
            document.addEventListener("mousemove",this.mouseHandler)
            document.addEventListener("mouseup",this.mouseHandler)
        }
        if(e.type==="mousemove"){
            // 输入框父元素节点的高度等于文档的高度 - 当前鼠标所在位置的Y坐标 - 高度差 + 拖动元素的高度
            let height = document.documentElement.clientHeight - e.y - this.hDif - this.line.clientHeight
            
            if(height <= this.maxHeight && height >= this.minHeight){
                this.textAreaContent.style.height = height +"px" 
                if(height >= this.maxHeight - 1){
                    this.props.dispatch({type:"changeBoxSendHeight",item:{height,maxHeightFix:true}})
                } else {
                    this.props.dispatch({type:"changeBoxSendHeight",item:{height,maxHeightFix:false}})
                }
            }
            // 当内容显示区域滚动条在底部时，调节输入框高度使其滚动条一直在底部
            if(this.scrollBox.scrollTop <= this.scrollBox.scrollHeight - this.scrollBox.parentElement.offsetHeight && this.scrollBox.scrollTop >=  this.scrollBox.scrollHeight - this.scrollBox.parentElement.offsetHeight - 25){
                this.scrollBox.scrollTop = this.scrollBox.scrollHeight - this.scrollBox.parentElement.offsetHeight
            }
        }
        if(e.type==="mouseup"){
            // 鼠标抬起后释放监听事件
            document.removeEventListener("mousemove",this.mouseHandler)
            document.removeEventListener("mouseup",this.mouseHandler)
        }
    }
    render() {
        return (
            <div className={css.resizeVertical + style.getWinStyle(css, 'resizeVerticalWin')} ref={(line) => { this.line = line }}></div>
        );
    }
}

const mapStateToProps = state => {
    return {
        boxSendHeight:  state.boxSendHeight,
    };
};



export default connect(
    mapStateToProps,
    null,
)(BoxSendResize);
