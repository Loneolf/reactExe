// react
import React from 'react';
import { connect } from 'react-redux';

// copy
import copy from 'copy-to-clipboard';

// antd
import { message } from 'antd';

// util
import * as util from '@u/util.js';
import * as linkMsgHandler from '@u/nim/container/link-msg-handler.js';
// redux
import { showPreviewModal } from '@r/actions/commonModal.js';
import * as fileRedux from '@/redux/actions/file';
import * as draftAction from '@r/actions/draft';
import * as messageListAction from '@r/actions/messageList';

// components
import BoxContentMessage from './box-content-message';
import AtHighlighted from '@c/common/at-highlighted';

// services
import { groupEmotAdd, groupEmotDel } from '@/services/group/group-emot';
import { fileRangeList } from '@s/file/file-list';
import { audioTranslate, audioBusMessagePush } from '@/services/session/session';

// debounce
import debounce from 'lodash/debounce';

// aiSDK
import * as ai from '@u/ai/api.js';

let isChangeLang = false;
// BoxContentMessageContainer
export class BoxContentMessageContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showBoxContentMessageState: false,
            audioText: this.props.audioContent && this.props.audioContent.audioText,
            isShowAudioText: Boolean(this.props.audioContent && this.props.audioContent.isShowAudioText),
            showTools: false,
            toolItemActive: 0,
            emojiVisible: false,
          //  workStatus: props.workStatus,
            robot_user: props.robot_user,
            isDownload: false,
            filePath: null,
            againDownload: false,
            controlSwitch: true,
            translating: false, // 正在翻译中
            isOriginal: true, // 是原始的还是翻译后的
            translateText: '',  // 翻译后的文本
           // isChangeLang: false, // 改变语言
            isManualTranslation: false // 手动触发
        };
    }

    componentDidMount = () => {
        this.clickEmojiItem = debounce(this.clickEmojiItem, 500);
        this.clickEmot = debounce(this.clickEmot, 500);
        this.clickVideo = debounce(this.clickVideo, 500);
        this.createMeetingSummary = debounce(this.createMeetingSummary, 500);
        this.audioTranslateAPI = debounce(this.audioTranslateAPI, 500);
        this.fristScrollIntoView();
        this.videoEventListen();

        // this.initStateData();
        // this.intiateScrollObserver();
        this.shouldObserverMsg();
        util.eventBus.once('onChange:window:active', this.shouldObserverMsg);
    };

    componentDidUpdate = (pre) => {
        // const preWs = pre.workStatus || {};
        // const ws = this.props.workStatus;
        // if (ws && ws.service_type && (!this.state.workStatus || ws.service_type != preWs.service_type)) {
        //     this.setState({
        //         workStatus: ws,
        //     });
        // }

        // if (!_.isEqual(this.props.sessionList_p2p_statue, pre.sessionList_p2p_statue)) {
        //     this.updateWorkStatus();
        // }

        if (pre && (pre.status === 'sending' || pre.status === 'fail')) {
            this.fileSendingDelete();
        }

        if (pre.isAutotranslation != this.props.isAutotranslation) this.shouldObserverMsg();

        isChangeLang = pre.targetLanguage != this.props.targetLanguage;
        if (isChangeLang){
            this.shouldObserverMsg();
        }
    };

    componentWillUnmount = () => {
        this.closeObserver();
        isChangeLang = false;
        util.eventBus.removeListener('onChange:window:active');
        this.setState = (state, callback) => {
            return;
        };
    };

    initStateData = () => {
        let isMsgNeedTranslate = this.isMsgNeedTranslate();
        if (!isMsgNeedTranslate) return;
        const { localCustom } = this.props.msg || {};
        const { translating = false, isOriginal = true, isManualTranslation = false } = localCustom || {};

        if (this.props.isAutotranslation || translating || !isOriginal || (!this.state.isOriginal && isChangeLang)){// 翻译中切换会话，如果再回来触发再次翻译
            return this.msgtTranslation(isManualTranslation); 
        }
        
        this.setState({ translating, isOriginal, isManualTranslation });
    };

    shouldObserverMsg = async ()=>{
        // first check grecept;
        const needRecept = this.ObserverReceipt();
        if (needRecept || this.isMsgNeedTranslate(true) && !await this.changeChangeLang()) {
            this.intiateScrollObserver()
        };
        this.initStateData();
    }

    /**
     * 群里的 非自己发出去的消息
     */
    ObserverReceipt = ()=>{
        const { sessionActive, id, userInfo } = this.props;
        return sessionActive.type === 'team' && id !== userInfo.id;
    };

    intiateScrollObserver = () => {
        //if (!this.isMsgNeedTranslate(true) && await this.changeChangeLang(isChangeLang)) return;
        const options = {
            root: document.getElementById('box-content'),
            //rootMargin: '20px 0px 0px 0px',
            threshold: [0.3],
        };

        try {
            if(!this.observer){
                const itemDom = document.getElementById(`${this.props.idClient}`);
                if (!itemDom) return;
    
                this.observer = new IntersectionObserver(this.observerCallback, options);
                this.observer.observe(itemDom);
            }

        } catch (error) {
            //util.log('zhangyongchang', 'yach-im-translate', 'intiateScrollObserver：error');
            util.log('qiuyanlong', 'msg-observer', this.props.idClient, error);
        }
    };

    closeObserver(){
        if(this.observer){
            this.observer.disconnect();
            this.observer = null;
        }
    }
 
    observerCallback = (entries) => {
        const isFocus = window.store.getState().electronMainFocusChange.focus;
        const {dingMsgs = []} = window.store.getState();
        const msg  = this.props.msg;
        const type = window.session_active && window.session_active.type;
        const flagRecept = msg && msg.flow && msg.flow === 'in' && isFocus;
        const flagDing   = isFocus && !!dingMsgs.length; 

        entries.forEach((entry) => {
            if (entry.isIntersecting){
                flagRecept && util.yach.sendTeamReceipt(msg, type);
                flagDing && util.yach.delGatherDingMsg(this.props.idClient);
                this.msgtTranslation();
            }
        });
    };

    /**
     * 目标语言发生变化时判断
     */
    changeChangeLang = async() => {
        if(!isChangeLang) return true;

        // this.setState({ isChangeLang });

        const { idClient, userInfo, id } = this.props;
        const localMsg = (await util.nimUtil.getLocalMsgByIdClient(idClient)) || {};
        const { localCustom } = localMsg.msg || {};
        const { isOriginal = true } = localCustom || {};

        return isOriginal && id == userInfo.id;
    }

    /**
     * 判断是否是要翻译的消息
     * 1000最大值需要从接口下发，存在local，然后在local获取
     * @returns boolean
     */
    isMsgNeedTranslate = (isObserver) => {
        const { id, userInfo, msg } = this.props;
        const { type, content, text } = msg || {};

        if(!util.yach.isOpenMainSwitch()) return false

        const { localCustom } = this.props.msg || {};
        const { translating = false, isOriginal = true, isManualTranslation = false } = localCustom || {};
        if(id == userInfo.id){// 自己发的消息
            if(isObserver) return false; // 事件触发的
            if(isManualTranslation && (!isOriginal || translating)) return true; // 手动的 同时是 翻译后的或翻译中的
            return false;
        }

        if(isManualTranslation){// 手动翻译的
            return  !isOriginal || translating;
        } 

        if(util.yach.getMsgType(this.props) == '38') return true;// 自动回复

        if (!type || !text) return false;

        const strLength = util.yach.getStrCharLength(text);
        const maxStringLength = util.yach.translateStringMaxLength() || 1000;
        // 文本字符数小于1000 && at人在内容最前边 进行翻译
        if (type == 'text' && strLength <= maxStringLength) return true;

        if (content) {
            const newContent = util.nimUtil.getJson(content);
            // 被回复文本字符数小于1000 && at人在内容最前边 进行翻译
            if (newContent.type == 6 && strLength <= maxStringLength) return true;
        }

        return false;
    };

    /**
     * 消息翻译
     * isManualTranslation: 是否是手动翻译
     * 消息翻译, 先从本地db中获取，没有再取接口数据
     */
    msgtTranslation = async (isManualTranslation) => {
        const { translateText, isOriginal} = this.state;
        const { idClient, isAutotranslation, targetLanguage, lastMsg } = this.props;
        isManualTranslation = isManualTranslation || this.state.isManualTranslation;

        const current = () => {
            // 翻译中
            this.setState({ translating: true, isOriginal: false });
            util.nimUtil.updateLocalMsg(idClient, { translating: true, isOriginal: false, isManualTranslation });

            this.getTranslationFromIndexedDB(isManualTranslation);

            // let lastMsg = messageList[messageList.length-1];
            if(!lastMsg || lastMsg.idClient != idClient) return;

            setTimeout(() => { 
                this.itemRef && this.itemRef.scrollIntoView(false)
            }, 5);
        }

        if(isChangeLang && !isOriginal) return current();

        // 关闭自动翻译，消息还原 
        if (!isAutotranslation && !isManualTranslation) return this.messageRestore();

        // if(!isAutotranslation && isManualTranslation && isOriginal && !isChangeLang)  return current();

        // 本地有值 && 屏蔽不支持自动翻译的消息
        if (translateText && (await util.yach.autoTranslationShield(targetLanguage, idClient)))
            return this.closeObserver(); // 关闭观察器

        current();
    };

    /**
     * indexDB中读取数据
     */
    getTranslationFromIndexedDB = async (isManualTranslation) => {
        let { targetLanguage, idClient, custom } = this.props;
        let indexedDBObj = await util.yach.getTranslationFromIndexedDB(targetLanguage, idClient);
        let {text = '', version, symbolDetail } = indexedDBObj || {};

        // 本地数据不存在，再从api获取数据
        if (!indexedDBObj || !text || version != 1) return this.audioTranslateAPI(isManualTranslation);
        if (custom) text = util.yach.atHighlighted(text, util.yach.atDataEscape(symbolDetail || [], custom), true);
        text = this.filterText(text);

        this.setState({ translateText: text || '' });
        this.saveMsgManual('translation', isManualTranslation, indexedDBObj);
    };

    /**
     * 调用翻译接口
     */
    audioTranslateAPI = async (isManualTranslation) => {
        let { targetLanguage, idClient, isAutotranslation, custom } = this.props;
        const text = util.yach.getMsgText(this.props);

        let transformObj = {}; // 消息进行转义
        transformObj.text = text;
        transformObj.version = 1; // 翻译版本

        // 获取不翻译文本的内容和位置
        let symbol_detail = util.yach.getSymbolDetail(text, custom);

        transformObj.symbolDetail = symbol_detail;

        if(!isManualTranslation && !isAutotranslation) return;
        if (!targetLanguage || !text || !idClient){
            this.setState({ translating: false, isOriginal: true });
            util.nimUtil.updateLocalMsg(idClient, { translating: false, isOriginal: true });
            return;
        }

        const param = {
            text,
            symbol_detail: JSON.stringify(symbol_detail),
            from: 'auto',
            to: targetLanguage,
        };
        const res = await audioTranslate(param);
        this.closeObserver()

        if(!this.state.translating){
            return;
        }

        if (!res || res.code != 200 || !res.obj) {
            if (isManualTranslation) message.error(res.msg);
            this.setState({ translating: false, isOriginal: true });
            util.nimUtil.updateLocalMsg(idClient, { translating: false, isOriginal: true });
            return;
        }

        transformObj.text = res.obj.dsttext;
        transformObj.symbolDetail = res.obj.symbol_detail;

        this.updateTranslateText(isManualTranslation, transformObj);
    };

    /**
     * 更新翻译后的文本
     */
    updateTranslateText = (isManualTranslation, transformObj) => {
        let { targetLanguage, idClient, custom} = this.props;

        let text = transformObj.text;

        if (custom) text = util.yach.atHighlighted(text, util.yach.atDataEscape(transformObj.symbolDetail || [], custom), true);
        
        text = this.filterText(text);

        this.setState({ translateText: text || '' });
        this.saveMsgManual('translation', isManualTranslation, transformObj);
        util.yach.saveTranslationToIndexedDB(targetLanguage, idClient, transformObj); // 存储成功翻译后的
    }

    /**
     * 除了手动翻译之外的消息翻译还原
     */
    messageRestore = async () => {
        const { idClient } = this.props;
        const localMsg = (await util.nimUtil.getLocalMsgByIdClient(idClient)) || {};
        if(!localMsg || !localMsg.msg) return;
        const { localCustom } = localMsg.msg;
        const { isManualTranslation = false } = localCustom || {};
        const { isOriginal } = this.state;

        if ((!localCustom || !isManualTranslation) && !isOriginal) {
            const { idClient } = this.props;
            this.setState({ isOriginal: true });
            util.nimUtil.updateLocalMsg(idClient, { isOriginal: true });
            this.updataTranslateLastMsg();
            util.log('zhangyongchang', 'yach-im-translate', 'messageRestore: 原文', idClient);
        }
        this.closeObserver()
    };

    /**
     * 存储手动翻译和还原的标识
     */
    saveMsgManual = (type, isManualTranslation, replaceObj) => {
        const { idClient, targetLanguage} = this.props;
        util.log('zhangyongchang', 'yach-im-translate', 'saveMsgManual', type, idClient, targetLanguage);
        if (type == 'translation') {
            // 更新session lastMsg 消息
            this.updataTranslateLastMsg('translation', replaceObj);

            //存储翻译的标识
            this.setState({ translating: false, isOriginal: false, isManualTranslation});
            util.nimUtil.updateLocalMsg(idClient, {
                lang: targetLanguage,
                translating: false,
                isOriginal: false,
                isManualTranslation,
                isChangeLang
            });
        } else {
            // 更新session lastMsg 消息
            this.updataTranslateLastMsg('origin');

            const newState = {
                translating: false, isOriginal: true,
            }
            if(typeof isManualTranslation !== 'undefined'){
                newState.isManualTranslation = isManualTranslation;
            }

            //还原去掉标识
            this.setState(newState);
            util.nimUtil.updateLocalMsg(idClient, {});
        }
    };

        /**
     * 机器翻译or还原
     */
    translateAndReduction = () => {
        const { isOriginal } = this.state;

        const maxStringLength = util.yach.translateStringMaxLength() || 1000;
        const text = util.yach.getMsgText(this.props);
        if (util.yach.getStrCharLength(text) > maxStringLength) return message.error(util.locale('im_DNST')); // 字数超过最大设置

        if (isOriginal) {
            this.msgtTranslation(true); // 调用方法进行翻译
        } else {
            this.saveMsgManual();
        }

        util.sensorsData.track('Click_ChatWindow_MessageOperate', { OperateType:'01-108' });
    };

    /**
     * 更新session lastMsg 消息
     */
    updataTranslateLastMsg = (type, replaceObj = {}) => {
        let { sessionActive, idClient, text, lastMsg} = this.props;

        // let lastMsg = messageList[messageList.length-1];
        if(!lastMsg || lastMsg.idClient != idClient) return;

        if(type == 'translation' && replaceObj.text) text = `[${util.locale('im_translation')}]${replaceObj.text}`
        if(type == 'origin') setTimeout(() => { this.itemRef.scrollIntoView(false)}, 10);

        type = type ? type : 'origin';

        util.log('zhangyongchang', 'yach-im-translate', 'updataTranslateLastMsg', idClient, type);
        util.eventBus.emit('translationSession', {sessionActiveId: sessionActive.id, msgId: idClient, type, text});
    }

    fristScrollIntoView = () => { // TODO-PO 此处存在性能问题 待优化
        // const { userInfo, shouldScroll, firstActive } = this.props;
        // const isSelf = this.props.id == userInfo.id;
        // if (shouldScroll || isSelf || firstActive) {
        //     if (this.itemRef.offsetHeight < 350) {
        //         this.itemRef.scrollIntoView();
        //     } else {
        //         this.itemRef.scrollIntoView(false);
        //     }
        // }
        // 如果当前待渲染的消息是最近一条  就滚动到可视区域
        // const {shouldScroll, lastMsg, idClient} = this.props;
        // if(shouldScroll || lastMsg.idClient === idClient){
        //     this.itemRef.scrollIntoView();
        // }
        
        // 首次进入的时候，或最后一条消息是自己发送的，则最后一条消息滚动到底部
        const flag = util.yach.gd('box-content-first-into');
        const scrollOver = util.yach.gd('scroll-client-height-over') || false;
        // 如果当前待渲染的消息是最近一条  就滚动到可视区域
        const {lastMsg, idClient} = this.props;

        if(!scrollOver || (flag || lastMsg.flow == 'out') && lastMsg.idClient === idClient){
            this.itemRef.scrollIntoView();
            util.yach.sd('box-content-first-into', false);
        }
    };
    /**
     *  功能：
     *   1: 发送失败的文件或者文件夹的假消息和真实消息替换
     *   2: 普通消息发送成功 但是云信显示数据库存写异步，导致数据对不上，手动的进行更新
     *   只要是进入这个方法，这个消息就是异常的。
     */
    fileSendingDelete = async () => {
        const { idClient, status } = this.props;
        if (status === 'success') return;

        try {
            const data = await util.nimUtil.getLocalMsgByIdClient(idClient);
            let localStatus = data && data.msg && data.msg.status;
            if (localStatus === 'success') {
                this.props.dispatch(messageListAction.replaceByIdClient(data.msg, idClient));
            }
        } catch (e) {
            console.log('fileSendingDelete>>>', e);
        }
    };

    showOffice = () => {
        // this.props.dispatch(showPreviewModal({type:this.props.type, url: this.props.file.url}));
        util.electronipc.electronOpenFilepreview({
            file: this.props.file.url,
            name: this.props.file.name,
        });
    };

    showImg = (url, data) => {
        if (util.electron.isElectron()) {
            if (JSON.parse(data.content).data.hasOwnProperty('relationId')) {
                let relation_id = JSON.parse(data.content).data.relationId;
                this.getFileList(relation_id, data);
            } else {
                this.setState(
                    {
                        data: {
                            success: true,
                            data: [
                                {
                                    name: JSON.parse(data.content).data.fileName,
                                    url: JSON.parse(data.content).data.fileOriginUrl,
                                    id: JSON.parse(data.content).data.relationId,
                                    curr: true,
                                },
                            ],
                            id: '',
                        },
                    },
                    () => {
                        util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                            this.getFileList(id, data);
                        });
                    }
                );
            }
        } else {
            this.props.dispatch(showPreviewModal({ type: 'img', url: url }));
        }
        // console.log(data);
        // this.props.dispatch(showPreviewModal({type: 'img', url: url}));
    };
    getFileList = async (relation_id, wdata) => {
        let formData = {
            receive_id: this.props.sessionActive.id,
            relation_id,
            max: 30,
            img: 'img',
        };
        try {
            const data = await fileRangeList(formData);
            if (data && data.code === 200) {
                const { obj } = data;
                let largeFileInfo = obj.largeFileInfo.map((item) => {
                    return {
                        url: item.file_url,
                        name: item.file_name,
                        id: item.relation_id,
                        curr: false,
                        width: item.width,
                        height: item.height
                    };
                });
                let lessFileInfo = obj.lessFileInfo.reverse().map((item) => {
                    return {
                        url: item.file_url,
                        name: item.file_name,
                        id: item.relation_id,
                        curr: false,
                        width: item.width,
                        height: item.height
                    };
                });
                let currentFileInfo = {
                    url: JSON.parse(wdata.content).data.fileOriginUrl,
                    name: JSON.parse(wdata.content).data.fileName,
                    id: JSON.parse(wdata.content).data.relationId,
                    curr: true,
                    width: JSON.parse(wdata.content).data.width,
                    height: JSON.parse(wdata.content).data.height
                };
                let allPicFiles = [...lessFileInfo, currentFileInfo, ...largeFileInfo];
                this.setState(
                    {
                        data: {
                            success: true,
                            data: allPicFiles,
                            id: JSON.parse(wdata.content).data.relationId,
                        },
                    },
                    () => {
                        util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                            this.getFileList(id, wdata);
                        });
                    }
                );
            } else {
                this.setState(
                    {
                        data: {
                            success: false,
                            data: [
                                {
                                    name: JSON.parse(wdata.content).data.fileName,
                                    url: JSON.parse(wdata.content).data.fileOriginUrl,
                                    id: JSON.parse(wdata.content).data.relationId,
                                    curr: true,
                                    width: JSON.parse(wdata.content).data.width,
                                    height: JSON.parse(wdata.content).data.height
                                },
                            ],
                            id: JSON.parse(wdata.content).data.relationId,
                        },
                    },
                    () => {
                        util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                            this.getFileList(id, wdata);
                        });
                    }
                );
                message.error(`获取失败`);
            }
        } catch (err) {
            this.setState(
                {
                    data: {
                        success: false,
                        data: [
                            {
                                name: JSON.parse(wdata.content).data.fileName,
                                url: JSON.parse(wdata.content).data.fileOriginUrl,
                                id: JSON.parse(wdata.content).data.relationId,
                                curr: true,
                                width: JSON.parse(wdata.content).data.width,
                                height: JSON.parse(wdata.content).data.height
                            },
                        ],
                        id: JSON.parse(wdata.content).data.relationId,
                    },
                },
                () => {
                    util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                        this.getFileList(id, wdata);
                    });
                }
            );
        }
    };

    showUserinfo = async (id) => {
        id = typeof id != 'object' ? id : this.props.id || this.props.from;
        // console.log('use nim getuser or getteam hh1');
        let data = await util.nimUtil.getUser(id);
        let temData = util.yach.parseCustomType('p2p', data);
        let type = window.session_active.type
        let isRobot = temData && temData.type == 'robot'
        if(type === 'p2p'){
            if (isRobot) return util.yach.showUserinfo({ id: id, width: 340, height: 210 });
            util.yach.showUserinfo(id, 105);
        } else {
            if(!this.showUserinfoTime) this.showUserinfoTime = 1
            this.showUserinfoTime++
            if(this.showUserinfoS) clearTimeout(this.showUserinfoS)
            this.showUserinfoS = setTimeout(()=>{
                if(this.showUserinfoTime === 2){
                    if (isRobot) return util.yach.showUserinfo({ id: id, width: 340, height: 210 });
                    util.yach.showUserinfo(id, 105);
                } else {
                    if(isRobot){
                        let custom = util.nimUtil.getJson(data.custom)
                        if(custom && custom.type != 0) return util.yach.showUserinfo({ id: id, width: 340, height: 210 });
                    }
                    util.yach.itemActiveRow(id, 'p2p');
                }
                this.showUserinfoTime = 1
            },300)
        }
    };

    /**
     * 利用electron将图片复制到剪贴板
     * @author wangwenjie1
     * @date 2020/01/07
     */
    copyImgToClipboard = async () => {
        const content = JSON.parse(this.props.content);
        if (content && content.data) {
            const base64 = await util.imageDealer
                .imageSrcToBase64(content.data.fileOriginUrl)
                .then((data) => {
                    return data;
                })
                .catch((data) => {
                    return data;
                });
            if (!base64) {
                return false;
            }
            util.electronipc.electronWriteImageToClipBoard(base64);
            return true;
        } else {
            return false;
        }
    };
    // copy
    /**
     * 将copyText 更名为 copyToClipboard
     * @author wangwenjie1
     * @date 2020/01/07
     */
    copyToClipboard = async (type, customType) => {
        const fileUrl = this.props.file && this.props.file.url ? this.props.file.url : '';
        if (type == 'custom') {
            if (customType === '8') {
                if (!(await this.copyImgToClipboard())) {
                    message.error(util.locale('im_copy_failure')); // 复制失败
                    return;
                }
            }else if(customType === '38'){
                try {
                    const msg = `[${util.locale('im_auto_reply')}]` + util.nimUtil.getJson(this.props.content).data.content.reply_content;
                    copy(msg)
                } catch (error) {
                    
                }
            } else {
                const isLinkMsg = customType == '23' || customType == '24';
                if (isLinkMsg) {
                    const linkContent = linkMsgHandler.isLinkMsg(this.props.msg);
                    if (customType == '23') {
                        copy(linkContent.url);
                    } else {
                        copy(new URLSearchParams(linkContent.messageUrl.split('?')[1]).get('url'));
                    }
                } else {
                    copy(this.props.text);
                }
            }
        } else {
            if (this.props.type == 'text') copy(this.props.text);
            if (this.props.type == 'file' || this.props.type == 'video') {
                fileUrl.indexOf('?') > 0
                    ? copy(this.props.file.url + '&download=' + this.props.file.name)
                    : copy(this.props.file.url + '?download=' + this.props.file.name + '.' + this.props.file.ext);
            }
            if (this.props.type == 'audio') {
                this.props.fromClientType == 'Web'
                    ? copy(this.props.file.url + '&download=' + this.props.file.name)
                    : copy(this.props.file.mp3Url);
            }
            if (this.props.type == 'image') {
                const copyText =
                    this.props.file.url.includes('createTime')
                        ? this.props.file.url + '&imageView'
                        : this.props.file.url + '?imageView&createTime=' + this.props.time;
                copy(copyText);
            }
            // if (this.props.type == 'custom') copy(this.props.content);
        }
        message.success(util.locale('im_copy_complete')); // 复制完成
        util.sensorsData.track('Click_ChatWindow_MessageOperate', { OperateType: 104 });
    };

    getImgScale = (height, width) => {
        if (!width || !height) return undefined;
        let scale = 1,
            maxWidth = 200,
            maxHeight = 200;
        if (width * scale > maxWidth) {
            scale = maxWidth / width;
        }
        if (height * scale > maxHeight) {
            scale = maxHeight / height;
        }
        return scale;
    };

    toggleAudioText = async (url, idClient) => {
        if (!this.state.isShowAudioText) {
            util.sensorsData.track('Click_ChatWindow_MessageOperate', { OperateType: '01-107' });
        }
        if (this.state.isShowAudioText) {
            this.setState({ isShowAudioText: false });
            util.nimUtil.updateLocalMsg(idClient, { audioText: this.state.audioText, isShowAudioText: false });
            return;
        }
        if (this.state.audioText && this.state.audioText !== '转换失败') {
            this.setState({ isShowAudioText: true });
            util.nimUtil.updateLocalMsg(idClient, { audioText: this.state.audioText, isShowAudioText: true });
            return;
        }
        this.setState({ isShowAudioText: true });
        this.audioToText(url, idClient);
    };

    audioToText = async (url, idClient) => {
        this.setState({ audioText: `${util.locale('im_converting')}…` }); // 转换中
        try {
            const { data } = await ai.audioToText(url, this.getPlatform());
            if (data) {
                const audioText =
                    data.result.text && data.result.text !== ''
                        ? data.result.text
                        : `「${util.locale('im_no_content')}」`; // 「无内容」
                this.setState({ audioText });
                util.nimUtil.updateLocalMsg(idClient, { audioText, isShowAudioText: true });
            }
        } catch (error) {
            this.setState({ audioText: util.locale('im_conversion_failed') }); // 转换失败
            util.nimUtil.updateLocalMsg(idClient, { audioText: '转换失败', isShowAudioText: true });
        }
        if (this.voiceReadRef) {
            this.props.setVoiceReadHeigth(this.voiceReadRef.offsetHeight);
        }
    };

    getPlatform = () => {
        const electron = util.electron;
        if (electron && electron.isElectron()) {
            if (util.electron.isMac()) {
                return 'mac';
            } else if (util.electron.isWin()) {
                return 'windows';
            } else {
                return 'windows';
            }
        } else {
            return 'windows';
        }
    };

    setVoiceReadRef = (el) => {
        this.voiceReadRef = el;
    };

    getItemRef = (el) => {
        this.itemRef = el;
    };

    itemMouseOver = () => {
        const { showTools } = this.state;
        const { messageListState, target } = this.props;
        if (messageListState.showCheckbox || showTools) return;

        if (target == '3002') this.setState({ showTools: true }); // 文件小助手添加更多图标
        if (!target || `${target}`.length <= 4) return;

        this.setState({ showTools: true });
    };

    itemMouseOff = () => {
        this.setState({ showTools: false, emojiVisible: false, toolItemActive: 0 });
    };

    /**
     * 点击表情回复
     */
    clickEmojiItem = (emojiName) => {
        const {target, idClient, time, scene} = this.props;

        // todo 从后端config获取参数，判断是否切换到新方案
        let isUseNew = false;

        // 群聊 && 是否使用新方案
        if(scene == 'team' && !isUseNew){
            //  之前方案
            this.clickEmojiOldItem(emojiName, target, idClient, time);
        } else {
            // todo 使用新方案
        }
    };

    /**
     * 使用更新群消息的表情回复
     */
    clickEmojiOldItem = async (emojiName, target, idClient, time) => {
        util.sensorsData.track('Click_ChatWindow_MessageOperate', { OperateType: 110 });

        emojiName = await util.emoji('getEmojiZH')(emojiName);

        this.setState({ emojiVisible: false, toolItemActive: 0 });
        const { emots = [] } = this.props;
        const params = {
            session_id: target,
            msg_id: idClient,
            emot: emojiName,
            curr_time: time,
        };
        for (let i = 0; i < emots.length; i++) {
            const el = emots[i];
            if (el.emoji == emojiName) {
                const userIds = el.userList.map((item) => item.userId);
                const { userInfo } = this.props;
                if (userIds.includes(userInfo.id + '')) {
                    await groupEmotDel(params);
                    return;
                }
            }
        }
        try {
            const datas = await groupEmotAdd(params);
            if (datas) {
                const { code, msg } = datas || {};
                if (code != 200) {
                    message.warning(msg);
                }
            }
        } catch (error) {
            message.warning(error);
        }
    }

    setActive = (activeIndex) => {
        this.setState({ toolItemActive: activeIndex });
    };

    clickEmot = (value) => {
        const { userInfo, target, idClient, scene } = this.props;

        // todo 从后端config获取参数，判断是否切换到新方案
        let isUseNew = false;

        // 群聊 && 是否使用新方案
        if(scene == 'team' && !isUseNew){
            const userIds = value.userList.map((item) => item.userId);
            if (userIds.includes(`${userInfo.id}`)) {
                const params = {
                    session_id: target,
                    msg_id: idClient,
                    emot: value.emoji,
                };
                groupEmotDel(params);
            } else {
                this.clickEmojiItem(value.emoji);
            }
        } else {
            // todo 使用新方案
        }
    };

    handleVisibleChange = (visible) => {
        this.setState({ emojiVisible: visible });
    };

    editTip = (text,idClient) => {
        util.eventBus.emit('editTip', {text,idClient});
        util.log('qinqinghao','13-im','box-content-message-container/editTip:编辑撤回消息',text,idClient)
    };

    fileDownload = async (url, idClient, name = '', ext, isdownloading,relationId) => {
        if (!name.endsWith(`.${ext}`) && ext) {
            name = `${name}.${ext}`;
        }
        if (isdownloading) return false;
        // util.cosfiles.fileDownload(idClient, url, name);
        util.cosfiles.fileDownload({idClient, url, name,relationId});

    };

    videoEventListen = () => {
        //util.log('panghaojie','box-content-message-container.js','videoEventListen')
        //下载回调
        util.electronipc.electronOnVideoWindowDownloadVideo(async (obj) => {
            util.log('panghaojie', 'box-content-message-container.js', 'videodownloadcb');
            const { url, idClient, name, ext, isdownloading } = obj;
            await this.videoFileDownload(url, idClient, name, ext, isdownloading);
        });
        // util.electronipc.electronChannelListen('videodownloadcb', async(obj) => {
        //     util.log('panghaojie','box-content-message-container.js','videodownloadcb')
        //     const {url, idClient,name, ext, isdownloading } = obj
        //     await this.videoFileDownload(url, idClient,name, ext, isdownloading)
        // })
        //取消下载回调
        util.electronipc.electronOnVideoWindowDownloadCancel((obj) => {
            util.log('panghaojie', 'box-content-message-container.js', 'videodownloadcancelcb');
            const { idClient } = obj;
            this.fileDownloadCancel(idClient);
        });
        // util.electronipc.electronChannelListen('videodownloadcancelcb', obj => {
        //     util.log('panghaojie','box-content-message-container.js','videodownloadcancelcb')
        //     const { idClient } = obj
        //     this.fileDownloadCancel(idClient)
        // })

        //打开文件夹
        util.electronipc.electronOnVideoWindowOpenFolder((obj) => {
            //提示，弹窗页面已做过处理，此处只处理主窗口的数据
            util.log('panghaojie', 'box-content-message-container.js', 'openfoldercb');
            const { idClient } = obj;
            const filestatus = {
                id: idClient,
                isDownloaded: false,
                downloadedPath: '',
            };
            this.props.dispatch(fileRedux.fileStatusUpdate(idClient, filestatus));
            util.nimUtil.updateLocalMsg(idClient, { isDownloadFlag: false, path: null });
        });
        // util.electronipc.electronChannelListen('openfoldercb', obj => {
        //     //提示，弹窗页面已做过处理，此处只处理主窗口的数据
        //     util.log('panghaojie','box-content-message-container.js','openfoldercb')
        //     const { idClient } = obj
        //     const filestatus = {
        //         id: idClient,
        //         isDownloaded: false,
        //         downloadedPath: ''
        //     }
        //     this.props.dispatch(fileRedux.fileStatusUpdate(idClient, filestatus));
        //     util.nimUtil.updateLocalMsg(idClient, { isDownloadFlag: false, path: null });
        // })
    };
    clickVideo = (data) => {
        const {
            fileUrl,
            idClient,
            fileName,
            fileExt,
            isdownloading,
            fileSize,
            filePath,
            fileDur,
            msg,
            isDownloadFlag,
            pic,
            taskId,
            relationId,
            coverUrl,
            width,
            height,
            csize,
        } = data;
        util.log('panghaojie', 'box-content-message-container.js', 'clickVideo', fileUrl, idClient, fileName, fileExt);
        util.electronipc.electronOpenVideoPreview({
            url: fileUrl,
            name: fileName,
            idClient,
            videoSize: fileSize,
            ext: fileExt,
            isDownloadFlag,
            filePath,
            fileDuration: util.videoUtil.getVideoTime(fileDur || 0),
            msg: msg || '',
            isdownloading,
            pic,
            taskId,
            relationId,
            width,
            height,
            coverUrl,
            csize,
            fileDur,
        });
        if (isdownloading) {
            // this.videoFileDownload(fileUrl, idClient, fileName, fileExt, isdownloading, true);
            this.videoFileDownload(fileUrl, idClient, fileName, fileExt, isdownloading, true,relationId);
        }
    };

    videoFileDownload = async (url, idClient, name = '', ext, isdownloading, noNeedDownload,relationId) => {
        util.log(
            'panghaojie',
            'box-content-message-container.js',
            'videoFileDownload',
            url,
            idClient,
            name,
            ext,
            isdownloading,
            noNeedDownload
        );
        if (!name.endsWith(`.${ext}`) && ext) {
            name = `${name}.${ext}`;
        }
        if (isdownloading && !noNeedDownload) return false;
        // if (!isdownloading) util.cosfiles.fileDownload(idClient, url, name);
        if (!isdownloading) util.cosfiles.fileDownload({idClient, url, name,relationId});
    };

    fileDownloadCancel = (id) => {
        util.log('panghaojie', 'box-content-message-container.js', 'fileDownloadCancel', id);
        let file = this.props.fileDownloadProgress.find((v) => v.id == id);
        this.props.dispatch(fileRedux.fileDownloadProgressRemove(id));
        util.log('panghaojie', 'box-content-message-container.js', 'fileDownloadCancel', !file);
        if (!file) return false;
        util.electronipc.electronDownloadFileDestory({ channelid: file.channelid });
        util.electronipc.electronSendCancelDownload();
    };

    openFile = ({path, idClient,relation_id}) => {
        util.log('panghaojie', 'box-content-message-container.js', 'openFile', path);
        if (!path) return;
        util.electronipc.electronCheckFile({ path }, (res) => {
            if (res) {
                util.electronipc.electronOpenFile({ path });
            } else {
                let filestatus = {
                    id: idClient,
                    isDownloaded: false,
                    downloadedPath: '',
                };
                this.props.dispatch(fileRedux.fileStatusUpdate(idClient, filestatus));
                // util.nimUtil.updateLocalMsg(idClient, { isDownloadFlag: false, path: null });
                util.cosfiles.fileDownloadStatusUpdate({path:null,key:relation_id});
            }
        });
    };
    // updateWorkStatus = () => {
    //     const { sessionActive } = this.props;
    //     if (sessionActive.type != 'team') return;
    //     const result = util.yach.getSessionSateById(this.props.id);
    //     if (result && result.service_type !== '999') {
    //         this.setState({
    //             workStatus: result,
    //         });
    //     }
    // };
    handleAtMember = (data) => {
        util.sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-147' });
        let str = ` @${data.fromNick}${data.yachNick ? `(${data.yachNick}) ` : ' '} `;
        if (data.robot_user) str = ` @${data.fromNick}(${data.fromNick}) `;
        this.props.dispatch(draftAction.draftEditorStateAtAdd(str, { id: data.id }));
        util.eventBus.emit('close-at-member');
    };

    filterText = (text) => {
        text = util.yach.textFiltering(text);
        text = util.yach.convertExpression(text, '34px', '34px');
        return text;
    };
    filterTextSpan = (key, text) => {
        if (text.replace(/\s*/g, '') == '') return null;
        return <span style={{ display: 'inline' }} key={key} dangerouslySetInnerHTML={{ __html: text }} />;
    };
    atHighlighted = ({ text, customContent, readers, readFlag }) => {
        if (!text)
            return <span style={{ display: 'inline' }} dangerouslySetInnerHTML={{ __html: this.filterText(text) }} />;
        try {
            const custom = JSON.parse(customContent);
            let readersUid = readers.uid || [];
            //readersUid.push(299193)
            let atHighlighted = custom.atHighlighted;
            if (!atHighlighted || (atHighlighted && !atHighlighted.length))
                return (
                    <span style={{ display: 'inline' }} dangerouslySetInnerHTML={{ __html: this.filterText(text) }} />
                );
            atHighlighted.sort((a, b) => a.index - b.index);
            let result = [];
            let currentIndex = 0;
            let filterText;
            for (let i = 0; i < atHighlighted.length; i++) {
                let el = atHighlighted[i];
                if (text.substr(el.index, el.atName.length).trim() == el.atName.trim()) {
                    filterText = this.filterTextSpan(
                        `${readers.msgId}_${i}_1`,
                        this.filterText(text.substring(currentIndex, el.index))
                    );
                    filterText && result.push(filterText);
                    result.push(
                        <AtHighlighted
                            key={`${readers.msgId}_${i}_2`}
                            showUserInfo={this.showUserinfo}
                            userid={el.id}
                            showFlag={readFlag}
                            isRead={readersUid.includes(+el.id)}
                            atName={this.filterText(el.atName)}
                        />
                    );
                    currentIndex = el.index + el.atName.length;
                }
            }
            filterText = this.filterTextSpan(`${readers.msgId}_end_3`, this.filterText(text.substring(currentIndex)));
            filterText && result.push(filterText);
            text = <>{result}</>;
            return text;
        } catch (error) {
            return text;
        }
    };

    createMeetingSummary = async () => {
        //请求接口，如果有会议纪要文档地址，直接打开，如果没有，服务端会创建一个新文档
        const { id } = this.props.sessionActive;
        const data = await util.summaryUtil.meetingSummaryGetUrl({
            group_tid: id,
        });
        data.title = util.locale('calendar_create_meeting_summary');
        data.sessionActive = this.props.sessionActive;
        util.summaryUtil.goDocument(data);

        //会议纪要引导消息点击埋点
        util.sensorsData.track('Click_Chat_Element', {
            pageName: 135,
            $element_name: '01-195',
        });
    };

    getTypeToMsgMap = () => ({
        'image'     : `[${util.locale('common_pic')}]`,
        'file'      : `[${util.locale('common_file')}]`,
        'video'     : `[${util.locale('common_video')}]`,
        'audio'     : `[${util.locale('common_audio')}]`,
        '2'         : `[${util.locale('common_week_report')}]`,
        '3'         : `[${util.locale('common_group_notice')}]`,
        '5'         : `[${util.locale('common_file')}]`,
        '7'         : `[${util.locale('common_chat_record')}]`,
        '8'         : `[${util.locale('common_pic')}]`,
        '10'        : `[${util.locale('common_file')}]`,
        '12'        : `[${util.locale('common_redpack')}]`,
        '13'        : `[${util.locale('common_redpack')}]`,
        '14'        : `[${util.locale('media_video_meeting')}]`,
        '16'        : `[${util.locale('common_doc_online')}]`,
        '18'        : `[${util.locale('media_video_meeting')}]`,
        '23'        : `[${util.locale('common_share')}]`,
        '24'        : `[${util.locale('common_share')}]`,
        '25'        : `[${util.locale('Emoji')}]`,
        '26'        : `[${util.locale('im_folder')}]`,
        '27'        : `[${util.locale('common_doc_online')}]`,
        '28'        : `[${util.locale('calendar_create_meeting_summary')}]`,
        '29'        : `[${util.locale('calendar_create_meeting_summary')}]`,
        '30'        : `[${util.locale('media_video')}]`,
        '31'        : `[${util.locale('im_location')}]`,
        '32'        : `[${util.locale('im_vote')}]`,
        '33'        : `[${util.locale('calendar_meeting_guidance_title')}]`,
    })

    mapTypeToShowSimpleMsg = (type, content) => {
        if (content) {
            content = util.nimUtil.getJson(content, {})
        }

        if (type == 'custom') {
            type = content.type
        }

        if (type == '26') {
            let name = content.data && content.data.fileName
            return `${this.getTypeToMsgMap()[type]} ${name}`
        }

        if (type == '10' || type == '5' || type == 'file') {
            let name = content.data && content.data.fileName
            return `${this.getTypeToMsgMap()[type]} ${name}`
        }

        if (type == '15') {
            return content.data.textMsgPc || ''
        }

        return this.getTypeToMsgMap()[type]
    }

    // 设置稍后处理
    setLater = async () => {
        let json = {
            sessionId: this.props.sessionActive.id,
            clientId: this.props.idClient,
            serverId: this.props.idServer,
            fromAccount: this.props.from,
            fromType: this.props.sessionActive.type == 'team' ? 'group' : 'personal',
            ext: {},
            message: this.mapTypeToShowSimpleMsg(this.props.type, this.props.content) || this.props.text,
            messageType:  this.props.type,
            status: 0,
            time: this.props.time,
        }

        let data = await audioBusMessagePush({
            type: 'later',
            json: JSON.stringify(json)
        })

        if (data && data.code == 200) {
            message.success(util.locale('im_later_success'))
        } else {
            message.error(util.locale('im_operate_error'))
        }

        util.sensorsData.track('Click_ChatWindow_MessageOperate', {
            OperateType: '01-109'
        })
    }
    getCustomType = () => {
        let { type } = this.props;
        if (type == 'custom') {
            try {
                const content = JSON.parse(this.props.content);
                type = content.type;
                if (type == 6 && content.data.type == 'audio') type = 'replyAudio';
            } catch (error) {
                return `${type}`;
            }
        }
        return `${type}`;
    };
    
    getCustomText = (data) => {
        let text = data.text;
        const newContent = util.nimUtil.getJson(data.content);

        if(newContent.type === 38){
            text = `[${util.locale('im_auto_reply')}]${newContent.data.content.reply_content}`
        }
        return {...data, text}
    }

    render = () => {
        // TODO-PO 此处存在性能问题 有大量冗余的渲染
        const { sessionActive, sessionActiveDetail, userInfo, id: userId } = this.props;
        // let { mtime, memberNum } =
        //     sessionList.filter((item) => {
        //         return item.id === sessionActive.id;
        //     })[0] || {};
        const {mtime, memberNum} = sessionActiveDetail || {};
        // console.log({mtime, memberNum})/*  */
        const isSelf = userId == userInfo.id;
        //let workStatus = this.state.workStatus; //|| this.props.workStatus;
        return (
            <div>
                <BoxContentMessage
                    {...this.props}
                    getCustomType={this.getCustomType}
                    //workStatus={workStatus}
                    //robot_user={this.props.robot_user}
                    getItemRef={this.getItemRef}
                    clickEmot={this.clickEmot}
                    showOffice={this.showOffice}
                    showImg={this.showImg}
                    copyToClipboard={this.copyToClipboard}
                    showUserinfo={this.showUserinfo}
                    editTip={this.editTip}
                    // id={this.props.id}
                    // idServer={this.props.idServer}
                    // idClient={this.props.idClient}
                    // flow={this.props.flow}
                    // status={this.props.status}
                    // text={this.props.text}
                    // content={this.props.content}
                    // custom={this.props.custom}
                    // time={this.props.time}
                    // fromNick={this.props.fromNick}
                    // yachNick={this.props.yachNick}
                    isTeam={this.props.sessionActive.type == 'team'}
                    file={this.props.file ? this.props.file : ''}
                    mtime={mtime}
                    memberNum={memberNum}
                    // deleteMsg={this.props.deleteMsg}
                    // resendMsg={this.props.resendMsg}
                    // fromClientType={this.props.fromClientType}
                    // target={this.props.target}
                    getImgScale={this.getImgScale}
                    isSelf={isSelf}
                    setIsPlay={this.setIsPlay}
                    toggleAudioText={this.toggleAudioText}
                    audioText={this.state.audioText}
                    isShowAudioText={this.state.isShowAudioText}
                    setVoiceReadRef={this.setVoiceReadRef}
                    // isInAt={this.props.isInAt}
                    clickEmojiItem={this.clickEmojiItem}
                    showTools={this.state.showTools}
                    setActive={this.setActive}
                    toolItemActive={this.state.toolItemActive}
                    itemMouseOver={this.itemMouseOver}
                    itemMouseOff={this.itemMouseOff}
                    showCheckbox={this.props.messageListState.showCheckbox}
                    // emots={this.props.emots}
                    // scheduleObj={this.props.scheduleObj}
                    handleVisibleChange={this.handleVisibleChange}
                    emojiVisible={this.state.emojiVisible}
                    ownerId={this.props.sessionOwner || 0}
                    fileDownload={this.fileDownload}
                    clickVideo={this.clickVideo}
                    fileDownloadCancel={this.fileDownloadCancel}
                    openFile={this.openFile}
                    isDownload={this.state.isDownload}
                    filePath={this.state.filePath}
                    againDownload={this.state.againDownload}
                    manager={this.state.manager}
                    // ismute={this.props.ismute}
                    // robotNum={this.props.robotNum}
                    // isLocal={this.props.isLocal}
                    handleAtMember={this.handleAtMember}
                    atHighlighted={this.atHighlighted}
                    createMeetingSummary={this.createMeetingSummary}
                    sessionActive={sessionActive}
                    // teamInfo={this.props.teamInfo}
                    // delSelfMsg={this.props.delSelfMsg}
                    // busyIconStatus={this.props.busyIconStatus}
                    translateAndReduction={this.translateAndReduction}
                    translating={this.state.translating}
                    isOriginal={this.state.isOriginal}
                    translateText={this.state.translateText}
                    showAutoTranslation={util.yach.showAutoTranslation()}
                    setLater={this.setLater}
                />
            </div>
        );
    };
}

const mapStateToProps = (state) => {
    return {
        messageListState:       state.messageListState,
        sessionActive:          state.sessionActive,
        sessionActiveDetail:    state.sessionList.find(({id}) => state.sessionActive.id === id),
        // sessionList:         state.sessionList,
        // messageList:         state.messageList,
        lastMsg:                state.messageList[state.messageList.length - 1],
        userInfo:               state.userInfo,
        sessionOwner:           state.sessionOwner,
        sessionList_p2p_statue: state.sessionList_p2p_statue,
        ismute:                 state.groupAll.ismute,
        ismanager:              state.groupAll.ismanager,
        robotNum:               state.getRobotNum,
        sessitonActivePic:      state.sessitonActivePic,
        fileDownloadProgress:   state.fileDownloadProgress,
        fileStatus:             state.fileStatus,
        uploadFileState:        state.uploadFile,
        busyIconStatus:         state.busyIconStatus,
        dingMsgs:               state.dingMsgs,
        targetLanguage:         state.targetLanguage,
    };
};

export default connect(mapStateToProps, null)(BoxContentMessageContainer);
