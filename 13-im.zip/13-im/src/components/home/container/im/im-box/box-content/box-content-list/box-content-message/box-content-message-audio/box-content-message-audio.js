// react
import React from 'react';

import './index.scss'

import { connect } from 'react-redux';

// redux
import { add } from '@r/actions/playAudio';
import * as util from '@u/util.js';
export class VoiceRead extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            // 音频源
            voice: this.props.audioUrl,
            // 当前播放时间
            timeCurrent: "00:00",
            // audio currentTime
            currentTime: 0,
            // 播放总时间
            voiceDuration: "00:00",
            // 音频容器长度
            audioLength: '138px'
        }
    }

    componentDidMount() {
        let voiceDuration = this.transTime(this.props.audioDur)
        this.setState({ voiceDuration })
    }

    play() {
        let audio = this.refs.audioTag;
        let {msg,flow,replyMsg={}} = this.props;
        let {msgId='',count=0,isListen } = this.getIsListenArg();
        let {idClient='',target=''} = replyMsg;
        let isreply = (idClient && target) ? true: false;

        audio.currentTime = this.state.currentTime;
        if (audio.paused) {
            this.stopOutherAudio()
            this.props.dispatch(add(this.props.idClient));
            audio.play();
            //如果没有加载出时间
            if (this.state.voiceDuration == "00:00") {
                window.setTimeout(() => {
                    this.loadVideo();
                }, 300);
        }
        } else { // pause music
            this.props.dispatch(add(''));
            audio.pause();
        }

        if((flow == 'in') || (flow == 'out' && idClient && target) ){
            let sid = idClient ? idClient : msg.idClient; 
            const param = {
                sessionId: isreply ? target : msg.target,
                list:[{
                        msgId:sid,
                        call_voice:{ msgId:sid, count: 1, isListen:1}
                }]
             };
            util.yach.audioMessageExtraData( isreply ? replyMsg : this.props.msg);
            util.yach.handleExtraDataSysMsg (param);
        }
    }    

    // audio的timeupdate事件，用于更新播放进度
    timeUpdate() {
        let audio = this.refs.audioTag;
        // let value = Math.round((Math.floor(audio.currentTime) / Math.floor(audio.duration)) * 100, 0);
        //console.log("timeUpdate " + audio);

        let timeline = this.refs.timeline;
        let playhead = this.refs.playhead;
        let playOverline = this.refs.playOverline
        let timelineWidth = timeline.offsetWidth - playhead.offsetWidth;
        let playPercent = timelineWidth * (audio.currentTime / audio.duration);
        playhead.style.webkitTransform = "translateX(" + playPercent + "px)";
        playhead.style.transform = "translateX(" + playPercent + "px)";
        playOverline.style.width = playPercent + 5 + 'px'

        //let timeCurrent = this.transTime(parseInt(audio.currentTime));
        let timeCurrent = this.transTime(Math.round(audio.currentTime));
        if(timeCurrent == this.state.voiceDuration){
            setTimeout(()=>{
                this.props.dispatch(add(''));
                audio.pause();
                audio.currentTime = 0;
                this.setState({timeCurrent: "00:00"});
           },1000);
        }
        
        this.setState({
            timeCurrent: timeCurrent,
            currentTime: audio.currentTime,
        });
    }

    /** 获取视频总长 */
    loadVideo() {
        let audio = this.refs.audioTag;
        //this.computedAudioLength(audio.duration)

        let duration = this.transTime(audio.duration);
        let time = duration == "NaN:NaN" ? "00:00" : duration;

        if (time == "00:00" && duration != "NaN:NaN" && !!initAudio) {
        audio.play();
        audio.pause();
        initAudio = false;

        window.setTimeout(() => {
            this.loadVideo();
        }, 300);
        }

        //this.setState({ voiceDuration: time });
    }

    // 计算语音长度
    computedAudioLength = duration => {
        let time = parseInt(duration);
        let minLength = 170
        let maxLength = 322
        time = Math.min(duration, 59)
        let length = minLength + (time - 1) * (maxLength - minLength) / 58
        this.setState({ audioLength: length + 'px' })
    }

    /**
     * 进度条操作
     * @param  {[type]} e [description]
     * @return {[type]}   [description]
     */
    timelineClick(e) {
        let timeline = this.refs.timeline;
        let playhead = this.refs.playhead;
        let audio = this.refs.audioTag;
        let timelineWidth = timeline.offsetWidth - playhead.offsetWidth;
        let playOverline = this.refs.playOverline
        // 更新坐标位置
        // e.pageX 鼠标点击位置
        let newLeft = '';
        if(this.props.flow == 'in'){
            newLeft = e.pageX - 940;
        }else if(this.props.flow == 'out'){
            newLeft = e.pageX - 1140;
        }
        let currentTime = audio.duration * newLeft / timelineWidth;
        if (newLeft >= 0 && newLeft <= timelineWidth) {
            playhead.style.transform = "translateX(" + newLeft + "px)";
            playOverline.style.width = newLeft + 'px'
        }
        if (newLeft < 0) {
            playhead.style.transform = "translateX(0)";
            currentTime = 0;
        }
        if (newLeft > timelineWidth) {
            playhead.style.transform = "translateX(" + timelineWidth + "px)";
            currentTime = audio.duration;
        }

        // 更新时间
        let timeCurrent = this.transTime(currentTime)
        this.setState({
            timeCurrent: timeCurrent,
            currentTime: currentTime,
        });

        // 如果在播放
        if (!audio.paused) {
            audio.currentTime = currentTime;
            audio.play();
        }
    }

    // 进度条点击
    touchStart(e) {
        let events = e.touches[0] || e;
        this.timelineClick(events);
    }

    touchMove(e) {
        let events = e.touches[0] || e;
        this.timelineClick(events);
    }

    touchEnd(e) {
        this.setState({
        touching: false,
        })
    }

    //转换音频时长显示
    transTime(time) {
        let duration = Math.round(time);
        let minute = Math.floor(duration / 60);
        let sec = duration % 60;
        if(!sec) sec = time > 0 ? '1' : '0';
        sec = `${sec}`;
        let isM0 = ':';
        if (minute == 0) {
            minute = '00';
        } else if (minute < 10) {
            minute = '0' + minute;
        }
        if (sec.length == 1) {
            sec = '0' + sec;
        }
        return minute + isM0 + sec
    }

    stopOutherAudio = () => {
        const sounds = document.getElementsByTagName('audio');
        for(let i=0; i<sounds.length; i++) {
            sounds[i].pause()
        }
    }

   getIsListenArg = ()=>{
       let { messageExtraData={},idClient} = this.props;
       return messageExtraData['call_voice'] || {};
   } 

  render() {
      const {audioText, isShowAudioText, isTeam, flow,robotNum} = this.props;
      let {count=0} = this.getIsListenArg();
      let memberNum = window.store.getState().sessionActive.memberNum || 0;

      return (
    //   <div className="voice-container" style={{width: this.props.audioLength}}>
      <div className="voice-container" style={{width: this.props.audioLength}}>
            <audio ref="audioTag" src={this.state.voice} onTimeUpdate={()=>this.timeUpdate()} onLoadedMetadata={()=>this.loadVideo()}/>
            <div className="controls">
              <div className="fake-control">
                <div className="inline-block voice-control">
                    <a className="playPause" onClick={()=>this.play()}>
                        {this.props.idClient ==  this.props.playAudio &&
                            <span className="icon iconfont iconzanting" />
                        }
                        {this.props.idClient !=  this.props.playAudio &&
                            <span className="icon iconfont iconbofang" style={{marginLeft: 2}} />
                        }
                    </a>
                    </div>
                    <div  className="fake-control-timeline" >
                        <div ref="timeline" className={`${this.props.flow === "in" ? "inTimeline" : "outTimeline"   } inline-block commonTimeLine`} >
                            <span ref='playOverline' className='playOverline'></span>
                            <div ref="playhead" className="playhead" onTouchStart={(e)=>this.touchStart(e)} onTouchMove={(e)=>this.touchMove(e)} onTouchEnd={(e)=>this.touchEnd(e)}></div>
                        </div>

                        <div className="inline-block play-time">
                            <div className="inline-block played-time">{this.state.timeCurrent}</div>
                            <div className="inline-block">/</div>
                            <div className="inline-block audio-time" id="audioTime">{this.transTime(this.props.audioDur)}</div>
                        </div>
                    </div>
              </div>
          </div>
          {audioText && isShowAudioText &&
            (audioText===`${util.locale('im_conversion_failed')}`?
            <div className="audio-mgtop-pos">
                <p className="meaning-tip along">{audioText}</p>
            </div> :
            <div className="audio-mgtop-pos">
                <p className="meaning">{audioText}</p>
                <p className="meaning-tip">{util.locale('media_voice_recognition')}</p>
            </div>

            )
          }
          { flow == 'out' && !isTeam && !!count && <p className="has-sound-people"> {util.locale('im_audio_listen_received')}</p> }
          { flow == 'out' && isTeam  && !!(memberNum - count -1 -robotNum) && !!count && <p className="has-sound-people">{ util.locale('im_audio_listen_received_x').replace('[x]',count)} </p> }
          { flow == 'out' && isTeam  &&  (memberNum - count -1 -robotNum) <=0 && !!count && <p className="has-sound-people">{ util.locale('im_audio_listen_received_all')} </p> }

      </div>
    );
  }
}

const mapStateToProps = state => {
    return {
        playAudio: state.playAudio
    };
};

export default connect(
    mapStateToProps,
    null
)(VoiceRead);
