// react
import React, { Fragment } from 'react';

// css
import css from './index.scss';

// antd
import { Modal } from 'antd';

//util
import * as util from '@u/util.js';

//component
import SettingTop from './setting-top/setting-top';
import SettingContent from './setting-content/setting-content';
import SettingBottom from './setting-bottom/setting-bottom';
import CommonModal from '@/components/common/common-modal';
import UserAdd from '@c/common/user-add/user-add-container';

// BoxOperation
export default function BoxSetting(props) {
    const {
        typeMsg,
        showNameInput,
        showSearchInput,
        searchValue,
        list,
        masterId,
        onFixtop,
        onNodisturb,
        onReadmore,
        onGroupNameblur,
        onEditCommon,
        onSearchValueChange,
        modalVisible,
        quitGroupModal,
        onShowGroupModal,
        disnotice,
        isTop,
        showimg,
        showname,
        memberNum,
        onToggleOwnerModal,
        quitGroupBtn,
        quitSquadBtn,
        quitGroupCancel,
        quitGroupOk,
        goManagement,
        userInfoId,
        delMember,
        delModalVisible,
        delCancel,
        delOk,
        delText,
        userAddShow,
        userAddDisids,
        userAddOk,
        userAddClose,
        getRule,
        getConfigEdite,
        handleKeyPress,
        tid,
        groupInfo,
        user_status,
        userIni,
        isAddress,
        handleCancelSearch,
        ifSearching,
        chatRecord,
        onMachineTranslation,
        isTranslation,
        hasMoreData,
        searchGroupUser
    } = props;

    const topProps = {
        showname,
        showNameInput,
        onGroupNameblur,
        onEditCommon,
        portrait: showimg,
        getConfigEdite,
        handleKeyPress,
        tid,
        typeMsg,
    };
    const contentProps = {
        searchValue,
        onReadmore,
        onEditCommon,
        showSearchInput,
        onSearchValueChange,
        list,
        masterId,
        onShowGroupModal,
        memberNum,
        userInfoId,
        delMember,
        getConfigEdite,
        typeMsg,
        groupInfo,
        user_status,
        userIni,
        handleCancelSearch,
        ifSearching,
        hasMoreData,
        searchGroupUser
    };
    const bottomProps = {
        onFixtop,
        onNodisturb,
        disnotice,
        isTop,
        quitGroupBtn,
        goManagement,
        getRule,
        list,
        typeMsg,
        groupInfo,
        user_status,
        userIni,
        isAddress,
        chatRecord,
        quitSquadBtn,
        onMachineTranslation,
        isTranslation,
    };
    const max = typeMsg && typeMsg.type === 'squad' ? 50000 : 2000;
    const space = util.locale.getLang() === 'en-US' ? ' ' : '';
    const exitChartTile =
        typeMsg.type === 'setting'
            ? `${util.locale('im_exit')}${space}${typeMsg.value}${space}${util.locale('im_chat')}`
            : `${util.locale('im_exit')}${space}${typeMsg.value}`;
    let exitChartText = `${util.locale('im_confirm_whether_exit')}${space}${typeMsg.value}，${util.locale(
        'im_and_not_receive_this'
    )}${space}${typeMsg.value}${space}${util.locale('im_message')}。`;
    if (userIni.card) exitChartText = util.locale('im_sure_quit_group');
    return (
        <div className={css.box}>
            <SettingTop {...topProps} />
            <div className={css.main}>
                <SettingContent {...contentProps} />
                <SettingBottom {...bottomProps} />
            </div>
            <CommonModal
                modalVisible={delModalVisible}
                setOKModal={delOk}
                setonCancelModal={delCancel}
                modalContent={delText}
            />
            <CommonModal
                modalTile={util.locale('common_tip')}
                modalVisible={modalVisible}
                setOKModal={onToggleOwnerModal}
                setonCancelModal={onToggleOwnerModal}
                modalContent={util.locale('im_group_administrator_cannot_quit')}
                okButtonProps={{ style: { display: 'none' } }}
                cancelButtonProps={{ style: { backgroundColor: ' #326FEF', color: '#FFFFFF' } }}
                cancelText={util.locale('im_confirm')}
            />
            <CommonModal
                modalTile={exitChartTile}
                modalVisible={quitGroupModal}
                setOKModal={quitGroupOk}
                setonCancelModal={quitGroupCancel}
                modalContent={exitChartText}
            />
            <UserAdd
                squadMax={typeMsg && typeMsg.type === 'squad' ? max : false}
                show={userAddShow}
                onOk={userAddOk}
                onClose={userAddClose}
                disabledids={userAddDisids}
                leftTitle={util.locale('im_new_members')}
                title={util.locale('im_add_new_member')}
                type={'addMembers'}
                maxLength={Math.min(max - userAddDisids.length, max) + userAddDisids.length}
            />
        </div>
    );
}
