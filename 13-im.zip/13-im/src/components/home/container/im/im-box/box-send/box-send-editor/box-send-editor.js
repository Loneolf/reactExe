import React from 'react'
import css from './index.scss'
import * as util from '@u/util.js'
import { Editor } from 'draft-js'
import { Menu, Dropdown } from 'antd'

const blockRendererFn = block => {
    if (block.getType() == 'atomic') {
        return {
            component: mediaBlock,
            editable: false
        }
    }
}

const mediaBlock = props => {
    let entity = props.contentState.getEntity(props.block.getEntityAt(0))
    let data = entity.getData()
    let type = entity.getType().toLowerCase()
    let media = null

    if (type == 'image') media = <img className={css.img} src={data.imgurl || data.src} />
  
    return media || <span></span>
}

export default props => {

    const menuPasteDisable = props.menuType == 'image'
    const menuSaveDisable = props.menuType != 'image'

    const contextMenu = (
        <Menu className="contextMenuItem">
            <Menu.Item key="1" onClick={props.handleCopy}>{util.locale("im_copy")}</Menu.Item>
            <Menu.Item key="2" onClick={props.handlePaste} disabled={menuPasteDisable}>{util.locale("im_paste")}</Menu.Item>
            <Menu.Item key="3" onClick={props.handleSave} disabled={menuSaveDisable}>{util.locale("im_saveas")}</Menu.Item>
        </Menu>
    )

    // console.timeEnd('draft-update-render')
    // console.timeEnd('draft')

    return (
        <Dropdown
            overlay={contextMenu}
            trigger={['contextMenu']}
            onVisibleChange={(visible) => {}}
            getPopupContainer={()=> document.getElementById('sendBox')}>
            <div className={css.box} id='sendEditor' 
                onClick={props.handleClick} 
                onKeyDown={props.handleKeyDown}
                style={{'pointerEvents': props.loading ? 'none' : 'unset'}}
                // onCompositionStart={props.handleCompositionStart}
                // onCompositionUpdate={props.handleCompositonUpdate}
                // onCompositionEnd={props.handleComonCompositionEnd}
                onContextMenu={props.handleMenu}>
                <Editor 
                    placeholder={ props.disabled ? util.locale("im_banned_by_the_administrator") : util.locale("im_please_enter_content")}
                    ref={props.getDraftRef}
                    editorState={props.editorState} 
                    onChange={props.change} 
                    //blockRendererFn={blockRendererFn}
                    keyBindingFn={props.keyBindingFn}
                    handleKeyCommand={props.handleKeyCommand}
                    handlePastedText={props.handlePastedText}
                    handleBeforeInput={props.handleBeforeInput}
                    handleDroppedFiles = {props.handleDroppedFiles}
                />
                {/* <button onClick={props.consoleEntity}>Entity</button> */}
            </div>
        </Dropdown>
    )
}