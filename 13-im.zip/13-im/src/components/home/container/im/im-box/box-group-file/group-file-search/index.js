import React from 'react';
import {connect} from 'react-redux';

// util
import * as util from '@u/util.js';
import { debounce } from 'lodash';


// service
import { fileGroupSpaceList } from '@s/group/group-file';

// component
import FileSearch from './file-search';
import FileList from '../common/file-list/container';

import css from './index.scss';

// 查询组件
class Index extends React.Component {
    state = {
        searchValue: '',
        noData: 'ready_search',
        fileList: [],
        hasMore: false,
        currentPage: 0,
        loading: false,
    };

    componentDidMount() {
        window.addEventListener('keydown', this.closeSlideCard);
    }

    componentWillUnmount() {
        window.removeEventListener('keydown', this.closeSlideCard);
    }

    // 监听按键 esc
    closeSlideCard = (ev) => {
        let code = ev.keyCode;
        if (code === 27) {
            //触发esc
            if (this.state.searchValue) {
                this.setState({
                    searchValue: '',
                    noData: 'ready_search',
                    fileList: [],
                    hasMore: false,
                    currentPage: 0,
                    loading: false,
                });
            } else {
                // 退出搜索状态
                this.props.hanleGoList();
            }
        }
    };

    // 搜索结果高亮
    searchHighlighted = (searchData, searchKye) => {
        if (!searchKye) return searchData;
        const regExp = new RegExp(searchKye.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1'), 'ig');
        return searchData.map((item) => {
            item.showFileName = item.fileName.replace(regExp, `<span style="color:#286CFB;">${searchKye}</span>`);
            item.userInfo = { ...item.userInfo };
            return item;
        });
    };

    // 查询操作
    getFileList = async (loadMore = false) => {
        this.setState({ loading: true });
        const { id } = window.session_active;
        const { searchValue, currentPage, fileList } = this.state;

        if(!searchValue.trim()){
            // 清空搜索项
            this.setState({
                noData: 'ready_search',
                fileList: [],
                hasMore: false,
                currentPage: 0,
                loading: false,
            })
            return;
        }

        const page=loadMore?currentPage+1:1;
        let formData = {
            group_tid: id,
            page,
            size: 20,
            query_str: searchValue,
        };

        const datas = await fileGroupSpaceList(formData);
        const { code, obj:{data} } = datas || {};
        let resArr = [];
        if(code==170001) {
            message.warn(this.locale('im_group_folder_delete'));
            this.handleAnyFolder(0);
            return;
        }
        if (code === 200) {
            // 高亮匹配
            resArr = this.searchHighlighted(data, searchValue);
            // 下载状态 
            resArr = util.cosfiles.fileDownloadStatusGetArr(resArr);
        }
        const arr = loadMore ? [...fileList, ...resArr] : resArr;
        this.setState({
            fileList: arr,
            currentPage: page,
            loading: false,
            hasMore: resArr.length === 20,
            noData: arr.length ?"": 'not_find'
        });
    };

    handleLoadMore = () => {
        this.getFileList(true);
    };

    handleSearch = debounce(
        () => {
            this.getFileList();
        },
        400
    );
    

    handleInputChange = (value) => {
        this.setState({
            searchValue: value,
        },this.handleSearch);
    };

    // 清空搜索项，且保持聚焦
    handleClear=()=>{
        this.setState({
            searchValue:'',
            noData: 'ready_search',
            fileList: [],
            hasMore: false,
            currentPage: 0,
            loading: false,
        })
        document.getElementById('fileSearchInput').focus();
    }

    // 重置msg状态
    resetLocalMsgState = ({relation_id, path}) => {
        const fileList = this.state.fileList.map((item) => {
            if (item.relation_id == relation_id) item.downloadPath = path;
            return item;
        });
        this.setState({
            fileList,
        });

        util.cosfiles.fileDownloadStatusUpdate({path,key:relation_id});
    };

    // 下一级
    handleNextFolder= async ({relation_id,fileName})=>{
        // todo: 处理
        this.props.hanleGoList({relation_id});
        util.cosfiles.goFloderPreview({relation_id,fileName})
    }

    render() {
        const { searchValue,noData,hasMore,loading,fileList } = this.state;
        const {hanleGoList}=this.props;
       
        const  FileSearchProps={
            searchValue,
            leftIconClick:hanleGoList,
            handleInputChange:this.handleInputChange,
            handleClear:this.handleClear
        }
        const FileListProps={
            noData,
            fileList,
            hasMore,
            loading,
            handleLoadMore:this.handleLoadMore,
            closedDownLoad:this.closedDownLoad,
            handleNextFolder:this.handleNextFolder,
            resetLocalMsgState:this.resetLocalMsgState,
            type:'search'
        }
        return (
            <div className={css.box}>
                <FileSearch {...FileSearchProps}/> 
                <FileList {...FileListProps} />
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        // sessionActive: state.sessionActive,
    };
};

export default connect(mapStateToProps, null)(Index);
