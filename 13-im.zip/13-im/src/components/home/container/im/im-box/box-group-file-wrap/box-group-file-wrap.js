import React, { useState, useEffect } from 'react';
import {connect} from 'react-redux';
import * as util from '@u/util.js';

import { Tabs } from 'antd';
const { TabPane } = Tabs;

import css from './index.scss';

// redux
import {hideSlideModal} from '@/redux/actions/commonModal';
import BoxGroupDocumentContainer from '@/components/home/container/im/im-box/box-group-document/box-group-document-container';
import BoxGroupFileContainer from '@/components/home/container/im/im-box/box-group-file/box-group-file';

function BoxGroupFileWrap(props) {
    const {slideModal:{
      name,params
    }}=props;
    const [activeKey,setActiveKey] = useState('1')
    const [typeName,setTypeName] = useState(name)
    useEffect(() => {
        
    }, []);

    
    const hiddenModal = () => {
      props.dispatch(hideSlideModal());
    }
    const tapChange = (key) => {
      setActiveKey(key)
    }
    return (
      <div className={css.boxGroupFileBox}>
        <span
          className="iconfont-yach yach-quanju-qunshezhi-guanbiqunshezhi"
          onClick={() => hiddenModal()}
        ></span>
        <Tabs activeKey={activeKey} onChange={tapChange} tabBarGutte='1'>
          <TabPane tab={util.locale('im_files')} key='1'>
              {activeKey == 1 && <BoxGroupFileContainer hiddenModal={hiddenModal} getFileParams={params}/>}
          </TabPane>
          <TabPane tab={util.locale('im_group_file_online_document')} key='2'>
              {activeKey == 2 && <BoxGroupDocumentContainer  hiddenModal={hiddenModal} typeName = {typeName} />}
          </TabPane>
        </Tabs>
      </div>
    );
};

const mapStateToProps = state => {
  return {
      
  };
};

export default connect(
  mapStateToProps,
)(BoxGroupFileWrap);
