import React from 'react';
import { Tooltip } from 'antd';

import css from './index.scss';

import moment from 'moment';

import * as util from '@u/util.js';

import BoxContentMessage from '../box-content/box-content-list/box-content-message/box-content-message';

import VoiceRead from '../box-content/box-content-list/box-content-message/box-content-message-audio/box-content-message-audio';

import BoxContentMessageCustomContainer from '../box-content/box-content-list/box-content-message/box-content-message-custom/box-content-message-custom-container';

export default class BoxHistoricalRecord extends React.Component {
    constructor(props) {
        super(props);
    }

    // url 过滤
    textMessage = () => {
        let text = this.props.text;
        if (this.props.custom) text = util.yach.atHighlighted(text, this.props.custom);
        text = util.yach.textFiltering(text);

        let _html = util.yach.convertExpression(text, '34px', '34px');

        return (
            <div className={css.contentText}>
                <pre
                    dangerouslySetInnerHTML={{
                        __html: _html,
                    }}
                />
            </div>
        );
    };

    // imgMessage
    imgMessage() {
        const { file = {}, showImg, time } = this.props;
        const fileUrl = `${file.url}`;
        const url =
            fileUrl && fileUrl.indexOf('createTime') > 0
                ? `${fileUrl}&imageView`
                : `${fileUrl}?imageView&createTime=${time}`;

        return (
            <div className={css.content}>
                <a onClick={() => showImg(url)}>
                    <img
                        style={{ maxHeight: '200px', maxWidth: '200px' }}
                        src={fileUrl}
                        alt={util.locale('im_image_lost')}
                        onContextMenu={(e) => e.preventDefault()}
                    />
                </a>
            </div>
        );
    }

    // fileMessage
    fileMessage(iconFontClass, jcontent, jext) {
        const { file = {}, idClient, isDownload, openFile, fileDownload } = this.props;

        // flag
        let iscosVideo = false;
        jcontent && (iscosVideo = true);

        let relationId = iscosVideo ? jcontent.data.relationId : file.relationId;

        const imgAddress = require(`@a/imgs/modelFileType/${iconFontClass}.svg`);

        let isDownloadFlag = false;
        const downloadPath=util.cosfiles.fileDownloadStatusGet(relationId);
        if (downloadPath) isDownloadFlag = true;

        if (this.props.againDownload) isDownloadFlag = false;

        const filePath =
            this.props.filePath || downloadPath;

        let fileUrl = iscosVideo ? jcontent.data.fileUrl : file && file.url ? file.url : '';
        let csize = iscosVideo ? jcontent.data.fileSize : file.size;
        let cdur = iscosVideo ? jcontent.data.dur : file.dur || file.duration;
        let fileName = iscosVideo ? jcontent.data.fileName : file.name;
        let fileExt = iscosVideo ? jext : file.ext;


        let exte = '';

        if (file.ext) exte = `.${fileExt}`;

        const hrefs =
            fileUrl.indexOf('?') > 0
                ? fileUrl + '&download=' + encodeURIComponent(file.name)
                : fileUrl + '?download=' + encodeURIComponent(file.name) + '.' + exte;
        return (
            <div className={css.contentFile}>
                <div className={css.svgContent}>
                    <img src={imgAddress} className={css.file_svg} />
                </div>
                <div className={css.fileContent}>
                    <span className={css.fileName}>{fileName}</span>
                    <span className={css.fileSize}>{util.yach.getFileSize(csize)}</span>
                </div>
                <div className={css.operate}>
                    <Tooltip
                        placement="top"
                        title={isDownloadFlag || isDownload ? util.locale('im_open') : util.locale('im_download')}
                    >
                        {isDownloadFlag || isDownload ? (
                            <a onClick={() => openFile({path:filePath, idClient,relation_id:relationId})}>
                                <span
                                    className={`${css.download} iconfont-yach yach-zaixianwendang-dakaiwendangicon`}
                                />
                            </a>
                        ) : (
                            // <a onClick={() => fileDownload(hrefs, idClient, fileName, fileExt)}>
                            <a onClick={() => fileDownload(hrefs, idClient, fileName, fileExt,relationId)}>
                                <span className={`${css.download} iconfont-yach yach-kapian-wenjian-xiazai-moren`} />
                            </a>
                        )}
                    </Tooltip>
                </div>
            </div>
        );
    }

    // video fileMessage
    fileMessageVideo(iconFontClass, jcontent, jext) {
        // flag
        let iscosVideo = false;
        jcontent && (iscosVideo = true);

        let relationId = iscosVideo ? jcontent.data.relationId : file.relationId;

        // bg pic
        //const imgAddress = require(`@a/imgs/modelFileType/${iconFontClass}.svg`)
        let pic = this.props.avatar;
        let newPic = this.props.sessitonActivePic && this.props.sessitonActivePic[this.props.id];
        if (newPic && newPic !== this.props.avatar) pic = newPic;

        const downloadPath=util.cosfiles.fileDownloadStatusGet(relationId);

        // download
        let isDownloadFlag = false,
            downloadstatus = false;
        if (downloadPath) isDownloadFlag = true;
        if (this.props.againDownload) isDownloadFlag = false;
        const filePath =downloadPath;

        // arg
        const { file = {}, idClient, isDownload, openFile, fileDownload } = this.props;
        let fileUrl = iscosVideo ? jcontent.data.fileUrl : file && file.url ? file.url : '';
        let csize = iscosVideo ? jcontent.data.fileSize : file.size;
        let cdur = iscosVideo ? jcontent.data.dur : file.dur || file.duration;
        let fileName = iscosVideo ? jcontent.data.fileName : file.name;
        let fileExt = iscosVideo ? jext : file.ext;
        let coverUrl = iscosVideo ? jcontent.data.coverUrl : file.coverUrl;
        let taskId = iscosVideo ? jcontent.data.taskId : file.taskId;

        // style
        const videoWrapStyle = util.videoUtil.getStyle(iscosVideo ? jcontent.data : file);
        const thisStyle = util.videoUtil.getStyle(iscosVideo ? jcontent.data : file);
        if (videoWrapStyle.width < 140) videoWrapStyle.width = 140;
        if (videoWrapStyle.height < 140) videoWrapStyle.height = 140;
        const videoNoRadius = videoWrapStyle.width != thisStyle.width || videoWrapStyle.height != thisStyle.height;

        return (
            <div
                className={`${css.contentFile} ${css.videoWrap} ${coverUrl ? css.videoWrapBackground : ''}`}
                style={videoWrapStyle}
            >
                {coverUrl ? (
                    <img src={coverUrl} alt="" className={css.coverUrl} />
                ) : (
                    <div className={css.videPosition} style={thisStyle}>
                        <video
                            className={`${css.video} ${videoNoRadius ? css.videoNoRadius : ''}`}
                            preload="meta"
                            style={thisStyle}
                        >
                            <source src={fileUrl} type="video/mp4" />
                        </video>
                    </div>
                )}
                <div className={css.videoFileContent}>
                    <span>{util.yach.getFileSize(csize)}</span>
                    <span className={css.videoTime}>{util.videoUtil.getVideoTime(cdur)}</span>
                </div>
                <div
                    className={css.videoPlayWrap}
                    onClick={() =>
                        this.props.clickVideo({
                            fileUrl,
                            idClient,
                            fileName,
                            fileExt,
                            isdownloading: !!downloadstatus,
                            fileSize: util.yach.getFileSize(csize),
                            filePath,
                            fileDur: cdur,
                            msg: this.props.msg || this.props.itemValue,
                            isDownloadFlag,
                            pic,
                            taskId,
                            relationId,
                            coverUrl,
                            csize,
                            width: util.videoUtil.getWH(iscosVideo ? jcontent.data : file).width,
                            height: util.videoUtil.getWH(iscosVideo ? jcontent.data : file).height,
                        })
                    }
                >
                    <p className={css.videoPlayInner}></p>
                </div>
            </div>
        );
    }

    // officeMessage
    officeMessage() {
        // const fileUrl = (this.props.file && this.props.file.url) ? this.props.file.url : '';
        const { file } = this.props;
        const fileUrl = file && file.url ? file.url : '';
        const fileName = file && file.name ? file.name : '';

        return (
            <div className={css.office}>
                <div className={css.fileContent}>
                    <div className={css.iconImg}>
                        <span className={css.icon} className="icon iconfont iconpdf" />
                    </div>
                    <div className={css.fileInfo}>
                        <span className={css.fileName}>{this.props.file.name}</span>
                        <span className={css.fileSize}>{util.yach.getFileSize(this.props.file.size)}</span>
                    </div>
                </div>
                <div className={css.download}>
                    <a onClick={() => this.props.showOffice(fileUrl, fileName)}>
                        <span className={css.icon} className="icon iconfont iconyulan" />
                        <span>{util.locale('im_preview')}</span>
                    </a>
                    <a
                        href={
                            fileUrl.indexOf('?') > 0
                                ? this.props.file.url + '&download=' + this.props.file.name
                                : this.props.file.url + '?download=' + this.props.file.name + '.' + this.props.file.ext
                        }
                    >
                        <span className={css.icon} className="icon iconfont iconxiazai" />
                        <span>{util.locale('im_download')}</span>
                    </a>
                </div>
            </div>
        );
    }

    // customMessage
    customMessage() {
        return (
            <div className={css.custom}>
                <BoxContentMessageCustomContainer isMultiSelect={true} {...this.props} />
            </div>
        );
    }

    audioMessage() {
        let { flow, idClient, file } = this.props;
        if (typeof file == 'string') {
            try {
                file = JSON.parse(file);
            } catch (error) {}
        }

        let audioLength = `${this.computedAudioLength(file.dur / 1000)}px`;

        return (
            <div className={css.voiceRead}>
                <div className={css.voiceReadContent}>
                    <VoiceRead
                        idClient={`${idClient}_historical`}
                        flow={flow}
                        isTeam={true}
                        audioUrl={file.url}
                        audioDur={file.dur / 1000}
                        audioLength={audioLength}
                    />
                </div>
            </div>
        );
    }

    noDateMessage() {
        return <pre>【 {util.locale('im_unsupported_message_types')} 】</pre>;
    }

    // 计算语音长度
    computedAudioLength = (duration) => {
        let minLength = 170;
        let maxLength = 322;
        let time = Math.min(duration, 59);
        let length = minLength + ((time - 1) * (maxLength - minLength)) / 58;
        return length;
    };

    /*
     更改记录：屏蔽 下期见到可以删除
    */
    renderContent() {
        const { type, file = {}, content } = this.props;
        switch (type) {
            case 'text': {
                return this.textMessage();
            }
            case 'image': {
                return this.imgMessage();
            }
            case 'file': {
                return this.fileMessage('_other');
            }
            case 'video': {
                if (file.coverUrl) return this.fileMessageVideo('_video');
                if (['mp4', 'ogg', 'webm', 'mov'].includes(`${file.ext || ''}`.toLowerCase())) {
                    return this.fileMessageVideo('_video');
                } else {
                    return this.fileMessage('_video');
                }
            }
            case 'custom': {
                try {
                    const jcontent = util.nimUtil.getJson(content);
                    const jext = jcontent.data.ext || util.videoUtil.getFileExtendingName(jcontent.data.fileUrl);
                    if (jcontent.type === 30) {
                        if (jcontent.data.coverUrl) return this.fileMessageVideo('_video', jcontent, jext);
                        if (['mp4', 'ogg', 'webm', 'mov'].includes(jext.toLowerCase()))
                            return this.fileMessageVideo('_video', jcontent, jext);
                        return this.fileMessage('_video', jcontent, jext);
                    }
                    return this.customMessage();
                } catch (error) {}
            }
            case 'audio': {
                return this.audioMessage();
            }
            default: {
                return this.noDateMessage();
            }
        }
    }
    render() {
        return (
            <div className={css.boxItem}>
                <img
                    className={css.userImg}
                    src={this.props.avatar}
                    onClick={() => this.props.showUserinfo(this.props.id)}
                />
                <div className={css.renderContent}>
                    <div className={css.contentTitle}>
                        <p className={css.name}>{this.props.fromNick}</p>
                        <p className={css.time}>
                            {util.locale.getLang() === 'en-US'
                                ? moment(parseInt(this.props.time)).format('MM-DD HH:mm:ss')
                                : moment(parseInt(this.props.time)).format('MM月DD日 HH:mm:ss')}
                        </p>
                    </div>
                    {this.renderContent()}
                </div>
            </div>
        );
    }
}
