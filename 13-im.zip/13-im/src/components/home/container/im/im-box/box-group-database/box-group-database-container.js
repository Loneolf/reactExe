// react
import React from 'react';
// ImBox
import BoxGroupDatabase from './box-group-database';
// connect
import {connect} from 'react-redux';
// redux
import {hideSlideModal} from '@/redux/actions/commonModal';
import {slideSearchValue} from '@r/actions/slideSearchValue';
import {showSlideModal} from '@/redux/actions/commonModal';

// ImBoxContainer
class BoxGroupDatabaseContainer extends React.Component {
    state = {
        activeKey: '1'
    }

    componentDidMount(){
        const activeKey=this.props.slideModal.activeKey;
        if(!activeKey) return;
        this.setState({
            activeKey
        })
    }

    componentWillUnmount(){
        // 滑块消失时，搜索关键字置空
        window.store.dispatch(slideSearchValue(''));
    }

    tapChange = (key) => {
        // 搜索文件时，清空store 的getFileParams
        if(key==3) {
            const {name} =window.store.getState().slideModal;
            this.props.dispatch(showSlideModal('groupDatabase', {name}));
        }
        this.setState({activeKey: key});
    }

    hiddenModal = () => {
        this.props.dispatch(hideSlideModal());
        window.store.dispatch(slideSearchValue(''));
    }

    render() {
        const {name,params} = this.props.slideModal;
        return(
            <BoxGroupDatabase
                tapChange = {this.tapChange}
                hiddenModal = {this.hiddenModal}
                activeKey = {this.state.activeKey}
                typeName = {name}
                getFileParams={params}
             />
        )
    }
}

const mapStateToProps = state => {
    return {
        // sessionActive: state.sessionActive,
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxGroupDatabaseContainer);
