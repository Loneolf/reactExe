import React, { useState, useEffect, useCallback } from 'react';
import {connect} from 'react-redux';
import { Input, message } from 'antd';
import * as util from '@u/util.js';
import folder from '@a/imgs/doc_normal/dir.png';

import css from './index.scss';
import debounce from 'lodash/debounce';
import { groupFileCreateFolder, fileAndFolderHasDelete } from '@s/group/group-file';

function GroupFileInput(props) {
  const [isRename,setIsRename] = useState(props.isRename)//重命名
  const [defaultValue, setDefaultValue] = useState(props.defaultValue)//重命名
  const [fileName,setFileName] = useState('')
  const [msgTips,setMsgTips] = useState('')

  useEffect(() => {
  }, []);
  
  const handleOnChange = (e) => {
    e.stopPropagation();
    setMsgTips('')
    let text = e.target.value.trim();
    setFileName(text)
  };
  const inputFocus = () =>{
    const inputDom = document.querySelector('#groupFileCreateFolder')
    if(inputDom) inputDom.focus()
  }

  const handleKeyPress = (e) => {
      const keyCode = e.which || e.keyCode;
      if (keyCode === 27) handleCancel();
      if (keyCode === 13 && !fileName) handleCancel();
      if (keyCode === 13 && fileName) handleSure();
  };

  const handleSure = useCallback(debounce(() => {
    util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-244' });
    if (!fileName) return handleCancel();
    if(!!msgTips) return inputFocus();
    if(/[\%\@\.\/*?\:\<\>\“\|]/.test(fileName)){
      inputFocus()
      return setMsgTips(util.locale('im_group_file_input_msg_tip1'))
    }
    if(util.yach.checkStrNum(fileName, 120)) {
      inputFocus()
      return setMsgTips(util.locale('im_group_file_input_msg_tip3'))
    }
    if (isRename) {
      handleRenameFile();
    } else {
      //需要再次判断是否删除了父级文件夹
      judgeCanNewFolder()
    }
  }, 500),[fileName,isRename,msgTips]);

  const handleCancel = () => {
    if (isRename) {
      handleCloseInput();
    } else {
      util.eventBus.emit('group-file-create-input-show',false);
    }
    util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-245' });
  };

  const handleCreateFolder = async (relation_id) => {
      const { id } = window.session_active;
      const params = {
        name: fileName,
        parent_relation_id: relation_id || 0,
        receive_group_id: id,
      };
      const res = await groupFileCreateFolder(params);
      const { code, msg } = res;
      if(code == 180001){
        setMsgTips(util.locale('im_group_file_input_msg_tip2'))
        inputFocus()
        return
      }
      if (code != 200) return message.error(msg);
      handleCloseCreateInput()
  }

  const handleCloseCreateInput = () => {
    if(fileName) util.eventBus.emit('group-file-list-refresh');
    util.eventBus.emit('group-file-create-input-show',false);
  };
  const judgeCanNewFolder = async() =>{
    const { relation_id } = props.groupFileLastBreadcrumb
    if(relation_id){
      const res = await fileAndFolderHasDelete({relation_id})
      if(!res || res.code != 200 || !res.obj) {
        util.eventBus.emit('group-file-create-input-show',false);
        util.eventBus.emit('group-file-list-return-all')
        return
      }
      if(res.obj.result) {
        message.error(util.locale('im_group_file_judge_can_upload'))
        util.eventBus.emit('group-file-create-input-show',false);
        util.eventBus.emit('group-file-list-return-all')
        return
      }
    }
    handleCreateFolder(relation_id);
  }

  // 重命名的逻辑
  const handleRenameFile = async () => {
      
  };

  const handleCloseInput = (params = null) => {
      
  };

  return (
    <div className={css.createInputWrap} onClick={e => {e.stopPropagation();}}>
      <div className={css.inputInner}>
        <img src={folder} />
        <Input
          id="groupFileCreateFolder"
          autoFocus
          placeholder={util.locale('im_group_file_input_placeholder')}
          type="text"
          onKeyDown={handleKeyPress}
          onChange={handleOnChange}
          defaultValue={defaultValue}
        />
        <span onClick={ handleCancel} className={`${css.cancel} iconfont-yach yach-quxiao1`}></span>
        <span onClick={ handleSure} className={`${css.confirm} iconfont-yach yach-queren`}></span>
      </div>
      <div className={css.msgTip}>{msgTips}</div>
    </div>
  );
};

const mapStateToProps = state => {
  return {
    groupFileLastBreadcrumb: state.groupFileLastBreadcrumb
  };
};

export default connect(
  mapStateToProps,
)(GroupFileInput);
