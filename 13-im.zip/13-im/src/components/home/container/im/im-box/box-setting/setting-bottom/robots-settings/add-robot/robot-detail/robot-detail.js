import React, { Component } from 'react';
import { connect } from 'react-redux';

import CommonNotice from './notice-common-robot';
import ChatRobotDetail from './chat-robot';

import style from './style.scss';

// 详情页容器, 方便以后扩展机器人大类
class RobotDetail extends Component {
    constructor(props) {
        super(props);
    }

    get detailContent() {
        const { item, detailType } = this.props;
        const isChatRobot = item.robot_type_id == 0 || item.type_id == 0;;
        if (isChatRobot) {
            return <ChatRobotDetail detailType={detailType} key={item.robot_id} item={item}></ChatRobotDetail>;
        } else {
            // 普通通知机器人/第三方
            return <CommonNotice detailType={detailType} key={item.robot_id} item={item}></CommonNotice>;
        }
    }

    render() {
        return <div className={style.robotDetail}>{this.detailContent}</div>;
    }
}
const mapStateToProps = (state, ownProps) => ({
    item: state.robots.selectedRobot || {}
});

export default connect(mapStateToProps, null)(RobotDetail);
