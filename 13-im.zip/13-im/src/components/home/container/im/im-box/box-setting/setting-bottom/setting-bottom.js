// react
import React from 'react';
import { connect } from 'react-redux';
// css
import css from './index.scss';
import { showSlideModal } from '@r/actions/commonModal';
// antd
import { Switch, Dropdown, Menu} from 'antd';

import * as util from '@/utils/util';
import { renderCustomMenu } from './../../../im-list/group-menu'

// 群聊  小组 

// BoxOperation
class SettingBottom extends React.Component {
 
    effectMenu = ()=>{
        // const { sessionActive } = window.store.getState();
        const sessionActive = window.session_active;
        const { typeMsg } = this.props;
        return(
            <Menu className={css.EffectMenuWrap} onClick={(e)=>util.yach.selectHandleClick(e,sessionActive.id)}>
                {renderCustomMenu(sessionActive.id, this.props.disnotice, typeMsg.type === 'squad' ? true : false)}
            </Menu>
        )
    }

    render() {
        const {
            typeMsg,
            disnotice,
            isTop,
            onFixtop,
            onNodisturb,
            quitGroupBtn,
            goManagement,
            getRule,
            teamCircleAdmin,
            isAddress,
            quitSquadBtn,
            onMachineTranslation,
            isTranslation,
            effectMode,
        } = this.props;

        const sessionActive = window.session_active;

        const card = teamCircleAdmin.card || 'common';
        const space = util.locale.getLang() === 'en-US' ? ' ' : '';

        const info = util.yach.checkTypeofSession(sessionActive.id);

        const groupName = util.locale(info.attr)? util.locale(info.attr): info.attr;

        return (
            <div className={css.bottomBox}>
                {typeMsg.type === 'setting' && getRule() && (
                    <div className={css.gtoupRules} onClick={goManagement}>
                        <span>{util.locale('im_group_management')}</span>
                        <div className={css.right}>
                            <span>{util.locale.getLang() !== 'en-US' && util.locale('im_set_PAB')}</span>
                            <span className={`${css.jiantou_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
                        </div>
                    </div>
                )}
                <div className={css.bottom} id="groupExit">
                    {
                        effectMode ? (
                            <Dropdown overlay={this.effectMenu()} 
                                trigger={['click']} 
                                overlayClassName={css.EffectMenuWrapBox}
                                getPopupContainer={() => document.getElementById('groupExit')}
                                placement="bottomRight"
                            >
                                <p className={css.exit}>
                                    <span>{util.locale('im_effect_mode_text_23')}</span>
                                    
                                    <span className={css.exitChBox}>
                                        <span className={css.groupName}>{groupName}</span>   
                                        <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`}></span>
                                    </span>
                                </p>
                            </Dropdown>
                        ) : null
                    } 

                    {
                        typeMsg.type === 'setting' ? (
                        <p onClick={this.props.openRobotSlide} className={css.exit}>
                            <span>{util.locale('im_group_assistant')}</span>
                            <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
                        </p>
                    ) : null}
                    {typeMsg.type === 'squad' && ['admin', 'owner'].includes(card) && (
                        <p onClick={this.props.openGroupSlide} className={css.exit}>
                            <span>{`${typeMsg.value}${util.locale.getLang() === 'en-US' ? ' ' : ''}${util.locale(
                                'im_manage'
                            )}`}</span>
                            <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
                        </p>
                    )}
                    {!isAddress && (
                        <>
                            <p>
                                <span>{util.locale('im_stick_to_top')}</span>
                                <Switch checked={isTop && true} onChange={onFixtop} />
                            </p>
                            {util.yach.showAutoTranslation() && (
                                <p className={css.autoTranslation}>
                                    <span>{util.locale('im_auto_translation')}</span>
                                    <Switch checked={!!isTranslation} onChange={onMachineTranslation} />
                                </p>
                            )}
                            {util.yach.showAutoTranslation() && (
                                <p className={css.autoTranslationMsg}>{util.locale('im_MWTPLA')}</p>
                            )}
                            <p>
                                <span>{util.locale('im_mute_notifications')}</span>
                                <Switch checked={disnotice} onChange={_.debounce((v)=>onNodisturb(v),300)} />
                            </p>
                        </>
                    )}
                    {typeMsg.type === 'setting' && typeMsg.groupType == 3 ? (
                        <p onClick={this.props.chatRecord} className={css.exit}>
                            <i>
                                <span>{util.locale('im_chat_history')}</span>
                                <span className={css.description}>{util.locale('im_GCHWT')}</span>
                            </i>
                            <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
                        </p>
                    ) : null}
                </div>
                {typeMsg.type === 'setting' ? (
                    <div className={css.exit} onClick={quitGroupBtn}>
                        <span>
                            {typeMsg.type === 'setting'
                                ? `${util.locale('im_exit')}${space}${typeMsg.value}${space}${util.locale('im_chat')}`
                                : `${util.locale('im_exit')}${space}${typeMsg.value}`}
                        </span>
                        <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
                    </div>
                ) : null}
                {typeMsg.type === 'squad' &&
                    ['admin', 'common'].includes(card) &&
                    teamCircleAdmin &&
                    !teamCircleAdmin.exit_open && (
                        <div className={css.exit} onClick={quitSquadBtn}>
                            <span>{util.locale('im_quit_the_group')}</span>
                            <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
                        </div>
                    )}
            </div>
        );
    }
}

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        openRobotSlide: () => dispatch(showSlideModal('robots')), //打开机器人设置侧边栏
        openGroupSlide: () => dispatch(showSlideModal('groupManagement')),
    };
};

const mapStateToProps = (state) => {
    return {
        // sessionActive       : state.sessionActive,
        teamCircleAdmin     : state.teamCircleAdmin,
        effectMode          : state.effectMode,
        effectlist          : state.effectInterfaceDate
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(SettingBottom);
