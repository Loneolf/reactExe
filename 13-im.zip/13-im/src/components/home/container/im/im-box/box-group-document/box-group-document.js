// react
import React from 'react';
// util
import * as util from '@u/util.js';
// css
import css from './index.scss';
import BoxGroupDocumentListContainer from '../box-group-document-list/box-group-document-list-container';
// components
import GroupDocSearchContainer from './group-doc-search/group-doc-search-container';
// antd
import { Menu, Dropdown, Button, Input } from 'antd';
// imgs
import wordImg from '@a/imgs/doc_create/word.png';
import excelImg from '@a/imgs/doc_create/excel.png';
import dirImg from '@a/imgs/doc_create/dir.png';
import formImg from '@a/imgs/doc_create/form.png';
import mindImg from '@a/imgs/doc_create/mind.png';
import pptImg from '@a/imgs/doc_create/ppt.png';

export default class BoxGroupDocument extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let {
            handleSearch,
            handleCreateBtn,
            handleMenuClick,
            isSearch
        } = this.props;

        const docMenu = (
            <Menu
                onClick={(e) => {
                    handleMenuClick(e);
                }}
                className={css.dropdown_menu}
            >
                <Menu.Item key="newdoc">
                    <img src={wordImg} />
                    {util.locale('im_group_doc_docs')}
                </Menu.Item>
                <Menu.Item key="mosheet">
                    <img src={excelImg} />
                    {util.locale('im_group_doc_sheets')}
                </Menu.Item>
                <Menu.Item key="slide">
                    <img src={pptImg} />
                    {util.locale('im_group_doc_slides')}
                </Menu.Item>
                <Menu.Item key="mindmap">
                    <img src={mindImg} />
                    {util.locale('im_group_doc_mind')}
                </Menu.Item>
                <Menu.Item key="form">
                    <img src={formImg} />
                    {util.locale('im_group_doc_forms')}
                </Menu.Item>
                <Menu.Item key="folder">
                    <img src={dirImg} />
                    {util.locale('im_group_doc_folders')}
                </Menu.Item>
            </Menu>
        );
        return (
            <div className={css.box}>
                {util.yach.getGroupFileStatus() ? <span className={css.groupFileTips}>{util.locale('im_group_doc_desc')}</span> : <span className={css.tips}>{util.locale('im_group_doc_desc')}</span>}
                {isSearch ? (
                    <GroupDocSearchContainer {...this.props} />
                ) : (
                    <>
                        <div className={css.boxCreate}>
                            <div className={css.searchBox}>
                                <Input
                                    placeholder={util.locale('im_group_doc_search')}
                                    prefix={
                                        <span
                                            className={`${css.input_icon} iconfont-yach yach-goutong-sousuoliaotianjilu`}
                                        />
                                    }
                                    readOnly
                                    onClick={handleSearch}
                                />
                                <Dropdown overlay={docMenu} trigger={['click']}>
                                    <Button className={css.new_create} onClick={handleCreateBtn}>
                                        {util.locale('im_group_doc_create')}
                                    </Button>
                                </Dropdown>
                            </div>
                        </div>
                        <BoxGroupDocumentListContainer {...this.props} />
                    </>
                )}
            </div>
        );
    }
}
