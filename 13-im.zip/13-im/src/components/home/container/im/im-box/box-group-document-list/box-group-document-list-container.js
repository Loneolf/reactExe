// react
import React from 'react';
// ImBox
import BoxGroupDocumentList from './box-group-document-list';
// connect
import {connect} from 'react-redux';
// util
import * as util from '@u/util.js';
// lodash
import debounce from 'lodash/debounce';
// antd
import { message } from 'antd';
// server
import { spaceFileDelete, shareDoc } from '@s/group/group-online-doc';

const pagesize = 20;
const page = 1;

// ImBoxContainer
class BoxGroupDocumentListContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            modalVisible: false,
            guid: '',
            currentGuid: '',
            defaultValue: '',
            showRenameInput: false,
            loading: false,
            showShareModal: false,
            shareGuid: ''
        }
    }

    componentDidMount(){
        this.toPre = debounce(this.toPre,300)
        this.toFirst = debounce(this.toFirst,300)
        this.toCurrent = debounce(this.toCurrent,300)
        this.share = debounce(this.share,300)
        this.rename = debounce(this.rename,300)
        this.delete = debounce(this.delete,300)
        this.openFile = debounce(this.openFile,300)
        util.eventBus.addListener('group-doc-rename-input', () => this.setState({showRenameInput: false}));
    }

    componentWillUnmount() {
        util.eventBus.removeListener('group-doc-rename-input');
    }

    toPre = async() => {
        const len = this.props.breadcrumbList.length
        if(len <= 2){
            this.toFirst()
            return
        }
        const item = this.props.breadcrumbList[len-2]
        this.props.refreshList({
            needFetch: true,
            group_id: this.props.sessionActive.id,
            folder: item.guid,
            guid: item.guid,
            page,
            pagesize,
            breadcrumbType:'del',
            name: item.name
        });
    }
    toFirst = async() => {
        this.props.refreshList({
            needFetch: true,
            group_id: this.props.sessionActive.id,
            page,
            pagesize,
            breadcrumbType:'delAll'
        });
    }
    toCurrent = async(item) => {
        this.props.refreshList({
            needFetch: true,
            group_id: this.props.sessionActive.id,
            folder: item.guid,
            guid: item.guid,
            page,
            pagesize,
            breadcrumbType:'del',
            name: item.name
        });
    }
    share = async(item) => {
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '01-218'});
        this.setState({showShareModal: true,shareGuid: item.guid})
    }
    rename = async(item) =>{
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '01-219'});
        this.setState({
            currentGuid: item.guid, 
            defaultValue: item.name || item.replaceName, 
            showRenameInput: true
        });
    }
    delete = async(item) =>{
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '01-217'});
        this.setState({
            modalVisible: true, 
            guid: item.guid
        })
    }

    // 确定
    setOKModal = async () => {
        this.setState({modalVisible: false});
        const {id} = this.props.sessionActive;
        const {isSearch} = this.props;
        const params = {
          group_id: id,
          guid: this.state.guid
        }
        const res = await spaceFileDelete(params);
  
        const {code, msg} = res || {};
        if (code !== 200) message.error(msg);
        if (code === 200) {
            message.success(util.locale('remind_toast_delete_success'));
            const data = {guid: this.state.guid, isRename: false}
            if (isSearch) this.props.refreshSearchList(data);
            if (!isSearch) this.props.refreshList(data);
        }
      }
  
    // 取消
    setonCancelModal = () => {
        this.setState({modalVisible: false})
    }

    openFile = (item) =>{
        this.sensorsData(item.type);
        if(item.type == 'folder'){
            util.eventBus.emit('group-doc-search', 'back');
            //如果是文件夹，请求列表
            this.props.refreshList({
                needFetch: true,
                group_id: this.props.sessionActive.id,
                folder: item.guid,
                guid: item.guid,
                page,
                pagesize,
                breadcrumbType:'add',
                name: item.name,
                path: item.path
            });
            return
        }
        let data = {};
        data.title = item.name
        data.sessionActive = this.props.sessionActive
        data.link = item.link
        util.summaryUtil.goDocument(data)
    }
    getUsers = async(value) => {
        this.setState({loading: true});
        let { teams,teamids,users } = value;
        let userIds = []
        if(Array.isArray(users)){
            users.forEach(item => {
                userIds.push(`${item.id}`)
            })
        }
        if(!Array.isArray(teamids)) teamids = []
        if(!Array.isArray(teamids)) teams = []
        // 只拿回针对群组的判断
        if(teams.length == 1){
            const vote = await this.forwardVoteCheck(teams);
            if(!vote){
                message.error(util.locale("im_failed_forward_goup_has_been_Muted"));
                this.setState({loading: false});
            }
        }
        //组合请求接口的数据
        const res = await shareDoc({
            receiver: JSON.stringify({
                userId: userIds,
                groupId: teamids
            }),
            guid: this.state.shareGuid
        })
        if(res && res.code == 200) this.shareOver();
    };
    closeGetUser = async () => {
        this.setState({showShareModal: false, loading: false})
    };
    
   forwardVoteCheck = async (arr)=>{
        /*
        转发权限判断
        */
        try{
            return await util.yach.msgForwardingVoteCheck(arr);
        }catch(e){
            console.log('forwardVoteCheck',e);
        }
    }
    shareOver =  () => {
        message.success(util.locale("im_forward_successfully"));
        this.setState({showShareModal: false, loading: false});        
    };

    sensorsData = (key) => {
        switch (key) {
            case 'newdoc':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-101'});
                break;
            case 'mosheet':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-102'});
                break;
            case 'slide':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-103'});
                break;
            case 'mindmap':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-105'});
                break;
            case 'form':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-104'});
                break;
            case 'folder':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-106'});
                break;
            default:
                break;
        }
    }

    handleCalcStrLen = (sString) => {
        let j = 0;
        let s = sString;
        if (!s) return j;
        for (let i=0; i<s.length; i++){
            if (s.substr(i,1).charCodeAt(0)>255) j = j + 2;
            else j++
        }
        return j;
    }
    handleWidth = (item) => {
        const { type, creator_id } = item
        const {ismanager,userInfo = {}} = this.props
        let str = ''
        if(type == 'folder'){
            if( ismanager || userInfo.id == creator_id){
                str = 'textTopTwo'
            }else{
                str = 'textTopZero'
            }
        }else{
            if( ismanager || userInfo.id == creator_id){
                str = 'textTopThree'
            }else{
                str = 'textTopOne'
            }
        }
        return str
    }

    render() {
        const shareProps = {
            type: "forward",
            placeholder: util.locale("im_search_contact/group"),
            loading: this.state.loading,
            show: this.state.showShareModal,
            onOk: this.getUsers,
            onClose: this.closeGetUser,
            title: util.locale("im_forward_message"),
            rightTitle: util.locale("im_recent_contact"),
            showButtonNumber: true,
            disabledids: [-1, -2],
            maxLength: 50 + 2,
            noNeedLeaveWord: true
        };
        const props = {
            ...this.state,
            ...this.props,
            toPre: this.toPre,
            toFirst: this.toFirst,
            toCurrent: this.toCurrent,
            share: this.share,
            rename: this.rename,
            delete: this.delete,
            setOKModal: this.setOKModal,
            setonCancelModal: this.setonCancelModal,
            openFile: this.openFile,
            handleCalcStrLen: this.handleCalcStrLen,
            shareProps,
            handleWidth: this.handleWidth
        }
        return(
            <BoxGroupDocumentList {...props}/>
        )
    }
}

const mapStateToProps = state => {
    return {
        sessionActive: state.sessionActive,
        ismanager: state.groupAll.ismanager,
        userInfo: state.userInfo
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxGroupDocumentListContainer);
