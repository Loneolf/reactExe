import React, { PureComponent } from 'react';

import style from './style.scss';

// 机器人卡片组件, 侧边栏和弹框内尺寸稍有不同
class RobotCard extends PureComponent {
    constructor(props) {
        super(props);
    }
    render() {
        const { item, onClick, className, showArrow } = this.props;
        return (
            <div onClick={onClick} key={item.robot_id} className={`${style.robotCard} ${className}`}>
                <div className={style.left}>
                    <img className={style.avatar} src={item.robot_icon_bigger} alt="" />
                    <div>
                        <div className={style.name}>{item.name}</div>
                        <div className={style.desc}>{item.robot_desc}</div>
                    </div>
                </div>
                {showArrow ? (
                    <span
                        style={{ fontSize: '6px' }}
                        className="iconfont-yach yach-qunshezhi-jiqiren-cehuatiaozhuantishi"
                    ></span>
                ) : null}
            </div>
        );
    }
}

export default RobotCard;
