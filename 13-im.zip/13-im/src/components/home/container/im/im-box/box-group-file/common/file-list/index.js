// react
import React from 'react';
import { Progress, Tooltip, Spin, Dropdown, Checkbox } from 'antd';
import InfiniteScroll from 'react-infinite-scroller';

// css
import css from './index.scss';

import * as util from '@u/util.js';
// imgs
import wordImg from '@a/imgs/modelFileType/word.svg';
import excelImg from '@a/imgs/modelFileType/excel.svg';
import pptImg from '@a/imgs/modelFileType/ppt.svg';
import pdfImg from '@a/imgs/modelFileType/pdf.svg';
import videoImg from '@a/imgs/modelFileType/video1.svg';
import otherImg from '@a/imgs/modelFileType/other.svg';
import dirImg from '@a/imgs/modelFileType/dir.svg';
import picImg from '@a/imgs/modelFileType/pic.svg';

import readySearch from '@a/imgs/online-doc-no-data.png';

import noImg from '@a/imgs/search-file-ready-search.png';

const genImg = (ext) => {
    const t = ext.toLowerCase();

    if (/folder/i.test(t)) return <img src={dirImg} />;
    if (/doc|docx/i.test(t)) return <img src={wordImg} />;
    if (/xls|xlsx/i.test(t)) return <img src={excelImg} />;
    if (/pptx|ppt/i.test(t)) return <img src={pptImg} />;
    if (/pdf/i.test(t)) return <img src={pdfImg} />;
    if (/png|jpg|bmp|jpeg|gif|svg|wmf|jpe|ico|pic|tiff|pjpeg|jfif|pjp/i.test(t)) return <img src={picImg} />;
    if (/wmv|asf|asx|rm|rmvb|mp4|3gp|mov|m4v|avi|dat|mkv|flv|vob|rn-realmedia|mid/i.test(t))
        return <img src={videoImg} />;
    return <img src={otherImg} />;
};

const getNodata = (type) => {
    // ready_search  no_file not_find
    let imgurl = '',
        text = '',
        cssName = '';
    switch (type) {
        case 'ready_search':
            imgurl = readySearch;
            cssName = css.readySearch;
            text = util.locale('im_group_file_ready_search_all');
            break;
        case 'no_file':
            imgurl = noImg;
            text = util.locale('im_group_doc_no_file');
            cssName = css.readyImg;
            break;
        case 'not_find':
            imgurl = noImg;
            text = util.locale('im_no_search_files_found');
            cssName = css.readyImg;
            break;
    }
    return (
        <div className={`${css.noData} ${cssName}`}>
            <img src={imgurl} />
            <p>{text}</p>
        </div>
    );
};

const genItem = (item, props) => {
    const {
        is_dir,
        file_extension,
        showFileName,
        fileName='',
        time,
        userInfo,
        update_userinfo,
        relation_id,
        downloadPath,
        update_time,
        parent_py_name = '',
    } = item;
    const { fileDownloadProgress, closedDownLoad, handleBtnClick, ismanager,type, } = props;
    const fileDownloadProgressItem = fileDownloadProgress.filter((item) => item.id == relation_id)[0];
    let user = update_userinfo || userInfo || {};
    let name = user.name_nick || user.name || '';
    name = name.length < 4 ? name : name.slice(0, 3) + '...';

    return (
        <li key={relation_id} onClick={(e) => handleBtnClick(e, is_dir == 1 ? 'itemClick' : 'preview', item)}>
            <div className={css.item}>
                {genImg(file_extension)}
                <div className={css.content}>
                    {type === 'pageList' ? (
                        fileName.length > 10 ? (
                            <Tooltip title={fileName}>
                                <p
                                    className={css.title}
                                    dangerouslySetInnerHTML={{
                                        __html: showFileName || fileName,
                                    }}
                                />
                            </Tooltip>
                        ) : (
                            <p className={css.title} dangerouslySetInnerHTML={{ __html: showFileName || fileName }} />
                        )
                    ) : (
                        <Tooltip title={parent_py_name+'/'+fileName}>
                            <p
                                className={css.title}
                                dangerouslySetInnerHTML={{
                                    __html: showFileName || fileName,
                                }}
                            />
                        </Tooltip>
                    )}
                    <p className={css.info}>
                        {is_dir != 1 && <span className={css.userName}>{util.yach.getFileSize(item.size)}&nbsp;</span>}
                        <span>{name}</span>
                        &nbsp;
                        <span>{util.formatDate.weeklyTimeFormat(update_time || time, true)}</span>
                    </p>
                </div>
                <div className={css.btnWrap}>
                    <Tooltip title={util.locale('im_group_file_foward')}>
                        <span
                            onClick={(e) => handleBtnClick(e, 'share', item)}
                            className="iconfont-yach yach-zhuanfa1"
                        />
                    </Tooltip>
                    {downloadPath ? (
                        <Tooltip title={util.locale('im_open')}>
                            <span
                                onClick={(e) => handleBtnClick(e, 'open', item)}
                                className="iconfont-yach yach-dakaibendi"
                            />
                        </Tooltip>
                    ) : (
                        fileDownloadProgressItem?<Tooltip title={util.locale('im_download')}>
                        <span
                            style={{color:'#B8BBC1'}}
                            className="iconfont-yach yach-xiazai1"
                        />
                    </Tooltip>:<Tooltip title={util.locale('im_download')}>
                            <span
                                onClick={(e) => handleBtnClick(e, 'download', item)}
                                className="iconfont-yach yach-xiazai1"
                            />
                        </Tooltip>
                    )}
                    <div
                        onClick={(e) => {
                            e.stopPropagation();
                        }}
                    >
                        <Dropdown
                            getPopupContainer={() => document.getElementById('groupFileListOut')}
                            overlay={
                                <div className={css.dropdownOut}>
                                    {!!item.msgId ? (
                                        <span onClick={(e) => handleBtnClick(e, 'jump', item)}>
                                            {util.locale('common_cometo_view')}
                                        </span>
                                    ) : (
                                        <Tooltip placement="top" title={util.locale('im_group_file_no_msg')}>
                                            <span className={css.btnGray}>{util.locale('common_cometo_view')}</span>
                                        </Tooltip>
                                    )}
                                    {ismanager || (!!userInfo && userInfo.id == util.yach.getAccount()) ? (
                                        <span
                                            className={css.deleteBtn}
                                            onMouseUp={(e) => handleBtnClick(e, 'delete', item)}
                                        >
                                            {util.locale('im_group_doc_del')}
                                        </span>
                                    ) : (
                                        <Tooltip placement="top" title={util.locale('im_group_file_no_role_delete')}>
                                            <span className={css.btnGray}>{util.locale('im_group_doc_del')}</span>
                                        </Tooltip>
                                    )}
                                </div>
                            }
                            trigger={['click']}
                        >
                            <span className="iconfont-yach yach-wenjian-gengduocaozuo" />
                        </Dropdown>
                    </div>
                </div>
            </div>
            {fileDownloadProgressItem && (
                <div className={css.progress}>
                    <Progress percent={fileDownloadProgressItem['percent']} size="small" showInfo={false} />
                    <div className={css.showInfo}>
                        <span className={css.speed}>{fileDownloadProgressItem['speed']}</span>
                        <Tooltip title={util.locale('im_file_download_cancel')}>
                            <span
                                onClick={(e) => {
                                    closedDownLoad(e, item, fileDownloadProgressItem['channelid']);
                                }}
                                className="iconfont-yach yach-0428_richengxiangqing-chuangjianricheng-fujianshangchuanzhongzhi"
                            ></span>
                        </Tooltip>
                    </div>
                </div>
            )}
        </li>
    );
};

export default (props) => {
    const { noData, fileList, hasMore, loading, delLoading, handleLoadMore, type, checkedId, handleCheckboxChange } = props;
    return (
        <>
            {loading && (
                <div className={css.loading}>
                    <Spin />
                </div>
            )}
            {delLoading && (
                <div className={`${css.delLoading}`}>
                    <Spin />
                </div>
            )}
            {!noData ? (
                <ul className={css.out} id="groupFileListOut">
                    {fileList && fileList.length > 0 && (
                        <InfiniteScroll
                            initialLoad={true}
                            pageStart={0}
                            loadMore={handleLoadMore}
                            hasMore={!loading && hasMore}
                            useWindow={false}
                        >
                            {type === 'pageList' ? (
                                <Checkbox.Group
                                    style={{ width: '100%' }}
                                    value={checkedId}
                                    onChange={handleCheckboxChange}
                                >
                                    {fileList.map((item) => {
                                        return (
                                            <div className={css.itemOut}>
                                                <Checkbox value={item.relation_id}></Checkbox>
                                                {genItem(item, props)}
                                            </div>
                                        );
                                    })}
                                </Checkbox.Group>
                            ) : (
                                fileList.map((item) => <div className={css.itemOut}>{genItem(item, props)}</div>)
                            )}
                        </InfiniteScroll>
                    )}
                </ul>
            ) : (
                getNodata(noData)
            )}
        </>
    );
};
