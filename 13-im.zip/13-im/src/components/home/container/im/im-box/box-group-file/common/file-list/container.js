// react
import React from 'react';
// connect
import { connect } from 'react-redux';
// redux
import * as fileRedux from '@/redux/actions/file';

// server
import { fileView } from '@s/file/file-info';
import { fileAndFolderDelete } from '@s/group/group-file';
// antd
import { message } from 'antd';

// util
import * as util from '@u/util.js';
import {batchForward} from '@u/lib/tools/file-forward.js'

// components
import Index from './index';
import UserAdd from '@c/common/user-add/user-add-container';
import CommonModal from '@/components/common/common-modal';

const fileType = ['doc', 'docx', 'xls', 'xlsx', 'pptx', 'ppt', 'pdf'];
const videoType = ['wmv','asf','asx','rm','rmvb','mp4','3gp','mov','m4v','avi','dat','mkv','flv','vob','rn-realmedia','mid']
const imageType = ['png','jpg','bmp','jpeg','gif','svg','wmf','jpe','ico','pic','tiff','pjpeg','jfif','pjp']
// ImBoxContainer
class BoxSearchFileContainer extends React.Component {
    state={
        showShareModal:false,
        forwardLoading:false,
        activeItem:{},
        modalVisible: false,
        deleteItem: {}
    }
    
    handleBtnClick = (e, type, item) => {
        e.stopPropagation();
        if (type === 'jump') {
            this.handleSession(item.time, item.msgId);
            util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-252' });
        } else if (type === 'preview') {
            this.handlePreview(item);
        } else if (type === 'open') {
            this.handleOpen(item);
        } else if (type === 'download') {
            this.handleDownload(item);
            util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-251' });
        } else if (type === 'share') {
            util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-250' });
            this.handleShare(item);
        } else if (type==='delete'){
            // 删除文件
            this.handleDlete(item);
            util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-256' });
        } else if (type === 'itemClick') {
            // 文件夹下一级
            this.props.handleNextFolder(item);
        }
    };

    // 选人弹框关闭回调
    closegetUser = async () => {
        this.setState({showShareModal: false, forwardLoading: false})
    };

    // 转发副本
    handleShare=(item)=>{
        this.setState({
            showShareModal: true,
            activeItem:item
        })
    }
    
    // 选人弹框确定回调
    getUsers = async(value) => {
        this.setState({forwardLoading: true});

        // 调用转发
        batchForward({
            targetObj:value,
            fileObj:this.state.activeItem,
            type:'forward',
            modalFn:()=>{this.setState({showShareModal: false, forwardLoading: false})},
            loadingFn:()=>{this.setState({forwardLoading: false})}
        });
    };

    // 预览
    handlePreview = async (item) => {
        const file_extension = item.file_extension.toLowerCase()
        if (fileType.includes(file_extension)) {
            // let signurldata = await util.cosfiles.getCosSignUrl(item.fileUrl);
            // let url = signurldata.signurlpreview || item.fileUrl;

            let resurl = { signurlpreview: item.fileUrl };
            let param = {};
            let data = await fileView({relation_id:item.relation_id});

            if(!data || data.code !== 200 || !data.obj) return;

            // office
            if(Object.keys(data.obj.wps).length === 0){
                resurl.signurlpreview = data.obj.default.presignet_url_view;
                util.electronipc.electronOpenFilepreview({
                    file: resurl.signurlpreview,
                    name: item.fileName,
                })
                return;
            }

            // wps
            if( data.obj.wps.code == 0){
                resurl.signurlpreview = data.obj.wps.path;
            } else {
                const { fileInfo3rd,wpsUrl } = data.obj.wps.requestData
                resurl.signurlpreview = wpsUrl;
                param = fileInfo3rd;
            }

            util.electronipc.electronOpenFilepreview({
                file: resurl.signurlpreview,
                name: item.fileName,
                param
            })
        } else if(videoType.includes(file_extension)){
            //视频预览
            util.videoUtil.getTransCodeInfo(item)
        }else if(imageType.includes(file_extension)){
            //图片预览
            util.imageUtil.handleImagePreview(item)
        }else{
            message.info(util.locale('im_file_no_preview'));
        }
    };

    // handleOpen
    handleOpen = (item, event) => {
        const { is_dir, downloadPath } = item;
        const path=downloadPath||''
        
        if (!path) return;

        util.electronipc.electronCheckFile({ path }, (res) => {
            if (res) {
                is_dir == 1
                    ? util.electronipc.electronOpenDirectory({ path })
                    : util.electronipc.electronOpenFile({ path });
            } else {
                message.warning(`${util.locale('im_file_uoliad_dir_xxx_moved').replace('[xxx]', item.fileName)}`);
                
                this.props.resetLocalMsgState({path:null,relation_id:item.relation_id});
            }
        });
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: is_dir == 1 ? '01-259':'01-257' });
    };

    // 跳转回话
    handleSession = (time, idClient) => {
        util.yach.handleMessageJump(time * 1000, idClient);
    };

    // 下载
    handleDownload = async (item, event) => {
        
        let { fileUrl: url, fileName: name,relation_id,is_dir } = item;
        this.setState()
        util.cosfiles.fileDownload({idClient:relation_id,relationId:relation_id,url,name,stype:is_dir==1 ? 26:10,from:'slide',resBack:(path)=>{
            this.props.resetLocalMsgState({
                path,
                isDownloadFlag: true,
                msgId:item.msgId,
                relation_id:item.relation_id,
            }
            )
        }});
        this.props.handleCancelChecked([relation_id])
    };

    // 取消下载
    closedDownLoad = (e, item, channelid) => {
        e.stopPropagation();
        util.electronipc.electronDownloadFileDestory({ channelid });
        this.props.dispatch(fileRedux.fileDownloadProgressRemove(item.relation_id));
    };

    handleDlete = (item) => {
        setTimeout(()=>{
            //等待删除按钮组件消失
            this.setState({
                deleteItem: item,
                modalVisible: true
            })
        },300)
    }
    setOKModal = async() => {
        let res = await fileAndFolderDelete({
            relation_id: this.state.deleteItem.relation_id
        })
        if(res && res.code == 200){
            this.setState({
                modalVisible: false
            })
            util.eventBus.emit('group-file-list-refresh')
        }
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-261' });
    }
    setonCancelModal = () =>{
        this.setState({
            modalVisible: false
        })
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-262' });
    }
    
    render() {
        const {showShareModal,forwardLoading, modalVisible, deleteItem}=this.state;
        const { 
            searchValue,handleInputChange,handleLoadMore,fileList,noData,hasMore,loading,delLoading,slideSearch,fileDownloadProgress,type,
        } = this.props;
        const indexProps={
            searchValue,handleInputChange,handleLoadMore,fileList,noData,hasMore,loading,delLoading,fileDownloadProgress,slideSearch,type,
            handleBtnClick:this.handleBtnClick,
            closedDownLoad:this.closedDownLoad,
            checkedId:this.props.checkedId,
            handleCheckboxChange:this.props.handleCheckboxChange,
            ismanager: this.props.ismanager
        }
        const forwardMsgProps={
            type: "forward",
            placeholder: util.locale("im_search_contact/group"),
            loading: forwardLoading,
            show: showShareModal,
            onOk: this.getUsers,
            onClose: this.closegetUser,
            title: util.locale("im_forward_message"),
            rightTitle: util.locale("im_recent_contact"),
            showButtonNumber: true,
            disabledids: [-1, -2],
            maxLength: 50 + 2,
        }

        return (
            <>
                <Index {...indexProps} />
                <UserAdd {...forwardMsgProps} />
                <CommonModal
                    closable={true}
                    modalTile={util.locale('im_reminder')}
                    okText={util.locale('common_make_sure')}
                    cancelText={util.locale('common_cancel')}
                    modalVisible={modalVisible}
                    setOKModal={this.setOKModal}
                    setonCancelModal={this.setonCancelModal}
                    maskClosable={false}
                    modalContent={
                        <div>
                            <p>{util.locale(deleteItem.is_dir ==1 ? 'im_group_file_single_delete1': 'im_group_file_single_delete2').replace('[xxx]',` ${deleteItem.fileName} `)}</p>
                            <p className="confirm2">{util.locale(deleteItem.is_dir ==1 ? 'im_group_file_delete_confirm2': 'im_group_file_single_delete3')}</p>
                        </div>
                    }
                />
            </>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        fileDownloadProgress:state.fileDownloadProgress,
        ismanager: state.groupAll.ismanager
    };
};

export default connect(mapStateToProps, null)(BoxSearchFileContainer);
