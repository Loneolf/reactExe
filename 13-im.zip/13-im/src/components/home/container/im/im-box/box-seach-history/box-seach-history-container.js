// react
import React from 'react';
// ImBox
import BoxSeachHistory from './box-seach-history';
// connect
import {connect} from 'react-redux';
// util
import * as util from '@/utils/util';
// debounce
import debounce from 'lodash/debounce';
// redux
import {hideSlideModal} from '@/redux/actions/commonModal';
import {slideSearchValue} from '@r/actions/slideSearchValue';
// ImBoxContainer
class BoxSeachHistoryContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state={
        textList: [],
        noData: ''
    }

    componentDidMount(){
        this.getTextList(this.props.slideSearch || '')
        // this.getTextList = debounce(this.getTextList.bind(this, this.props.slideSearch || ''), 500);

        this.handleInputFocus()
        window.addEventListener('keydown', this.closeSlideCard)
    }

    componentWillUnmount() {
        window.removeEventListener('keydown', this.closeSlideCard)
    }

    // 1s后自动获焦点
    handleInputFocus = () => {
        let mesInput = document.getElementsByClassName('ant-input')[0]
        setTimeout(() => {
            mesInput.focus()
        },500)
    }
    // 监听按键 esc
    closeSlideCard = (ev) => {
        let code = ev.keyCode
        if (code === 27) { // 触发esc
            if (this.props.slideSearch) {
                window.store.dispatch(slideSearchValue(''));
                this.getTextList()
            } else {
                this.props.hiddenModal()
            }
        }
    }

    seachData = (value) => {
        this.getTextList(value.target.value)

        window.store.dispatch(slideSearchValue(value.target.value));
    }

    getTextList = async(seachData = '') => {
        if(!seachData) return this.setState({textList: [], noData: ''});
        let filterList= []
        // const { id, type } = this.props.sessionActive;
        const { id, type } = window.session_active;
        const messageTypeList = ['text', 'custom']
        const textList = await util.nimUtil.getLocalMsgs(type, '', id, undefined, 100, true, seachData, messageTypeList);
        if(!textList.msgs || textList.msgs.length == 0) {
            util.sensorsData.track('Load_SearchResult_ChatWindow', {
                source: 105,
                search_type: 104,
                chat_id: id
            });
            return this.setState({noData: util.locale("im_no_chat_history_about_keywords")})
        }else{
            util.sensorsData.track('Load_SearchResult_ChatWindow', {
                source: 105,
                search_type: 104,
                chat_id: id
            });
        }
        for (let element of textList.msgs) {
           const obj = await util.nim.genMsgItem(element);
           filterList.push(obj);
        }
        this.replaceKeyWord(filterList, seachData);
        this.setState({noData: ''});
    }

    replaceKeyWord = (filterList, searchKye) => {
        if (searchKye) {
            const regExp = new RegExp(searchKye.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1"), 'ig');
            filterList.filter((item) => {
                let text = item.text;
                let strIndex = text.indexOf(searchKye);
                let showPoint = false;
                if(strIndex && strIndex > 20) {
                    if(text.length - strIndex < 20){
                        text = text.slice(strIndex - 10);
                    }else{
                        text = text.slice(strIndex);
                    }
                    showPoint = true;
                }
                item.text = text.replace(
                    regExp,
                    `Tspan0 Tspan1Tspan2${searchKye}Tspan3`
                ); //进行替换，并定义高亮的样式
                item.text = util.yach.convertExpression(util.yach.textFiltering(item.text));
                if(showPoint) item.text = '...'+item.text;
            });
        }
        this.setState({textList: filterList});
    } 

    setIdClient = (idClient, time) => {
        util.yach.handleMessageJump(time, idClient);
    }

    keyDownhandle = e => {
        if(e.key !== 'Tab') return
        e.preventDefault();
    }

    render() {
        return(
            <BoxSeachHistory
                seachData={this.seachData}
                textList={this.state.textList}
                setIdClient={this.setIdClient}
                noData={this.state.noData}
                keyDownhandle = {this.keyDownhandle }
                slideSearch = {this.props.slideSearch}
             />
        )
    }
}

const mapStateToProps = state => {
    return {
        // sessionActive: state.sessionActive,
        messageList: state.messageList,
        slideSearch: state.slideSearch
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxSeachHistoryContainer);
