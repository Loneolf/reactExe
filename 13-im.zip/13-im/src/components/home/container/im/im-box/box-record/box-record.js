import React from 'react';

import css from './index.scss';
import * as util from '@u/util.js';


export default props => (
    <div className={css.box}>
        {!props.hasPower && (
            <div className={css.hasPower}>
                <div className={css.powerPic}></div>
                <div className={css.powerTxt}>{util.locale("im_weekly_no_view")}</div>
            </div>
        )}
    </div>
);
