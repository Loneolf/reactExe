import React from 'react';
import {connect} from 'react-redux';

//util
import * as util from '@u/util.js';

//redux
import * as messageListAction from '@r/actions/messageList';
import * as messageUploadAction from '@r/actions/messageListUploadState';

//components
import BoxContentMessageUpload from './box-content-message-upload';

//antd 
export class BoxContentMessageUploadContainer extends React.Component {
    constructor(props) {
        super(props);

    }
    componentDidUpdate = (pre) => {
        const {idClient, uploadFileState, } = this.props;
        const {idClient: preIdClient, uploadFileState: preUploadFileState} = pre;
        if(!uploadFileState[idClient]|| !preUploadFileState[preIdClient]) return;
    }
    
    delFakeMsg = async ()=>{
        const {uploadFileState, idClient} = this.props;
        const uploadData = uploadFileState[idClient] || {};

        const {status} = uploadData;
        const failShow = (status == 'uploadStart') || (status == 'uploadFail');
        if(failShow) return;
       
        if(!status && !failShow){
            try{
                const data = await util.nimUtil.getLocalMsgByIdClient(idClient);
                if(data && !data.msg){
                    util.log('qiuyanlong','yach-im','bingo','fakemsg ✅');
                    this.props.delByIdClient(idClient);
                }
            }catch(e){}
        }
    }


    deleteLocalCustomMessage = (params) => {
        this.props.delLocalMessage(params)
        let temlog = {
            status: params.status,
            progress:params.progress,
            msg: params.msg && params.msg.content 
        };
        util.log('qiuyanlong','yach-im','deleteLocalCustomMessage',JSON.stringify(temlog));
    }
    retry = () => {
        // const {msgObj, sessionActive} = this.props;
        const { msgObj } = this.props;
        const sessionActive = window.session_active;
        this.props.retryUpload({
            sessionActive,
            msgObj: msgObj.msg || msgObj
        });
        util.log('qiuyanlong','yach-im','file uoload:retry',JSON.stringify(msgObj.msg || msgObj));
    }
    getCustomData = () => {
        const content = util.nimUtil.getJson(this.props.content);
        const {type, data} = content;
        const {name, type: typeTxt, path, base64} = data;
        let message = {};
        let fileType = null;
        switch(type){
            case 5: //office
                fileType = util.yach.getFileType(name);
                message = {
                    fileType,
                    ...data
                }
            break;
            case 8:// 图片
                message = {
                    ...data
                }
            break;
            case 10:// other file
                fileType = util.yach.getFileType(name);
                if(typeTxt == 'video') fileType = '_video';
                message = {
                    fileType,
                    ...data
                }
            break;
            case 26:// other file
                message = {
                    fileType:'_dir',
                    ...data
                } 
            break;     
            case 30:// other file
                message = {
                    fileType:'_video',
                    ...data
                }       
            break;
        }
        return message
    }
    render = () =>{
        const {uploadFileState, idClient} = this.props;
        const customData = this.getCustomData();
        return (
            <BoxContentMessageUpload
                {...customData}
                retry = {this.retry}
                deleteLocalCustomMessage = {this.deleteLocalCustomMessage}
                uploadData = {uploadFileState[idClient] || {}}
            />
        )
    }
}
const mapDispatchToProps = {
    sendUploadMsg: messageListAction.uploadRequest,
    delByIdClient : messageListAction.delByIdClient,
    retryUpload: messageUploadAction.retryUpload,
    updateState: messageUploadAction.update,
    delLocalMessage: messageUploadAction.delLocalMessage
}
const mapStateToProps = state => {
    return {
        uploadFileState: state.uploadFile,
        // sessionActive: state.sessionActive,

    }
}
export default connect(mapStateToProps, mapDispatchToProps)(BoxContentMessageUploadContainer);