// react
import React from 'react';

// css
import css from './index.scss';

//component
import CommonModal from '@/components/common/common-modal';

import UserAdd from '@c/common/user-add/user-add-container';

// no img
import noImg from '@a/imgs/no-img.png';

// util
import * as util from '@/utils/util';

// BoxOperation
export default class BoxConfiguration extends React.Component{
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div className={css.box}>
                {this.props.getRule() &&
                    <div className={css.gtoupRules} onClick={this.props.openGetUser}>
                        <span>{util.locale('im_add_group_administrator') }</span>  {/**添加群管理员 */} 
                        <div className={css.right} >
                        <span className={`${css.jiantou_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`}/>
                        </div>
                    </div>
                }
                <div className={css.peopleList}>
                    {this.props.managers && this.props.managers.length>0 &&
                        this.props.managers.map(item=>(
                            <div className={css.bottom} key={item.account}>
                                <div className={css.info}>
                                    <img src={item.avatar} />
                                    <span>{util.yach.decodeUnicode(item.nick)}</span>
                                </div>
                                {this.props.getRule() &&
                                    <span onClick={() => this.props.remove(util.yach.decodeUnicode(item.nick), item.account)}>{util.locale('im_remove') /**移除 */}</span>
                                }
                            </div>
                        ))
                    }
                    {!this.props.managers || this.props.managers.length==0 &&
                    <div className={css.noImg}>
                        <img src={noImg}/>
                        <p>{util.locale('im_please_add_administrator')}</p> {/**请添加管理员 */} 
                    </div>
                    }
                </div>
                <CommonModal
                    modalVisible={this.props.modalVisible}
                    setOKModal={this.props.setOKModal}
                    setonCancelModal={this.props.setonCancelModal}
                    modalContent={this.props.popText}
                />
                <UserAdd {...this.props.userAddProps} />
            </div>
        );
    }
}
