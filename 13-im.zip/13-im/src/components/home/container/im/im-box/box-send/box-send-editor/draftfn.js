import { EditorState, ContentState, SelectionState, RichUtils, Modifier, CompositeDecorator, AtomicBlockUtils, convertToRaw, getVisibleSelectionRect } from 'draft-js'
import { convertToHTML, convertFromHTML } from 'draft-convert'
import getContentStateFragment from 'draft-js/lib/getContentStateFragment'
import customEntity from './entity'
import * as util from '@u/util.js'
import lodash from 'lodash'

let draftInstance = null

const setInstance = ref => draftInstance = ref

const getInstance = () => draftInstance

const focusEditor = () => {
    if (!draftInstance) return false
    draftInstance.focus()
}

const blurEditor = () => {
    if (!draftInstance) return false
    draftInstance.blur()
}

// 设置修饰器
const setDecorator = data => {
    const staticStrategy = type => (contentBlock, callback, contentState) => {
        contentBlock.findEntityRanges(character => {
            const entityKey = character.getEntity()
            if (entityKey === null) return false

            const entity = contentState.getEntity(entityKey)
            return entity.type.toLowerCase() == type
        }, callback)
    }

    const decorators = data.map(item => ({
        strategy: staticStrategy(item.type),
        component: item.component
    }))

    const compositeDecorator = new CompositeDecorator(decorators)

    return compositeDecorator
}

// 添加纯文本
const addText = (editorState, text) => {
    let contentState = editorState.getCurrentContent()
    let selectionState = editorState.getSelection()

    if (!selectionState.isCollapsed()) {
        return EditorState.push(editorState, Modifier.replaceText(contentState, selectionState, text, undefined), 'replace-text')
    } else {
        let contentTextLength = contentState.getPlainText().length
        let cz = 2000-contentTextLength
        text = contentTextLength >=2000 ? '': (cz >0)? text.slice(0, cz): ''
        return EditorState.push(editorState, Modifier.insertText(contentState, selectionState, text, undefined), 'insert-text')
    }
}

// 添加实体
const addEntity = (editorState, data) => {
    let contentState = editorState.getCurrentContent()
    let selectionState = editorState.getSelection()
    let nextContentState = contentState.createEntity(data.type, data.mutability || 'IMMUTABLE', data)
    let entityKey = nextContentState.getLastCreatedEntityKey()

    if (!selectionState.isCollapsed()) {
        return EditorState.push(editorState, Modifier.replaceText(nextContentState, selectionState, data.text || ' ', undefined, entityKey), 'replace-text')
    } else {
        return EditorState.push(editorState, Modifier.insertText(nextContentState, selectionState, data.text || ' ', undefined, entityKey), 'insert-text')
    }
}

// 添加原子
const addAtomic = (editorState, data) => {
    let contentState = editorState.getCurrentContent()
    let nextContentState = contentState.createEntity(data.type, 'IMMUTABLE', data)
    let entityKey = nextContentState.getLastCreatedEntityKey()

    let nextEditorState = EditorState.set(editorState, {
        currentContent: nextContentState
    })

    nextEditorState = AtomicBlockUtils.insertAtomicBlock(nextEditorState, entityKey, ' ')

    return nextEditorState
}

// 添加片段
const addFragment = (editorState, blockMap) => {
    let contentState = editorState.getCurrentContent()
    let selectionState = editorState.getSelection()
    return EditorState.push(editorState, Modifier.replaceWithFragment(contentState, selectionState, blockMap), 'insert-fragment')
}

// 清除范围
const removeRange = (editorState, obj) => {
    let contentState = editorState.getCurrentContent()
    let selectionState = editorState.getSelection()

    selectionState = selectionState.merge(obj || {})

    return EditorState.push(
        editorState,
        Modifier.removeRange(contentState, selectionState),
        'remove-range'
    );
}

// 重构range数据以兼容emoji算1个字符的问题
const resetRangeFixEmoji = (range, textarr) => {
    textarr = textarr.map(char => {
        if (char.length == 1) return char
        let code = escape(char)
        let emojilength = code.replace(/%uD83D|%uD83C/g, '').split('%').length - 1
        return [char, ...new Array(emojilength - 1).fill('')]
    }).flat()

    let originRangeOffset = range.offset
    let originRangeLength = range.length
    range.offset = textarr.slice(0, originRangeOffset).reduce((a, v) => a + v.length, 0)
    range.length = textarr.slice(originRangeOffset, originRangeOffset + originRangeLength).reduce((a, v) => a + v.length, 0)
    return range
}

const getAtEntityData = ({range,lastBlockLength,blockText, entityObj}) => {
    const {text} = entityObj.data;
    const textRange = blockText.slice(range.offset);
    const startIndex = lastBlockLength + range.offset + textRange.indexOf(text);
    const endIndex = startIndex + text.length;
    return {
        ...entityObj,
        text,
        startIndex,
        endIndex
    }
}
//获取所有实体数据
const getEntityData = editorState => {
    let contentState = editorState.getCurrentContent()
    let rawData = convertToRaw(contentState)
    let entityData = [];
    let lastBlockLength = 0
    // rawData.blocks.forEach(block => {
    //     let blockText = block.text
    //     block.entityRanges.forEach(range => {
    //         let text = block.text.slice(range.offset, range.offset + range.length);
    //         let entityObj = rawData.entityMap[range.key];
    //         if(entityObj.type == 'at') entityData.push(getAtEntityData({range,entityObj, blockText, lastBlockLength}));
    //         else {
    //             entityData.push({
    //                 ...entityObj,
    //                 text,
    //                 range,
    //                 startIndex: lastBlockLength + range.offset,
    //                 endIndex: lastBlockLength + range.offset + range.length
    //             });                
    //         }

    //     });
    //     lastBlockLength += block.text.length + 1
    // });
    rawData.blocks.forEach(block => {
        let textarr = lodash.toArray(block.text)
        block.entityRanges.forEach(range => {
            range = resetRangeFixEmoji(range, textarr)
            let text = block.text.slice(range.offset, range.offset + range.length);
            entityData.push({
                ...rawData.entityMap[range.key],
                text,
                range,
                startIndex: lastBlockLength + range.offset,
                endIndex: lastBlockLength + range.offset + range.length
            });
        });
        lastBlockLength += block.text.length + 1
    });
    return entityData;
};

//获取选中的文本
const getSelectionText = editorState => {
    let contentState = editorState.getCurrentContent();
    let selection = editorState.getSelection();
    let text = ''
    getContentStateFragment(contentState, selection).map(fragment => {
        text += fragment.getText()
    })
    return text;
};

// 获取第一个元数据
const getFirstCharacter = editorState => {
    let contentState = editorState.getCurrentContent()
    let contentBlock = contentState.getFirstBlock()
    let characterList = contentBlock.getCharacterList()

    if (!characterList) return null
    let character = characterList.get(0)

    if (!character) return null
    let key = character.entity
    let entity = contentBlock.getEntity(key)

    if (!entity) return null
    return entity.type
}

// 合并光标选中
const mergeSelectioning = (editorState, obj) => {
    let selection = editorState.getSelection()
    let selectionNew = selection.merge(obj);

    return EditorState.forceSelection(editorState, selectionNew)
}

// 清空内容
const clearText = editorState => {
    const contentState = editorState.getCurrentContent()
    const firstBlock = contentState.getFirstBlock()
    const lastBlock = contentState.getLastBlock()

    const allSelected = new SelectionState({
        anchorKey: firstBlock.getKey(),
        anchorOffset: 0,
        focusKey: lastBlock.getKey(),
        focusOffset: lastBlock.getLength(),
        hasFocus: true
    })

    return RichUtils.toggleBlockType(EditorState.push(
        editorState,
        Modifier.removeRange(contentState, allSelected, 'backward'),
        'remove-range'
    ), 'unstyled')
}

// 初始化内容
const initDraft = () => {
    let decorator = setDecorator(customEntity.CUSTOMENTITIES)
    let editorState = EditorState.createEmpty(decorator)
    editorState = setFocusEnd(editorState)
    return editorState
}

// 聚焦光标展示出来
const showFocusSelection = editorState => {
    let selectionState = editorState.getSelection()
    let blockkey = selectionState.getFocusKey()
    let dom = document.querySelector(`[data-offset-key="${blockkey}-0-0"]`)
    dom.scrollIntoView(false)

    // let selection = window.getSelection()
    // if (!selection || !selection.rangeCount) return null

    // let parentRect = parentEl.getBoundingClientRect()
    // let rect = getVisibleSelectionRect(window)
    // let top = rect.top - parentRect.top

    // console.log(112233, rect.top, parentRect.top, top)

    // parentEl.scrollTo(0, top)
}

// 检查实体上光标状态
const checkEntitySelection = (editorState, isLeftKey, isRightKey) => {
    let nextEditorState = editorState
    let contentState = editorState.getCurrentContent()
    let selectionState = editorState.getSelection()
    let blockkey = selectionState.getFocusKey()
    let anchorOffset = selectionState.getAnchorOffset()
    let focusOffset = selectionState.getFocusOffset()

    let rawData = convertToRaw(contentState)
    rawData.blocks.forEach(block => {
        let textarr = lodash.toArray(block.text)
        if (block.key != blockkey) return false
        block.entityRanges.forEach(range => {
            range = resetRangeFixEmoji(range, textarr)
            if (range.length == 1 && anchorOffset == range.offset) {
                let wantGoLeft = isLeftKey
                anchorOffset = wantGoLeft ? range.offset - 1 : range.offset + range.length
                nextEditorState = mergeSelectioning(editorState, {
                    anchorOffset,
                    focusOffset: anchorOffset
                })
                return 
            }
            if (range.length == 1 && focusOffset == range.offset) {
                focusOffset = anchorOffset < focusOffset ? range.offset + range.length : range.offset - 1
                isLeftKey && (focusOffset = range.offset - 1)
                isRightKey && (focusOffset = range.offset + range.length)
                nextEditorState = mergeSelectioning(editorState, {
                    focusOffset
                })
                return
            }
            if (anchorOffset > range.offset && anchorOffset < range.offset + range.length) {
                let wantGoLeft = anchorOffset == range.offset + range.length - 1 && isLeftKey
                anchorOffset = wantGoLeft ? range.offset : range.offset + range.length
                nextEditorState = mergeSelectioning(editorState, {
                    anchorOffset,
                    focusOffset: anchorOffset
                })
                return 
            }
            if (focusOffset > range.offset && focusOffset < range.offset + range.length) {
                focusOffset = anchorOffset < focusOffset ? range.offset + range.length : range.offset
                isLeftKey && (focusOffset = range.offset)
                isRightKey && (focusOffset = range.offset + range.length)
                nextEditorState = mergeSelectioning(editorState, {
                    focusOffset
                })
                return
            }
        })
    })

    return nextEditorState
}

//设置光标到富文本框末尾
const setFocusEnd = editorState => {
    return EditorState.moveFocusToEnd(editorState)
}

// editorstate转换为html
const transToHtml = editorState => {
    let contentState = editorState.getCurrentContent()
    let transRule = {
        entityToHTML: (entity, text) => {
            let myentity = customEntity.CUSTOMENTITIES.find(v => v.type == entity.type)
            if (myentity && myentity.exporter) 
            return myentity.exporter(entity, text)
            return text
        }
    }
    return convertToHTML(transRule)(contentState) 
}

// editorstate转换为纯文本
const transToText = editorState => {
    let contentState = editorState.getCurrentContent()
    return contentState.getPlainText()
}

// editorstate转换为自定义纯文本
const transToCustomText = (editorState, imgseat) => {
    let contentState = editorState.getCurrentContent()
    let rawData = convertToRaw(contentState)
    let customText = []

    if (imgseat === undefined) {
        imgseat = `[${util.locale('im_image')}]`
    }

    rawData.blocks.forEach(block => {
        let text = block.text
        let entityData = []
        block.entityRanges.forEach(range => {
            entityData.push({
                ...rawData.entityMap[range.key],
                ...range
            })
        })
        entityData.reverse().forEach(entity => {
            if (entity.type == customEntity.ENTITYIMAGE.type) {
                let seat = imgseat
                text = text.slice(0, entity.offset - 1) + seat + text.slice(entity.offset + entity.length)
            }
        })
        customText.push(text)
    })

    return customText.join('\n')
}

// html转为contentstate
const createContentFromHtml = html => {
    let contentState = ContentState.createFromText('')
    
    if (!html) return contentState

    // const blocksFromHTML = convertFromHTML(html)
    // contentState = ContentState.createFromBlockArray(
    //     blocksFromHTML.contentBlocks || [],
    //     blocksFromHTML.entityMap,
    // )

    // return contentState
    const transRule = {
        htmlToEntity: (nodename, node, createEntity) => {
            if (node.nodeType != 1) return false
            let entitytype = node.getAttribute('data-entity')
            let myentity = customEntity.CUSTOMENTITIES.find(v => v.type == entitytype)
            if (myentity && myentity.importer) return myentity.importer(nodename, node, createEntity)
        }
    }
    return convertFromHTML(transRule)(html)
}

// text转html
const textToHtml = text => {
    let html = text
    html = html.replace(/&/g, '&amp;')
    html = html.replace(/</g, '&lt;')
    html = html.replace(/>/g, '&gt;') 
    html = html.replace(/\n/g, '<br/>')
    return html
}

export default {
    setInstance,
    getInstance,
    focusEditor,
    blurEditor,
    setDecorator,
    addText,
    addAtomic,
    addEntity,
    transToHtml,
    transToText,
    transToCustomText,
    getSelectionText,
    getEntityData,
    clearText,
    mergeSelectioning,
    createContentFromHtml,
    getFirstCharacter,
    checkEntitySelection,
    setFocusEnd,
    removeRange,
    addFragment,
    initDraft,
    showFocusSelection,
    textToHtml,
}