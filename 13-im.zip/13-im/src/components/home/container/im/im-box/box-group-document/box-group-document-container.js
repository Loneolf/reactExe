// react
import React from 'react';
// ImBox
import BoxGroupDocument from './box-group-document';
// connect
import {connect} from 'react-redux';
// util
import * as util from '@u/util.js';
// server
import { spaceFileList } from '@s/group/group-online-doc';

// imgs
import wordImg from '@a/imgs/doc_normal/word.png';
import excelImg from '@a/imgs/doc_normal/excel.png';
import dirImg from '@a/imgs/doc_normal/dir.png';
import formImg from '@a/imgs/doc_normal/form.png';
import mindImg from '@a/imgs/doc_normal/mind.png';
import pptImg from '@a/imgs/doc_normal/ppt.png';
import whiteImg from '@a/imgs/doc_normal/white.png';

class BoxGroupDocumentContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state = {
        isSearch: false,
        docList: [],
        fileName: '',
        showNameInput: false,
        createPlaceholder: '', 
        showImg: null,
        fileType: null,
        breadcrumbList:[{name:util.locale('im_group_doc_all'),guid:''}], //面包屑数据
        hasMore: true,
        pagesize: 20,
        currentPage: 1,
        total: 0,
        loading: false,
        folder: null
    }

    componentDidMount () {
        util.eventBus.addListener('group-doc-search', (value) => this.hanlelevel(value));
        util.eventBus.addListener('group-doc-close-create-input', (value) => this.handleCloseCreateInput(value));
        this.initData();
        util.sensorsData.track('PageView_Chat', { pageName: '01-135' });
    }

    componentWillUnmount () {
        util.eventBus.removeListener('group-doc-search');
        util.eventBus.removeListener('group-doc-close-create-input');
    }

    initData = async () => {
        const params = {
            // group_id: this.props.sessionActive.id,
            group_id: window.session_active.id,
            page: this.state.currentPage,
            pagesize: this.state.pagesize
        }
        this.getList(params);
    }

    // 删除/重命名成功之后，立即请求列表数据，后端接口不能更新，前端操作数据更新
    refreshList = (params) => {
        if(params.needFetch){
            this.handleFetch(params)
            return
        }
        let docList = [...this.state.docList];
        if (!docList.length) return;
        // 重命名
        if (params.isRename) {
            let data = docList.find(item => {
                return item.guid === params.guid
            })
            data.name = params.name;
            this.setState({docList})
        } else {
        // 删除 
            const screenArr = docList.filter((item) => {
                return item.guid !== params.guid
            });
            this.setState({docList: screenArr});
        }
    }

    // 新建之后，将新建数据插入到docList数组第一项
    handleCloseCreateInput = (value) => {
        if (!value) {
            this.setState({showNameInput: false});
            return;
        }
        let docList = [...this.state.docList];
        docList.unshift(value);
        this.setState({showNameInput: false, docList})
    }

    hanlelevel = (value) => {
        if (value === 'search') this.setState({ isSearch: true})
        if (value === 'back') this.setState({ isSearch: false})
    }

    getList = async(data) => {
        this.setState({ loading: true })
        const { group_id, folder, page, pagesize} = data
        const params = {
            group_id, page, pagesize
        }
        if(folder){
            params.folder = folder
        }else{
            delete params.folder
        }
        const res = await spaceFileList(params)
        this.setState({ loading: false });
        if(!res || res.code != 200 || !res.obj) return;
        this.setState({
            docList : res.obj.list || [],
            currentPage: +res.obj.currentPage,
            total: +res.obj.total
        })
    }

    handleInfiniteOnLoad = async () => {
        const {docList, currentPage, total, pagesize, folder} = this.state;
        if (docList.length >= total) {
            this.setState({
                hasMore: false,
            });
            return;
        }
        const params = {
            // group_id: this.props.sessionActive.id,
            group_id: window.session_active.id,
            page: currentPage + 1,
            pagesize
        }
        if(folder){
            params.folder = folder
        }else{
            delete params.folder
        }
        const res = await spaceFileList(params)
        if(!res || res.code != 200 || !res.obj) return;
        if (!res.obj.list.length) {
            this.setState({
                hasMore: false
            });
            return;
        }
        this.setState({
            docList: docList.concat(res.obj.list),
            total: +res.obj.total,
            currentPage: +res.obj.currentPage
        })

    }
  
    handleCreateBtn = () => {
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '01-220'});
        util.eventBus.emit('group-doc-create-btn');
    }
  
    handleMenuClick = (o) => {
        o.domEvent.stopPropagation();
        this.setState({showNameInput: true});
        this.handleDocStyle(o.key);
    }

    handleDocStyle = (key) => {
        switch (key) {
            case 'newdoc':
                this.setState({createPlaceholder: util.locale('im_group_doc_create_docs'), showImg: wordImg, fileType: 'newdoc'})
                break;
            case 'mosheet':
                this.setState({createPlaceholder: util.locale('im_group_doc_create_sheets'), showImg: excelImg, fileType: 'mosheet'})
                break;
            case 'slide':
                this.setState({createPlaceholder: util.locale('im_group_doc_create_slides'), showImg: pptImg, fileType: 'slide'})
                break;
            case 'mindmap':
                this.setState({createPlaceholder: util.locale('im_group_doc_create_mind'), showImg: mindImg, fileType: 'mindmap'})
                break;
            case 'form':
                this.setState({createPlaceholder: util.locale('im_group_doc_create_forms'), showImg: formImg, fileType: 'form'})
                break;
            case 'folder':
                this.setState({createPlaceholder: util.locale('im_group_doc_create_folders'), showImg: dirImg, fileType: 'folder'})
                break;
            default:
                this.setState({createPlaceholder: '', showImg: whiteImg})
                break;
        }
    }

    handleSearch = () => {
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '224'});
        this.setState({ isSearch: true})
    }
    handleFetch = async(params) =>{
        //需要处理文件列表，面包屑
        const { group_id, folder, page, pagesize, name, guid, path } = params;
        this.setState({folder, currentPage: 1, hasMore: true});
        this.getList({ group_id, folder, page, pagesize });
        //面包屑需要增加或者删除
        if (path && !!path.length) {
            path[0].name = util.locale('im_group_doc_all');
            path.push({ guid, name });
            this.setState({
                breadcrumbList: path,
            });
            return;
        }
        let breadcrumbList = this.state.breadcrumbList;
        if (params.breadcrumbType == 'del') {
            const index = breadcrumbList.findIndex((item) => {
                return item.guid == guid;
            });
            if (breadcrumbList[index + 1]) {
                const len = breadcrumbList.length - 1 - index;
                for (let i = 0; i < len; i++) {
                    breadcrumbList.pop();
                }
            }
        } else if (params.breadcrumbType == 'add') {
            breadcrumbList.push({ name, guid });
        } else if (params.breadcrumbType == 'delAll') {
            breadcrumbList = [{ name: '全部', guid: '' }];
        }
        this.setState({
            breadcrumbList
        });
    }
    render() {
        return(
            <BoxGroupDocument 
            showNameInput = {this.state.showNameInput}
            isSearch = {this.state.isSearch}
            docList = {this.state.docList}
            createPlaceholder = {this.state.createPlaceholder}
            showImg = {this.state.showImg}
            fileType = {this.state.fileType}
            hasMore = {this.state.hasMore}
            loading = {this.state.loading}
            handleInfiniteOnLoad = {this.handleInfiniteOnLoad}
            handleMenuClick = {this.handleMenuClick}
            handleCreateBtn = {this.handleCreateBtn}
            handleSearch = {this.handleSearch}
            refreshList={this.refreshList}
            breadcrumbList={this.state.breadcrumbList}
            />
        )
    }
}

const mapStateToProps = state => {
    return {
        // sessionActive: state.sessionActive,
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxGroupDocumentContainer);
