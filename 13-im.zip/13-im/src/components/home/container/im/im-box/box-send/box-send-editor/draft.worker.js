import draftfn from './draftfn'

self.onmessage = e => {
    console.log(112233, 'worker get data from main', e)

    let data = e.data
    
    if (data.type == 'updata') {

    }

    if (data.type == 'add') {
        // self.postMessage('')
    }
}