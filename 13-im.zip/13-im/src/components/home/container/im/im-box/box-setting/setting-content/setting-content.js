// react
import React, { Fragment } from 'react';

// css
import css from './index.scss';

// antd
import { Switch, Input } from 'antd';
import * as yach from '@u/yach';
import { showUserinfo } from '@/utils/yach';

// logo
import del from '@a/imgs/del.png';
import * as util from "@/utils/util";

// BoxOperation
export default function SettingContent(props) {
    const {
        searchValue,
        userInfoId,
        onEditCommon,
        showSearchInput,
        onSearchValueChange,
        memberNum,
        list,
        masterId,
        onShowGroupModal,
        delMember,
        getConfigEdite,
        typeMsg,
        onReadmore,
        groupInfo,
        user_status,
        userIni,
        handleCancelSearch,
        ifSearching,
        hasMoreData,
        searchGroupUser
    } = props;

    const card = typeMsg && typeMsg.type === 'squad' && userIni && userIni.card && userIni.card
    return (
        <div className={css.content}>
            <div className={css.contentTop}>
                <div className={css.search}>
                    {showSearchInput ? (
                        <div className={css.searching}>
                            <Input
                                onInput={e =>
                                    onSearchValueChange(e.target.value)
                                }
                                value={searchValue}
                                type="text"
                                autoFocus
                                placeholder={util.locale("im_search_group_member")}
                            />
                            <span
                                onClick={() => {
                                    onEditCommon('showSearchInput');
                                    onSearchValueChange('');
                                    handleCancelSearch();
                                }}
                            >
                                {util.locale("im_cancel")}
                            </span>
                        </div>
                    ) : (
                        <Fragment>
                            <p className={css.title}>
                                { `${(typeMsg && typeMsg.value) ? typeMsg.value : util.locale("im_group")}${util.locale.getLang() === 'en-US' ? " " : ''}${util.locale("im_members")}` } <span>{groupInfo.user_total || list.length || '--'}</span>{util.locale.getLang() === 'en-US' ? "" : util.locale("im_user")}
                            </p>
                            <div className={css.icons}>
                                {getConfigEdite && getConfigEdite() || (groupInfo && groupInfo.hasOwnProperty('invite_open') && !groupInfo.invite_open) ?
                                    <span
                                        onClick={onShowGroupModal}
                                        className={`${css.chengyuan_icon} ${css.addUser} iconfont-yach yach-quanju-qunshezhi-tianjiaqunchengyuan-changtai`}
                                    /> : null
                                }
                                <span
                                    onClick={onEditCommon.bind(
                                        this,
                                        'showSearchInput'
                                    )}
                                    className={`${css.sousuo_icon} iconfont-yach yach-quanju-qunshezhi-sousuoqunchengyuan-changtai`}
                                />
                            </div>
                        </Fragment>
                    )}
                </div>
                {/* <div className={css.tip}>
                    <p>新成员入群可查看最近100条聊天记录</p>
                </div> */}
            </div>
            <div className={css.contentMiddle} id='usersOut'>
                <div className={css.inner}>
                    {Array.isArray(list) && list.map(item => {
                        const {
                            id,
                            role,
                            name,
                            pic,
                            name_nick,
                            user_id
                        } = item;
                        let other = null;
                        if (role == 0) {
                            other = (typeMsg && typeMsg.type === 'squad') ? <i>{util.locale("im_group_leader")}</i> : <i>{util.locale("im_group_administrator")}</i>;
                        } else if (role == 1) {
                            other = <i>{util.locale("im_administrator")}</i>;
                        }
                        // 第一行判断逻辑是之前群主是否可移除群成员，包含小组逻辑 ，第二行为新增群管理员可以移除普通成员
                        let isShowX = (userInfoId == masterId || card === 'owner') && role != 0 || (card === 'admin' && role != 0 && role != 1)
                                    || (typeMsg && typeMsg.type === 'setting' && role == 2 && groupInfo && groupInfo.user_type == 1);
                        return id ? (
                            <div
                                key={id}
                            >
                                <img
                                    src={pic}
                                    alt=""
                                    onClick={e => {
                                        const uid = (typeMsg && typeMsg.type === 'setting') ? id : user_id
                                        showUserinfo(uid, 106)
                                    }}
                                />
                                { isShowX &&
                                    <img
                                        className={css.del}
                                        src={del}
                                        onClick={() => {
                                            delMember(name, (typeMsg && typeMsg.type === 'setting') ? id : user_id)
                                        }}
                                    />
                                }
                                {/* <span>{name}{!!name_nick && '(' + name_nick + ')'}</span> */}
                                <span>{name_nick || name}</span>
                                {other}
                            </div>
                        ) : null;
                    })}
                </div>
                {(typeMsg && typeMsg.type === 'setting'&& !ifSearching) && <p id="checkIsIn"></p>}
                {/* 群 / 小组 人员列表中的 “加载更多” */}
                {
                    (typeMsg.type == 'squad' &&  !!groupInfo.offset_id && +groupInfo.offset_id !== 0) || (typeMsg.type == 'setting' && !!hasMoreData) ? <div className={css.more} onClick={() => onReadmore(searchGroupUser)}>{util.locale("im_setting_view_more")}</div> : null
                }
            </div>
        </div>
    );
}
