/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-16 14:36:32
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-25 11:08:01
 */
// react
import React, { Fragment } from 'react';

// css
import css from './index.scss';

import { Switch } from 'antd';
import * as util from '@u/util.js';
import SettingContent from '../box-setting/setting-content/setting-content';

// BoxOperation
export default function  BoxSquadSetting(props) {
    const {
        onFixtop,
        isTop,
        disnotice,
        onNodisturb,
        showimg,
        showname,
        squadDetails
    } = props;
    return (
        <div className={css.box}>
            <div className={css.top}>
                <img src={showimg}/>
                <div style={{display: "flex"}}>
                    <div  className={css.showname} title={showname}>{showname}</div>
                </div>           
            </div>
            <div className={css.bottom}>
                <p>
                    <span>{util.locale("im_group_members")}</span>
                    <span className={css.peopleNumber}>{squadDetails && squadDetails.ex && squadDetails.ex.user_total}人</span>
                </p>
                {/* <SettingContent /> */}
                <p className={css.exit}>
                    <span>{util.locale("im_team_management")}</span>
                    <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
                </p>
                <p>
                    <span>{util.locale("im_stick_to_top")}</span>
                    <Switch checked={isTop} onChange={onFixtop} />
                </p>
                <p>
                    <span>{util.locale("im_mute_notifications")}</span>
                    <Switch checked={disnotice} onChange={_.debounce((v)=>onNodisturb(v),300)} />
                </p>
            </div>
        </div>
    );
}
