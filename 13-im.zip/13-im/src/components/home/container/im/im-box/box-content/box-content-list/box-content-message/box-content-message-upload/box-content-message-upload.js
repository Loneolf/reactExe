import React from 'react';
//util
import * as util from '@u/util.js';
import moment from 'moment';

//css
import css from './index.scss';

//components
import Progress from '@c/common/progress';
import Img from '@c/common/img';

export default class BoxContentMessageUpload extends React.Component {
    constructor (props){
        super(props);
        this.cancelRef = React.createRef();
    }
 
    getUnit = (B, digit)  => {
        if(B < 1024 * 1024){
            return `${(B/1024).toFixed(digit)} KB`;
        }else {
            return `${(B/1024/1024).toFixed(digit)} MB`;
        }
    }
    getProgress = (progress) => {
        if(!progress) return {}
        return {
            percent:`${progress.percent*100}%`,
            speed: `${this.getUnit(progress.speed,1)}/s`,
            total: progress.total
        }
    }
    render = () => {
        const {fileType, path, base64, size, name, width,
             height, uploadData, deleteLocalCustomMessage, retry,type
            } = this.props; 
        const {status, progress} = uploadData;
        const {percent, speed, total} = this.getProgress(progress);
        const visible = ['uploadStart', 'uploading'].includes(status)? 'visible' : 'hidden';
        //const failShow = (!status || (status == 'uploadFail')) ? '' : 'none';
        // 明确：是重新发送，不是失败
        const failShow = !status || (status == 'uploadFail');

        return (
            <div className ={`${css.modBoxContentMessageUpload} ${fileType? 'file' : ''}`} >
                <div className = {css.container}>
                    {
                        failShow && <div className = {`${css.fail} iconfont-yach yach-goutong-xiaoxi-fasongshibai-moren`}
                          onClick = {retry}
                        />
                    }
                    <div className = {`${css.body} ${fileType? css.file : css.image}`}>
                        <div className = {css.img} >
                            {fileType?
                                <img src = {require(`@a/imgs/modelFileType/${fileType}.svg`)} />
                                :
                                <Img src = {util.imageDealer.encodeImgPath(path) || base64} width= {width || 280} height= {height || 135}/>
                            }
                        </div>
                        <div className = {css.txt} style= {{display: fileType ? 'block' : 'none'}}>
                            <div className= {css.fileName}>{name}</div>
                            <div className= {css.size}>{this.getUnit(size,1)}</div>
                            <div className= {css.speed} style = {{visibility:visible}}>{speed}</div>
                        </div>                    
                    </div>
                </div>
                <div className = {css.progress} style = {{visibility:visible}} ref= {this.cancelRef}>
                        <Progress
                            percent = {percent}
                            speed = {null}
                            handleCancle = {() => deleteLocalCustomMessage(uploadData)}
                            popupContainer = {this.cancelRef.current}
                        />
                    </div>  
            </div>
        )
    }
}