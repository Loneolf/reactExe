// react
import React from 'react';

// util
import * as util from '@u/util.js';

// antd
import { Input } from 'antd';

// css
import css from './index.scss';
export default class GroupDocInput extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
        const {
            handleKeyPress, 
            createPlaceholder,
            showImg,
            defaultValue,
            handleCancel,
            handleSure,
            handleOnChange,
            isRename
        } 
        = this.props;
        return(
          <div className={`${css.createBox} ${!isRename ? css.createInput : ''}`} onClick={e => {e.stopPropagation();}}>
            <img src={showImg} />
            <Input
              autoFocus
              placeholder={createPlaceholder}
              type="text"
              maxLength={50}
              onKeyDown={handleKeyPress}
              onChange={handleOnChange}
              defaultValue={defaultValue}
            />
            <span onClick={ handleCancel} className={`${css.quxiao} iconfont-yach yach-quxiao1`}></span>
            <span onClick={ handleSure} className={`${css.queren} iconfont-yach yach-queren`}></span>
          </div>
        )
    }
}
