import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import { Tooltip, Spin } from 'antd';
import flattenDeep from 'lodash/flattenDeep';
import { toggleAddRobotWindow, robotGoGeneralDetail } from '@r/actions/robots';
import { DetailType, PageType } from '@r/reducers/robots';
import { ROBOTS_ROBOT_DETAIL } from '@r/actiontype/robots';
import RobotCard from './robot-card/robot-card';
import * as util from '@u/util.js';
import style from './index.scss';

// 机器人人配置侧边栏
class RobotsSettings extends PureComponent {
    constructor(props) {
        super(props);
    }

    get hasNoticeRobots() {
        // 是否有通知机器人
        const { inUseList } = this.props;
        return (((inUseList || [])[0] || {}).items || []).length > 0;
    }
    get hasChatRobots() {
        // 是否有聊天机器人
        const { inUseList } = this.props;
        return (((inUseList || [])[1] || {}).items || []).length > 0;
    }
    render() {
        const { inUseList, windowHeight, isFull, robotGoGeneralDetail } = this.props;
        const hasContent = this.hasChatRobots || this.hasNoticeRobots; //有内容显示, 否则显示 empty 状态
        return (
            <div className={style.robotsSettings}>
                {inUseList ? (
                    hasContent ? (
                        <div style={{ height: `${windowHeight - 140}px`, overflowY: 'auto' }}>
                            {(inUseList || [])
                                .filter(c => (c.items || []).length > 0)
                                .map(r => {
                                    return (
                                        // 机器人分类组
                                        <div key={r.categoryID} className="categroyGroup">
                                            <div className={style.groupName}>{r.category}</div>
                                            {r.items.map(i => (
                                                <RobotCard
                                                    showArrow={true}
                                                    className={style.onSlide}
                                                    key={i.robot_id}
                                                    item={i}
                                                    onClick={() =>
                                                        robotGoGeneralDetail({ ...i, categoryID: r.categoryID })
                                                    }
                                                ></RobotCard>
                                            ))}
                                        </div>
                                    );
                                })}
                        </div>
                    ) : (
                        <div
                            style={{ height: `${windowHeight - 140}px`, minHeight: `${windowHeight - 140}px` }}
                            className={style.empty}
                        >
                            <img
                                style={{ display: 'inline-block' }}
                                width="64px"
                                height="64px"
                                src={require('@a/imgs/noRobot.png')}
                                alt=""
                            />
                            <span className={style.tip}>{util.locale("im_no_robots_added_to_this_group")}</span>
                        </div>
                    )
                ) : (
                    <Spin style={{ height: `${windowHeight - 140}px`, overflowY: 'auto' }} />
                )}

                <Tooltip
                    getPopupContainer={() => document.getElementById('robot-add-btn')}
                    placement="top"
                    title={util.locale("im_robots_10_most")}
                >
                    <div
                        id="robot-add-btn"
                        onClick={isFull || !inUseList ? null : this.props.openWindow}
                        className={`${style.btn} ${isFull || !inUseList ? style.disabled : ''}`}
                    >
                        <span
                            style={{ marginRight: '4px', fontSize: '14p' }}
                            className="iconfont-yach yach-qunshezhi-tianjiajiqirenbutton"
                        ></span>
                        {util.locale("im_add_robot")}
                    </div>
                </Tooltip>
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => ({
    inUseList: state.robots.inUseList,
    windowHeight: state.windowInfo.innerHeight,
    isFull: flattenDeep((state.robots.inUseList || []).map(c => c.items || [])).length >= 10
});
const mapDispatchToProps = dispatch => {
    return {
        openWindow: () => dispatch(toggleAddRobotWindow()),
        robotGoGeneralDetail: v => {
            // 详情状态调整, 切触发接口获取详情数据
            dispatch(robotGoGeneralDetail(v));
            dispatch({
                type: ROBOTS_ROBOT_DETAIL,
                payload: {
                    robot_id: v.robot_id
                }
            });
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(RobotsSettings);
