// react
import React from 'react';
import { connect } from 'react-redux';

// redux
import { showSlideModal } from '@r/actions/commonModal';
import { chatRobot } from '@r/actions/chatRobot.js';
import { ucenterUserInfoGet } from "@/services/ucenter/ucenter-user";

// util
import { eventBus, yachLocalStorage, locale, sensorsData, summaryUtil, log } from '@u/util.js';
import { getGroupFileStatus } from '@u/yach/lib/yach-group-file.js';

// debounce
import debounce from 'lodash/debounce';

// BoxInfo
import BoxInfo from './box-info';

// BoxInfoContainer
class BoxInfoContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            sign: '',
            fullSign:'',
            showNickName: false,
            busyinfo: '',
            pic: '',
            is_robot: false,
            newDeptName:[],// 部门信息，数组对象格式，用于个人信息弹框部门信息省略
            position:'' , // 个人职位
            searchHistoryGuide:false, // 搜索-新手引导
            groupDocGuide: false, // 群文档-新手引导
            groupFileGuide: false // 群文件-新手引导
        }
    }

    componentDidMount() {
        this.initData();
        this.meetingSummaryClick = debounce(this.meetingSummaryClick, 500);
        window.addEventListener('resize',this.reSetSign);
    }

    componentWillUnmount(){
        window.removeEventListener('resize', this.reSetSign)
        eventBus.removeListener('message:box:update');
    }

    // 初始化
    initData = () => {
        this.getSign();
        eventBus.addListener('message:box:update', () => {
            this.getSign();
        });

        const groupFileStatus = getGroupFileStatus()

        // 新手引导相关
        this.setState({groupDocGuide: !yachLocalStorage.ls('group_doc_guide')});
        this.setState({groupFileGuide: !yachLocalStorage.ls('group_file_guide')});
        const { type, id } = window.session_active;
        if ((id && id.length > 4 && type === 'p2p') || (groupFileStatus? yachLocalStorage.ls('group_file_guide'): yachLocalStorage.ls('group_doc_guide'))) {
            this.setState({searchHistoryGuide: !yachLocalStorage.ls('searchHistoryGuide')});
        }
    }

    // 关闭群文档-新手引导&打开侧边栏
    closeGroupDocTips = (flag = false) => {
        if (!flag) this.showRightModal({type: 'groupDocument'});

        this.setState({groupDocGuide: false})

        if (!yachLocalStorage.ls('group_doc_guide')) yachLocalStorage.ls('group_doc_guide', true);

        // 群文档引导关闭后 判断历史记录icon引导是否要展示
        if (!yachLocalStorage.ls('searchHistoryGuide')) this.setState({searchHistoryGuide: true});
    }

    // 关闭群文件-新手引导&打开侧边栏
    closeGroupFileTips = (flag = false) => {
        if (!flag) this.showRightModal({type: 'groupFile'});

        this.setState({groupFileGuide: false})

        if (!yachLocalStorage.ls('group_file_guide')) yachLocalStorage.ls('group_file_guide', true);

        // 群文档引导关闭后 判断历史记录icon引导是否要展示
        if (!yachLocalStorage.ls('searchHistoryGuide')) this.setState({searchHistoryGuide: true});
    }

    // 关闭历史搜索-新手引导
    closeSearchHistoryTips = (name, flag = false) => {
        if (!flag) this.showRightModal({type: 'groupDatabase', name });
        this.setState({searchHistoryGuide: false});
        if (!yachLocalStorage.ls('searchHistoryGuide')) yachLocalStorage.ls('searchHistoryGuide', true);
    }

    //
    getSign = async () => {
        const {type, id} = window.session_active;
        if (type != 'p2p' || !id)  return this.setState({ sign: ''}) 

        // 助手类去掉签名
        if (id && id.length == 4 && type == 'p2p' ) return this.setState({ showNickName: true, showsign: ''});

        try {
            const userinfo  = await ucenterUserInfoGet({ user_id: id });
            if (userinfo.code != 200 || !userinfo.obj) return this.setState({ showNickName: true });
            
            // 处理已离职
            if (userinfo.obj.status == 3) return this.setState({ sign: `(${locale('im_resigned')})`, showNickName: true });

            // get sign
            let { name, dept_name, busyinfo, pic, is_robot, new_dept_name, position } = userinfo.obj;
            let fullSign = name;
            if (dept_name) {
                fullSign = `${name}(${dept_name}${position && position !== '-1' ? '-' + position : ''})`;
                if (~fullSign.indexOf('好未来教育科技集团-')) fullSign = fullSign.replace('好未来教育科技集团-','');
            }
            // 将当前会话的，从接口请求的个人信息进行缓存
            try {
                sessionStorage.setItem('activeUserinfoFromAPI', JSON.stringify(userinfo.obj))
            } catch (error) {  }
            

            // let sign = this.setSignLength(fullSign);
            this.setState({ 
                sign: fullSign,
                fullSign,
                showNickName: true,
                busyinfo,
                pic,
                is_robot: !!is_robot,
                newDeptName: new_dept_name,
                position
            })
            this.reSetSign();

            window.store.dispatch(chatRobot(!!is_robot));
        } catch(e) { 
            console.log('getSign>>>>',e)
        }
    }

    setSignLength = (sign)=>{
        if(!this.usermsgBox || !this.usermsgBox.innerText.trim()) return sign

        let width = this.usermsgBox.parentElement.clientWidth
        this.usermsgBox.innerText = sign
        if( this.usermsgBox.scrollWidth < width) return sign

        let headIndex = sign.indexOf('(')
        let head = sign.slice(0, headIndex + 7)
        let signArr = sign.slice(headIndex + 7).split('')

        for (let i = 0; i < signArr.length; i++) {
            let temArr = signArr.slice(i).join('')
            this.usermsgBox.innerText = `${head}...${temArr}`
            if (this.usermsgBox.scrollWidth <= width) {
                yachLocalStorage.ls('userInfoSignCopy',{new:this.usermsgBox.innerText, all:sign})
                return this.usermsgBox.innerText
            }
        }

        return sign
    }

    getUsermsgBoxRef = (ref)=>{
        this.usermsgBox = ref
    }
    
    reSetSign = ()=>{
        let {fullSign} = this.state
        let sign = this.setSignLength(fullSign)
        if(fullSign !== sign) this.setState({sign})
    }

    showRightModal = (obj) => {
        const chat_id = window.session_active.id
        switch (obj.type) {
            case 'operation':
                sensorsData.track('Click_Chat_Element', { chat_id, pageName: 135, $element_name: 178 });
                break;
            case 'seachHistory':
                sensorsData.track('Click_Chat_Element', { chat_id, pageName: 135, $element_name: 179 });
                break;
            case 'seachImg':
                sensorsData.track('Click_Chat_Element', { chat_id, pageName: 135, $element_name: 180 });
                break;
            case 'setting':
                sensorsData.track('Click_ChatWindow_SetUp');
                sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-179'});
                break;
            case 'groupDatabase':
                sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-177'});
                break;
            case 'groupFile':
            case 'groupDocument':
                sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-227'});
                break;
            default:
                break;
        }
        this.props.dispatch(showSlideModal(obj.type, { name: obj.name }));
    };

    meetingSummaryClick = async () => {
        //请求接口，如果有会议纪要文档地址，直接打开，如果没有，服务端会创建一个新文档
        const { id } = window.session_active;
        const data = await summaryUtil.meetingSummaryGetUrl({group_tid: id});
        data.title = locale('calendar_create_meeting_summary');
        data.sessionActive = window.session_active;
        summaryUtil.goDocument(data);

        //数据埋点
        sensorsData.track('Click_Chat_Element', { pageName: 135, $element_name: '01-193' })
    }
    
    render() {
        const { pic, sign, fullSign, busyinfo, showNickName, is_robot, newDeptName, position, searchHistoryGuide, groupDocGuide, groupFileGuide } = this.state
        const { teamType, singleType, isHiddenSessionType, sessionList, sessionActive } = this.props;
        const { id, type } = window.session_active;

        let { showimg, showname, yachNick } = sessionList.find(item => item.id == sessionActive.id) || {}

        log('bgm','boxjs','img&name', !!showimg, !!sessionActive.showimg, !!showname, !!sessionActive.showname)

        showimg = showimg || sessionActive.showimg
        yachNick = yachNick || sessionActive.yachNick
        showname = showname || sessionActive.showname

        const isdependent = teamType && (teamType.type == 1 || teamType.type == 3) ? teamType.type : 0;

        return (
            <BoxInfo
                showDepart={isdependent}
                id={id}
                messageType={type}
                showimg={showimg || pic}
                showname={showname} 
                yachNick={yachNick}
                isHiddenSessionType={isHiddenSessionType}
                teamType={teamType}
                singleType={singleType}
                // busyIconStatus={busyIconStatus}
                showsign={sign}
                fullSign={fullSign}
                busyinfo={busyinfo}
                showNickName={showNickName}
                is_robot={is_robot}
                newDeptName={newDeptName}
                position={position}
                searchHistoryGuide={searchHistoryGuide}
                groupDocGuide={groupDocGuide}
                groupFileGuide={groupFileGuide}
                closeGroupDocTips={this.closeGroupDocTips}
                closeGroupFileTips={this.closeGroupFileTips}
                closeSearchHistoryTips={this.closeSearchHistoryTips}
                showRightModal={this.showRightModal}
                meetingSummaryClick={this.meetingSummaryClick}
                getUsermsgBoxRef={this.getUsermsgBoxRef}
            />
        );
    }
}

const mapStateToProps = state => ({
    sessionActive: state.sessionActive,
    sessionList: state.sessionList,
   // busyIconStatus:state.busyIconStatus
});

export default connect(mapStateToProps)(BoxInfoContainer);
