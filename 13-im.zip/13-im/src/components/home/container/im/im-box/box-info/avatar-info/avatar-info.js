// react
import React from 'react';

// util
import { config } from '@/utils/util';

// css
import css from './index.scss';

// 
export default props => {
    const { 
        showimg, 
        showTeamImgFlag,
        goUserInfo,
        goUserInfoParams
    } = props;

    let imgStyle = showTeamImgFlag ? css.teamUser: css.user;

    console.log('avatar-info 渲染次数')

    return(
        <div className={imgStyle} onClick={()=>goUserInfo(...goUserInfoParams)}>
            <img draggable="false" src={showimg} onError={(e) => {e.target.src=config.nim.showimg}}/>
        </div>
    )
}