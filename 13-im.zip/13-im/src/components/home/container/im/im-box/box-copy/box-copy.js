import React, { Component } from 'react';
import css from './index.scss';
import * as util from '@u/util.js';
import {connect} from 'react-redux';
import {message} from 'antd'

const { clipboard } = require('electron')

class BoxCopy extends Component {
    
    componentDidMount(){
        // 在整个文档上挂载右键事件和鼠标按下的事件。
        document.addEventListener('mousedown',(e)=>{this.mouseDownHandle(e)})
        document.addEventListener('contextmenu',(e)=>{this.contextmenuHandle(e)})
    }

    componentWillUnmount(){
        document.removeEventListener('mousedown',this.mouseDownHandle)
        document.removeEventListener('contextmenu',this.contextmenuHandle)
    }

    // 当鼠标右键时，判断有没有选中文字，有选中文字的话，根据选取和鼠标位置控制是否显示复制文字及显示位置。
    contextmenuHandle = (e)=>{
        e.preventDefault();
        if(!this.copyBox) return;
        if(!util.yachLocalStorage.ls('isSelectText')) return 
        this.selectedText = window.getSelection().toString();
        if(!this.selectedText || this.sendBoxArea) return this.copyBox.style.display = 'none';
        let select = window.getSelection().getRangeAt(0).getBoundingClientRect()
        if(e.x < select.x || e.x > select.x+select.width) return
        if(e.y < select.y || e.y > select.y+select.height) return
        let x = e.x
        let width = document.documentElement.clientWidth - (util.electron.isMac() ? 97 : 114)
        if(x > width) x = width
        this.copyBox.style.top = e.y + 2 + 'px';
        this.copyBox.style.left = x + 2 + 'px';
        this.copyBox.style.display = 'block';
    }

    // 点击选中文字，复制选中文字到剪切板，将复制提示消失。
    copySelect = ()=>{
        if(!this.selectedText){
            this.copyBox.style.display = 'none'
            return message.error(util.locale('im_copy_failure'),0.5)
        }
        let userSign = util.yachLocalStorage.ls('userInfoSignCopy')
        if(userSign && userSign.new){
            if(~this.selectedText.indexOf(userSign.new)) this.selectedText = this.selectedText.replace(userSign.new,userSign.all)
        }
        clipboard.writeText(this.selectedText.trim())
        message.success(util.locale('im_copy_success'),0.5)
        this.copyBox.style.display = 'none'
    }

    // 根据点击位置设置boxinfo，box-content，box-send的是否可选中文字属性。当点击了box-info,则box-content和box-send都不可选，其它两项同理
    boxSelectArea = (e)=>{
        let boxInfo = this.copyBox.nextElementSibling;
        let boxContent = boxInfo.nextElementSibling ;
        if(!boxInfo || !boxContent ) return false
        let height = document.documentElement.clientHeight , sendBoxH = this.props.boxSendHeight.height
        let sendBox = boxContent.nextElementSibling
        // 用点击的位置来判断是点击了boxinfo 还是点击了boxcontent，如果后期boxInfo高度更改，这里也要更改。
        // sendBoxH + 72为输入区的整体高度。
        let boxInfoHeight = util.electron.isMac() ? 62 : 90
        this.sendBoxArea = false
        if(e.y < boxInfoHeight) {
            boxInfo.style.userSelect = 'text'
            boxContent.style.userSelect = 'none'
            if(sendBox) sendBox.style.userSelect = 'none'
        } else if((e.y > boxInfoHeight && e.y+sendBoxH+72 <= height) || !sendBox){
            boxContent.style.userSelect = 'text'
            boxInfo.style.userSelect = 'none'
            if(sendBox) sendBox.style.userSelect = 'none'
        } else if(e.y+sendBoxH+72 > height && sendBox){
            if(!this.props.slideModal.kind) this.sendBoxArea = true
            sendBox.style.userSelect = 'text'
            boxInfo.style.userSelect = 'none'
            boxContent.style.userSelect = 'none'
        }
        return true
    }

    // 当是在侧边栏选中文字并右键出复制时，点击位置判断是否在侧边栏上。
    judgePosition = (e) => {
        let type = this.props.slideModal.kind
        let arr = {historicalRecord:450,record:540,scheduleInfo:400,remindInfo:430}
        let left = document.documentElement.clientWidth - e.x
        if(arr[type] && left < arr[type] || (!arr[type] && left < 332)) return true
        return false
    }

    // 当鼠标按下时，判断是否有选择文字，如果有的话，设置相对应的属性。
    mouseDownHandle = (e)=>{
        if(!this.copyBox) return
        // 有侧边栏并且点击侧边栏的关闭按钮，设置属性，返回。
        if(e.target.className == 'iconfont-yach yach-quanju-qunshezhi-guanbiqunshezhi'){
            util.yachLocalStorage.ls('isSelectText',false)
            this.copyBox.style.display = 'none'
            return
        }
        // 搜点击位置异常时，直接退出函数
        if(!this.boxSelectArea(e)) return
        // 有侧边栏并且点击的是非侧边栏位置，直接不显示复制文字。
        if(this.props.slideModal.kind && !this.judgePosition(e)) this.copyBox.style.display = 'none' ;
        // 如果有选中文字，在本地存储中存放一个isSelectText字段来记录当前是有选中文字的，这样点击链接之前就先阻止链接。
        let selectedText = window.getSelection().toString();
        if(selectedText) return util.yachLocalStorage.ls('isSelectText',true);
        // 如果没有选中文字，设置isSelectText为false，
        util.yachLocalStorage.ls('isSelectText',false)
    }

    render() {
        return (
            <div 
                ref={(dom)=>{this.copyBox = dom}} 
                className={css.copyBox}
            >
                <div className={`${css.copyMask} ${this.props.slideModal.kind ? css.slideModalMask : ''}`} onClick={()=>{this.copyBox.style.display = 'none';}}>
                    {
                        this.props.slideModal.kind && <>
                            <div className={css.topMask} onClick={()=>{this.copyBox.style.display = 'none';}}></div>
                            <div className={css.rightMask} onClick={()=>{this.copyBox.style.display = 'none';}}></div>
                        </>
                    }
                    
                </div>
                <div className={`${css.text} ${!util.electron.isMac() ? css.windowText : ''}`} onClick={this.copySelect}>{util.locale('im_copy')} {util.electron.isMac() ? '(⌘' : '(ctrl+'}C)</div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        boxSendHeight:  state.boxSendHeight,
        slideModal:state.slideModal,
    };
};

export default connect(mapStateToProps, null,)(BoxCopy);