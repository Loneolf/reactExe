import React from 'react'
import {withRouter} from 'react-router'
import {connect} from 'react-redux'

import * as util from '@u/util.js';
import BoxRecord from './box-record'

import {logDetailGet} from '@s/record/record-read'
import {logMystarlist, logReaded, logReadedList} from '@s/record/record-ope';
import {yachToMuse} from '@s/muse/muse-tab';


import {userFollowModify} from '@r/actions/user';
import {recordReadListClear, recordReadListModifyRead, recordReadListSet} from '@r/actions/record';
import {recordWriteModifyidSet} from '@r/actions/recordWrite';
import {workCurrSet} from '@r/actions/work';

class BoxRecordContaner extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            hasPower: true
        }
    }
    componentDidMount() {
        this.setMuseConfig()
        this.refreshFollow()
        this.getRecordDetail(this.props.recordDetailCurrid)
    }
    componentWillUnmount() {
        this.props.dispatch(recordReadListClear());
    }
    getRecordDetail = async id => {
        if (!id) return false
        let query = {}
        if (this.props.slideModal.params) {
            this.props.slideModal.params.forEach(item => {
                let key = Object.keys(item)[0]
                let value = item[key]
                query[key] = value
            })
        }
        let data = await logDetailGet({ log_id: id, ...query})
        if (data && data.code == 200) {
            this.props.dispatch(recordReadListSet([data.obj]));
            let isMine = data.obj.send_user_id == this.props.userInfo.id;
            !isMine && this.doRead(id);
        } else if (data && data.code == 10000){
            this.setState({
                hasPower :false
            })
        }
    }
    //设置muse配置
    setMuseConfig = async () => {
        let museToken = ''
        await util.yach.refreshToken();
        let yachToken = util.yachLocalStorage.ls('yach_usertoken')
        let data = await yachToMuse({token: yachToken});
        if (data && data.status == 200) {
            museToken = data.data.token;
        }
        util.yachLocalStorage.ls('muse_usertoken', museToken, 1);
    }
    //执行阅读
    doRead = async log_id => {
        let data = await logReaded({ log_id });
        if (data && data.code === 200) {
            this.refreshRead(log_id);
        }
    };
    //刷新已读列表
    refreshRead = async log_id => {
        let data = await logReadedList({ log_id });
        if (data && data.code === 200) {
            data.obj.list = data.obj.list.map(v => ({
                id: v.user_id,
                name: v.username,
                pic: v.avatar
            }))
            this.props.dispatch(recordReadListModifyRead(log_id, data.obj));
        }else if(data && data.code === 401){

        }
    };
    //更新关注列表
    refreshFollow = async () => {
        let data = await logMystarlist();
        if (data && data.code == 200) {
            this.props.dispatch(userFollowModify(data.obj.list));
        }
    }
    //打开用户面板
    openUserPanel = user => {
        let userData = {
            type: 'user-panel',
            user
        }
        window.postMessage(userData, '*')
    }
    //周报分享
    recordShare = card => {
        let postShareData = {
            type: 'weekly-share',
            card
        }
        window.postMessage(postShareData, '*');
    }
    //周报修改
    recordModify = card => {
        this.props.history.replace('/work');
        let modifyWorkData = {
            page: 'weekly',
            url: `${util.config.webHost}work/weekly/write?type=yach&record_id=${card._id}&yach_token=${util.yachLocalStorage.ls('yach_usertoken')}`
        }
        this.props.dispatch(workCurrSet(modifyWorkData))
        this.props.dispatch(recordWriteModifyidSet(card._id));
    }
    render(){
        const props = {
            ...this.state,
            content: this.props.recordReadList[0],
            recordShare: this.recordShare,
            recordModify: this.recordModify,
            openUserPanel: this.openUserPanel
        }
        return <BoxRecord {...props} />
    }
}

const mapStateToProps = state => ({
    userInfo: state.userInfo,
    slideModal: state.slideModal,
    recordDetailCurrid: state.recordDetailCurrid,
    recordReadList: state.recordReadList
})

export default connect(mapStateToProps)(withRouter(BoxRecordContaner))