// react
import React from 'react';

// css
import css from './index.scss';

import * as util from '@u/util.js';

export default (props) => {
    const {
        searchValue,
        handleInputChange,
        leftIconClick,
        handleClear
    } = props;

    return (
        <div className={css.inputContent}>
            <span onClick={leftIconClick.bind(this,null)} className={`${css.leftIcon} iconfont-yach yach-zuojiantou`} />
            <div className={css.inputOut}>
                <span className="icon iconfont iconsousuo" />
                <input 
                    id='fileSearchInput'
                    autoFocus={true}
                    placeholder={util.locale('im_group_file_search')}
                    value={searchValue}
                    onChange={(e)=>handleInputChange(e.target.value)}
                />      
                {
                    searchValue&&<em className={css.clear} onClick={handleClear}/>
                }
            </div>
        </div>
    );
};
