// react
import React from 'react';
// ImBox
import GroupDocSearch from './group-doc-search';
// connect
import { connect } from 'react-redux';
// util
import * as util from '@u/util.js';
// lodash
import debounce from 'lodash/debounce';
// server
import { spaceFileSearch, spaceFileList } from '@s/group/group-online-doc';
// redux
import {hideSlideModal} from '@/redux/actions/commonModal';

class GroupDocSearchContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state = {
        noSearch: true,
        resultDesc: util.locale('im_group_doc_start_search'),
        hasMore: true,
        searchValue: '',
        docList: [],
        total: 0,
        currentPage: 1,
        pagesize: 20,
        breadcrumbList: [{ name: util.locale('im_group_doc_all'), guid: '' }], //面包屑数据
    };

    componentDidMount() {
        this.getFileList = debounce(this.getFileList, 500);
    }

    componentWillUnmount() {}

    // 删除/重命名成功之后，立即请求列表数据，后端接口不能更新，前端操作数据更新
    refreshSearchList = (params) => {
        const { searchValue } = this.state;
        const regExp = new RegExp(searchValue.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1'), 'ig');
        let docList = [...this.state.docList];
        if (!docList.length) return;
        // 重命名
        if (params.isRename) {
            let data = docList.find((item) => {
                return item.guid === params.guid;
            });
            data.replaceName = params.name.replace(regExp, `<span style="color:#286CFB;">${searchValue}</span>`);
            this.setState({ docList });
        } else {
            // 删除
            const screenArr = docList.filter((item) => {
                return item.guid !== params.guid;
            });
            this.setState({ docList: screenArr });
        }
    };

    // 搜索列表接口
    getList = async (page, keyword) => {
        // const id = this.props.sessionActive.id;
        const id = window.session_active.id;
        if(!id) return;
        const { pagesize } = this.state;
        const params = {
            group_id: id,
            keyword,
            page,
            pagesize,
        };
        const res = await spaceFileSearch(params);
        const {code, obj = {}} = res || {};
        let docList = [],
            total = 0,
            currentPage = 0;
        if (code === 200) {
            const resultData = this.searchHighlighted(obj.list || [], keyword);
            docList = resultData;
            total = +obj.total;
            currentPage = +obj.currentPage;
        }
        return {
            docList,
            total,
            currentPage,
        }
    }

    // 搜索结果
    getFileList = async (value) => {
        if (!value) {
            this.setState({ resultDesc: util.locale('im_group_doc_start_search'), noSearch: true });
            // 列表数组清空  TODO
            return;
        }
        const s = await this.getList(1, value);
        const {docList, total, currentPage} = s || {};
        if (!docList.length) this.setState({ resultDesc: util.locale('im_group_doc_no_search_file'), noSearch: false });
        if (docList.length) {
            this.setState({
                resultDesc: '',
                noSearch: false,
                docList,
                total,
                currentPage,
                breadcrumbList: [{ name: util.locale('im_group_doc_all'), guid: '' }],
            });
        }
    };

    handleBack = () => {
        util.eventBus.emit('group-doc-search', 'back');
    };

    handleOnChange = (event) => {
        const value = event.target.value;
        this.setState({ searchValue: value });
        if(!value) event.target.focus()
        this.getFileList(value.trim());
    };

    handleInfiniteOnLoad = async () => {
        let {docList, total, currentPage, searchValue} = this.state;
        if (docList.length >= total) {
            this.setState({
                hasMore: false,
            });
            return;
        }
        const datas = await this.getList(currentPage + 1, searchValue);
        this.setState({
            docList: docList.concat(datas.docList),
            total: +datas.total,
            currentPage: +datas.currentPage,
        });

        if(datas.docList.length == 0){
            this.setState({
                hasMore: false,
            });
        }
    };

    // 搜索结果高亮
    searchHighlighted = (searchData, searchKye) => {
        if (!searchKye) return searchData;
        const regExp = new RegExp(searchKye.replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1'), 'ig');
        searchData.forEach((item) => {
            item.replaceName = item.name.replace(regExp, `<span style="color:#286CFB;">${searchKye}</span>`);
            item.creator = item.creator.replace(regExp, `<span style="color:#286CFB;">${searchKye}</span>`);
        });
        return searchData;
    };


    // 按esc键时，如果有值，将值情况，如果没值，侧边栏退出
    keyDownhandle = e => {
        if(e.key !== 'Escape') return
        if(!this.state.searchValue) return this.handleBack()
        this.setState({searchValue:'', resultDesc: util.locale('im_group_doc_start_search'), noSearch: true})
        
    }

    render() {
        const { noSearch, resultDesc, hasMore, docList,searchValue } = this.state;
        return (
            <GroupDocSearch
                {...this.props}
                noSearch={noSearch}
                resultDesc={resultDesc}
                searchValue={searchValue}
                handleBack={this.handleBack}
                handleOnChange={this.handleOnChange}
                setOKModal={this.setOKModal}
                hasMore={hasMore}
                docList = {docList}
                handleInfiniteOnLoad={this.handleInfiniteOnLoad}
                refreshSearchList={this.refreshSearchList}
                keyDownhandle={this.keyDownhandle}
            />
        );
    }
}

const mapStateToProps = (state) => {
    return {
        // sessionActive: state.sessionActive,
    };
};

export default connect(mapStateToProps, null)(GroupDocSearchContainer);
