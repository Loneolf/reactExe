// react
import React from 'react';
// util
import * as util from '@u/util.js';
// antd
import { Input } from 'antd';
// css
import css from './index.scss';
// components
import noSearchImg from '@a/imgs/online-doc-no-data.png';
import noDataImg from '@a/imgs/no-img.png';
import BoxGroupDocumentListContainer from '../../box-group-document-list/box-group-document-list-container'

export default class GroupDocSearch extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
      const {handleBack, 
            handleOnChange,
            noSearch,
            resultDesc,
            keyDownhandle,
            searchValue
      } = this.props;

      return(
          <div className={css.boxSearch}>
              <div className={css.search}>
                <span onClick={handleBack} className={`${css.iconBack} iconfont-yach yach-fanhui`}></span>
                <Input
                  autoFocus
                  allowClear
                  placeholder= {util.locale('im_group_doc_search')}
                  type="text"
                  value={searchValue}
                  onChange={handleOnChange}
                  prefix={<span className={`${css.input_icon} iconfont-yach yach-goutong-sousuoliaotianjilu`} />}
                  className={css.searchInput}
                  onKeyDown = {keyDownhandle}
                />
              </div>

              <div>
                {!noSearch ? 
                  (
                    !resultDesc ? <BoxGroupDocumentListContainer {...this.props} /> : 
                      <div className={css.noSearch}>
                        <img src={noDataImg} className={css.noDataImg} />
                        <p>{resultDesc}</p>
                      </div>
                  )
                :
                (
                  <div className={css.noSearch}>
                    <img src={noSearchImg} />
                    <p>{resultDesc}</p>
                  </div>
                )
                }
              </div>
          </div>
      )
    }
}
