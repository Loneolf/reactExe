 
// react
import React from 'react';
// css
import css from './index.scss';
// components
import BoxInfo from './box-info/box-info-container';
import BoxContent from './box-content/box-content-container';
import BoxSend from './box-send/box-send-container';
import BoxReply from './box-reply/box-reply-container';
import BoxMultipleForwardingContainer from './box-multiple-forwarding/box-multiple-forwarding-container'
import AddRobotDialog from "./box-setting/setting-bottom/robots-settings/add-robot/add-robot"
import BoxCopy from './box-copy/box-copy'

// ImBox
export default class ImBox extends React.Component {
   
    constructor(props){
        super(props);
    }
      /**
      * isschedule-replaced by isHiddenSessionType
      */
      render() {       
        const {isHiddenSessionType, componentNames, teamType, showRobotDialog, singleType} = this.props;
        return (
              <div className={css.box}>
                  <BoxCopy />
                  
                  <BoxInfo isHiddenSessionType={isHiddenSessionType} teamType={teamType} singleType={singleType}/>
                  {
                      isHiddenSessionType ? componentNames :<BoxContent setBoxContentRef={this.props.setBoxContentRef} getHeight={this.props.getHeight} groupType={teamType.type} />
                  }
                  {this.props.replyShow && <BoxReply setBoxReplyRef={this.props.setBoxReplyRef} />}

                  {(!isHiddenSessionType && !this.props.showCheckbox) && <BoxSend teamType={teamType}  />}

                  {this.props.showCheckbox && <BoxMultipleForwardingContainer />}
             
                  {showRobotDialog?<AddRobotDialog></AddRobotDialog>:null}
              </div>
          );
      }
  }
  
