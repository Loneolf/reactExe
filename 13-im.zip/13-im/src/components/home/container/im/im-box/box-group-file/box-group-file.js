import React, { useState, useEffect, useCallback } from 'react';
import { connect } from 'react-redux';
// antd
import { Menu, Dropdown, Button, Input, message } from 'antd';
import * as util from '@u/util.js';

import css from './index.scss';
import GroupFileSearch from './group-file-search/index';
import GroupFileList from './group-file-list/index';
import GroupFileUpload from './group-file-upload/group-file-upload';
import GroupFileUploadList from './group-file-upload/group-file-upload-list';

// imgs
import folder from '@a/imgs/doc_normal/dir.png';
import uploadImg from '@a/imgs/group_file/upload.png';
import uploadFolderImg from '@a/imgs/group_file/uploadFolder.png';

import { fileAndFolderHasDelete } from '@s/group/group-file';

function BoxGroupFileList(props) {
    const [isSearch,setIsSearch] = useState(false);

    useEffect(() => {
      util.sensorsData.track('PageView_Chat', { pageName: '01-138' });
      return ()=>{
        //卸载组件
      }
    }, []);

    const handleSearch = () => {
        setIsSearch(true);
    };
    const hanleGoList = (value) => {
        setIsSearch(false);
    };
    const handleCreateBtn = () => {
      util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-241' });
    }
    const handleMenuClick = (e) => {
      e.domEvent.stopPropagation();
      //处理新建和上传逻辑
      if(e.key == 'newFolder'){
        //新建文件夹
        judgeCanNewFolder()
      }else{
        util.eventBus.emit('group-file-upload',e.key,props.groupFileLastBreadcrumb);
      }
      util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: e.key == 'newFolder'?'01-242': '01-243'});
    }
    const judgeCanNewFolder = async() =>{
      const {relation_id} = props.groupFileLastBreadcrumb
      if(relation_id){
        const res = await fileAndFolderHasDelete({relation_id})
        if(!res || res.code != 200 || !res.obj) return util.eventBus.emit('group-file-list-return-all')
        if(res.obj.result) {
          message.error(util.locale('im_group_file_judge_can_upload'))
          util.eventBus.emit('group-file-list-return-all')
          return
        }
      }
      util.eventBus.emit('group-file-create-input-show',true);
    }
    const docMenu = (
      <Menu
          onClick={(e) => {
              handleMenuClick(e);
          }}
          className={css.dropdown_menu}
      >
          <Menu.Item key="newFolder">
              <img src={folder} />
              {util.locale('im_group_file_new_folder')}
          </Menu.Item>
          {util.electron.isMac() &&
            <Menu.Item key="dir">
              <img src={uploadImg} />
              <span>{util.locale("im_group_file_upload_file_folder")}</span>
            </Menu.Item>
          }
          {!util.electron.isMac() &&
            <Menu.Item key="file">
              <img src={uploadImg} />
              <span>{util.locale("im_group_file_upload_file")}</span>
            </Menu.Item>
          }
          {!util.electron.isMac() &&
            <Menu.Item key="dir">
              <img src={uploadFolderImg} />
              <span>{util.locale("im_group_file_upload_folder")}</span>
            </Menu.Item>
          }
      </Menu>
  );

    return (
      <div className={css.boxGroupFileListWrap}>
        {
          isSearch ?
          <GroupFileSearch hanleGoList={hanleGoList}/> : 
          (
            <>
              <div className={css.searchBox}>
                <Input
                    placeholder={util.locale('im_group_file_search')}
                    prefix={
                        <span
                            className={`${css.input_icon} iconfont-yach yach-goutong-sousuoliaotianjilu`}
                        />
                    }
                    readOnly
                    onClick={handleSearch}
                />
                <Dropdown overlay={docMenu} trigger={['click']}>
                    <Button className={css.new_create} onClick={handleCreateBtn}>
                      {util.locale('im_group_file_new')}
                    </Button>
                </Dropdown>
              </div>
              <GroupFileUploadList />
              <GroupFileList getFileParams={props.getFileParams} />
            </>
          )
        }
        <GroupFileUpload />
      </div>
    );
}

const mapStateToProps = (state) => {
    return {
      groupFileLastBreadcrumb: state.groupFileLastBreadcrumb
    };
};

export default connect(mapStateToProps)(BoxGroupFileList);
