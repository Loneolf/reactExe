import React, { Component } from 'react';
import { Input, Switch, Button, Spin } from 'antd';
import { connect } from 'react-redux';
import copy from 'copy-to-clipboard';

import * as util from '@u/util.js';
import { DetailType, ListType, PageType } from '@r/reducers/robots';
import { robotChangeState, toggleAddRobotWindow, robotDetailModalSet } from '@r/actions/robots';
import {
    ROBOTS_ADD_ROBOT_FETCH,
    ROBOTS_DEL_ROBOT_FETCH,
    ROBOTS_SAVE_ROBOT_FETCH,
    ROBOTS_RESET_ROBOT_FETCH,
    ROBOTS_INUSE_FETCH
} from '@r/actiontype/robots';
import CommonModal from '@/components/common/common-modal';

import style from './style.scss';
class NoticeCommonRobotDetail extends Component {
    constructor(props) {
        super(props);
        const robotConf = util.yachLocalStorage.ls('platformConfigRobot') || {};
        this.state = {
            // 交互状态
            webhookCopy: false, //是否复制成功
            secretCopy: false,
            //yach.js 中存储的配置链接
            customizedDoc: robotConf[100070001],
            customizedSignDoc: robotConf[100070003],
            thirdPartyDoc: robotConf[100070002],
            modalInfo: {
                title: util.locale("im_reminder"),
                content: '',
                okText: util.locale("common_ok"),
                cancelText: util.locale("im_cancel"),
                onOk: function() {},
                onCancel: () => this.hideModal()
            }
        };
        this.goEditList = this.goEditList.bind(this);
    }
    showModal = () => {
        this.state.modalInfo = {
            title: util.locale("im_delete_robot"),
            content: util.locale("im_confirm_delete_robot"),
            okText: util.locale("im_yes"),
            cancelText: util.locale("im_no"),
            onOk: this.props.delRobot,
            onCancel: () => this.hideModal()
        };
        this.props.robotDetailModalSet(true);
    };

    hideModal = () => {
        this.props.robotDetailModalSet(false);
    };

    changeName = e => {
        const value = e.target.value;
        if (this.strLen(value) > 40) return;
        // this.setState({
        //     name:value
        // })

        this.props.robotChangeState({
            selectedRobot: {
                ...this.props.item,
                name: value
            }
        });
    };
    openLink(key) {
        // 跳转浏览器窗口
        let url = this.state.customizedSignDoc;
        if (key == 'conf') {
            url = this.confLink;
        }
        window.open(url);
    }
    reset(type) {
        // 重置确认
        switch (type) {
            case 'secret':
                this.state.modalInfo = {
                    title: null,
                    content: util.locale("im_after_resetting_tip"),
                    okText: util.locale("im_reset"),
                    cancelText: util.locale("im_cancel"),
                    onOk: () => this.resetSecret(),
                    onCancel: () => this.hideModal()
                };
                break;
            case 'webhook':
                this.state.modalInfo = {
                    title: null,
                    content: util.locale("im_after_resetting_tip_webhook"),
                    okText: util.locale("im_reset"),
                    cancelText: util.locale("im_cancel"),
                    onOk: () => this.resetHook(),
                    onCancel: () => this.hideModal()
                };

            default:
                break;
        }
        this.props.robotDetailModalSet(true);
    }
    resetSecret() {
        this.props.resetRobot('secret');
    }
    resetHook() {
        this.props.resetRobot('webhook');
    }
    copy(type) {
        if (type == 'webhook') {
            copy(this.props.item.webhook);
            this.webhookTimer && clearTimeout(this.webhookTimer);
            this.webhookTimer = setTimeout(() => {
                this.setState({
                    [type + 'Copy']: false
                });
            }, 2000);
        }
        if (type == 'secret') {
            copy(this.props.item.secret);
            this.secretTimer && clearTimeout(this.secretTimer);
            this.secretTimer = setTimeout(() => {
                this.setState({
                    [type + 'Copy']: false
                });
            }, 2000);
        }
        this.setState({
            [type + 'Copy']: true
        });
    }
    clearTimer() {
        //清除 copy 的计时器
        this.webhookTimer && clearTimeout(this.timerHandler);
        this.secretTimer && clearTimeout(this.secretTimer);
    }

    strLen = sString => {
        //英文,非英文字符数判断
        let j = 0;
        let s = sString;
        if (!s) return j;
        for (let i = 0; i < s.length; i++) {
            if (s.substr(i, 1).charCodeAt(0) > 255) j = j + 2;
            else j++;
        }
        return j;
    };
    componentWillUnmount() {
        this.clearTimer();
    }

    toggleEnabled(e) {
        this.props.robotChangeState({
            selectedRobot: {
                ...this.props.item,
                status: e
            }
        });
    }
    get confLink() {
        const { robot_type_id } = this.props.item;
        // 机器人分类（0:会话机器人1:第三方机器人2:自定义机器人）
        return robot_type_id == 2 ? this.state.thirdPartyDoc : this.state.customizedDoc;
    }
    goEditList() {
        this.props.inUseRobotsFetch();
        this.props.robotChangeState({
            pageType: PageType.LIST,
            listType: ListType.MODIFY,
            selectedRobot: null
        });
    }
    get isEdit() {
        const { detailType } = this.props;
        return detailType == DetailType.MODIFY;
    }
    get isAdd() {
        const { detailType } = this.props;
        return detailType == DetailType.ADD;
    }
    get isAddSuccess() {
        const { detailType } = this.props;
        return detailType == DetailType.ADDSUCCESS;
    }
    get isReadOnly() {
        const { detailType } = this.props;
        return detailType == DetailType.READ;
    }

    render() {
        const { item, modalVisible, saveRobot, addRobot, closeDialog, loading, confirmLoading } = this.props;
        return (
            <div className={style.commonNotice}>
                <div style={{ height: '370px', overflow: 'auto', paddingBottom: '20px' }}>
                    <div className={style.avatar}>
                        <img src={item.robot_icon_bigger} alt="" />
                    </div>
                    {this.isAddSuccess ? (
                        // 添加成功页
                        <div className={style.row}>
                            <div className={`${style.label} ${style.statue}`}>{util.locale("im_add_status")}</div>
                            <div className={style.text}>{util.locale("im_added")}</div>
                            <span
                                style={{ fontSize: '6px', color: '#4cb666', marginLeft: '7px' }}
                                className="iconfont-yach  yach-tianjiajiqiren-tianjiachenggong"
                            ></span>
                        </div>
                    ) : (
                        <div className={style.row}>
                            <div className={`${style.label} ${style.name} ${style.required}`}>{util.locale("im_name_robot")}</div>
                            <Input
                                disabled={this.isReadOnly}
                                style={{ width: '380px' }}
                                onChange={!this.isReadOnly ? e => this.changeName(e) : null}
                                value={item.name}
                            />
                        </div>
                    )}
                    {this.isEdit || this.isAddSuccess || this.isReadOnly ? (
                        <React.Fragment>
                            <div
                                className={`${style.row} ${this.isEdit ? style.edit : ''} ${
                                    this.isAddSuccess ? style.isAddSuccess : ''
                                } ${this.isReadOnly ? style.isReadOnly : ''}`}
                            >
                                <div className={`${style.label} ${style.webhook}`}>Webhook</div>
                                <Input className={`${style.webhook}`} value={item.webhook} />
                                <div>
                                    <button className={style.copyBtn} onClick={() => this.copy('webhook')}>
                                        {util.locale("im_copy")}
                                        {this.state.webhookCopy ? (
                                            <span
                                                style={{
                                                    fontSize: '14px',
                                                    color: '#4cb666',
                                                    right: '7px',
                                                    position: 'absolute'
                                                }}
                                                className="iconfont-yach yach-tianjiajiqiren-lianjiefuzhichenggongtishi"
                                            ></span>
                                        ) : null}
                                    </button>
                                    {this.isEdit ? (
                                        <button className={style.resetBtn} onClick={() => this.reset('webhook')}>
                                            {util.locale("im_reset")}
                                        </button>
                                    ) : null}
                                </div>
                            </div>
                            {item.secret && (
                                <React.Fragment>
                                    <div
                                        className={`${style.row} ${this.isEdit ? style.edit : ''} ${
                                            this.isAddSuccess ? style.isAddSuccess : ''
                                        } ${this.isReadOnly ? style.isReadOnly : ''}`}
                                    >
                                        <div className={`${style.label} ${style.secret}`}>{util.locale("im_key")}</div>
                                        <Input className={`${style.secret}`} value={item.secret} />
                                        <div>
                                            <button
                                                className={` ${style.btn} ${style.copyBtn}`}
                                                onClick={() => this.copy('secret')}
                                            >
                                                {util.locale("im_copy")}
                                                {this.state.secretCopy ? (
                                                    <span
                                                        style={{
                                                            fontSize: '14px',
                                                            color: '#4cb666',
                                                            right: '7px',
                                                            position: 'absolute'
                                                        }}
                                                        className="iconfont-yach yach-tianjiajiqiren-lianjiefuzhichenggongtishi"
                                                    ></span>
                                                ) : null}
                                            </button>
                                            {this.isEdit ? (
                                                <button className={style.resetBtn} onClick={() => this.reset('secret')}>
                                                    {util.locale("im_reset")}
                                                </button>
                                            ) : null}
                                        </div>
                                    </div>
                                    <div className={style.secretTip}>
                                        <span>{util.locale("im_key_refer_doc")}</span>
                                        <span
                                            onClick={() => this.openLink('sign')}
                                            data-href={this.state.customizedSignDoc}
                                            className={style.linkLike}
                                        >
                                            {util.locale("im_documentation")}
                                        </span>
                                    </div>
                                </React.Fragment>
                            )}
                            <div className={style.row}>
                                <div className={`${style.label}`}>{util.locale("im_type_of")}</div>
                                <div className={style.text}>{item.type_name}</div>
                            </div>
                            {this.isEdit || this.isReadOnly ? (
                                <div className={style.row}>
                                    <div className={`${style.label} ${style.enabled}`}>{util.locale("im_whether_enable")}</div>
                                    <div>
                                        <Switch
                                            checked={item.status == '1'}
                                            onChange={!this.isReadOnly ? e => this.toggleEnabled(e) : null}
                                        />
                                    </div>
                                </div>
                            ) : null}
                        </React.Fragment>
                    ) : null}
                    {this.isAdd ? (
                        <div className={style.row}>
                            <div className={`${style.label}`}>{util.locale("im_type_of")}</div>
                            <div className={style.text}>{item.type_name}</div>
                        </div>
                    ) : null}
                    {this.isEdit || this.isReadOnly ? (
                        <div className={style.row}>
                            <div className={`${style.label}`}>{util.locale("im_add_by")}</div>
                            <div className={style.text}>{item.cuser_name}</div>
                        </div>
                    ) : null}
                </div>
                {this.isAdd ? (
                    <div className={`${style.noticeFooter} ${style.add}`}>
                        <div className={style.left}>
                            <div onClick={() => this.openLink('conf')} className={style.confSec}>
                                <span
                                    style={{ fontSize: '14px' }}
                                    className="iconfont-yach yach-bianjijiqiren-peizhishuoming"
                                ></span>
                                <span className={style.conf}>{util.locale("im_configuration_instructions")}</span>
                            </div>
                        </div>
                        <div className={style.btnGroup}>
                            <button className={`${style.btn}`} onClick={this.goEditList}>
                                {util.locale("im_cancel")}
                            </button>

                            <Button
                                loading={loading}
                                style={{ marginLeft: '30px' }}
                                className={`${style.primary} ${style.btn}`}
                                onClick={addRobot}
                            >
                                {util.locale("common_robot_add")}
                            </Button>
                        </div>
                    </div>
                ) : null}
                {this.isAddSuccess ? (
                    <div className={`${style.noticeFooter} ${style.add}`}>
                        <div className={style.left}>
                            <div onClick={() => this.openLink('conf')} className={style.confSec}>
                                <span
                                    style={{ fontSize: '14px' }}
                                    className="iconfont-yach yach-bianjijiqiren-peizhishuoming"
                                ></span>
                                <span className={style.conf}>{util.locale("im_configuration_instructions")}</span>
                            </div>
                        </div>
                        <div className={style.btnGroup}>
                            <button
                                style={{ marginLeft: '30px' }}
                                className={`${style.primary} ${style.btn}`}
                                onClick={closeDialog}
                            >
                                {util.locale("im_done")}
                            </button>
                        </div>
                    </div>
                ) : null}
                {this.isEdit || this.isReadOnly ? (
                    <div className={`${style.noticeFooter} ${style.edit}`}>
                        <div className={style.left}>
                            <div onClick={() => this.openLink('conf')} className={style.confSec}>
                                <span
                                    style={{ fontSize: '14px' }}
                                    className="iconfont-yach yach-bianjijiqiren-peizhishuoming"
                                ></span>
                                <span className={style.conf}>{util.locale("im_configuration_instructions")}</span>
                            </div>
                            {this.isEdit ? (
                                <div className={style.delSec}>
                                    <span
                                        style={{ fontSize: '14px' }}
                                        className="iconfont-yach yach-bianjijiqiren-shanchujiqiren"
                                    ></span>
                                    <span onClick={this.showModal} className={style.delText}>
                                        {util.locale("im_delete_robot")}
                                    </span>
                                </div>
                            ) : null}
                        </div>
                        <div className={style.btnGroup}>
                            <button className={`${style.btn}`} onClick={this.goEditList}>
                                {util.locale("im_cancel")}
                            </button>

                            {this.isEdit ? (
                                <Button
                                    loading={loading}
                                    onClick={saveRobot}
                                    style={{ marginLeft: '30px' }}
                                    className={`${style.primary} ${style.btn}`}
                                >
                                    {util.locale("im_save")}
                                </Button>
                            ) : null}
                        </div>
                    </div>
                ) : null}

                <CommonModal
                    modalTile={this.state.modalInfo.titile}
                    okText={this.state.modalInfo.okText}
                    cancelText={this.state.modalInfo.cancelText}
                    modalVisible={modalVisible}
                    setOKModal={this.state.modalInfo.onOk}
                    setonCancelModal={this.hideModal}
                    modalContent={this.state.modalInfo.content}
                    confirmLoading={confirmLoading}
                />
            </div>
        );
    }
}
const mapDispatchToProps = dispatch => {
    return {
        closeDialog: () => {
            dispatch(toggleAddRobotWindow());
        },
        robotChangeState: v => dispatch(robotChangeState(v)),
        robotDetailModalSet: v => dispatch(robotDetailModalSet(v)),
        addRobot: () => dispatch({ type: ROBOTS_ADD_ROBOT_FETCH }),
        delRobot: () => dispatch({ type: ROBOTS_DEL_ROBOT_FETCH }),
        saveRobot: () => dispatch({ type: ROBOTS_SAVE_ROBOT_FETCH }),
        resetRobot: key => dispatch({ type: ROBOTS_RESET_ROBOT_FETCH, payload: key }),
        inUseRobotsFetch: () => dispatch({ type: ROBOTS_INUSE_FETCH })
    };
};
const mapStateToProps = (state, ownProps) => ({
    modalVisible: state.robots.modalVisible,
    loading: state.robots.loading,
    confirmLoading: state.robots.confirmLoading
});

export default connect(mapStateToProps, mapDispatchToProps)(NoticeCommonRobotDetail);
