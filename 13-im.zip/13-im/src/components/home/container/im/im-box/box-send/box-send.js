// react
import React from 'react';

// css
import css from './index.scss';

// antd
import { Input, Menu, Popover, Button, Dropdown, Tooltip, Modal } from 'antd';

import EmojiModalContainer from '@c/common/expression-tab/expression-tab-container';
import UserAt from '@c/common/user-at/user-at-container';
import BoxSendResize from './box-send-resize/box-send-resize'
import Draft from './box-send-editor/box-send-editor-container'

// TextArea
const { TextArea } = Input;
// util
import * as util from '@u/util.js';
import _ from "lodash";

// BoxSend UI 组件不要随意改造成类组件！
export default class BoxSend extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidMount = () => {}

    handleScreenCutEnter=()=>{
        this.timeInterval=setTimeout(()=>{
            this.props.handleScreenCutPopover(true);
        },100)
    }
    handleScreenCutLeave=()=>{
        this.timeInterval && clearTimeout(this.timeInterval);
        this.timeInterval=null;
        this.props.handleScreenCutPopover(false);
    }
    
    componentDidUpdate(preProps) {
        const { ismute,ismanager} = preProps;
        if (ismute !== this.props.ismute || ismanager !== this.props.ismanager) {
            const M = this.props.ismute && !this.props.ismanager;
            if (!M) {
                //document.getElementById('sendBox').focus()
            }
        }

    }

    render() {
        const {
            handleCopy,
            handlePasteClick,
            selectedText,
            ismute,
            ismanager,
            screenCutPopover,
            screenCutPopoverClick,
            startCall,
            videoSession,
            teamType,
            messageType,
            onlineMeeting,
            emojiContentVisible,
            fileChange,
            filesModleVisible,
            filesModleVisibleHandleOk,
            filesModleVisibleHandleCancel,
            openCalendar,
            createVote,
            breakPaste,
            excelData,
            excelTurnImgType,
            showChooseExcelModal,
            excelTurnImg,
            excelKeepText,
            excelModalCancel,
            turnImg
        } = this.props;
        let sendButtonStyle = this.props.textInputValue
            ? css.buttonActive
            : css.buttonDisable;
                   
        const M = ismute && !ismanager;
        const shutUpClass = M ? css.stopActive : '';

        const emojiContent = (
            <div>
                {emojiContentVisible && <EmojiModalContainer clickEmojiItem={emojiName =>this.props.clickEmojiItem(emojiName)}
                    handleVisibleChange = {isShow => this.props.handleVisibleChange(isShow)}
                />}
            </div>
        );

        const menu = (
            <Menu>
                <Menu.Item className="inputFileItem">
                    <span>{util.locale("im_sent_doc")}</span>
                    <input
                        className="inputFile"
                        type="file"
                        ref="file"
                        name="img"
                        onChange={this.props.fileChange}
                    />
                </Menu.Item>
            </Menu>
        );
        const contextMenu = (
            <Menu className="contextMenuItem">
              <Menu.Item disabled={!selectedText} key="1" onClick={handleCopy}>{util.locale("im_copy")}</Menu.Item>
              <Menu.Item key="2" onClick={handlePasteClick}>{util.locale("im_paste")}</Menu.Item>
            </Menu>
        );

        const callMenu = (
            //  onClick={voiceSession}
            <Menu className="">
              <Menu.Item key="1" onClick={startCall}>{util.locale('im_voice_calls')}</Menu.Item>
              <Menu.Item key="2" onClick={videoSession}>{util.locale('media_online_meeting')}</Menu.Item>
            </Menu>
        )

        let sendBoxText = ''
        const isDefault = this.props.sendType == 'default' ? true : false
        
        if (util.electron.isMac()) {
            
            const classSend = isDefault == true ? 'yach-goutong-shuruqu-fasongicon-moren' : 'yach-goutong-shuruqu-zhehangicon-moren'

            const classBr = isDefault == true ? 'yach-goutong-shuruqu-zhehangicon-moren' : 'yach-goutong-shuruqu-fasongicon-moren'

            sendBoxText = (
                <div className={css.send_box} style={{display: 'flex'}}>
                    <span className={`${css.send_icon} iconfont-yach ${classSend}`}/>
                    <span className={css.send_text}>{util.locale("im_send")}</span>
                    /
                    <span className={`${css.send_icon} ${css.moren_icon} iconfont-yach ${classBr}`}/>
                    {util.locale("im_newline")}
                </div>
            )
        } else {
            sendBoxText = (
                `${isDefault == true ? 'Enter' : 'Ctrl+Enter'}${util.locale("im_send")}，${isDefault == true ? 'Ctrl+Enter' : 'Enter'}${util.locale("im_newline")}`
            )
        }

        // 发送文件按钮  win和mac差异化显示
        const inputButton = ()=>{
            const content = (
                <>
                   <p onClick={_.debounce( ()=>{ fileChange('file')},200) }>{util.locale('im_sent_doc')}</p>
                   <p onClick={_.debounce( ()=>{ fileChange('dir')},200) }>{util.locale('im_sent_bolders')}</p>
                </>
              );
            if (util.electron.isMac()) {
               return(
                    <>
                      <input
                        className="inputFile"
                        type="button"
                        ref="file"
                        onClick={fileChange}
                        id="fileInput"
                        style={{ display: 'none' }}
                    />
                     <Tooltip
                        placement='top'
                        overlayClassName='boxSendTooltip'
                        title={util.locale('im_file_uoliad_dir_common_send')}
                     >
                        <label
                            className="icon iconfont-yach yach-149goutong-huihuachuangkou-wenjian"
                            htmlFor="fileInput"
                        />
                    </Tooltip> 
                 </>
               )
            }
            return(
                <Popover content={content}
                    placement="topLeft"
                    overlayClassName="inputfile"
                    visible={this.props.visibleFileable}
                    onVisibleChange={this.props.handleVisibleChangeFile}
                >
                <span className="icon iconfont-yach yach-149goutong-huihuachuangkou-wenjian" />
            </Popover>
            )   
        };

        let shortCutInfo = util.yachLocalStorage.ls('systemset_shortcut') || {};
        const screenShotText = shortCutInfo && shortCutInfo.screenShot && shortCutInfo.screenShot.text

        return (
            <div className={ css.boxSend + util.style.getWinStyle(css, 'boxSendWin')} id='sendBox'>
                <BoxSendResize />

                 {/* 发送文件夹确认model */}
                <Modal 
                    visible      = { filesModleVisible.show }
                    onOk         = { filesModleVisibleHandleOk } 
                    onCancel     = { filesModleVisibleHandleCancel }
                    maskClosable = {!1}
                    width        = {416}
                    closable     = {!1}
                    style        = {{height: 144, borderRadius:6 }}
                    bodyStyle    = {{fontSize:14, fontWeight:500, color:'#2F3238' }}
                    centered
                > 
                    <p>{util.locale('im_file_uoliad_dir_common_dialog').replace('N',filesModleVisible.num)}</p>
                </Modal>
                
                <Modal
                    title={<div className='excelTurnImgModalBoxTitle'><h3>{util.locale('im_paste_format')}</h3><span onClick={excelModalCancel} className='iconfont-yach yach-lujing'></span></div>}
                    wrapClassName='excelTurnImgModalBox'
                    visible={showChooseExcelModal}
                    onOk={excelKeepText}
                    onCancel={excelTurnImg}
                    okText={util.locale('im_canvert_text')}
                    cancelText={util.locale('im_canvert_img')}
                    okType='default'
                    maskClosable={false}
                    closable={false}
                    centered
                >
                    <img className='pastExcelTurnImg' src={excelData && excelData.list[0] && excelData.list[0].base64} />
                </Modal>

                <div className={css.toolbar + ' '+shutUpClass} id='sendTools'>
                    <div className={css.item}>
                      
                        { inputButton() }

                        <Popover content={emojiContent}
                            getPopupContainer={()=> document.getElementById('sendBoxEmojiContent')}
                            trigger="click"
                            visible={emojiContentVisible}
                            onVisibleChange={this.props.handleVisibleChange}
                        >
                            <span className="icon iconfont-yach yach-149goutong-huihuachuangkou-biaoqing" id="sendBoxEmojiContent"/>
                        </Popover>

                        <span
                            onClick={(e)=>{screenCutPopoverClick(e,
                                (util.yachLocalStorage.ls('systemset_general') || {})['screenshot']
                            )}}
                            className="icon iconfont-yach yach-149goutong-huihuachuangkou-jietu"
                            onMouseEnter={this.handleScreenCutEnter}
                            onMouseLeave={this.handleScreenCutLeave}
                        >
                            {
                                screenCutPopover?<div className={css.screenCutPopover}>
                                    <div onClick={(e)=>{screenCutPopoverClick(e,false)}}>{screenShotText ? util.locale("im_screenshot")+'（'+screenShotText+'）': util.locale("im_screenshot")}</div>
                                    <div onClick={(e)=>{screenCutPopoverClick(e,true)}}>{util.locale("im_screenshot_and_hide_the_TALK_window")}</div>
                                </div>:null
                            }
                        </span>
                        {
                            // 普通群/会议群
                            messageType == 'team' && (
                                teamType.type !== 1 && 
                                <Tooltip title={util.locale('media_online_meeting')} 
                                    overlayClassName='boxSendMeeting'
                                >
                                        <span
                                            className={`icon iconfont-yach yach-149goutong-huihuachuangkou-huiyi`}
                                            onClick={_.debounce(onlineMeeting,500)}
                                        />
                                </Tooltip>
                            )
                        }
                        {
                            // 部门群
                            messageType == 'team' && (
                                teamType.type === 1 &&
                                <Tooltip title={util.locale('media_section_meeting')} overlayClassName='boxSendMeeting'>
                                    <span
                                        className={`icon iconfont-yach yach-147_huihua_bumenqun_moren` }
                                        onClick={_.debounce(onlineMeeting,500)}
                                    />
                                </Tooltip>
                            )
                        }
                        {this.props.isHiddenVideo() && <>  
                            <Dropdown overlay={callMenu} placement="topCenter">
                                <span  
                                    className="icon iconfont-yach yach-149goutong-huihuachuangkou-huiyi" 
                                />
                            </Dropdown>
                        </>
                        }
                        <div className={css.toDoBox}>
                            <Tooltip
                                placement='top'
                                overlayClassName='boxSendTooltip'
                                title={util.locale('im_todo')}
                            >
                                <span 
                                    onClick={this.props.toDo} 
                                    className="icon iconfont-yach yach-149goutong-huihuachuangkou-todo" 
                                />
                            </Tooltip>
                        </div>
                        <div className={css.remind}>
                            <Tooltip
                                placement='top'
                                overlayClassName='boxSendTooltip'
                                title={util.locale('calendar_top_tab_remind')}
                            >
                                <span 
                                    onClick={this.props.remind} 
                                    className="icon iconfont-yach yach-149goutong-huihuachuangkou-tixing" 
                                />
                            </Tooltip>
                        </div>
                        <div className={css.calendar}>
                            <Tooltip
                                placement='top'
                                overlayClassName='boxSendTooltip'
                                title={util.locale('calendar_top_tab_schecule')}
                            >
                                <span 
                                    onClick={openCalendar} 
                                    className="icon iconfont-yach yach-149goutong-huihuachuangkou-rili" 
                                />
                            </Tooltip>
                        </div>
                        {
                            //群
                            messageType == 'team' && (
                                <Tooltip 
                                    title={util.locale('im_vote_create')} 
                                    overlayClassName='boxSendMeeting'
                                >
                                    <span
                                        className={`icon iconfont-yach yach-149goutong-huihuachuangkou-toupiao`}
                                        onClick={createVote}
                                    />
                                </Tooltip>
                            )
                        }
                    </div>

                </div>
                <div className={ css.content + ' '+ shutUpClass + util.style.getWinStyle(css, 'contentWin') } id="draft-content">
                    {/* <Dropdown
                        overlay={contextMenu} 
                        trigger={['contextMenu']}
                        disabled ={ M }
                        onVisibleChange={(visible) => {}}>
                        <TextArea
                            id='sendBox'
                            placeholder={ M ? util.locale("im_banned_by_the_administrator") : util.locale("im_please_enter_content")}
                            disabled={true}
                            maxLength={2000}
                            ref={el => this.props.inputMessagesEndEl(el)}
                            value={M ? '':this.props.textInputValue}
                            autoFocus
                            style={{ height: '100%'}}
                            onChange={this.props.textareaValue}
                            onKeyDown={this.props.handleKeyPress}
                        />
                    </Dropdown> */}
                    <Draft 
                        disabled={M}
                        sendImageAndMsgAll={this.props.sendImageAndMsgAll}
                        userAtShow={this.props.userAtShow}
                        userAtClose={this.props.closeUserAt}
                        sendType={this.props.sendType}
                        handlePaste={this.props.handlePaste}
                        breakPaste={breakPaste}
                        turnImg={turnImg}
                        excelTurnImgType={excelTurnImgType}
                    />
                </div>
                <div className={css.btn + ' '+shutUpClass}>
                    <div className={css.btn_item} onClick={this.props.sendImageAndMsgAll}>
                        <Button className={sendButtonStyle}>{util.locale("im_send")}</Button>
                    </div>
                    <div className={css.msg}>{sendBoxText}</div>
                </div>
                <div
                    className={css.groupPeople + ' '+shutUpClass}
                    style={{'bottom':`${this.props.boxSendHeight.height+73}px`}}
                >
                    {this.props.sessionActive.type == 'team' && (
                        <UserAt
                            show={this.props.userAtShow}
                            id={this.props.sessionActive.id}
                            input={this.props.userAtInput}
                            callback={this.props.getClickUser}
                            showUserCB ={this.props.showUserCB}
                            close={this.props.closeUserAt}
                            atAll = {this.props.atAll}
                        />
                    )}
                </div>
            </div>
        );
    }
}
