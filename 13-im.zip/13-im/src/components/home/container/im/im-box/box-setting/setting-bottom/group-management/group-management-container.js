/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-17 21:22:13
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-16 19:01:56
 */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { showSlideModal } from '@r/actions/commonModal';
// antd
import { Switch, message } from 'antd';
import * as util from '@/utils/util';

import css from './index.scss';

import { hideSlideModal } from "@/redux/actions/commonModal";
import CommonModal from '@/components/common/common-modal';
import UserAdd from '@c/common/user-add/user-add-container';
import { sessionActiveSet } from '@r/actions/session.js';
import { setBol } from '@r/actions/dismissTeamModa';
import * as teamCircleAction from '@r/actions/teamCircle';
import { setInviteIni, setDocIni, disband, ownerIni, squadExitIni } from '@/services/group/group-user';

// 侧边栏容器
class GroupManagementContainer extends Component {
    constructor(props) {
        super(props)
        this.state = {
            user_status: '',
            quitSquadModal: false,
            ownerIniModal: false,
            squadAddShow: false,
            userAddDisids: [],
            ownerName: ''
        }
    }
    componentDidMount() {
        // const { teamCircle, sessionActive} = this.props

        this.isAddress = location.pathname.match(/\/address-list/)

        const { teamCircle } = this.props;
        // this.squad_id =  sessionActive.id
        this.squad_id = window.session_active.id;
        if (teamCircle && teamCircle[this.squad_id]) {
            this.setState({
                user_status: teamCircle[this.squad_id].info.user_status
            })
        }
        this.initStatus()
    }

    initStatus = () => {
        const data = this.props.teamCircleAdmin
        if (!['admin', 'owner'].includes(data.card)) {
            // 退出会话
            this.props.quitSquad()
        }
    }

    // 禁止退出小组开关
    exitGroupOpen = async ()=> {
        try {
            const exit_open = !this.props.teamCircleAdmin.exit_open
            const data = await squadExitIni({squad_id: this.squad_id, exit_ini: exit_open ? 'open' : 'close'})
            if (data.code === 200) {
                this.props.updateIni({...this.props.teamCircleAdmin, exit_open})
            } else this.handlerQuitSquad(data)
        } catch(e) {
            message.warning(e)
        }
    }

    // 发布开关
    handlerDocOpen = async () => {
        try {
            const { teamCircle } = this.props
            const doc_open = !this.props.teamCircleAdmin.doc_open
            const data = await setDocIni({squad_id: this.squad_id, doc_ini: doc_open ? 'open' : 'close'})
            
            if (data.code === 200) {
                this.props.updateIni({...this.props.teamCircleAdmin, doc_open})
                // 改变发话题状态
                const opt = teamCircle[this.squad_id]
                opt.info.doc_open = doc_open
                this.props.update({
                    [this.squad_id]: opt
                })
            } else this.handlerQuitSquad(data)
        } catch(e) {
            message.warning(e)
        }
    }

    // 邀请开关
    handlerInviteOpen = async () => {
        try {
            const invite_open = !this.props.teamCircleAdmin.invite_open
            const data = await setInviteIni({squad_id: this.squad_id, invite_ini: invite_open ? 'open' : 'close'})
            if (data.code === 200) {
                this.props.updateIni({...this.props.teamCircleAdmin, invite_open})
            } else this.handlerQuitSquad(data)
        } catch(e) {
            message.warning(e)
        }
    }

    // 解散小组
    handlerDisband = async () => {
        try {
            const data = await disband({ squad_id: this.squad_id })
            if (data.code === 200) {
                // 退出小组
                data.code = 40304
                this.handlerQuitSquad(data)
            } else message.warning(data.msg)
            this.openSquadModal('quitSquadModal', false)
        } catch(e) {
            message.warning(e)
        }
    } 
    
    // 退出小组
    handlerQuitSquad = data => {
        data.msg && message.warning(data.msg)
        if(data.code == 40319 || data.code == 40311) this.props.quitSquad() // 没有权限时，打开小组设置页
        if (+data.code === 40303 || +data.code === 40304) {
            this.props.hideSlideModal()

            // const { id, type } = this.props.sessionActive;
            // const nimId = util.nim.getNimId(type, id);

            const { nimId } = window.session_active;
            util.nim.deleteLocalSession(nimId)
            this.props.sessionActiveSet({})
            this.props.setBol(false)
        }
    }

    openSquadModal = (type, value) => {
        this.setState({
            [type]: value
        })
    }

    // 添加窗口开关
    squadAddSwitch = status => {
        this.setState({
            squadAddShow: status
        })
    }

    // 组长转让
    handlerOwnerChange = data => {
        this.ownerData = data
        this.setState({
            ownerName: data.currList.find(item => !!item.name).name
        })
        this.openSquadModal('ownerIniModal', true)
    }
    
    // 组长转移
    handlerOwnerDialog = async () => {
        if (!this.ownerData || !this.ownerData.currList || !this.ownerData.currList.length) {
            message.warning(util.locale("im_noUser"))
            return
        }
        try {
            const { teamCircle } = this.props
            const data = await ownerIni({squad_id: this.squad_id, user_id: this.ownerData.currList[0].user_id })
            if (data.code === 200) {
                this.props.updateIni({...this.props.teamCircleAdmin, card: 'common'})
                const opt = teamCircle[this.squad_id]
                opt.info.user_status = 'common'
                this.props.update({
                    [this.squad_id]: opt
                })
                setTimeout(this.initStatus.bind(this))
            } else this.handlerQuitSquad(data)
        } catch(e) {
            message.warning(e)
        }
        this.squadAddSwitch(false)
        this.openSquadModal('ownerIniModal', false)
    }

    render() {
        const card = this.props.teamCircleAdmin.card || 'common'
        console.log('aaa',this.props.teamCircleAdmin)
        return (
          <div className={css.manbox}>
            <div className={css.bottom}>
                <p>
                    <span>{util.locale("im_only_group_leaders_and_administrators_can_invite_members")}</span>
                    <Switch checked={this.props.teamCircleAdmin.invite_open} onClick={this.handlerInviteOpen} />
                </p>
                {
                    ['owner'].includes(card) ? 
                    <p className={css.exit} onClick={this.props.openSettingAdminSlide}>
                        <span>{util.locale("im_configuration_administrator")}</span>
                        <span className={css.hc}>{this.props.teamCircleAdmin.user_info.current}/{this.props.teamCircleAdmin.user_info.total}</span>
                        <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
                    </p> : null
                }
                <p>
                    <span>{util.locale("im_prohibited_topics")}<span className={css.dec}>{util.locale("im_only_group_leaders_and_administrators_can_post_topics")}</span></span>
                    <Switch checked={this.props.teamCircleAdmin.doc_open} onClick={this.handlerDocOpen} />
                </p>

                <p>
                    <span className={css.exitGroup}>
                        <span className={css.exitName}>{util.locale("im_not_leave_group")}</span>
                        <span className={css.exitdec}>{util.locale("im_able_not_exit")}</span>
                    </span>
                    <Switch checked={this.props.teamCircleAdmin.exit_open} onClick={this.exitGroupOpen} />
                </p>

                {
                    ['owner'].includes(card) ?
                        <>
                            <p onClick={() => {this.squadAddSwitch(true)}} className={css.exit}>
                                <span>{util.locale("im_leader_transfer")}</span>
                                <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} />
                            </p> 
                            <div className={css.redButt}>
                                <span onClick={() => {this.openSquadModal('quitSquadModal', true)}}>{util.locale("im_dissolution_team")}</span>
                            </div>
                        </>
                    : null
                }
            </div>
            <CommonModal
                modalVisible={this.state.quitSquadModal}
                setOKModal={this.handlerDisband}
                setonCancelModal={() => {this.openSquadModal('quitSquadModal', false)}}
                modalContent={util.locale("im_WANR")}
            />
            <CommonModal
                modalVisible={this.state.ownerIniModal}
                setOKModal={this.handlerOwnerDialog}
                setonCancelModal={() => {this.openSquadModal('ownerIniModal', false)}}
                modalContent={`${util.locale("im_confirm_transfer_team_leader_to")} ${this.state.ownerName}`}
            />
            <UserAdd
                typeMsg={{type: 'squad', value: util.locale("im_team")}}
                show={this.state.squadAddShow}
                onClose={() => {this.squadAddSwitch(false)}}
                disabledids={[]}
                leftTitle={util.locale("im_group_leader")}
                title={util.locale("im_leader_transfer")}
                listTitle={util.locale("im_select_group_leader")}
                type={'squad'}
                check={'radio'}
                onOk={this.handlerOwnerChange}
            />
          </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
        teamCircle: state.teamCircle,
        // sessionActive: state.sessionActive,
        sessionList: state.sessionList,
        teamCircleAdmin: state.teamCircleAdmin
    };
};

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        openSettingAdminSlide: () => dispatch(showSlideModal('settingAdmin')), //打开机器人设置侧边栏
        quitSquad: () => dispatch(showSlideModal('squad')),
        hideSlideModal: () => dispatch(hideSlideModal()),
        sessionActiveSet: () => dispatch(sessionActiveSet({})),
        setBol: () => dispatch(setBol()),
        update: obj => dispatch(teamCircleAction.update(obj)),
        updateIni: data => dispatch(teamCircleAction.updateIni(data))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(GroupManagementContainer);
