// react
import React from 'react';
import {connect} from 'react-redux';
// component
import BoxConfiguration from './box-configuration';
// util
import * as util from '@/utils/util';
// antd
import {message} from 'antd';
// services
import {groupUsersAdminCancel, groupUsersAdminSet} from '@/services/group/group-user';
// debounce
import debounce from 'lodash/debounce';

// BoxOperationContainer
class BoxConfigurationContainer extends React.Component {
    state = {
        modalVisible: false,
        loading: false,
        userAddShow: false,
        managers: [],
        disabledids:[],
        popText:'',
        removeName:'',
        removeId:'',
        owner:[]
    };

    componentDidMount() {
        // const {sessionActive} = this.props
        this.isAddress = location.pathname.match(/\/address-list/)
        // this.squad_id = sessionActive.id
        this.squad_id = window.session_active.id;
        this.getManagerAndOwner();
        this.removeManager = debounce(this.removeManager, 500);
    }

    groupUsersAdminSet = async(id, admin_users) => {
        const datas = await groupUsersAdminSet({ tid:id, admin_users: admin_users});
        if(datas){
            const { code } = datas || {};
            if (code === 200) {
               util.sensorsData.track('Click_Chat_Element', {pageName: 144, $element_name: 129, chat_id: id});
               return true;
            } else {
                message.success(util.locale('im_add_administrator_failed'));
                return false;
            }
        }
    };

    groupUsersAdminCancel = async(id, admin_users) => {
        const datas = await groupUsersAdminCancel({ tid:id, admin_users: admin_users});
        if(datas){
            const { code } = datas || {};
            if (code === 200) {
               util.sensorsData.track('Click_Chat_Element', {pageName: 145, $element_name: 129, chat_id: id});
               return true;
            } else {
                message.success(util.locale('im_failed_to_remove_administrator'));
                return false;
            }
        }
    };

    setonCancelModal = () => {
        this.setState({modalVisible: false});
    }

    setOKModal = async() => {
        const adminCancelObj = await this.groupUsersAdminCancel(this.squad_id, JSON.stringify([this.state.removeId]))
        if(adminCancelObj){
            try {
                // let obj = await util.nimUtil.removeTeamManagers(this.props.sessionActive.id, [this.state.removeId]);
                // if(obj){
                //     message.success(this.state.removeName+ " "+ util.locale('im_administrator_removed_successfully'));
                //     this.getManagerAndOwner();
                // }
                message.success(this.state.removeName+ " "+ util.locale('im_administrator_removed_successfully'));
                this.getManagerAndOwner();
            } catch (error) {
                message.error(error);
            }
        }
        this.setState({modalVisible: false});
    }

    removeManager = (name, id) => {
        this.setState({
            modalVisible: true, 
            popText: `${this.locale('im_confirm_removal')} ${util.locale.getLang() !== 'en-US' ? name + ' '+ this.locale('common_manager2') : this.locale('common_manager2') + ' ' + name}`, // 是否确认移除
            removeName: name,
            removeId: id
        });
    }

    openGetUser = () => {
        this.setState({userAddShow: true});
    }

    getUsers = (value) =>{
        this.setState({loading: true});
        let managers = [];
        managers = value.users.map(item => item.id);
        this.setManagers(managers);
    }

    setManagers = async(managers) => {
       const adminSetObj = await this.groupUsersAdminSet(this.squad_id, JSON.stringify(managers));
       if(adminSetObj){
            try {
                // const obj = await util.nimUtil.addTeamManagers(this.props.sessionActive.id, managers);
                // if(obj){
                //     this.getManagerAndOwner();
                //     this.setState({userAddShow: false});
                // }
                this.getManagerAndOwner();
                this.setState({userAddShow: false});
            } catch (error) {
                message.error(error);
            }
        }
        this.setState({loading: false});
    }



    getManagerAndOwner = async() => {
        let managers = [],
            owner = [],
            managersAndOwner = [],
            disabledids = [];
        const obj = await util.nimUtil.getTeamMembers(this.squad_id);
        managers = obj.members.filter(item=>{
            return item.type == 'manager';
        });
        owner = obj.members.filter(item=>{
            return item.type == 'owner';
        });
        this.getManagers(managers);
        managersAndOwner = managers.concat(owner);
        disabledids = managersAndOwner.map(item=> item.account)
        this.setState({disabledids: disabledids, owner: owner});
    }

    getManagers = async(managers) => {
        let obj = [],
            item = [];

        for (let index = 0; index < managers.length; index++) {
            console.log('hh3');
            item = await util.nim.getNimInfo('p2p', managers[index].account);
            obj.push(item);
        }
        this.setState({managers: obj});
    }

    closegetUser = () => {
        this.setState({loading: false, userAddShow: false})
    }

    getRule = () => {
        const { id } = this.props.userInfo;
        if(this.state.owner.length>0 && this.state.owner[0].account == id) return true;
        return false;
    }

    render() {
        // const {sessionActive } = this.props
        const sessionActive = window.session_active;
        const userAddProps = {
            type: "group",
            groupId: sessionActive.id,
            loading: this.state.loading,
            show: this.state.userAddShow,
            onOk: this.getUsers,
            onClose: this.closegetUser,
            disabledids: this.state.disabledids,
            title: util.locale('im_add_group_administrator'), // 添加群管理员
            leftTitle: this.locale('common_manager2'),
            rightTitle: util.locale('im_select_administrator') // 选择管理员
        };
        return (
            <BoxConfiguration 
                modalVisible = {this.state.modalVisible}
                managers = {this.state.managers}
                popText = {this.state.popText}
                setOKModal = {this.setOKModal}
                setonCancelModal = {this.setonCancelModal}
                remove = {this.removeManager}
                openGroupCreate = {this.openGroupCreate}
                userAddProps = {userAddProps}
                openGetUser = {this.openGetUser}
                getRule = {this.getRule}
            />
        );
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
        // sessionActive: state.sessionActive,
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxConfigurationContainer);
