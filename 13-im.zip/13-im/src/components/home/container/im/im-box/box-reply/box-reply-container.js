import React from 'react'
import { connect } from 'react-redux'

import BoxReply from './box-reply'

// actions
import { show as replyShow} from '@r/actions/reply';

// util
import * as util from '@/utils/util';
import * as linkMsgHandler from '@u/nim/container/link-msg-handler';

class BoxReplyContaner extends React.Component {

    state = {
        name: '',
        content: ''
    }

    closeReply = () => {
        this.props.dispatch(replyShow(false));
    }

    goMessagePlace = () => {
        const { idClient } = this.props.reply.item;
        util.eventBus.emit('clickMessageId', idClient);
    }

    render(){
        const { type, text, fromNick, file, content, fromYachNick} = this.props.reply.item;
        let contentText = '';
        let customContent = '';
        switch (type) {
            case 'image':
                contentText = `[${util.locale('im_image_message')}]`;
                break;
            case 'audio':
                contentText = `[${util.locale('im_voice_messages')}]`;
                break;
            case 'video':
                contentText =  `[${util.locale('im_video_message')}]${file.name}`;
                break;
            case 'file':
                contentText = `[${util.locale('im_files')}]${file.name}`;
                break;
            case 'custom':
                if(content){
                    try {
                        customContent = JSON.parse(content);
                        const isLinkMsg = customContent.type == 23 || customContent.type == 24;
                        if(customContent.type == 6){
                            contentText = text;
                        } else if(customContent.type == 8){
                            contentText = `[${util.locale('im_image_message')}]`;
                        } else if(customContent.type == 10) {
                            contentText = `[${util.locale('im_files')}]${customContent.data.fileName}`;
                        } else if(customContent.type == 16) {
                            contentText = `[${util.locale('im_online_documents')}]${customContent.data.title}`;
                        }else if(customContent.type == 25) {
                            contentText = `[${util.locale('Emoji')}]`;
                        }else if(customContent.type == 26) {
                            contentText = `[${util.locale('im_folder')}]`;
                        }else if(customContent.type == 30) {
                            contentText = `[${util.locale('im_video_message')}]`;
                        }else if(customContent.type == 31) {
                            contentText = `[${util.locale('im_location')}]${customContent.data.name}`;
                        }else if(customContent.type == 32) {
                            contentText = `[${util.locale('im_vote')}]${customContent.data.title}`;
                        }
                        else if(isLinkMsg) {
                            contentText = linkMsgHandler.replyTip(customContent);
                        } else if(customContent.type == 15) {
                            contentText = `[markdown]${customContent.data.content.content}`
                        } else if(customContent.type == 38) {// 私聊 -> 个人状态 -> 自动回复
                            try {
                                contentText = `[${util.locale('im_auto_reply')}]${customContent.data.content.reply_content}`
                            } catch (error) {
                                console.error('私聊回复[自动回复]消息时，出现异常：', error)
                            }
                            
                        }
                        else{
                            contentText = `[${util.locale('im_files')}]${customContent.data.fileName}`;
                        }
                    } catch (error) {
                        contentText = text;
                        console.log('reply', contentText);
                    }
                }else{
                    contentText = text;
                }
                break;
            default:
                contentText = text;
                break;
        }
        return (
            <BoxReply
                setBoxReplyRef = {this.props.setBoxReplyRef}
                closeReply = {this.closeReply}
                name = {`${fromNick}${fromYachNick?'('+fromYachNick+')':''}`}
                content = {contentText}
                customContent={customContent}
                goMessagePlace = {this.goMessagePlace}
            />
        )
    }
}

const mapStateToProps = state => ({
    userInfo: state.userInfo,
    reply: state.reply
})

export default connect(mapStateToProps)(BoxReplyContaner)
