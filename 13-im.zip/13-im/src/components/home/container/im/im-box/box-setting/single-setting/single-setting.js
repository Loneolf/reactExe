
// react
import React from 'react';

// css
import css from './index.scss';

import { Switch, Dropdown } from 'antd';
import * as util from '@u/util.js';

// BoxOperation
export default function BoxSingleSetting(props) {
    const {
        onFixtop,
        isTop,
        disnotice,
        onNodisturb,
        showimg,
        showinfo,
        goUserInfo,
        id,
        onMachineTranslation,
        isTranslation,
        sign,
        effectMode,
        groupName,
        effectMenu,
    } = props;
    return (
        <div className={css.singleSettingBox}>
            <div className={css.top}>
                <img
                    src={showimg}
                    onClick={() => {
                        goUserInfo(showinfo.id);
                    }}
                />
                <div className={css.showInfo}>
                    <div className={css.showNick}>{showinfo.yachNick || showinfo.showname}</div>
                    <div className={css.showSign}>{sign || showinfo.fullSign}</div>
                </div>
            </div>
            <div className={css.bottom} id="groupExit">
                {
                    effectMode ? (
                        <Dropdown overlay={effectMenu(disnotice)} 
                            trigger={['click']} 
                            overlayClassName={css.EffectMenuWrapBox}
                            getPopupContainer={() => document.getElementById('groupExit')}
                            placement="bottomRight"
                        >
                            <p className={css.exit}>
                                <span>{util.locale('im_effect_mode_text_23')}</span>
                                <span className={css.exitChBox}>
                                    <span className={css.groupName}>{groupName}</span>  
                                    <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`}></span> 
                                </span> 
                            </p>
                        </Dropdown>
                    ) : null
                }
                <p>
                    <span>{util.locale('im_stick_to_top')}</span>
                    <Switch checked={isTop} onChange={onFixtop} />
                </p>
                {util.yach.showAutoTranslation() && (
                    <p className={css.autoTranslation}>
                        <span>{util.locale('im_auto_translation')}</span>
                        <Switch checked={!!isTranslation} onChange={onMachineTranslation} />
                    </p>
                )}
                {util.yach.showAutoTranslation() && (
                    <p className={css.autoTranslationMsg}>{util.locale('im_MWTPLA')}</p>
                )}
                {id == util.yach.getAccount() ? null : (
                    <p>
                        <span>{util.locale('im_mute_notifications')}</span>
                        <Switch checked={disnotice} onChange={_.debounce((v)=>onNodisturb(v),300)} />
                    </p>
                )}
            </div>
        </div>
    );
}
