
// react
import React from 'react';
import { connect } from 'react-redux';
// antd
import { Menu} from 'antd';
// util
import * as util from '@/utils/util';
// component
import BoxSingleSetting from './single-setting';
import { renderCustomMenu } from './../../../im-list/group-menu';
// services
import { sessionTopAdd, sessionTopCancel, setAutoMachineTranslation } from '@/services/session/session';
// css
import css from './index.scss';
// BoxSquadSettingContainer
class BoxSingleSettingContainer extends React.Component {
    // 置顶
    handleFixtop = async (value) => {
        // const { id } = this.props.sessionActive;
        const { id } = window.session_active;
        if (value) {
            await util.nim.handleFixtop(id, true);
            sessionTopAdd({ top_id: id });
        } else {
            await util.nim.handleFixtop(id, false);
            sessionTopCancel({ top_id: id });
        }
    };

    // 消息免打扰
    handleNodisturb = async (value) => {
        // const { id, type } = this.props.sessionActive;
        const { id, type } = window.session_active;
        if (value) {
            await util.nim.handleMuteList(type, id, true);
        } else {
            await util.nim.handleMuteList(type, id, false);
        }
    };

    goUserInfo = () => {
        // util.yach.showUserinfo(this.props.sessionActive.id);
        util.yach.showUserinfo(window.session_active.id);
    };

    //机器翻译
    handleMachineTranslation = async (value) => {
        // let { id } = this.props.sessionActive;
        let { id } = window.session_active;
        id = `${id}`;
        await util.nim.handleMachineTranslation(id, !!value);
        await setAutoMachineTranslation({ session_id: id, auto_translate: value ? 1 : 0 });
        util.sensorsData.track('Click_Chat_Element', {
            chat_id: id,
            pageName: 136,
            $element_name: value ? '01-230':'01-231',
        });
    };

    // 部门信息简略，当部门信息有多个时，只显示第一个，后三个及职位，其中如果第一个为好未来教育科技集团，则自动过滤
    setSign = (deptName,position,name)=>{
        if(!deptName || !deptName.length) return
        if(deptName[0].name == '好未来教育科技集团') deptName.shift();
        let more = false;
        let len = deptName.length
        if(len >= 5){
           deptName.splice(1,len-4) ;
           more = true ;
        }
        let newLen = deptName.length;
        let temSin = deptName.reduce((sum,item,index)=>{
        let tem = item.name;
            newLen > 1 && index == 0 && (tem += more ?  '...' : '-');
            if(index != newLen - 1 && index != 0) tem+='-'; 
            return sum+tem
        },'');
        let temStr = `${temSin}${position ? ' | ' + position : ''}`;
        return name ? `${name}(${temStr})` : temStr
    }

    // 所在分组
    effectMenu = (disnotice)=>{
        // const {sessionActive} = this.props;
        const sessionActive = window.session_active;
        return(
            <Menu className={css.EffectMenuWrap} onClick={(e)=>util.yach.selectHandleClick(e,sessionActive.id)}>
                {renderCustomMenu(sessionActive.id,disnotice,false)}
           </Menu>
        )
    }

    render() {
        // const { sessionList, sessionActive, effectMode } = this.props;
        const { sessionList, effectMode } = this.props;
        const sessionActive = window.session_active;
        const showinfo = this.props.slideModal.name;
        const { isTop, showimg, showname, disnotice } =
            sessionList.filter((item) => {
                return item.id == sessionActive.id;
            })[0] || {};
        const { translationList = [] } = this.props;
        let isTranslation = translationList.includes(`${sessionActive.id}`);

        const info = util.yach.checkTypeofSession(sessionActive.id);
        const groupName = util.locale(info.attr)? util.locale(info.attr): info.attr;

        const props = {
            isTop,
            showimg,
            showname,
            disnotice,
            showinfo,
            onFixtop: this.handleFixtop,
            onNodisturb: this.handleNodisturb,
            goUserInfo: this.goUserInfo,
            id: sessionActive.id,
            sign:this.setSign(showinfo.newDeptName,showinfo.position,showinfo.showname),
            onMachineTranslation: this.handleMachineTranslation,
            isTranslation,
            effectMode,
            groupName,
            effectMenu: this.effectMenu,
        };
        return <BoxSingleSetting {...props} />;
    }
}

const mapStateToProps = (state) => {
    return {
        userInfo            : state.userInfo,
        // sessionActive       : state.sessionActive,
        sessionList         : state.sessionList,
        translationList     : state.translationList,
        effectMode          : state.effectMode,
        effectlist          : state.effectInterfaceDate,
    };
};

export default connect(mapStateToProps, null)(BoxSingleSettingContainer);
