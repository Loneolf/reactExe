import React, { useState, useEffect, useCallback } from 'react';
import {connect} from 'react-redux';
import {Tooltip} from 'antd';
import * as util from '@u/util.js';
import debounce from 'lodash/debounce';
import { sessionUploadFileDel, sessionUploadFileRetry } from '@r/actions/sessionUploadFile';

import css from './index.scss';
// imgs
import wordImg from '@a/imgs/modelFileType/word.svg';
import excelImg from '@a/imgs/modelFileType/excel.svg';
import pptImg from '@a/imgs/modelFileType/ppt.svg';
import pdfImg from '@a/imgs/modelFileType/pdf.svg';
import videoImg from '@a/imgs/modelFileType/video.svg';
import otherImg from '@a/imgs/modelFileType/other.svg';
import dirImg from '@a/imgs/modelFileType/dir.svg';
import picImg from '@a/imgs/modelFileType/pic.svg';
import cancelUploadImg from '@a/imgs/group_file/cancelUpload.png'

function GroupFileUploadList(props) {

  useEffect(() => {
    
  }, []);

  const genImg = (ext='') => {
    const t = ext.toLowerCase();

    if (/folder/i.test(t)) return dirImg;
    if (/doc|docx/i.test(t)) return wordImg;
    if (/xls|xlsx/i.test(t)) return excelImg;
    if (/pptx|ppt/i.test(t)) return pptImg;
    if (/pdf/i.test(t)) return pdfImg;
    if (/png|jpg|bmp|jpeg|gif|svg|wmf|jpe|ico|pic|tiff|pjpeg|jfif|pjp/i.test(t)) return picImg;
    if (/wmv|asf|asx|rm|rmvb|mp4|3gp|mov|m4v|avi|dat|mkv|flv|vob|rn-realmedia|mid/i.test(t)) return videoImg;
    return otherImg;
  };
  const cancelUpload = useCallback(debounce((uploadItem) =>{
    const {id, progress, idClient, msg } = uploadItem
    props.dispatch(sessionUploadFileDel({
      id, progress, idClient, msg,
      sessionActive: window.session_active
    }))
    console.log('phj-cancelUpload',uploadItem);
  },500),[]);
  const retryUpload = useCallback(debounce((uploadItem) =>{
    const {id, idClient, msg} = uploadItem
    props.dispatch(sessionUploadFileRetry({
      id,
      idClient,
      msg,
      sessionActive: window.session_active
    }))
    console.log('phj-retryUpload',uploadItem);
  },500),[]);
  const getExt = (path='',type) => {
    if(type=='dir') return 'folder'
    if(!path) return ''
    const strArr = /\\/.test(path) ? path.split('\\') : path.split('/')
    const str = strArr[strArr.length-1]
    const extArr = str.split('.')
    if(extArr.length) return extArr[extArr.length-1]
    return ''
  }
  const getName = (path='') =>{
    if(!path) return ''
    const strArr = /\\/.test(path) ? path.split('\\') : path.split('/')
    const name = strArr[strArr.length-1] || ''
    return name
  }


  return (
    <>
    {(props.uploadArray && props.uploadArray.length) ?
      <div className={css.fileUploadListWrap}>
        <div className={css.uploadQueue}>{util.locale('im_group_file_input_upload_queue')}</div>
        <div className={css.uploadWrap}>
          {props.uploadArray.map((uploadItem) => {
            return (
              (!!uploadItem.id && uploadItem.actionData) && <div className={css.uploadItemWrap} key={uploadItem.id}>
                <div className={css.imgWrap}>
                  <img src={genImg(getExt(uploadItem.actionData.custom.data.path,uploadItem.actionData.custom.data.type))} className={css.uploadItemImg}/>
                  { uploadItem.needBell?
                    <Tooltip placement="top"
                      title={util.locale('im_group_file_input_upload_tip_title')}
                    >
                        <p className={`${css.bellBox} ${uploadItem.actionData.custom.data.type=='dir'?'': css.bellBox1}`}></p>
                    </Tooltip>
                  :null}
                </div>
                <div className={css.uploadItemRight}>
                  <p className={css.uploadItemName}>{getName(uploadItem.actionData.custom.data.path)}</p>
                    {uploadItem.status == 'uploading' ? 
                      <div className={css.uploadingWrap}>
                        <div className={css.progressWrap}>
                          <div className={css.progressInner} style={{width: Math.floor(uploadItem.progress.percent * 165)}}></div>
                        </div>
                        <p className={css.progressSpeed}>{util.yach.getUnit(uploadItem.progress.speed,1)}</p>
                        <img src={cancelUploadImg} onClick={cancelUpload.bind(null,uploadItem)} className={css.cancelUploadImg}/>
                      </div>
                    :null}
                    {uploadItem.status == 'uploadStart' ? 
                      <div className={css.uploadStartWrap}>
                        <p className={css.uploadStart}>{util.locale('im_group_file_input_upload_wait')}</p>
                        <p className={css.uploadCancel} onClick={cancelUpload.bind(null,uploadItem)}>{util.locale('im_cancel')}</p>
                      </div>
                    :null}
                    {(uploadItem.status == 'uploadFail' || !uploadItem.status) ? 
                      <div className={css.uploadFailWrap}>
                        <p className={css.uploadFail}>{util.locale('common_msg20')}</p>
                        <p>
                          <span className={css.uploadRetry} onClick={retryUpload.bind(null,uploadItem)}>{util.locale('im_group_file_input_upload_retry')}</span>
                          <span className={css.uploadCancel} onClick={cancelUpload.bind(null,uploadItem)}>{util.locale('im_cancel')}</span>
                        </p>
                      </div>
                    :null}
                    {uploadItem.status == 'uploadAbort' ?
                      <div className={css.uploadAbortWrap}>
                        <p className={css.uploadAbort}>{util.locale('im_group_file_input_upload_abort')}</p>
                        <p className={`${css.uploadCancel} ${css.uploadAbortCancel}`} onClick={cancelUpload.bind(null,uploadItem)}>{util.locale('im_group_file_input_upload_ok')}</p>
                      </div>
                    :null}
                </div>
              </div>
            )
          })}
        </div>
      </div>
    :null}
    </>
  );
};

const mapStateToProps = state => {
  const getArray = (obj={}) =>{
    const arr = []
    for (const itemValue in obj) {
      if(obj[itemValue]) arr.push(obj[itemValue])
    }
    // console.log('phj-getArray',arr)
    return arr
  }
  return {
    uploadArray: getArray(state.sessionUploadFile[window.session_active.id])
  };
};

export default connect(
  mapStateToProps,
)(GroupFileUploadList);
