// react
import React from 'react';

import { Tabs } from 'antd';

const { TabPane } = Tabs;
import * as util from '@u/util.js';

// css
import css from './index.scss';

import BoxSeachImgContainer from '../box-seach-img/box-seach-img-container';
import BoxSeachHistoryContainer from '../box-seach-history/box-seach-history-container';
import BoxOnlineDocContainer from '../box-online-doc/box-online-doc-container';
import BoxSearchFileContainer from '../box-search-file/file-main/index.js';

export default class boxGroupDatabase extends React.Component{
    
    render(){
        const {typeName,activeKey,getFileParams} = this.props;
        return(
            <div className={css.box}>
                <span
                    className="iconfont-yach yach-quanju-qunshezhi-guanbiqunshezhi"
                    onClick={() => this.props.hiddenModal()}
                />
                <Tabs activeKey={activeKey} onChange={this.props.tapChange} tabBarGutte='1'>
                    <TabPane tab={util.locale('media_message')} key='1'>
                        {this.props.activeKey == 1 && <BoxSeachHistoryContainer hiddenModal={this.props.hiddenModal}/>}
                    </TabPane>
                    <TabPane tab={util.locale('media_online_document')} key='2'>
                        {this.props.activeKey == 2 && <BoxOnlineDocContainer  hiddenModal={this.props.hiddenModal} typeName = {typeName} />}
                    </TabPane>
                    <TabPane tab={util.locale('media_file')} key='3'>
                        {this.props.activeKey == 3 && <BoxSearchFileContainer  hiddenModal={this.props.hiddenModal} typeName = {typeName} getFileParams={getFileParams} />}
                    </TabPane>
                    <TabPane tab={util.locale('media_image_video')} key='4'>
                        {this.props.activeKey == 4 && <BoxSeachImgContainer typeName = {typeName} />}
                    </TabPane>
                </Tabs>
            </div>
        )
    }
}
