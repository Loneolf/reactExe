import { forwardFolderCheck} from '@s/folder/index.js';
import {showSlideModal} from '@/redux/actions/commonModal';
import * as util from '@u/util.js';
import {fileStatusUpdate} from '@/redux/actions/file'

// 跳转文件夹
export const goFloderPreview= async ({relation_id,isMultiSelect,fileName})=>{
    const receive=window.store.getState().sessionActive.id
    let goFilehistory=false;
    if(isMultiSelect){
        const s =await forwardFolderCheck({relation_id,receive});
        if(s&&s.code==200) goFilehistory=s.obj.result;
    }
    if(!goFilehistory){
        window.store.dispatch(showSlideModal('groupDatabase', {activeKey:'3',params:{relation_id,fileName}}));
    }else{
        window.store.dispatch(showSlideModal('filePreview', {relation_id,fileName}));
    }
}
