import React from 'react'
import {connect} from 'react-redux'
import BoxLink from './box-link'
class BoxInfoContainer extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        const webviewProps={
            url:this.props.slideModal.url,
        }
        return  <BoxLink {...webviewProps}/>
    }
}
const mapStateToProps = state => ({
    slideModal: state.slideModal
})

export default connect(mapStateToProps)(BoxInfoContainer)
