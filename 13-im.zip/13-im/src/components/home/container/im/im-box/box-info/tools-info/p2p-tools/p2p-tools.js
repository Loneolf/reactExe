// react
import React from 'react';

// util
import * as util from '@/utils/util';

// css
import css from './index.scss';
import { Tooltip } from 'antd';

// component
import TopRepeatGroup from '@c/common/repeat-group-modal/repeat-group-modal-container';
import UserAdd from '@c/common/user-add/user-add-container';
import ToolsContainer from '../common/tools';

// 
export default props => {
    const {
        showname,
        fullSign,
        newDeptName,
        position,
        searchHistoryGuide,
        showNickName,
        yachNick,
        closeSearchHistoryTips,
        openGroupCreate,
        userAddProps,
        showModalProps,
        showRightModal 
    } = props;
    
    return ( 
        <div className={css.tool} id="p2pTools">
            <ToolsContainer 
                toolName={'search'}
                domId={'p2pTools'}
                closeSearchHistoryTips={closeSearchHistoryTips}
                searchHistoryGuide={searchHistoryGuide}
                curSession={'single'}
            />
            <Tooltip title={util.locale('im_set_up_new_group')} mouseEnterDelay={1}>
                <span
                    className={`${css.icon} iconfont-yach yach-149goutong-huihuachuangkou-tianjialianxirenicon`}
                    onClick={openGroupCreate}
                />
                <UserAdd {...userAddProps} />
                <TopRepeatGroup {...showModalProps} />
            </Tooltip>
            <ToolsContainer 
                toolName={'more'}
                showRightModal={showRightModal}
                rightModalParams={{
                    type: 'singleSetting',
                    name: {
                        showname,
                        fullSign,
                        showNickName,
                        yachNick,
                        newDeptName,
                        position
                    }}
                }
            />
        </div>
    )
}
