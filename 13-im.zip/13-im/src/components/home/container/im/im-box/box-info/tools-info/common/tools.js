// react
import React from 'react';

// util
import { locale } from '@u/util.js';

// css
import css from './index.scss';
import { Tooltip, Popover } from 'antd';

// 
export default props => {
    const {
        toolName,
        closeSearchHistoryTips,
        domId,
        searchHistoryGuide,
        curSession,
        showRightModal,
        rightModalParams
    } = props;

    const searchHistoryTips = (
        <div className={css.guideBox} onClick={() => {closeSearchHistoryTips(null, true)}}>
            <span>{locale('im_chat_history_tip')}</span>
            <span className={`${css.btnOk} iconfont-yach yach-lujing`}></span>
        </div>
    )
    // team
    const searchTipStyle = curSession === 'single' ? 'GroupDocPopoverBox searchHistoryBoxP2P' : 'GroupDocPopoverBox searchHistoryBox'
    const searchTipStyleEn = curSession === 'single' ? 'searchHistoryBoxP2P1' : 'searchHistoryBox1'

    return(
        <>
            { toolName === 'search' &&
                <Popover 
                    content={searchHistoryTips}
                    overlayClassName={`${searchTipStyle} ${locale.getLang() === 'en-US' ? `${searchTipStyleEn}` : ''}`}
                    getPopupContainer={()=> document.getElementById(`${domId}`)}
                    visible={searchHistoryGuide}
                    placement='bottom'
                >
                    <Tooltip title={locale('media_search')} mouseEnterDelay={1} key='2' placement="bottom">
                        <span
                            className={`${css.icon} iconfont-yach yach-149goutong-huihuachuangkou-qunneisousuoicon`}
                            onClick={() => {closeSearchHistoryTips(`${curSession}`)}}
                        />
                    </Tooltip>
                </Popover>
            }
            
            { toolName === 'more' && 
                <Tooltip title={locale('media_more')} mouseEnterDelay={1}>
                    <span
                        className={`${css.icon} iconfont-yach yach-149goutong-huihuachuangkou-gengduoicon`}
                        onClick={showRightModal.bind(this, rightModalParams)}
                    />
                </Tooltip>
            }
        </>
    )
}
