// react
import React from 'react';
import { Progress, Tooltip, Spin } from 'antd';
import InfiniteScroll from 'react-infinite-scroller';

// css
import css from './index.scss';

import * as util from '@u/util.js';
// imgs
import wordImg from '@a/imgs/modelFileType/word.svg';
import excelImg from '@a/imgs/modelFileType/excel.svg';
import pptImg from '@a/imgs/modelFileType/ppt.svg';
import pdfImg from '@a/imgs/modelFileType/pdf.svg';
import videoImg from '@a/imgs/modelFileType/video.svg';
import otherImg from '@a/imgs/modelFileType/other.svg';
import dirImg from '@a/imgs/modelFileType/dir.svg';
import picImg from '@a/imgs/modelFileType/pic.svg';

import noImg from '@a/imgs/online-doc-no-data.png';
import readySearch from '@a/imgs/search-file-ready-search.png';

const genImg = (ext) => {
    const t = ext.toLowerCase();

    if (/folder/i.test(t)) return <img src={dirImg} />;
    if (/doc|docx/i.test(t)) return <img src={wordImg} />;
    if (/xls|xlsx/i.test(t)) return <img src={excelImg} />;
    if (/pptx|ppt/i.test(t)) return <img src={pptImg} />;
    if (/pdf/i.test(t)) return <img src={pdfImg} />;
    if (/png|jpg|bmp|jpeg|gif|svg|wmf|jpe|ico|pic|tiff|pjpeg|jfif|pjp/i.test(t)) return <img src={picImg} />;
    if (/wmv|asf|asx|rm|rmvb|mp4|3gp|mov|m4v|avi|dat|mkv|flv|vob|rn-realmedia|mid/i.test(t)) return <img src={videoImg} />;
    return <img src={otherImg} />;
};

const getNodata = (type) => {
    // ready_search  no_file not_find
    let imgurl = '',
        text = '',
        cssName = '';
    switch (type) {
        case 'ready_search':
            imgurl = readySearch;
            text = util.locale('im_group_file_ready_search');
            cssName = css.readyImg;
            break;
        case 'no_file':
            imgurl = noImg;
            text = util.locale('im_group_doc_no_file');
            break;
        case 'not_find':
            imgurl = noImg;
            text = util.locale('im_no_search_files_found');
            break;
    }
    return (
        <div className={`${css.noData} ${cssName}`}>
            <img src={imgurl} />
            <p>{text}</p>
        </div>
    );
};

export default (props) => {
    const {
        noData,
        fileList,
        hasMore,
        loading,
        handleLoadMore,
        fileDownloadProgress,
        closedDownLoad,
        handleBtnClick,
    } = props;
    return (
        <>
            {loading && (
                <div className={css.loading}>
                    <Spin />
                </div>
            )}
            {!noData ? (
                <ul className={css.out}>
                    {fileList && fileList.length > 0 && (
                        <InfiniteScroll
                            initialLoad={true}
                            pageStart={0}
                            loadMore={handleLoadMore}
                            hasMore={!loading && hasMore}
                            useWindow={false}
                        >
                            {fileList.map((item) => {
                                const {
                                    is_dir,
                                    file_extension,
                                    showFileName,
                                    fileName,
                                    time,
                                    userInfo,
                                    relation_id,
                                    downloadPath,
                                    root,
                                } = item;
                                const fileDownloadProgressItem = fileDownloadProgress.filter(
                                    (t) => t.id == relation_id
                                )[0];
                                return (
                                    <li
                                        key={relation_id}
                                        onClick={(e) => handleBtnClick(e, is_dir == 1 ? 'itemClick' : 'preview', item)}
                                    >
                                        <div className={css.item}>
                                            {genImg(file_extension)}
                                            <div className={css.content}>
                                                {fileName.length > 10 ? (
                                                    <Tooltip title={fileName}>
                                                        <p
                                                            className={css.title}
                                                            dangerouslySetInnerHTML={{
                                                                __html: showFileName || fileName,
                                                            }}
                                                        />
                                                    </Tooltip>
                                                ) : (
                                                    <p
                                                        className={css.title}
                                                        dangerouslySetInnerHTML={{ __html: showFileName || fileName }}
                                                    />
                                                )}
                                                <p className={css.info}>
                                                    {is_dir != 1 && <span className={css.userName}>{util.yach.getFileSize(item.size)} |&nbsp;</span>}
                                                    <span>{util.formatDate.weeklyTimeFormat(time, true)}</span>
                                                    &nbsp;
                                                    <span
                                                        dangerouslySetInnerHTML={{
                                                            __html: userInfo.showName || userInfo.name,
                                                        }}
                                                    />
                                                </p>
                                            </div>
                                            <div className={css.btnWrap}>
                                                <Tooltip title={util.locale('im_group_file_foward')}>
                                                    <span
                                                        onClick={(e) => handleBtnClick(e, 'share', item)}
                                                        className="iconfont-yach yach-zhuanfa1"
                                                    />
                                                </Tooltip>
                                                {
                                                    downloadPath ? (
                                                        <Tooltip title={util.locale('im_open')}>
                                                            <span
                                                                onClick={(e) => handleBtnClick(e, 'open', item)}
                                                                className="iconfont-yach yach-dakaibendi"
                                                            />
                                                        </Tooltip>
                                                    ) : (
                                                        fileDownloadProgressItem?<Tooltip title={util.locale('im_download')}>
                                                        <span
                                                            style={{color:'#B8BBC1'}}
                                                            className="iconfont-yach yach-xiazai1"
                                                        />
                                                    </Tooltip>:
                                                        <Tooltip title={util.locale('im_download')}>
                                                            <span
                                                                onClick={(e) => handleBtnClick(e, 'download', item)}
                                                                className="iconfont-yach yach-xiazai1"
                                                            />
                                                        </Tooltip>
                                                    )
                                                }
                                                {!!root && (
                                                    <Tooltip title={util.locale('im_view_in_chat')}>
                                                        <span
                                                            onClick={(e) => handleBtnClick(e, 'jump', item)}
                                                            className="iconfont-yach yach-tiaozhuanhuihua"
                                                        />
                                                    </Tooltip>
                                                )}
                                            </div>
                                        </div>
                                        {fileDownloadProgressItem && (
                                            <div className={css.progress}>
                                                <Progress
                                                    percent={fileDownloadProgressItem['percent']}
                                                    size="small"
                                                    showInfo={false}
                                                />
                                                <div className={css.showInfo}>
                                                    <span className={css.speed}>
                                                        {fileDownloadProgressItem['speed']}
                                                    </span>
                                                    <Tooltip title={util.locale('im_file_download_cancel')}>
                                                        <span
                                                            onClick={(e) => {
                                                                closedDownLoad(
                                                                    e,
                                                                    item,
                                                                    fileDownloadProgressItem['channelid']
                                                                );
                                                            }}
                                                            className="iconfont-yach yach-0428_richengxiangqing-chuangjianricheng-fujianshangchuanzhongzhi"
                                                        ></span>
                                                    </Tooltip>
                                                </div>
                                            </div>
                                        )}
                                    </li>
                                );
                            })}
                        </InfiniteScroll>
                    )}
                </ul>
            ) : (
                getNodata(noData)
            )}
        </>
    );
};
