// react
import React from 'react';
import { connect } from 'react-redux';
import { message } from 'antd';

// component
import BoxSetting from './box-setting';
import * as util from '@/utils/util';

// debounce
import debounce from 'lodash/debounce';

//services
import { groupInfoEdit, groupInfoGet, groupUsersAdd } from '@/services/group/group-info';
import {
    groupUsersQuit,
    groupUserDel,
    groupUsersEsList,
    squadUserList,
    delSquadUser,
    getSquadInit,
    addSquadUser,
    squadQuit,
} from '@/services/group/group-user';
import { sessionActiveSet } from '@/redux/actions/session.js';
import { hideSlideModal, showSlideModal } from '@/redux/actions/commonModal';
import { sessionTopAdd, sessionTopCancel, setAutoMachineTranslation } from '@/services/session/session';
import { searchGpinusersearch } from '@s/search/search.js';
import { setBol } from '@r/actions/dismissTeamModa';

// actions
import * as teamCircleAction from '@r/actions/teamCircle';

// BoxOperationContainer
class BoxSettingContainer extends React.Component {
    constructor(props) {
        super(props);
        this.pageNumInit = 15; // 第一次打开设置页面 默认加载条数
        // this.pageNum = 50; // 点击加载更多 或 搜索时，每次加载的条数 
        this.pageNum = 15;    // 但是：后端接口的分页处理，需要每次请求的rows（数据个数）保持一致，因此149版本暂定为统一加载为15条!!
        // 加载状态
        this.isListLoding = false;
        this.user_status = '';
    }
    state = {
        showNameInput: false,
        showSearchInput: false,
        searchValue: '',
        list: [],
        modalVisible: false,
        quitGroupModal: false,
        delModalVisible: false,
        delText: '',
        userAddShow: false,
        groupInfo: '',
        owner: {},
        admin: [],
        userIni: {},
        typeMsg: {
            type: 'setting',
            value: util.locale('im_group'),
        },
        page: 1,
        userLoading: false,
        ifSearching: false,
        userIds: [],
        hasMoreData: false, // 判断群设置中的人数是否加载完成
        searchGroupUser: false,
        searchPage: 1,
        searchList: []
    };

    componentDidMount() {
        this.initData();
        this.searchGpinusersearch = debounce(this.searchGpinusersearch, 300);
        window.addEventListener('keydown', this.closeSlideCard);
    }

    componentWillUnmount() {
        window.removeEventListener('keydown', this.closeSlideCard);
    }

    // 监听按键 esc
    closeSlideCard = (ev) => {
        let code = ev.keyCode;
        if (code === 27) {
            // 触发esc
            if (this.state.searchValue) {
                this.setState({ searchValue: '' });
            } else {
                window.store.dispatch(hideSlideModal());
            }
        }
    };

    initData = async () => {
        this.isAddress = location.pathname.match(/\/address-list/);
        const { teamCircle, sessionActive } = this.props;
        const id = sessionActive.id;
        if (teamCircle && teamCircle[id]) {
            this.user_status = teamCircle[id].info.user_status;
        }
        switch (this.props.type) {
            case 'setting':
                // 群列表请求
                // this.scrollObserver();
                this.getGroupUserList(this.pageNumInit);
                this.groupInfoGet();
                console.log('qq2');
                let teamInfo = await util.yach.teamTypeIsWhat(id);
                this.setState({
                    typeMsg: {
                        type: 'setting',
                        value: util.locale('im_group'),
                        groupType: teamInfo.type,
                    },
                });
                break;
            case 'squad':
                this.setState({
                    typeMsg: {
                        type: 'squad',
                        value: util.locale('im_team'),
                    },
                });
                // 小组列表请求
                this.getSquadUserList(this.pageNumInit);
                this.props.getUserIniRequest({ squad_id: id });
                break;
            default:
                break;
        }
    };

    getGroupUserList = async (pageNum) => {
        if (this.state.userLoading) return;
        this.setState({
            userLoading: true,
        });
        const { list, page, total } = await this.getGroupList(this.state.page, pageNum);
        this.setState((pre) => ({
            page: page + 1,
            groupInfo: { ...pre.groupInfo, user_total: total },
        }));
        // 请求数据判断
        let isLastPageData = page > 1 && ((this.pageNumInit + pageNum * (page-1)) <= total)
        this.isAllData(page, this.pageNumInit, total, isLastPageData)

        // if (page == sumpage) this.observer.unobserve(target);
        if (!list.length) return;

        const arr = await util.yach.base64ImgArrGetTmp(list, 'pic');
        this.getList(arr);
        this.setState({
            userLoading: false,
        });
    };

    // 149版本：取消了局部滚动
    // scrollObserver = () => {
    //     const options = {
    //         root: document.querySelector('#usersOut'),
    //         rootMargin: '0px 0px 120px 0px',
    //         threshold: [0],
    //     };
    //     this.observer = new IntersectionObserver((entries, observer) => {
    //         entries.forEach((entry, index) => {
    //             if (entry.isIntersecting) {
    //                 this.getGroupUserList(entry.target);
    //             }
    //         });
    //     }, options);
    //     const checkIsIn = document.querySelector('#checkIsIn');
    //     checkIsIn && this.observer.observe(checkIsIn);
    // };

    goManagement = () => {
        this.props.showSlideModal('management');
    };

    groupInfoGet = async () => {
        const { id } = this.props.sessionActive;
        const datas = await groupInfoGet({ tid: id });
        if (datas) {
            const { code, obj = {} } = datas || {};
            if (code === 200) {
                this.setState({
                    groupInfo: { ...obj, user_total: obj.group_users_count },
                });
            }
        }
    };

    groupUserDel = async (id, users) => {
        // const checkIsIn = document.querySelector('#checkIsIn');
        // checkIsIn && this.observer.unobserve(checkIsIn);
        try {
            const datas = await groupUserDel({ tid: id, users: users });
            const { code } = datas
            if (code === 200) {
                this.initGroupUserList(users);
                message.success(this.state.userName + ' ' + util.locale('im_move_out_successfully'));
            } else {
                message.error(datas.msg);
                if(code === 40002 || code === 40047) this.deletLocalSession();
                if(code === 40051) this.initGroupUserList(users);
            } 
        } catch (error) {
            util.log('qinqinghao','box-setting-container:groupUserDel','接口请求出错')
        }
    };

    initGroupUserList = (users)=>{
        let temList = [...this.state.list]
        let temId = JSON.parse(users)[0]
        temList.some((item,index) => {
            if(item.id == temId) temList.splice(index,1) 
            return item.id == temId
        })
        let {groupInfo} = this.state
        groupInfo.user_total -= 1
        this.setState({list:temList,groupInfo})

        // this.setState({
        //     list: [],
        //     admin: [],
        //     owner: {},
        //     page: 1,
        //     showSearchInput: false,
        //     ifSearching: false,
        //     searchValue: '',
        // },() => { this.getGroupUserList(this.pageNumInit); });
    }

    //查询群组用户
    searchGpinusersearch = async (q, page) => {
        const { id } = this.props.sessionActive;
        if(page == 1) this.setState({list: [], searchList: []})
        let data = await searchGpinusersearch({ groupid: id, querystr: q, page: page, pagesize: this.pageNum });
        if (data && data.code == 200) {
            if (data.obj.list) {
                const resArr = await util.yach.base64ImgArrGetTmp(data.obj.list, 'pic');
                this.setState({
                    list: [...this.state.searchList, ...resArr],
                    ifSearching: true,
                    searchList: [...this.state.searchList, ...resArr]
                });
            }
            
            // 数据判断
            let isLastPageData = page > 1 && ((this.pageNum * (page -1) + data.obj.list.length) < data.obj.total)
            this.isAllData(page, this.pageNum, data.obj.total, isLastPageData)
        }
    };
    // 判断用户列表数据是否请求完了
    isAllData = (page, pageNum, total, isLastPageData) => {
        if((page === 1 && pageNum < total) || isLastPageData) {
            this.setState({ hasMoreData: true })
        } else {
            this.setState({ hasMoreData: false })
        }
    }

    // 获取小组成员列表
    getSquadUserList = async (pageNum, offset_id = 0, where = '') => {
        if (this.isListLoding) return;
        this.isListLoding = true;
        const { id } = this.props.sessionActive;
        const opt = {
            squad_id: id,
            offset_id,
            limit: pageNum,
        };
        where && (opt.where = where);
        try {
            const datas = await squadUserList(opt);
            this.isListLoding = false;
            if (datas) {
                const { code, obj = {} } = datas || {};
                if (code !== 200 || !obj.data || !obj.data.list) {
                    this.handlerQuitSquad(datas);
                    return;
                }
                const list = [];
                for (const key in obj.data.list) {
                    const users = obj.data.list[key];
                    Array.prototype.push.apply(
                        list,
                        users.map((item) => {
                            item.role = key === 'admin' ? 1 : key === 'owner' ? 0 : 2;
                            return item;
                        })
                    );
                }
                if (list.length < pageNum) obj.data.info.offset_id = 0;
                const resArr = await util.yach.base64ImgArrGetTmp(list, 'pic');

                const data = {
                    groupInfo: { ...obj.data.info, ...obj.data.ex },
                };
                this.ex = obj.data.ex;
                if (offset_id === 0) data.list = [];
                this.setState(data);
                this.getList(resArr);
            } else message.warning(datas.msg);
        } catch (e) {
            message.warning(e);
        }
    };

    // 配置基本信息
    getInit = async (squad_id) => {
        try {
            const rel = await getSquadInit({ squad_id });
            if (rel.code === 200) {
                const data = rel.obj && rel.obj.data ? rel.obj.data : null;
                this.setState({
                    userIni: data,
                });
            } else message.warning(data.msg);
        } catch (e) {
            message.warning(e);
        }
    };

    // 获取群成员列表
    getGroupList = async (page, pageNum) => {
        const { id } = this.props.sessionActive;
        const datas = await groupUsersEsList({
            tid: id,
            page,
            rows: pageNum,
        });
        if (datas) {
            const { code, obj = {} } = datas || {};
            if (code === 200) {
                return {
                    list: obj.list,
                    page: Number(obj.page) || 1,
                    total: obj.total,
                    // sumpage: obj.sumpage,
                };
            }
        }
        return {
            page: 1,
            list: [],
            total: 0,
            // sumpage: 1,
        };
    };

    getList = (arr = []) => {
        this.setState((pre) => {
            const list = pre.list.concat(arr);
            const owner = list.find((item) => +item.role === 0) || {};
            const admin = list.filter((item) => +item.role === 1);

            return {
                list,
                owner,
                admin,
            };
        });
    };

    handleGroupInfoEdit = async (prama) => {
        const { id } = this.props.sessionActive;
        try {
            const datas = await groupInfoEdit({ tid: id, ...prama });
            if (datas) {
                const { code, msg } = datas || {};
                if (code === 200) {
                    // 修改成功
                    setTimeout(() => {
                        const nimId = util.nim.getNimId('team', id);
                        util.nim.setCurrentSession(nimId);
                    }, 300);
                } else {
                    message.warning(msg);
                }
            }
        } catch (error) {
            message.warning(error);
        }
    };

    // 置顶
    handleFixtop = async (value) => {
        const { id } = this.props.sessionActive;
        if (value) {
            await util.nim.handleFixtop(id, true);
            sessionTopAdd({ top_id: id });
        } else {
            await util.nim.handleFixtop(id, false);
            sessionTopCancel({ top_id: id });
        }
    };

    // 消息免打扰
    handleNodisturb = (value) => {
        const { id, type } = this.props.sessionActive;
        if (value) {
            util.nim.handleMuteList(type, id, true);
        } else {
            util.nim.handleMuteList(type, id, false);
        }
    };

    // 查看更多
    handleReadmore = (isFromGroupSearch) => {
        if(!isFromGroupSearch) {
            switch (this.props.type) {
                case 'setting':
                    // 群 列表请求
                    this.getGroupUserList(this.pageNum);
                    break;
                case 'squad':
                    // 小组列表请求
                    this.getSquadUserList(this.pageNum, this.state.groupInfo.offset_id, this.state.searchValue);
                    break;
            }
        } else {
            // 群：查看更多需要单独处理，是单独调接口
            let page = this.state.searchPage
            this.searchGpinusersearch(this.state.searchValue, page + 1);
            this.setState({searchPage: page+1})
        }
    };

    // 公共input显隐
    handleEditCommon = (type) => {
        this.setState((prev) => ({
            [type]: !prev[type],
        }));
    };

    // 取消查询状态
    handleCancelSearch = () => {
        this.setState({
            ifSearching: false,
        });
    };

    // blur发起请求
    handleGroupNameblur = async (value) => {
        const oldname = this.props.sessionActive.showname;
        const newname = value.trim();
        if (newname.length > 0 && oldname != newname) {
            // let obj = await util.nimUtil.updateTeam(this.props.sessionActive.id, {name: newname});
            // if(obj) this.handleGroupInfoEdit({group_name: newname});
            this.handleGroupInfoEdit({ group_name: newname });
            // this.props.dispatch(sessionActiveSet(Object.assign(this.props.sessionActive, {showname:newname})));
            this.props.sessionActiveSet(Object.assign(this.props.sessionActive, { showname: newname }));
        }
        this.handleEditCommon('showNameInput');
    };

    handleSearchValueChange = (value) => {
        this.setState(
            {
                searchValue: value,
            },
            () => {
                this.inputTimer && clearTimeout(this.inputTimer);
                this.inputTimer = setTimeout(() => {
                    switch (this.props.type) {
                        case 'setting':
                            this.searchGroupHandle()
                            break;
                        case 'squad':
                            let pageSize = this.state.searchValue ? this.pageNum : this.pageNumInit
                            this.getSquadUserList(pageSize, 0, this.state.searchValue);
                            break;
                    }
                }, 500);
            }
        );
    };

    searchGroupHandle = () => {
        // 149: 群搜索成员 分页处理
        if(this.state.searchValue) {
            this.setState({searchGroupUser: true, list: [], searchPage: 1})
            this.searchGpinusersearch(this.state.searchValue, this.state.searchPage);
        } else {
            this.setState({searchGroupUser: false, searchList: [], searchPage: 1, list: [], page: 1})
            this.getGroupUserList(this.pageNumInit); // 搜索结果清空 调用初始化请求user接口
        }
    }

    // 退出群聊
    handleLeaveTeam = async () => {
        let item = this.props.sessionActive;
        let s = await groupUsersQuit({ tid: item.id });
        if (s.code == 200) {
            await util.nimUtil.deleteLocalMsgsBySession('team', item.id);
            this.props.hideSlideModal();
            this.deletLocalSession()
        }
    };

    deletLocalSession = ()=>{
        let { id, type } = this.props.sessionActive;
        this.props.sessionActiveSet({});
        let nimId = util.nim.getNimId(type, id);
        util.nim.deleteLocalSession(nimId);
    }


    // 退出小组
    leaveSquad = async () => {
        util.log('qinqinghao', 'box-setting-container:leavesquad', '退出小组点击');
        let item = this.props.sessionActive;
        let s = await squadQuit({ squad_id: item.id });
        if ((s.code == 200 && s.obj && s.obj.rlt) || s.code == 40304 || s.code == 40303) {
            if (s.code == 40304 || s.code == 40303) message.error(s.msg);
            await util.nimUtil.deleteLocalMsgsBySession('team', item.id);
            this.props.hideSlideModal();
            this.deletLocalSession()
            util.log('qinqinghao', 'box-setting-container:leavesquad', '退出小组成功');
        } else {
            util.log('qinqinghao', 'box-setting-container:leavesquad', '退出小组失败');
            message.error(s.msg);
        }
    };

    // 退群提示
    toggleQuitGroupModal = () => {
        this.setState((prev) => ({
            quitGroupModal: !prev.quitGroupModal,
        }));
    };

    quitGroupOk = () => {
        this.setState({ quitGroupModal: false });
        const { sessionActive } = this.props;
        if (sessionActive.type == 'team') return this.handleLeaveTeam();
        let tem = util.nimUtil.getJson(sessionActive.custom);
        if (tem && tem.identification == 'squad') this.leaveSquad();
    };

    quitGroupCancel = () => {
        this.setState({
            quitGroupModal: false,
        });
    };

    // 群主提示
    toggleOwnerModal = () => {
        this.setState((prev) => ({
            modalVisible: !prev.modalVisible,
        }));
    };

    quitGroupBtn = () => {
        const { id } = this.props.userInfo;
        if (this.state.owner && this.state.owner.id == id) {
            this.toggleOwnerModal();
        } else {
            this.toggleQuitGroupModal();
        }
    };

    quitSquadBtn = () => {
        this.toggleQuitGroupModal();
    };

    showGroupModal = async () => {
        //const { id } = this.props.sessionActive;
        //this.props.dispatch(showGroupModal({ type: 'addNumber', id }));
        let userIds = [];
        const { id } = this.props.sessionActive;
        const datas = await groupUsersEsList({
            tid: id,
            rows: 2000,
        });
        if (datas) {
            const { code, obj = {} } = datas || {};
            if (code === 200) {
                userIds = obj.list.map((item) => item.id + '');
            }
        }
        this.setState({
            userAddShow: true,
            userIds,
        });
    };

    // 添加用户
    userAddOk = async (data) => {
        console.log();
        const { id } = this.props.sessionActive;
        if (this.props.type === 'squad') {
            this.addSquadUser(data);
        } else {
            const ids = data.allDataUsers.map((v) => v.id);
            this.addTeamMembers(id, ids);
        }
    };

    // 添加小组成员
    addSquadUser = async (data) => {
        try {
            const opt = {
                user_ids: data.allDataUsers.map((v) => v.id).join(','),
                squad_id: this.props.sessionActive.id,
                dept_ids: data.orgs.length ? data.orgs.map((item) => item.deptId).join(',') : '',
            };
            const obj = await addSquadUser(opt);

            if (obj.code === 200) {
                if (!this.state.list.length || this.state.list.length < this.pageNum) this.getSquadUserList(this.pageNum);
                else {
                    const groupInfo = this.state.groupInfo;
                    groupInfo.user_total += data.allDataUsers.length;
                    this.setState({
                        groupInfo,
                    });
                }
                this.userAddClose();
                message.success(util.locale('im_added'));
            } else this.handlerQuitSquad(obj);
        } catch (e) {
            message.error(e);
        }
    };
    // 一次最大可以添加2000人
    addTeamMembers = async (id, ids) => {
        let maxCanAddMembers = 2000; //Math.max(2000 - this.state.list.length, 2000)
        ids = ids.slice(0, maxCanAddMembers);
        try {
            let r = await groupUsersAdd({
                tid: id,
                users: JSON.stringify(ids),
            });
            if (r.code == 200) {
                this.userAddClose();
                this.props.hideSlideModal();
            } else {
                message.error(r.msg);
            }
        } catch (err) {
            message.error(util.locale('im_failed_to_add'));
        }
    };

    userAddClose = () => {
        this.setState({ userAddShow: false });
    };

    // 移除成员弹窗
    delMember = (userName, userId) => {
        this.setState({
            userId,
            userName,
            delText: `${util.locale('im_confirm_removal')} ${userName} ${
                util.locale.getLang() === 'en-US'
                    ? ''
                    : this.state.typeMsg.type === 'setting'
                    ? this.state.typeMsg.value + '' + util.locale('im_members')
                    : ''
            }`,
            delModalVisible: true,
        });
    };

    delCancel = () => {
        this.setState({ delModalVisible: false });
    };

    // 删除组、群成员
    delOk = async () => {
        if (this.props.type === 'setting') {
            this.delGroupUser();
        } else if (this.props.type === 'squad') {
            this.delSquadUser();
        }
    };

    delSquadUser = async () => {
        try {
            const data = await delSquadUser({ user_ids: this.state.userId, squad_id: this.props.sessionActive.id });
            this.setState({ delModalVisible: false });
            if (data.code === 200) {
                message.success(this.state.userName + ' ' + util.locale('im_move_out_successfully'));
                this.filterUsers(this.state.userId);
            } else this.handlerQuitSquad(data);
        } catch (error) {
            message.error(this.state.userName + util.locale('im_failed_to_move_out'));
        }
    };

    delGroupUser = () => {
        const { id } = this.props.sessionActive;
        try {
            // const obj = util.nimUtil.removeTeamMembers(this.props.sessionActive.id, [this.state.userId]);
            // if (obj) {
            //     this.setState({delModalVisible: false});
            //     message.success(this.state.userName + " " + util.locale("im_move_out_successfully"));
            //     this.groupUserDel(this.props.sessionActive.id, JSON.stringify([this.state.userId]));
            // }
            this.setState({ delModalVisible: false });
            this.groupUserDel(id, JSON.stringify([this.state.userId]));
        } catch (error) {
            message.error(this.state.userName + util.locale('im_failed_to_move_out'));
        }
    };

    // 删除的小组成员过滤
    filterUsers = (userId) => {
        const groupInfo = this.state.groupInfo;
        groupInfo.user_total--;
        this.setState({
            list: this.state.list.filter((item) => item.user_id !== userId),
            groupInfo,
        });
    };

    getRule = () => {
        let arr = [];
        const { id } = this.props.userInfo;
        arr = this.state.list.filter((item) => {
            return id == item.id;
        });
        if (arr && arr.length > 0) return arr[0].role == 0 || arr[0].role == 1;
        return false;
    };

    getConfigEdite = () => {
        switch (this.props.type) {
            case 'setting':
                if (this.state.groupInfo.config_edite < 2) {
                    return this.state.groupInfo.user_type < 2;
                }
                if (this.state.groupInfo.config_edite == 2) return true;
                break;
            case 'squad':
                if (this.user_status === 'admin' || this.user_status === 'owner') return true;
                if (this.props.teamCircleAdmin.card && ['owner', 'admin'].includes(this.props.teamCircleAdmin.card))
                    return true;
                return false;
            default:
                return false;
        }
        return false;
    };

    handleKeyPress = (e) => {
        const keyCode = e.which || e.keyCode;
        if (keyCode == 13) this.handleGroupNameblur(e.target.value);
    };

    // 退出小组
    handlerQuitSquad = (data) => {
        data.msg && message.warning(data.msg);
        if (+data.code === 40303 || +data.code === 40304) {
            this.props.hideSlideModal();
            this.deletLocalSession()
            this.props.setBol(false);
        }
    };

    // 弹出聊天记录
    chatRecord = () => {
        const { sessionActive } = this.props;
        this.props.showSlideModal('historicalRecord', {
            tid: sessionActive.id,
            type: 2,
            name: util.locale('im_chat_history'),
        });
    };

    //机器翻译
    handleMachineTranslation = async (value) => {
        let { id } = this.props.sessionActive;
        id = `${id}`;
        await util.nim.handleMachineTranslation(id, !!value);
        await setAutoMachineTranslation({ session_id: id, auto_translate: value ? 1 : 0 });
        util.sensorsData.track('Click_Chat_Element', {
            chat_id: id,
            pageName: 137,
            $element_name: value ? '01-230':'01-231',
        });
    };

    render() {
        const { sessionList, sessionActive, addWindowShow, teamCircleAdmin } = this.props;
        const {
            list,
            showNameInput,
            showSearchInput,
            searchValue,
            modalVisible,
            quitGroupModal,
            userAddShow,
            owner,
            userIni,
            ifSearching,
            userIds,
            hasMoreData,
            searchGroupUser
        } = this.state;
        const sid = sessionActive.id;
        const { disnotice, isTop, showimg, showname, memberNum } =
            sessionList.filter((item) => {
                return item.id == sid;
            })[0] || {};
        const { translationList = [] } = this.props;
        let isTranslation = translationList.includes(`${sid}`);
        let userAddDisids = this.props.type === 'setting' ? userIds : list.map((v) => v.user_id + '');

        let masterId = owner ? (this.props.type === 'setting' ? owner.id : owner.user_id) : '';

        const props = {
            userIni: teamCircleAdmin,
            user_status: this.user_status,
            tid: sessionActive,
            disnotice,
            isTop,
            showimg,
            showname,
            memberNum,
            list,
            masterId,
            searchValue,
            showNameInput,
            showSearchInput,
            modalVisible,
            quitGroupModal,
            userAddShow,
            userAddDisids,
            ifSearching,
            hasMoreData,
            searchGroupUser,
            isTranslation,
            typeMsg: this.state.typeMsg,
            // groupInfo: this.state.groupInfo,
            groupInfo: { ...this.state.groupInfo, ...this.props.teamCircleAdmin },
            userAddOk: this.userAddOk,
            userAddClose: this.userAddClose,
            onFixtop: this.handleFixtop,
            onNodisturb: this.handleNodisturb,
            onReadmore: this.handleReadmore,
            onEditCommon: this.handleEditCommon,
            onGroupNameblur: this.handleGroupNameblur,
            onSearchValueChange: this.handleSearchValueChange,
            onToggleOwnerModal: this.toggleOwnerModal,
            onShowGroupModal: this.showGroupModal,
            quitGroupBtn: this.quitGroupBtn,
            quitSquadBtn: this.quitSquadBtn,
            quitGroupOk: this.quitGroupOk,
            quitGroupCancel: this.quitGroupCancel,
            goManagement: this.goManagement,
            userInfoId: this.props.userInfo.id,
            delMember: this.delMember,
            delCancel: this.delCancel,
            delOk: this.delOk,
            delModalVisible: this.state.delModalVisible,
            delText: this.state.delText,
            getRule: this.getRule,
            getConfigEdite: this.getConfigEdite,
            handleKeyPress: this.handleKeyPress,
            isAddress: this.isAddress,
            handleCancelSearch: this.handleCancelSearch,
            chatRecord: this.chatRecord,
            onMachineTranslation: this.handleMachineTranslation,
        };
        return <BoxSetting {...props} />;
    }
}

const mapStateToProps = (state) => {
    return {
        userInfo: state.userInfo,
        teamCircle: state.teamCircle,
        sessionActive: state.sessionActive,
        sessionList: state.sessionList,
        teamCircleAdmin: state.teamCircleAdmin,
        translationList: state.translationList,
    };
};

const mapDispatchToProps = {
    getUserIniRequest: teamCircleAction.getUserIniRequest,
    hideSlideModal,
    showSlideModal,
    sessionActiveSet,
    setBol
};

export default connect(mapStateToProps, mapDispatchToProps)(BoxSettingContainer);
