import React from 'react';
import { connect } from 'react-redux';
import { message } from 'antd';
import * as util from '@u/util.js';
import SendFileModal from '@c/common/sendFile-modal';
import * as sendFn from './box-send-fn';

import * as messageListAction from '@r/actions/messageList';
import * as draftAction from '@r/actions/draft';
import { sessionUploadFile } from '@r/actions/sessionUploadFile';

//message.config({ maxCount: 1});

class BoxSendModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            sendModalShow: false,
            sendModalTitle: '',
            sendModalClass: '',
        };
    }

    componentDidUpdate(prevProps) {
        if (prevProps.sendFileAction != this.props.sendFileAction && this.props.sendFileAction == 'input') {
            this.sendFileByTargetInput(this.props.sendFileTarget);
        }
        if (prevProps.sendFileAction != this.props.sendFileAction && this.props.sendFileAction == 'drag') {
            this.sendFileByTarget(this.props.sendFileTarget);
        }
        if (prevProps.sendFileAction != this.props.sendFileAction && this.props.sendFileAction == 'screencut') {
            this.sendFileByScreenCut(this.props.sendFileBase64, this.props.sendFileScreen);
        }
        if (prevProps.sendFileAction != this.props.sendFileAction && this.props.sendFileAction == 'paste') {
            this.sendFileByPaste(this.props.sendFileCliped);
        }
    }

    // 检查是否选择了文件夹
    checkIsDirectory = (path) => {
        let reqdata = { path };
        return new Promise((resolve) => {
            util.electronipc.electronGetFileStat(reqdata, (res) => {
                if (!res) return resolve(false);
                let isDirectory = res.isDirectory;
                return resolve(isDirectory);
            });
        });
    };

    commonUploadHandle = (copyTarget) => {
        this.directoryBeforUploadCheck(copyTarget, (fileInfo) => {
            console.log('返回的结果是', fileInfo);
            for (let i = 0; i < fileInfo.length; i++) {
                ((k) => {
                    setTimeout(() => {
                        let { size, name, path, ext, base64 } = fileInfo[k];
                        let type = sendFn.getType(ext);
                        if (type === 'dir') {
                            this.showSendModal('dir', name, size, path);
                        } else if (type === 'image' && fileInfo.length > 1) {
                            this.showSendModal(type, name, size, path, '', '', '', true);
                        } else {
                            this.showSendModal(type, name, size, path);
                        }
                    }, 0);
                })(i);
            }
        });
    };

    /**
     *
     * @param {*} copyTarget
     * 区别： 为了修复多选多文件卡死处理方案，两种性能差不多，先采用上面方案，2先保留
     */
    commonUploadHandle2 = (copyTarget) => {
        this.directoryBeforUploadCheck(copyTarget, async (fileInfo) => {
            console.log('返回的结果是', fileInfo);
            let actionQueu = [];
            if (fileInfo.length === 1 && sendFn.getType(fileInfo[0].ext) === 'image')
                return this.showSendModal(
                    'image',
                    fileInfo[0].name,
                    fileInfo[0].size,
                    fileInfo[0].path,
                    '',
                    '',
                    '',
                    true
                );
            for (let i = 0; i < fileInfo.length; i++) {
                let { size, name, path, ext, base64 = '', imgurl = '' } = fileInfo[i];
                let type = sendFn.getType(ext);

                this.fileinfo = {
                    type,
                    name: name || util.locale('im_files'),
                    size: size || '0',
                    path: path || '',
                    base64: base64 || '',
                    imgurl: imgurl || '',
                };

                if (/image/.test(type)) {
                    type = 8;
                    this.fileinfo = {
                        ...this.fileinfo,
                        ...(await util.imageDealer.getImageInfo(path || base64)),
                    };
                } else if (/word|excel|ppt|pdf/.test(type)) {
                    type = 5;
                } else if (type === 'dir') {
                    type = 26;
                } else {
                    type = 10;
                }

                actionQueu.push({
                    // sessionActive: this.props.sessionActive,
                    sessionActive: window.session_active,
                    custom: {
                        type,
                        data: {
                            ...this.fileinfo,
                            sender: util.yach.getAccount(),
                        },
                        status: 'uploading',
                    },
                });
            }
            this.props.fileUpload(actionQueu);
        });
    };

    directoryBeforUploadCheck = (copyTarget, cb) => {
        util.electronipc.mutilFileUploadReg(copyTarget, (res) => {
            console.log('qiuyanlong', '上传前校验回执', res);
            let fileInfo = [];
            let errtext = [];
            let errorInfo = new Map();

            for (let i = res.length - 1; i >= 0; i--) {
                const { size, has_large_2g, all_file_num, ext, type, error, filetype, imageinfo } = res[i];
                error && errorInfo.set(i, error.message);
                if (ext === 'dir' && size > 10737418240) {
                    !errorInfo.has(i) && errorInfo.set(i, util.locale('im_file_uoliad_dir_blow_10g'));
                }

                if (ext === 'dir' && has_large_2g) {
                    !errorInfo.has(i) && errorInfo.set(i, util.locale('im_file_uoliad_dir_blow_2g'));
                }

                if (ext === 'dir' && all_file_num > 1000) {
                    !errorInfo.has(i) && errorInfo.set(i, util.locale('im_file_uoliad_dir_blow_1k'));
                }
                //允许空文件夹上传
                // if (ext === 'dir' && !size) {
                //     !errorInfo.has(i) && errorInfo.set(i, util.locale('im_file_uoliad_dir_not_empty'));
                // }

                if (ext !== 'dir' && size > 2147483648) {
                    !errorInfo.has(i) && errorInfo.set(i, util.locale('im_file_uoliad_file_once_sender'));
                }

                if (filetype == 'image' && imageinfo && imageinfo.width * imageinfo.height > 9999 * 9999) {
                    !errorInfo.has(i) && errorInfo.set(i, util.locale('im_send_img_maxsize_limit'));
                }
            }

            for (let i = 0; i < res.length; i++) {
                if (!errorInfo.has(i)) fileInfo.push(res[i]);
            }

            if (errorInfo.size) {
                for (let [key, value] of errorInfo) {
                    errtext.push(value);
                }
            }

            if (errtext.length) {
                message.warning(Array.from(new Set(errtext)).join(', '));
            }

            cb && cb(fileInfo);
        });
    };

    // 上传方式1：通过文件按钮方式上传
    sendFileByTargetInput = async (target) => {
        if (!target.length) return;
        this.props.fileUplaodEventRegistryRemove('input');
        let copyTarget = [...target];
        this.commonUploadHandle(copyTarget);
        util.log('qiuyanlong', 'yach-im', 'upload:input', copyTarget);
    };

    // 上传方式2：发送文件：【拖拽】方式
    sendFileByTarget = async (filelist) => {
        this.props.fileUplaodEventRegistryRemove('drag');
        this.commonUploadHandle(filelist);
        util.log('qiuyanlong', 'yach-im', 'upload:drag', filelist);
    };

    // 发送文件3：通过粘贴方式 clipdata: ['..././x.log','..././x.log']
    sendFileByPaste = async (clipdata) => {
        if (this.props.ismute && !this.props.ismanager) return false;
        this.props.fileUplaodEventRegistryRemove('paste');
        this.commonUploadHandle(clipdata);
        util.log('qiuyanlong', 'yach-im', 'upload:paste', clipdata);
    };

    // 发送文件4：通过截图方式
    sendFileByScreenCut = (base64, filePath) => {
        if (this.props.ismute && !this.props.ismanager) return false;
        let type = 'image';
        let filename = `${util.locale('im_screenshot')}.png`;
        let filesize = base64.length;
        let path = filePath;
        let url = base64;
        this.showSendModal(type, filename, filesize, path, url, base64);
    };

    // 显示发送模态框
    showSendModal = async (type, name, size, path, imgurl, base64, buffer, isquick) => {
        // let sendModalType = 'file',
        //     sendModalTitle = '',
        //     sendModalContent = '',
        //     sendModalClass = '',
        //     children = '',
        //     showname = this.props.sessionActive.showname;
        // const { sendFileAction } = this.props;

        let common = {
            type: type || 'other',
            name: name || util.locale('im_files'),
            size: size || '0',
            path: path || '',
            base64: base64 || '',
            imgurl: imgurl || '',
        };

        if (type == 'video') {
            //let ext = path.substring(path.lastIndexOf('.') + 1, path.length);
            // name = `${util.locale('common_msg42').replace('[xxx]',moment(parseInt(Date.now())).format('YYYY-MM-DD HH:mm'))}`;
            // name = `${name}.${ext}`;
            try {
                const res = await util.videoUtil.getVideoDimensionsOf([path]);
                const { width, height, duration, codeh264 } = res[0];
                this.fileinfo = {
                    ...common,
                    width,
                    height,
                    dur: duration,
                    codeh264,
                };
                console.log('phj-fileinfo', this.fileinfo);
            } catch (e) {
                console.log('>>>>getVideoDimensionsOf', e);
            }
        } else {
            this.fileinfo = { ...common };
        }
        //群文件上传时图片不放入输入框
        if (type == 'image' && !isquick && !this.props.noDraftEditorStateImgAdd) {
            // 图片压缩
            //let base64 = await util.imageDealer.imageSrcToBase64(imgurl, 324, 0.8);
            //this.fileinfo.imgurl = util.imageDealer.base64ToBlob(base64);
            // 1.4.4版本：图片不走弹框方式，改为放在输入框里
            this.props.draftEditorStateImgAdd(this.fileinfo);
        } else {
            // 1.4.4版本：其他格式文件走上传
            this.fileUpload(type);
        }
    };

    // 上传前校验一次 上传和校验分离
    fileUpload = async (ptype) => {
        console.log('通过验证了开始上传了啊');
        let { type, path, base64 } = this.fileinfo;
        if (/image/.test(type)) {
            type = 8;
            this.fileinfo = {
                ...this.fileinfo,
                ...(await util.imageDealer.getImageInfo(path || base64)),
            };
        } else if (/word|excel|ppt|pdf/.test(type)) {
            type = 5;
        } else {
            type = 10;
        }

        ptype === 'dir' && (type = 26);
        util.yach.getSwitchState() && ptype === 'video' && (type = 30);

        if(this.props.groupFileUpload){
            //群文件上传
            this.props.sessionUploadFile({
                foldRelationId:this.props.foldRelationId || 0,
                needBell: this.props.needBell,
                sessionActive: window.session_active,
                custom: {
                    type,
                    data: {
                        ...this.fileinfo,
                        sender: util.yach.getAccount(),
                    },
                    status: 'uploading'
                },
            })
        }else{
            //会话上传
            this.props.fileUpload({
                // sessionActive: this.props.sessionActive,
                sessionActive: window.session_active,
                custom: {
                    type,
                    data: {
                        ...this.fileinfo,
                        sender: util.yach.getAccount(),
                    },
                    status: 'uploading',
                },
            });
        }
        

        this.closeModal();
    };
    // 模态框按键
    fileModalKeyDown = (event) => {
        if (this.state.sendModalShow && event.keyCode == 13) {
            this.fileUpload();
        }
    };

    // 关闭弹框
    closeModal = () => {
        this.setState({ sendModalShow: false });
    };

    render() {
        return (
            <SendFileModal
                modalTile={this.state.sendModalTitle}
                modalVisible={this.state.sendModalShow}
                setOKModal={this.fileUpload}
                setonCancelModal={this.closeModal}
                modalContent={this.state.sendModalContent}
                wrapClassName={this.state.sendModalClass}
                fileModalKeyDown={this.fileModalKeyDown}
                children={this.state.children || null}
            />
        );
    }
}

const mapDispatchToProps = {
    fileUpload: messageListAction.uploadRequest,
    draftEditorStateImgAdd: draftAction.draftEditorStateImgAdd,
    sessionUploadFile: sessionUploadFile
};
const mapStateToProps = (state) => ({
    // sessionActive: state.sessionActive,
});

export default connect(mapStateToProps, mapDispatchToProps)(BoxSendModal);
