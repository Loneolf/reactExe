// react
import React from 'react';

// util
import { style } from '@u/util.js';

// css
import css from './index.scss';

// component
import AvatarInfoContainer from './avatar-info/avatar-info-container';
import MainInfoContainer from './main-info/main-info-container';
import ToolsInfoContainer from './tools-info/tools-info-container';

// BoxInfo
export default props => {
    const {
        id,
        showNickName,
        yachNick,
        showname,
        showsign,
        fullSign,
        teamType,
        singleType,
        messageType,
        showRightModal,
        showDepart,
        showimg,
        isHiddenSessionType,
        busyinfo,
        is_robot,
        meetingSummaryClick,
        getUsermsgBoxRef,
       // busyIconStatus,
        newDeptName,
        position,
        searchHistoryGuide,
        groupDocGuide,
        closeGroupDocTips,
        closeGroupFileTips,
        closeSearchHistoryTips,
        groupFileGuide
    } = props;

    const avatarProps = {
        id,
        messageType,
        singleType,
        is_robot,
        showimg
    }

    const mainProps = {
        id,
        messageType,
        is_robot,
        showname,
        showDepart,
        isHiddenSessionType,
        showNickName,
        yachNick,
        busyinfo,
       // busyIconStatus,
        showsign,
        getUsermsgBoxRef
    }

    const toolsProps = {
        id,
        messageType,
        singleType,
        is_robot,
        isHiddenSessionType,
        showRightModal,
        teamType,
        groupDocGuide,
        meetingSummaryClick,
        searchHistoryGuide,
        closeGroupDocTips,
        closeGroupFileTips,
        closeSearchHistoryTips,
        showname,
        fullSign,
        newDeptName,
        position,
        showNickName,
        yachNick,
        groupFileGuide
    }

    return (
        <div className={css.box + style.getWinStyle(css, 'boxWin')} id = 'boxInfo'>
            {/* 左侧头像 */}
            <AvatarInfoContainer {...avatarProps}/>

            {/* 中部个人信息 */}
            <MainInfoContainer {...mainProps}/>

            {/* 右侧工具栏 */}
            <ToolsInfoContainer {...toolsProps} />
        </div>
    )
}

