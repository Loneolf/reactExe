// react
import React from 'react';
// ImBox
import GroupDocInput from './group-doc-input';
// connect
import { connect } from 'react-redux';
// util
import * as util from '@u/util.js';
// server
import { spaceFileAdd, spaceFileUpdate } from '@s/group/group-online-doc';
// antd
import { message } from 'antd';
// lodash
import debounce from 'lodash/debounce';

class GroupDocInputContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state = {
        showNameInput: null,
        createPlaceholder: null,
        showImg: null,
        fileName: this.props.defaultValue || '',
        fileType: '',
    };

    componentDidMount() {
        this.handleSure = debounce(this.handleSure, 500, {
            'leading': true,
            'trailing': false
        });
        util.eventBus.addListener('group-doc-create-btn', () => this.handleSure());
    }

    componentWillUnmount() {
        util.eventBus.removeListener('group-doc-create-btn')
    }

    handleOnChange = (e) => {
        e.stopPropagation();
        let text = e.target.value.trim();
        text = util.yach.textFiltering(text);
        this.setState({ fileName: text });
    };

    handleKeyPress = (e) => {
        const keyCode = e.which || e.keyCode;
        const { fileName } = this.state;
        if (keyCode === 27) this.handleCancel();
        if (keyCode === 13 && !fileName) this.handleCancel();
        if (keyCode === 13 && fileName) this.handleSure();
    };

    handleSure = () => {
        const { isRename } = this.props;
        const { fileName } = this.state;
        if (!fileName) return this.handleCancel();
        if (isRename) {
            this.handleRenameDoc();
        } else {
            this.handleCreateDoc();
        }
    };

    handleCancel = () => {
        const { isRename } = this.props;
        if (isRename) {
            this.handleCloseInput();
        } else {
            this.handleCloseCreateInput();
        }
    };

    handleCreateDoc = async () => {
        this.setState({ showNameInput: false });

        // const { id } = this.props.sessionActive;
        const { id } = window.session_active;
        const { fileName } = this.state;
        const { fileType,breadcrumbList } = this.props;
        const params = {
            name: fileName,
            type: fileType,
            group_id: id,
        };
        if(breadcrumbList && breadcrumbList.length>1) params.folder = breadcrumbList[breadcrumbList.length-1].guid
        
        let res = await spaceFileAdd(params);

        const { code, msg, obj = {} } = res;
        if (code === 200) {
            this.sensorsData(obj.type);
            this.handleCloseCreateInput(obj)
        } else {
            message.error(msg);
        }
    };

    handleCloseCreateInput = (data = null) => {
        util.eventBus.emit('group-doc-close-create-input', data);
        if (data && data.type !== 'folder') this.props.openFile(data);
    };

    handleCreateBtn = () => {
        const { fileName } = this.state;
        if (fileName) this.handleCreateDoc();
    }

    // 重命名的逻辑
    handleRenameDoc = async () => {
        // const { id } = this.props.sessionActive;
        const { id } = window.session_active;
        const { fileName } = this.state;
        const { currentGuid } = this.props;
        const params = {
            group_id: id,
            name: fileName,
            guid: currentGuid,
        };
        let res = await spaceFileUpdate(params);
        const { code, msg } = res;
        if (code === 200) {
            this.handleCloseInput({name: fileName, guid: currentGuid, isRename: true});
        } else {
            message.error(msg);
        }
    };

    handleCloseInput = (params = null) => {
        util.eventBus.emit('group-doc-rename-input');
        const {refreshList, refreshSearchList, isSearch} = this.props;
        if (params && refreshList && !isSearch) refreshList(params);
        if (params && refreshSearchList && isSearch) refreshSearchList(params);
    };

    sensorsData = (key) => {
        switch (key) {
            case 'newdoc':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-221'});
                break;
            case 'mosheet':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-222'});
                break;
            case 'slide':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-223'});
                break;
            case 'mindmap':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-225'});
                break;
            case 'form':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-224'});
                break;
            case 'folder':
                util.sensorsData.track('Click_Chat_Element', { pageName: '01-135', $element_name: '141', file_type: '01-226'});
                break;
            default:
                break;
        }
    }
        
    render() {
        return (
            <GroupDocInput
                showNameInput={this.state.showNameInput}
                createPlaceholder={this.props.createPlaceholder}
                showImg={this.props.showImg}
                defaultValue={this.props.defaultValue}
                isRename={this.props.isRename}
                handleKeyPress={this.handleKeyPress}
                handleCancel={this.handleCancel}
                handleSure={this.handleSure}
                handleOnChange={this.handleOnChange}
            />
        );
    }
}

const mapStateToProps = (state) => {
    return {
        // sessionActive: state.sessionActive,
    };
};

export default connect(mapStateToProps, null)(GroupDocInputContainer);
