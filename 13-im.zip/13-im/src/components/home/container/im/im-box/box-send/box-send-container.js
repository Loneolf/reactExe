// react
import React from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import { message } from 'antd';
// util
import * as util from '@u/util.js';
import * as linkMsgHandler from '@u/nim/container/link-msg-handler.js';
import { clipboard } from 'electron'
// BoxSend
import BoxSend from './box-send';
import BoxSendModal from './box-send-modal';
// common modal
import SendFileModal from '@c/common/sendFile-modal';
import FileModalInfo from '@c/common/file-modal-info';
// redux
import { add, replace } from '@r/actions/messageList';
import { show as replyShow } from '@r/actions/reply';
import { showOnlineIcon, hideOnlineIcon } from '@/redux/actions/meeting';
import { showMeetingStateAction, switchOnlineState, setEnterMeetingStatus } from '@/redux/actions/calender';
import {remindWin as remindWinAction} from '@r/actions/remind';
import * as draftAction from '@r/actions/draft';
import * as messageListAction from '@r/actions/messageList';
// debounce
import debounce from 'lodash/debounce';
// file info upload
import { fileUploadCos } from '@u/lib/file/file';
import { fileUpdateRevoke } from '@s/file/file-update';
import copy from 'copy-to-clipboard';
// server
import { robotMessageAPI, robotWelcomeAPI } from '@s/robots';
import { groupSpeak } from '@s/search/search';
import {audioBusMessagePush} from '@/services/message/message-quick';

import VideoSessione from '@c/common/video-session/video-session-container';
import { meetingStatus, meetingLeaveEnd, meetingCreateJoin, meetingFullScreenState } from '@/services/meeting/meeting.js';
import { meetingCreateJoinFun, saveTid, handleJoinFail, cancelAllCall } from '@u/lib/zoom/zoomFn';
import { videoSessionlHide, videoSessionShow } from '@/redux/actions/commonModal';
import { agoraRTMChannelListen } from '@u/lib/agora/agora-rtm-listen.js';
import draftfn from './box-send-editor/draftfn';
import {imCreateCanlendar} from '@c/home/container/coordination/schedule/common/common.js'
import { showSlideModal } from "@/redux/actions/commonModal";


let reportState = {
    userid: '',        //当前账号对应的zoom userid
    event_duration: 0, //说话时长
    talk_start: 0,
    end_talk: 0,
    notalk_start: 0
};
window.enterMeetingList = null;
let canOpenZoomInvite = false;//控制默认打开选人组件

// BoxSendContainer
class BoxSendContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state = {
        textInputValue: '',
        userAtShow: false,
        userAtInput: '',
        atListId: [],
        atAll: true,
        allAtUserIds: [],
        allAtList: [],
        atHighlighted: [],
        modalShow: false,
        evenFile: null,
        emojiContentVisible: false,
        iconName: 'iconweizhiwenjian',
        isFileImage: '',
        selectedText: '',
        screenCutPopover: false,
        children: '',
        className: '',
        modalTile: '',
        senBoxValue: '',
        file: {
            name: '',
            size: '',
            type: '',
        },
        localImageFile: {
            base64: '',
            name: '',
        },
        teamType: {
            type: 0, // 默认0
            attr: {}, // 相关熟悉
        },
        showVideoSession: false,
        showVideo: null,
        showAudio: null,
        onlineMeetingId: '',
        messageLoading: null,
        loopfntime: 20,             // 定时器的循环时间

        sendType: (util.yachLocalStorage.ls('systemset_shortcut') && util.yachLocalStorage.ls('systemset_shortcut').sendType) || 'default', // 发消息的方式

        visibleFileable: false,

        filesModleVisible: { show: false, num:0 },
        filePreActionType:'',
        isSendMessage:false, // 是否发送过信息，用于搜索权重计算

        breakPaste:false, // 阻断粘贴，使用键盘粘贴时，先阻断，判断是否是Excel，如果不是的话再粘上
        excelData:null, // Excel 粘贴数据
        showChooseExcelModal:false,  // excel粘贴站图片模态框
        turnImg:false, // 是否选择了转图片
        excelTurnImgType:'text'//粘贴是否是文本或者是Excel，默认是文本
    };

    componentWillMount() {
        const { userInfo, sessionActive } = this.props;
        const saveId = userInfo.id + '-' + sessionActive.id;
        const textInputValue = util.yach.getUserStorage('yach_draft')[saveId] || '';
        const atIds = util.yach.getUserStorage('yach_draft_id')[saveId] || [];
        const atHighlighted = util.yach.getUserStorage('yach_highlighted')[saveId] || [];
        const allAtList = util.yach.getUserStorage('yach_all_at_list')[saveId] || [];
        if (!textInputValue) return;
        this.setState(
            {
                textInputValue: textInputValue,
                allAtUserIds: atIds,
                allAtList: allAtList,
                atHighlighted,
            },
            () => {
                this.cursorSelectionRange();
            }
        );
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'componentWillMount', sessionActive.id, sessionActive.type);
    }

    componentWillReceiveProps(prov) {
        this.setUserStorage();
        if (prov.sessionActive.id != this.props.sessionActive.id) {
            this.setState({
                textInputValue: '',
                atListId: [],
                allAtUserIds: [],
            });
        }
    }

    async componentDidUpdate(prov, prevState) {
        const {sessionActive } = this.props;
        const { nimId } = sessionActive;
        if (prov.sessionActive.id != this.props.sessionActive.id) {
            const { userInfo } = this.props,
                saveId = userInfo.id + '-' + sessionActive.id,
                textInputValue = util.yach.getUserStorage('yach_draft')[saveId] || '',
                atIds = util.yach.getUserStorage('yach_draft_id')[saveId] || '',
                atHighlighted = util.yach.getUserStorage('yach_highlighted')[saveId] || '';
            this.setState(
                {
                    textInputValue: textInputValue,
                    allAtUserIds: atIds || [],
                    atHighlighted,
                },
                () => {
                    this.cursorSelectionRange();
                }
            );
        }

        if (prevState.textInputValue != this.state.textInputValue) {
            this.diffContent(prevState.textInputValue, this.state.textInputValue);
        }

        if (!nimId) return;
        if (!this.onlineMeetingSwitch &&
            !this.state.meetingHasPeople &&
            this.props.newMessageComing !== prov.newMessageComing) {
            await this.props.dispatch(switchOnlineState(''));
            window.HasReceiveProps = true;
            this.meetingStateLoopInit();
        }
        if (prov.draftEditorState != this.props.draftEditorState) {
            let text = draftfn.transToText(this.props.draftEditorState)
            this.setState({ textInputValue: text })
            // console.timeEnd('draft-dispatch-update')
            // console.time('draft-update-render')
        }
        if(this.props.messageList.length>0) this.localeMessageList = this.props.messageList
    }

    componentDidMount() {
        //this.systemSendType();
        this.initData();
        this.addListener();
        this.addDebounce();
        
    }

    componentWillUnmount() {
        this.setUserStorage();
        //const node = ReactDOM.findDOMNode(this.inputMessagesEndRef);
        //node.removeEventListener('paste', this.handlePaste);
        //node.removeEventListener('mousedown', this.handleMouseDown);
        //node.removeEventListener('select', this.handleSelect);

        const draftNode = document.getElementById('sendEditor')
        // draftNode.removeEventListener('paste', this.handlePaste);
        draftNode.removeEventListener('compositionupdate', this.handleCompositionupdate)
        document.removeEventListener('keydown', this.excelKeyDownHandle)
        util.eventBus.removeListener('screencut')
        util.eventBus.removeListener('sendType')
        util.eventBus.removeListener('sendMsg');
        try {
            document.removeEventListener('click', this.bindTodoTipsHide, false);
        } catch (e) {
            console.log(e)
        }
        this.reclearAllVariable('uninstall');
        util.eventBus.removeListener('enter-online-meeting');
        util.eventBus.removeListener('close-at-member');
        util.eventBus.removeListener('inputUploadHandle'); 
        this.isGropSpeak()
    }

    initData = () => {
        this.isNotScheduleMeeting();
        this.robotWelcome();
        this.copyPasteObj = {
            singleClickX: 0,
            singleClickY: 0,
            isfirstFocus: false,
            isAtLast: true,
            insertModel: true,
            isSelected: false,
        };
        util.yachLocalStorage.ls('zoom_bangongshi_session_id', { sessionActiveId: this.props.sessionActive.id });
        setTimeout(this.meetingStateLoopInit, 260);
        // window.setEnterMeeting = this.setEnterMeeting;
        this.initTime = new Date().getTime()
    };

    addDebounce = () => {
        this.sendImageAndMsgAll = debounce(this.sendImageAndMsgAll, 200);
        this.diffContent = debounce(this.diffContent, 200);
        this.screenCut = debounce(this.screenCut, 500);
        this.startCall = debounce(this.startCall, 500);
        this.meetingCreateJoinFun = debounce(this.meetingCreateJoinFun, 500);
    };

    addListener = () => {
        //const node = (this.node = ReactDOM.findDOMNode(this.inputMessagesEndRef));
        //node.addEventListener('paste', this.handlePaste);
        //node.addEventListener('mousedown', this.handleMouseDown);
        //node.addEventListener('select', this.handleSelect);

        const draftNode = document.getElementById('sendEditor')
        // draftNode.addEventListener('paste', this.handlePaste);
        draftNode.addEventListener('compositionupdate', this.handleCompositionupdate)
        document.addEventListener('keydown', this.excelKeyDownHandle)
        util.eventBus.addListener('screencut', data => this.screenCutCallback(data))

        util.eventBus.addListener('sendMsg', (item) => this.sendMsgFun(item));
        util.eventBus.addListener('sendType', data => this.setState({ sendType: data }))
        util.eventBus.addListener('dropImBox', (value) => this.handleDrag(value));
        util.eventBus.addListener('enter-online-meeting', this.joinMeetingGroupFn);
        util.eventBus.addListener('close-at-member', () => this.closeUserAt());
    };

    // 发送过信息后会向后端上报数据，用于优化搜索权重排序
    isGropSpeak = () => {
        if(this.props.sessionActive.type != 'team' || !this.localeMessageList || this.localeMessageList.length == 0) return
        if(new Date().getTime() - this.initTime < 500) return
        let len = this.localeMessageList.length
        if(this.localeMessageList[len - 1] && this.localeMessageList[len - 1].time < this.initTime) return
        let selfSpeakTime
        for (let i = 0; i < len; i++) {
            if(this.localeMessageList[i].from == this.props.userInfo.id){
                selfSpeakTime = this.localeMessageList[i].time 
            }
        }
        if(!selfSpeakTime || selfSpeakTime < this.initTime) return
        groupSpeak({group_tid:this.props.sessionActive.id,s_time:parseInt((new Date().getTime())/1000)})
    }

    // 机器人欢迎接口
    robotWelcome = async () => {
        const {sessionActive} = this.props;
        const electronMainFocusChange = window.store.getState().electronMainFocusChange;
        if( electronMainFocusChange && !electronMainFocusChange.focus || !navigator.onLine ) {
            util.log('robotWelcome',electronMainFocusChange.focus,navigator.onLine);
            return;
        };
        util.log('robotWelcome',sessionActive.id);
        if (sessionActive.type == 'p2p') {
            let sdata = util.yach.parseCustomType('p2p',sessionActive);
            if(sdata.type === 'robot') {
                await robotWelcomeAPI({ msgtype: 'welcome',  corp_id: this.props.userInfo.cp_id || 1, conversation_id: sessionActive.id});
            }
        }
    };
    // 机器人发消息接口
    robotMessage = async (object) => { 
        try {
            let result = await robotMessageAPI(object) || {};

            const { code, obj } = result;
            if (code !== 200) {
                util.log('zhangpeng', 'box-send-container', 'robotMessage机器人发消息接口出错了', result);
                return;
            }
            if (!obj.custom) {
                return;
            }
            const { type, body = {}, conversation_id: conversationId } = obj.custom;
            const { pathname } = window.location;

            setTimeout(()=>{
                const { sessionActive = {} } = window.store.getState();
                const { id: curSessionId } = sessionActive;
                // type：类型（1:跳转链接，侧边栏打开）
                if (pathname.includes('im') && curSessionId === conversationId && type == 1 && body.url) {
                    window.location.href = body.url;
                }
            }, 600)
        } catch (error) {
            console.log(error)
        }
    };

    // 机器人回复消息封装
    sendRobotMessage = async (reply, seedMsg, reply_content, conversation_type, at_highlight, chatbot_uid, replymsgtype) => {
        const obj = {
            msgtype: 'reply',
            content: seedMsg.text,
            create_at: seedMsg.time,
            conversation_type,
            conversation_id: seedMsg.to,
            corp_id: this.props.userInfo.cp_id || 1,
            msg_id: seedMsg.idServer,
            reply_content,
            reply_msg_id: reply.idServer,
            at_highlight,
            chatbot_uid,
            replymsgtype
        };
        await this.robotMessage(obj);
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendRobotMessage');
    };

    handleMouseDown = (e) => {
        const node = this.node;
        this.copyPasteObj.insertModel = node.selectionStart === node.selectionEnd;
        if (e.buttons === 2) {
            if (!window.getSelection().toString()) {
                // 已经是选中状态
                if (this.copyPasteObj.insertModel) {
                    const insetPos = node.selectionStart;
                    const value = node.value;
                    node.value = '';
                    setTimeout(() => {
                        node.value = value;
                        node.setSelectionRange(insetPos, insetPos);
                    }, 0);
                }
            }
        } else if (e.buttons === 1) {
            this.copyPasteObj.singleClickX = e.offsetX;
            this.copyPasteObj.singleClickY = e.offsetY;
            setTimeout(() => {
                this.copyPasteObj.isAtLast = node.selectionStart === node.value.length;
            }, 0);
        }
    };
    handleSelect = () => {
        const selectionObj = window.getSelection();
        const selectedText = selectionObj.toString();
        if (this.state.selectedText !== selectedText) {
            this.setState({
                selectedText,
            });
        }
    };

    getType(ext) {
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'getType', ext);
        if (ext == 'doc' || ext == 'docx') return 'word';
        if (/msword|vnd.openxmlformats-officedocument.wordprocessingml.document/i.test(ext)) return 'word';
        if (ext == 'xls' || ext == 'xlsx') return 'excel';
        if (/spreadsheet|x-excel|vnd.ms-excel|vnd.openxmlformats-officedocument.spreadsheetml.sheet/i.test(ext))
            return 'excel';
        if (ext == 'ppt' || ext == 'pptx') return 'ppt';
        if (
            /powerpoint|ms-powerpoint|vnd.openxmlformats-officedocument.presentationml.presentation|vnd.openxmlformats-officedocument.presentationml.slideshow/i.test(
                ext
            )
        ) {
            return 'ppt';
        }
        if (/pdf/i.test(ext)) return 'pdf';
        if (/png|jpg|bmp|jpeg|gif|svg|wmf|jpe|ico|pic|tiff|pjpeg|jfif|pjp/i.test(ext)) return 'image';
        if (/wmv|asf|asx|rm|rmvb|mp4|3gp|mov|m4v|avi|dat|mkv|flv|vob|rn-realmedia|mid/i.test(ext)) return 'video';
        return 'other';
    }

    getIconByFileType(type) {
        const types = ['word', 'excel', 'pdf', 'ppt', 'video', 'video', 'other'];
        if (types.includes(type)) return this.setState({ iconName: type });
        return this.setState({ iconName: 'other' });
    }
    
    handlePasteClick = () => {
        this.isPasteByRightMenu = true;
        document.execCommand('paste');
    };


    showFile = (e) => {
        if (e.type === 'paste') {
            this.setState({ isFileImage: false });
            //获取文件信息，同File对象相同
            let files = e.clipboardData.files;
            let type = this.getType(files && files[0] && files[0].type);
            if (files && files[0]) {
                this.setState({
                    file: {
                        name: files && files[0] && files[0].name,
                        size: util.yach.getFileSize(files && files[0] && files[0].size),
                        type: type,
                    },
                });
                this.getIconByFileType(type);
            }
            util.log('zhangyongchang', 'yach-im', 'box-send-container', 'showFile');
        }
        this.getEventFile(e);
    };

    screenCutSend = (base64) => {
        this.setState(
            {
                isFileImage: true,
                localImageFile: {
                    base64,
                    name: `${util.locale('im_screenshot')}.jpeg`,
                },
                modalTile: `${util.locale('im_sent_screenshot_to')}${this.props.sessionActive.showname}`,
                children: <img src={base64} style={{ width: '100%', height: '100%', objectFit: 'scale-down' }} />,
                className: 'sendFileModal',
            },
            () => {
                this.screenshotModalOpen();
            }
        );
    };

    cursorSelectionRange = () => {
        //const node = ReactDOM.findDOMNode(this.inputMessagesEndRef);
        //const strLength = this.state.textInputValue.length;
        //util.yach.setSelectionRange(node, strLength, strLength);
    };

    setUserStorage = () => {
        const { userInfo, sessionActive } = this.props;
        const saveId = userInfo.id + '-' + sessionActive.id;
        let { textInputValue = '', allAtUserIds, allAtList, atHighlighted } = this.state;
        //let hasImg = draftfn.getEntityData(this.props.draftEditorState).find(v => v.type == 'image')
        //if (hasImg) textInputValue = `[${util.locale('im_image')}]` + textInputValue
       
        // 该部分是处理切换的时候 特殊类型不在进行草稿处理 直接return 
        if(sessionActive.type === 'p2p'){
            let stype = util.yach.parseCustomType('p2p',sessionActive);
            if(stype.res || ['3004'].includes(sessionActive.id)) return util.yach.setUserStorage('yach_draft',saveId); 
        }
       
        textInputValue = draftfn.transToCustomText(this.props.draftEditorState)
        if (this.props.userInfo.id) { 
            util.yach.setUserStorage(
                'yach_draft',
                saveId,
                textInputValue.trim().length > 0 ? textInputValue : undefined
            );
            util.yach.setUserStorage(
                'yach_draft_html',
                saveId,
                draftfn.transToHtml(this.props.draftEditorState) || undefined
            );
            util.yach.setUserStorage('yach_draft_id', saveId, allAtUserIds);
            util.yach.setUserStorage('yach_all_at_list', saveId, allAtList);
            util.yach.setUserStorage('yach_highlighted', saveId, atHighlighted);
        }
    };


    fileNumMore_10 = (list)=>{
        let len = list.length || 0;
        if(len>10 && len <=100 ) this.setState({ filesModleVisible:{show: true,num:len} });
        if(len>100)  return  message.warning(util.locale('im_file_uoliad_dir_once_sender'));  
    }

    /**
     * type: input drag paste cut
     * bind
     */
    fileUplaodEventRegistryBind = (type,dataObj)=>{
        this.setState(pre=>({filePreActionType:type}),()=>{
            util.eventBus.addListener(`${type}UploadHandle`,()=>{
                 this.setState(
                    {
                        sendFileAction: type,
                        sendFileTarget: type !== 'paste'? dataObj : [],
                        sendFileCliped: type === 'paste'? dataObj : [],
                        visibleFileable: false,
                    },
                    () => {
                        this.setState({ sendFileAction: '' });
                    }
                 ) 
            });
        });
    }

    /**
     *  unbind
     */
    fileUplaodEventRegistryRemove = (type)=>{
        util.eventBus.removeListener(`${type}UploadHandle`);
    }

    // 上传文件方式一：input框选择 
    fileChange = async (stype) => {
        // 每一次上传之前就清理掉事件监听
        this.fileUplaodEventRegistryRemove('input');
        this.setState({ visibleFileable:false });
        util.electronipc.electronOpenDialog(stype,(res)=>{
            console.log('qiuyanlong','选择的内容是',res);
            const {canceled,filePaths} = res;
            const len = filePaths.length;

            this.fileUplaodEventRegistryBind('input',filePaths);
            if(canceled && !len )  return;
            if(len && len <=10)  return util.eventBus.emit('inputUploadHandle'); 
            this.fileNumMore_10(filePaths);   
      });

      util.sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-168'});
    };


    // 上传文件方式二：拖动文件
    handleDrag = (obj) => {
        //obj.event.stopPropagation();
        this.fileUplaodEventRegistryRemove('drag');
        obj.event.preventDefault();
        if(this.props.ismute && !this.props.ismanager) {
            return
        }
        if (obj.event.type === 'drop') {
           let dropFiles = []; 
           let target  = obj.event.dataTransfer;
           if(target.items !== undefined) {
             for(var i = 0; i < target.items.length; i++) {
                var item = target.items[i];
                if(item.kind === "file") {
                    var filesss = item.getAsFile();
                    dropFiles.push(filesss);
                 }
              }
           }
         let filelist =  dropFiles.map(item=>item.path);
         let len = filelist.length;
         this.fileUplaodEventRegistryBind('drag',filelist);
         if(!len)  return;
         if(len <=10)  return util.eventBus.emit('dragUploadHandle'); 
         this.fileNumMore_10(filelist);   
        }
    };

     // 上传文件方式 三：粘贴板
     handlePaste = (e) => {
        this.setState({breakPaste:true})
        this.fileUplaodEventRegistryRemove('paste');
        util.electronipc.electronClipboardAnalysis((data) => {
            data = this.handleClipboardData(data)
            if(data.type === 'excel'){
                this.paste_excel_text = this.parseExcelTurnText(data.html, data.text) || data.text
                util.sensorsData.track('PageView_Chat', { pageName: '01-131'});
                return this.setState({excelTurnImgType:'excel',excelData:data,showChooseExcelModal:true}) 
            }
            if(data.type !== 'excel') this.setState({excelTurnImgType:'text',breakPaste:false})
            // if (!data.type || data.type == 'text') return false;

            if (data.text) {
                this.props.dispatch(draftAction.draftEditorStateTextAdd(data.text))
            }

            if (data.list && data.list.length) {
                let filelist = data.list.map(v => v.filepath);
                let len = filelist.length;
                if (data.type != 'files' || !data.list) return false
            
                this.fileUplaodEventRegistryBind('paste',filelist);
                if(!len)  return;
                if(len <=10)  return util.eventBus.emit('pasteUploadHandle'); 
                this.fileNumMore_10(filelist); 
            }
        });
    };

    // 处理剪贴板数据
    handleClipboardData = data => {
        let platform = util.electron.isMac() ? 'mac' : 'windows'
        let bookmark = clipboard.readBookmark()

        // 文本图片都要保留的
        if (data.type == 'excel') {
            return data
        }

        // 只保留图片
        let macfile = platform == 'mac' && clipboard.read('public.file-url')
        let urlimage = bookmark && bookmark.url
        let onlyimage = !data.text && data.list && data.list.length
        if (macfile || urlimage || onlyimage) {
            data.text = ''
            return data
        }

        // 只保留文本
        data.list = null
        return data
    }

    parseExcelTurnText = (html,text)=>{
        // if(this.props.excelTurnImgType === 'text') return text
        text = text.replace(/\t/g,'\n')
        if(!html) return text
        let firstTrIndex = html.indexOf('<tr')
        html = html.substring(firstTrIndex)
        if((~html.indexOf('OneNote.File') || ~html.indexOf('Microsoft OneNote')) && !~html.indexOf('<tr')) return text
        try {
            let arr1 = html.split('</tr>')
            arr1.pop()
            let arr2 = []
            arr1.forEach(item => {
                let tem
                tem = item.split('</td>') 
                tem.pop()
                arr2.push(tem)
            });
            arr2.forEach(item => {
                item.forEach((n,i)=>{
                    n = n.replace(/[\r\n ]/g,'')
                    n = n.replace(/<br>/g,'\n')
                    item[i] = (n.replace(/<\/?.+?\/?>/g,'')).trim()+'\n'
                    if(item[i].indexOf('<td') != -1 && item[i].indexOf('>')){
                        item[i] = item[i].split('>')[1]
                    }
                }) 
                
            });
            let result = (arr2.flatMap((x)=>{return x})).join('').trim()
            result = result.replace(/\&nbsp;/g,"");
            result = result.replace(/\&lt;/g,"<");
            result = result.replace(/\&gt;/g,">");
            result = result.replace(/\&quot;/g,`"`);
            result = result.replace(/\&#39;/g,"'");
            result = result.replace(/\&amp;/g,"&");
            return result
        } catch (error) {
            return text.trim()
        }
        
    }

      // 上传文件方式四：截图
      screenCut = (hideMain) => {
        const { screenCutPopover } = this.state;
        if (screenCutPopover) {
            // 开始切图之后关掉Popover
            this.setState({
                screenCutPopover: false,
            });
        }
        util.electronipc.electronScreenCut({ hideMain });
        util.sensorsData.track('Click_Chat_Element', {
            pageName: 135,
            $element_name: 359,
        });
    };

    excelTurnImg=()=>{
        const data = this.state.excelData
        if (data.type !=='excel' || !data.list || !data.list[0] || !data.list[0].base64 || !data.list[0].filepath) return message.warn(util.locale('im_error_data'))
        const path = require('path');
        this.setState({
                sendFileAction: 'screencut',
                sendFileBase64: data.list[0].base64,
                sendFileScreen: `${path.dirname(data.list[0].filepath).replace(/\\/g,'/')}/${path.basename(data.list[0].filepath)}`
            },() => {this.setState({ sendFileAction: '' });});
        this.paste_excel_text = ''
        this.setState({breakPaste:false,excelData:null,showChooseExcelModal:false,turnImg:true},()=>{this.setState({turnImg:false})})
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-131', $element_name: '01-205'});
    }

    excelKeepText=()=>{
        // 弹窗关闭draft焦点不对会有问题，先聚焦，再粘贴文本
        draftfn.focusEditor()

        setTimeout(() => {
            let editorstate = this.props.draftEditorState
            let html = draftfn.textToHtml(this.paste_excel_text)
            let contentState = draftfn.createContentFromHtml(html)
            let blockMap = contentState.blockMap
            editorstate = draftfn.addFragment(editorstate, blockMap)
            this.props.dispatch(draftAction.draftEditorStateSet(editorstate))
            this.paste_excel_text = ''
            this.setState({breakPaste:false,excelData:null,showChooseExcelModal:false,turnImg:false})
        }, 0);

        util.sensorsData.track('Click_Chat_Element', { pageName: '01-131', $element_name: '01-206'});
    }
    excelModalCancel=()=>{
        this.paste_excel_text = ''
        this.setState({breakPaste:false,excelData:null,showChooseExcelModal:false,turnImg:true},()=>{this.setState({turnImg:false})})
    }

    excelKeyDownHandle = (e)=>{
        const {showChooseExcelModal} = this.state
        if(!showChooseExcelModal || e.key !== 'Enter') return
        let time = setTimeout(() => {
            clearTimeout(time)
            this.excelKeepText()
        }, 100);
    }

    handleVisibleChangeFile = visibleFileable => {
        this.setState({ visibleFileable });
    }

    sendYunxinFile = async (event, fileText, fileType) => {
        const {
            sessionActive: { type, id },
        } = this.props;
        try {
            const { pushPayload } = this.getPushObj(fileText);
            let obj = null;
            if (fileType == 'node') {
                obj = await util.nim.sendFile(type, id, event, 'node', pushPayload);
            } else {
                obj = await util.nim.sendFile(type, id, event, 'blob', pushPayload);
            }
            if (obj) {
                if (obj.to == window.store.getState().sessionActive.id) this.pushMessage(obj, 1);
                this.uploadSensorsData(obj);
            }
        } catch (error) {
            message.error(error.message);
            console.log(error.message);
        }
    };

    sendLocalImageFile = async (file) => {
        const { sessionActive } = this.props;
        if (!sessionActive) return;
        const { pushContent, pushPayload } = this.getPushObj(`[${util.locale('im_image')}]`);
        let formData = new FormData();
        let apns = '';
        formData.append('file', file.base64);
        formData.append('file_name', file.name.substring(0, file.name.lastIndexOf('.')));
        formData.append('source', sessionActive.type == 'team' ? 'group' : 'person');
        formData.append('recive_id', sessionActive.id);
        apns = {
            forcePush: false,
        };
        await this.sendLocalImage(formData, this.state.localImageFile.name, pushContent, pushPayload, apns);
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendLocalImageFile', sessionActive.id, sessionActive.type);
    };

    sendFile = async (file, name, size, fileText, type) => {
        util.log('zhangyongchang', 'yach-im', 'box-send-container.js', 'sendFile');
        const { sessionActive } = this.props;
        if (!sessionActive) return;
        const { pushContent, pushPayload } = this.getPushObj(fileText);
        let formData = new FormData();
        let apns = '';
        formData.append('img', file);
        formData.append('source', sessionActive.type == 'team' ? 'group' : 'person');
        formData.append('group_tid', sessionActive.id);
        apns = {
            forcePush: false,
        };
        if (type == 1) {
            await this.sendOffice(formData, name, size, pushContent, pushPayload, apns);
        } else if (type == 2) {
            await this.sendImage(formData, name, size, pushContent, pushPayload, apns);
        } else if (type == 3) {
            await this.sendCustomize(formData, name, size, pushContent, pushPayload, apns);
        }
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendFile');
    };

    getPushObj = (fileText) => {
        const { userInfo, sessionActive } = this.props;
        const { name, name_nick } = userInfo;
        if (!sessionActive) return;
        let pushContent = '',
            pushPayload = {};
        if (sessionActive.type == 'team') {
            pushContent = `${name}${name_nick ? '(' + name_nick + ')' : ''}: ${fileText}`;
            pushPayload = {
                pushTitle: util.yach.decodeUnicode(sessionActive.showname),
                sessionType: 1,
                sessionID: sessionActive.id,
            };
        } else {
            pushContent = `${fileText}`;
            pushPayload = {
                pushTitle: util.yach.decodeUnicode(name_nick || name),
                sessionType: 0,
                sessionID: sessionActive.id,
            };
        }
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'getPushObj');
        return { pushContent, pushPayload };
    };

    changeMsgId = async (relation_id, msg_id) => {
        await fileUpdateRevoke({ relation_id, msg_id });
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'changeMsgId');
    };

    sendCustomize = async (formData, name, size, pushContent, pushPayload, apns) => {
        try {
            const { sessionActive } = this.props;
            const receive_type = sessionActive.type == 'team' ? 0 : 1;
            const data = await fileUploadCos({
                formData,
                filetype: 'file',
                receive_id: sessionActive.id,
                receive_type,
            });
            if (data && data.code === 200) {
                const { obj = '' } = data;
                const custom = {
                    type: 10,
                    data: {
                        fileName: name,
                        fileSize: size,
                        fileThumbnailUrl: obj.thumbnail_url,
                        thumbWidth: obj.thumb_width,
                        thumbHeight: obj.thumb_height,
                        width: obj.width,
                        height: obj.height,
                        relationId: obj.relation_id,
                        fileOriginUrl: obj.origin_url,
                        id: obj.file_id,
                    },
                };
                const sendCustomMsg = await this.sendCustomMsg(custom, pushContent, pushPayload, apns);
                const { idClient } = sendCustomMsg;
                this.changeMsgId(obj.relation_id, idClient);
            } else {
                message.error(`${name} ${util.locale('common_msg20')}`);
            }
            util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendCustomize');
        } catch (err) {
            util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendCustomize: catch');
            message.error(`${name} ${util.locale('common_msg20')}`);
        }
    };

    sendLocalImage = async (formData, name, pushContent, pushPayload, apns) => {
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendLocalImage');
        try {
            const { sessionActive } = this.props;
            const receive_type = sessionActive.type == 'team' ? 0 : 1;
            const data = await fileUploadCos({
                formData,
                filetype: 'image',
                receive_id: sessionActive.id,
                receive_type,
            });
            //console.warn(data, 8888);
            if (data && data.code === 200) {
                const { obj = '' } = data;
                const custom = {
                    type: 8,
                    data: {
                        fileName: obj.name,
                        fileSize: obj.fileSize,
                        fileOriginUrl: obj.origin_url,
                        width: obj.width,
                        height: obj.height,
                        relationId: obj.relation_id,
                        fileThumbnailUrl: obj.thumbnail_url,
                        thumbWidth: obj.thumb_width,
                        thumbHeight: obj.thumb_height,
                        id: obj.file_id,
                    },
                };
                const sendCustomMsg = await this.sendCustomMsg(custom, pushContent, pushPayload, apns);
                const { idClient } = sendCustomMsg;
                this.changeMsgId(obj.relation_id, idClient);
            } else {
                message.error(`${name} ${util.locale('common_msg20')}`);
            }
        } catch (err) {
            message.error(`${name} ${util.locale('common_msg20')}`);
        }
    };
    sendImage = async (formData, name, size, pushContent, pushPayload, apns) => {
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendImage');
        try {
            const { sessionActive } = this.props;
            const receive_type = sessionActive.type == 'team' ? 0 : 1;
            const data = await fileUploadCos({
                formData,
                filetype: 'image',
                receive_id: sessionActive.id,
                receive_type,
            });
            if (data && data.code === 200) {
                const { obj = '' } = data;
                const custom = {
                    type: 8,
                    data: {
                        fileName: name,
                        fileSize: size,
                        fileOriginUrl: obj.origin_url,
                        fileThumbnailUrl: obj.thumbnail_url,
                        thumbWidth: obj.thumb_width,
                        thumbHeight: obj.thumb_height,
                        width: obj.width,
                        height: obj.height,
                        relationId: obj.relation_id,
                        id: obj.file_id,
                    },
                };
                const sendCustomMsg = await this.sendCustomMsg(custom, pushContent, pushPayload, apns);
                const { idClient } = sendCustomMsg;
                this.changeMsgId(obj.relation_id, idClient);
            } else {
                message.error(`${name} ${util.locale('common_msg20')}`);
            }
        } catch (err) {
            message.error(`${name} ${util.locale('common_msg20')}`);
        }
    };

    sendOffice = async (formData, name, size, pushContent, pushPayload, apns) => {
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendOffice');
        try {
            const { sessionActive } = this.props;
            const receive_type = sessionActive.type == 'team' ? 0 : 1;
            const data = await fileUploadCos({
                formData,
                filetype: 'file',
                receive_id: sessionActive.id,
                receive_type,
            });
            if (data && data.code === 200) {
                const { obj = '' } = data;
                const custom = {
                    type: 5,
                    data: {
                        fileName: name,
                        fileSize: size,
                        fileUrl: obj.origin_url,
                        id: obj.file_id,
                        relationId: obj.relation_id,
                    },
                };
                const sendCustomMsg = await this.sendCustomMsg(custom, pushContent, pushPayload, apns);
                const { idClient } = sendCustomMsg;
                this.changeMsgId(obj.relation_id, idClient);
            } else {
                message.error(`${name} ${util.locale('common_msg20')}`);
            }
        } catch (err) {
            message.error(`${name} ${util.locale('common_msg20')}`);
        }
    };

    sendCustomMsg = async (custom, pushContent, pushPayload, apns = {}) => {
        const { sessionActive } = this.props;
        const customMsg = await util.nim.sendCustomMsg(
            sessionActive.type,
            sessionActive.id,
            JSON.stringify(custom),
            apns,
            pushContent,
            '',
            pushContent,
            pushPayload,

            async (msg) => {
                const obj = await util.nim.genMsgItem(msg);
                if (msg.to == window.store.getState().sessionActive.id) this.props.dispatch(add(obj));
            }
        );
        if (customMsg.to == window.store.getState().sessionActive.id) this.pushMessage(customMsg, 2);
        this.uploadSensorsData(customMsg);
        util.yach.refreshConnect(customMsg);
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendCustomMsg');
        return customMsg;
    };

    sendMsgFun = (item) => {
        let { scene, fromNick, from, fromYachNick } = item;
        fromNick = util.yach.decodeUnicode(fromNick);
        let textInputValue = this.state.textInputValue;
        // this.state.atHighlighted.push({
        //     id: from,
        //     index: textInputValue.length,
        //     atName: `@${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`,
        // });
        if (scene == 'team' && from != this.props.userInfo.id) {
            textInputValue = `${textInputValue} @${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}  `;
            this.setState({ textInputValue: textInputValue }, () => {
                this.resetAtHighIndex(this.state.textInputValue);
            });
            this.setState({
                allAtUserIds: [...this.state.allAtUserIds, from],
                allAtList: [
                    ...this.state.allAtList,
                    { id: from, name: `${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}` },
                ],
            });
            let text = ` @${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''} `
            if(item.robot && item.robot[item.from] == 'robot_user') text = ` @${fromNick}(${fromNick}) `
            let data = { id: from }
            this.props.dispatch(draftAction.draftEditorStateAtAdd(text, data))
        }
        setTimeout(draftfn.focusEditor, 100)
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'sendMsgFun', scene, from);
        this.cursorSelectionRange();
    };

    textareaValue = (event) => {
        event.persist()
        this.setState({ textInputValue: event.target.value }, () => {
            this.resetAtHighIndex(this.state.textInputValue);
            if(!event.target.value || event.target.value.trim()) this.setUserStorage()
        });
    };

    //监听变化后做diff算法
    diffContent = (_old, _new) => {
        const { type } = this.props.sessionActive;
        if (type == 'p2p') return;
        let insertAt = false;
        let diffArr = util.diff(_old, _new);

        if (_new == '@') {
            insertAt = 'insert';
        }

        if (diffArr && diffArr.length) {
            if (diffArr.find((v) => v[0] == util.diff.INSERT && v[1].trim(' ') == '@')) {
                insertAt = 'insert';
            }
            if (diffArr.find((v) => v[0] == util.diff.DELETE && v[1].trim(' ') == '@')) {
                insertAt = 'delete';
            }
            this.dataAll = diffArr;
        }

        if (insertAt == 'insert') {
            this.setState({
                userAtShow: true,
                userAtInput: '',
            });
            return false;
        }

        if (insertAt == 'delete') {
            this.closeUserAt();
            return false;
        }

        // at 人逻辑梳理：
        // userAtShow：控制at人框显示与否，和是否搜索无关，有人就显示，没人就隐藏
        // searching：控制是否在打字搜索中
        // 只要searching中input值变化（或输入@首次显示框）就触发搜索，如果搜到了就show，没搜到就不show

        // 目前遗留问题：
        // 1.从中间@人时搜索不对，因为我们获取的最后一个@符号之后的字作为搜索文本
        // 2.中文搜索时中文+一半拼音时不对，因为判断的只把当时的拼音作为搜索文本

        if (this.searching) {
            let index = _new.lastIndexOf('@')
            if (index == -1) return this.closeUserAt()
            let q = _new.slice(_new.lastIndexOf('@') + 1);
            if (q.length > 16) return this.closeUserAt()
            this.setState({ userAtInput: q });
        }
    };

    handleCompositionupdate = e => {
        let data = e.data || ''
        let text = data.split('\'').join('')
        if (text && this.searching) {
            this.setState({ userAtInput: text })
        }
    }

    closeUserAt = () => {
        this.setState({
            userAtShow: false
        });
        this.searching = false;
    };

    showUserCB = isUserSearched => {
        this.searching = true
        this.setState({
            userAtShow: !!isUserSearched
        })
        // this.searching = bl;
    };

    getEventFile = (e) => {
        if (e.clipboardData && e.clipboardData.items) {
            this.uploadEvenData(e.clipboardData);
        } else if (e.dataTransfer && e.dataTransfer.items) {
            this.uploadEvenData(e.dataTransfer);
        }
    };

    uploadPasteData = (evenFile) => {
        if (evenFile) {
            var reader = new FileReader();
            let that = this;
            reader.onload = function (event) {
                if (that.state.file.type == 'image') {
                    that.setState({
                        modalTile: `${util.locale('im_sent_to')}${that.props.sessionActive.showname}`,
                        children: (
                            <img
                                src={event.target.result}
                                style={{ width: '100%', height: '100%', objectFit: 'scale-down' }}
                            />
                        ),
                        className: 'sendFileModal',
                    });
                } else if (that.state.file.type == 'video') {
                    that.setState({
                        children: (
                            <FileModalInfo
                                username={that.props.sessionActive.showname}
                                iconName={that.state.iconName}
                                fileType={util.locale('im_video')}
                                fileSize={that.state.file.size}
                                fileName={that.state.file.name}
                            />
                        ),
                        className: 'smallSendFileModal',
                        modalTile: '',
                    });
                } else {
                    that.setState({
                        children: (
                            <FileModalInfo
                                username={that.props.sessionActive.showname}
                                iconName={that.state.iconName}
                                fileType={util.locale('im_files')}
                                fileSize={that.state.file.size}
                                fileName={that.state.file.name}
                            />
                        ),
                        className: 'smallSendFileModal',
                        modalTile: '',
                    });
                }
                that.setState({ evenFile: evenFile });
                that.screenshotModalOpen();
            };
            reader.readAsDataURL(evenFile);
        }
    };

    uploadEvenData = (obj) => {
        const {
            items: { length: iteamLength },
        } = obj;
        let evenFile = '';
        let that = this;
        for (let i = 0; i < obj.items.length; i++) {
            const item = obj.items[i];
            if (item.kind === 'string') {
                if (this.isPasteByRightMenu) {
                    return (this.isPasteByRightMenu = false);
                }
                item.getAsString(function (str) {
                    const node = ReactDOM.findDOMNode(that.inputMessagesEndRef);
                    util.yach.insertAtCursor(
                        node,
                        str,
                        (value) => {
                            that.setState({ textInputValue: value });
                        },
                        () => {
                            this.resetAtHighIndex(this.state.textInputValue);
                        }
                    );
                });
                return;
            } else if (item.kind === 'file') {
                evenFile = obj.items[0].getAsFile();
                this.uploadPasteData(evenFile);
            }
        }
    };

    clipboardDataUpload = async (blob) => {
        util.log('zhangyongchang', 'yach-im', 'box-send-container.js', 'clipboardDataUpload');
        if (!blob) return;
        if ((blob.size / 1024 / 1024).toFixed(1) > 2 * 1024) {
            message.warning(util.locale('im_send_file_size_cannot_exceed_2G'));
            return;
        }
        this.inputMessagesFocus();
        const { name = util.locale('im_files') } = blob;
        const hide = message.loading(`${name} ${util.locale('im_uploading')}...`, 0);
        try {
            const ext = blob.name.substring(blob.name.lastIndexOf('.') + 1, blob.name.length);
            if (/doc|docx|xls|xlsx|pptx|ppt|pdf/i.test(ext)) {
                await this.sendFile(blob, blob.name, blob.size, `[${util.locale('im_files')}]`, 1);
            } else if (/png|jpg|bmp|jpeg|gif|svg|wmf|jpe|ico|pic|tiff|pjpeg|jfif|pjp/i.test(ext)) {
                await this.sendFile(blob, blob.name, blob.size, `[${util.locale('im_image')}]`, 2);
            } else if (/wmv|asf|asx|rm|rmvb|mp4|3gp|mov|m4v|avi|dat|mkv|flv|vob/i.test(ext)) {
                await this.sendYunxinFile(blob, `[${util.locale('im_files')}]`, 'blob');
            } else {
                await this.sendFile(blob, blob.name, blob.size, `[${util.locale('im_files')}]`, 3);
            }
            hide();
        } catch (error) {
            hide();
            message.error(error.message);
        }
    };

    uploadSensorsData = (obj) => {
        let fileType = 104;
        if (obj.type == 'image') {
            fileType = 102;
        } else if (obj.type == 'audio') {
            fileType = 103;
        } else if (obj.type == 'video') {
            fileType = 105;
        } else if (obj.type == 'custom' && JSON.parse(obj.content).type == 8) {
            fileType = 102;
        }
        util.yachLocalStorage.ls('message_id',{message_id:obj.idClient})
        util.yach.sendMessageSensorsData(fileType);
    };

    handleKeyPress = (e) => {
        const keyCode = e.which || e.keyCode;
        const ctrlKey = e.ctrlKey;
        const metaKey = e.metaKey;
        const shiftKey = e.shiftKey;

        if ((ctrlKey && keyCode == 13) || (shiftKey && keyCode === 13) || (metaKey && keyCode == 13)) {
            e.preventDefault();
            if (this.state.sendType == 'reverse') {
                (!this.searching || !this.state.userAtShow) && this.sendMsg();
            } else {
                this.setNewline();
            }
        } else if (keyCode == 13) {
            e.preventDefault();
            // 送消息
            if (this.state.sendType == 'reverse') {
                this.setNewline();
            } else {
                (!this.searching || !this.state.userAtShow) && this.sendMsg();
            }
        } else if (keyCode == 27) {
            this.closeUserAt();
        } else if (keyCode == 38 || keyCode == 40) {
            this.searching && e.preventDefault();
        } else if ((keyCode == 90 && metaKey) || keyCode == 33 || keyCode == 34) {
            e.returnvalue = false;
            e.preventDefault();
            return;
        }
    };

    // 设置换行符
    setNewline = () => {
        // const node = ReactDOM.findDOMNode(this.inputMessagesEndRef);
        // const cursorIndex = node.selectionStart;
        // const { textInputValue } = this.state;
        // this.setState(
        //     {
        //         textInputValue: textInputValue.substring(0, cursorIndex) + '\n' + textInputValue.substring(cursorIndex),
        //     },
        //     () => {
        //         node.selectionStart = cursorIndex + 1;
        //         node.selectionEnd = cursorIndex + 1;
        //         this.scrollToBottom();
        //         this.resetAtHighIndex(this.state.textInputValue);
        //     }
        // );
    };

    // 获得子元素
    inputMessagesEnd = (ref) => {
        this.inputMessagesEndRef = ref;
    };

    // 获得@后点击的群成员
    getClickUser = (atValue, list) => {
        if (!atValue) return;
        const { name, nick } = atValue;
        const value = { ...atValue, name: nick ? name + '(' + nick + ')' : name };
        if (!value && !list.length) {
            //当at组件返回空时说明没搜到东西但是按下回车了，这时主动去触发回车发消息事件
            //这样处理不太好，但暂时没想到更优雅的方式~
            this.sendImageAndMsgAll();
            return false;
        }
        this.setState(
            {
                //textInputValue: this.strAdd(this.dataAll, value),
                allAtList: [...list],
                allAtUserIds: [...this.state.allAtUserIds, value.id],
            },
            () => {
                //this.resetAtHighIndex(this.state.textInputValue);
                //this.cursorSelectionRange();
            }
        );

        let editorState = this.props.draftEditorState
        let currContent = editorState.getCurrentContent()
        let selection = editorState.getSelection()
        let block = currContent.getBlockForKey(selection.focusKey)

        let endindex = selection.focusOffset
        let startindex = block.text.slice(0, endindex).lastIndexOf('@')

        if (startindex != -1) {
            let mergeobj = {anchorOffset: startindex}
            editorState = draftfn.mergeSelectioning(editorState, mergeobj)
        }

        this.props.dispatch(draftAction.draftEditorStateSet(editorState))

        let text = ` @${value.name} `
        this.props.dispatch(draftAction.draftEditorStateAtAdd(text, value))
    };

    strAdd = (dataAll, value) => {
        let name = util.yach.decodeUnicode(value.name);
        let str = ` @${name}  `;
        for (let index = 0; index < dataAll.length; index++) {
            if (!index && dataAll[0][0] == 0) {
                if (dataAll[0][1].lastIndexOf('@') != -1 && dataAll[1][1] != '@') {
                    str = dataAll[0][1].substr(0, dataAll[0][1].lastIndexOf('@')) + str;
                } else {
                    str = dataAll[0][1] + str;
                }
            } else if (dataAll[index][0] == 0) {
                // if(dataAll[index-1][0] != -1)str += dataAll[index][1];
                str += dataAll[index][1];
            } else {
                this.setAtHighlighted(str.length - ` @${name}  `.length, ` @${name}  `, `@${name}`, value.id);
            }
        }
        return str;
    };

    setAtHighlighted = (startIndex, atNameLength, atName, id) => {
        atName = util.yach.decodeUnicode(atName);
        let param = {
            id: id,
            startIndex: startIndex,
            endIndex: startIndex + atNameLength.length,
            atName: atName,
        };
        this.state.atHighlighted.push(param);
    };

    setAtHighlightedByEntity = () => {
        let entity = this.entitydataBeforesend
        let atentity = entity.filter(v => v.type == 'at')
        let atHighlighted = atentity.map(v => ({
            id: v.data.id,
            index: v.startIndex,
            startIndex: v.startIndex,
            endIndex: v.endIndex,
            // pc at 数据强依赖于text文本中间有空格，atname字段后面没空格，才能保证atHighlighted方法的 + 1 逻辑正常
            // text文本中间有空格：基本三端都有空格
            // atname字段后面没空格：这就是下面这行的原因
            atName: v.text.slice(0, v.text.length - 1),
        }))
        atHighlighted = atHighlighted.sort((a, b) => a.index - b.index)
        this.setState({ atHighlighted })
    }

    scrollToBottom = () => {
        const node = ReactDOM.findDOMNode(this.inputMessagesEndRef);
        node.scrollTop = node && node.scrollHeight;
    };

    // 添加 @ 用户
    atUser() {
        // console.log('atUser', this.state.allAtList, this.state.allAtUserIds);
        // if (this.state.allAtUserIds.length > 0) {
        //     let selectAtUserIds = [];
        //     for (let i = 0; i < this.state.allAtUserIds.length; i++) {
        //         for (let j = 0; j < this.state.allAtList.length; j++) {
        //             if (this.state.allAtUserIds[i] == this.state.allAtList[j].id) {
        //                 const { nick, name } = this.state.allAtList[j];
        //                 console.log(this.state.textInputValue, ` @${nick ? name + '(' + nick + ')' : name}  `)
        //                 if (this.state.textInputValue.indexOf(` @${nick ? name + '(' + nick + ')' : name}  `) != -1) {
        //                     selectAtUserIds.push(this.state.allAtUserIds[i] + '');
        //                 }
        //             }
        //         }
        //     }
        //     return [...new Set(selectAtUserIds)];
        // }
        let entity = this.entitydataBeforesend
        let atentity = entity.filter(v => v.type == 'at')
        let selectAtUserIds = atentity.map(v => v.data.id + '')
        return [...new Set(selectAtUserIds)]
    }

    sendImageAndMsgAll = async () => {
        draftfn.blurEditor()
        let entitydata = draftfn.getEntityData(this.props.draftEditorState)
        let imgdata = entitydata.filter(v => v.type == 'image')
        let text = this.state.textInputValue
        if (text.length > 2000) return message.warn(util.locale('im_send_maxtext'))

        this.entitydataBeforesend = entitydata
        this.customtextBeforesend = draftfn.transToCustomText(this.props.draftEditorState)
        this.props.dispatch(draftAction.draftEditorStateClear())
        
        if (imgdata && imgdata.length && imgdata[0].startIndex == 1) {
            this.uploadImage(imgdata)
            setTimeout(() => {
                this.sendMsg(text)
                draftfn.focusEditor()
            }, 300)
        } else {
            await this.sendMsg(text)
            setTimeout(() => {
                this.uploadImage(imgdata)
                draftfn.focusEditor()
            }, 300)
        }
        this.setState({isSendMessage:true,excelTurnImgType:'text'})
    }

    // 上传图片
    uploadImage = imgdata => {
        if (!imgdata) {
            let entitydata = entitydataBeforesend
            imgdata = entitydata.filter(v => v.type == 'image')
        }
        
        imgdata.forEach(async img => {
            let data = img.data
            if (!data) return false

            data.type = 'image'
       
            Object.assign(data, await util.imageDealer.getImageInfo(data.path || data.base64));
            let uploadreq = {
                sessionActive: this.props.sessionActive,
                custom: { type: 8, data, status: 'uploading' }
            }

            this.props.dispatch(messageListAction.uploadRequest(uploadreq))
        })
    }

    sendMsg = async text => {
        const { userInfo, sessionActive } = this.props;
        // util.log('mayuanlong', 'sendMsg: start', sessionActive.id, sessionActive.type);
        const { name, name_nick } = userInfo;
        if (!sessionActive) return;
        //let text = await this.resetAtHighIndex(this.state.textInputValue, true);
        let customtext = this.customtextBeforesend
        //let text = draftfn.transToCustomText(this.props.draftEditorState, '')
        let atUserList = this.atUser() || []
        await this.setAtHighlightedByEntity()

        text = text.substr(0, 1999);
        const msgTrim = text.trim();
        if (!msgTrim) return;
        let apns = {
                forcePush: false,
            },
            pushContent = '',
            pushName = '',
            pushPayload = {},
            sessionType = 0;
        if (sessionActive.type == 'team' && atUserList && atUserList.length > 0) {
            apns = {
                accounts: atUserList,
                content: `${name}${name_nick ? '(' + name_nick + ')' : ''}: ${text.substr(0, 100)}`,
                forcePush: true,
            };
            sessionType = 1;
            pushContent = `${name}${name_nick ? '(' + name_nick + ')' : ''}: ${text.substr(0, 100)}`;
            pushName = sessionActive.showname;
        } else if (sessionActive.type == 'team' && atUserList && atUserList.length == 0) {
            sessionType = 1;
            pushContent = `${name}${name_nick ? '(' + name_nick + ')' : ''}: ${text.substr(0, 100)}`;
            pushName = sessionActive.showname;
        } else {
            pushContent = `${text.substr(0, 100)}`;
            sessionType = 0;
            pushName = name_nick || name;
        }
        pushPayload = {
            pushTitle: util.yach.decodeUnicode(pushName),
            sessionType: sessionType,
            sessionID: sessionActive.id,
        };
       
        util.yach.setUserStorage('yach_draft', userInfo.id + '-' + sessionActive.id, undefined);
        util.yach.setUserStorage('yach_draft_id', userInfo.id + '-' + sessionActive.id, undefined);
        util.yach.setUserStorage('yach_highlighted', userInfo.id + '-' + sessionActive.id, undefined);

        this.setState({ textInputValue: '', allAtUserIds: [] });
        // this.props.dispatch(draftAction.draftEditorStateClear())

        let seedMsg = null;
        let sendData = [sessionActive.type, sessionActive.id, apns, text, pushContent, pushPayload];
        if (this.props.reply.replyShow) {
            seedMsg = await this.replyMsg(...sendData);
            util.yachLocalStorage.ls('message_id',{message_id:seedMsg.idClient})
            util.yach.sendMessageSensorsData(101);
        } else {
            //let linktext = text
            let linktext = customtext.replace(`[${util.locale('im_image')}]`, '')
            if (linkMsgHandler.isUrl(linktext)) {
                // 链接类型需要特殊处理处理
                seedMsg = await linkMsgHandler.processLinkMsg(
                    sessionActive,
                    linktext,
                    '',
                    pushPayload,
                    {},
                    this.props.dispatch
                );
            } else {
                seedMsg = await this.sendTextMsg(...sendData);
                if (seedMsg) {
                    util.yachLocalStorage.ls('message_id',{message_id:seedMsg.idClient})
                    util.yach.sendMessageSensorsData(101);
                }
            }
        }
        this.setState({ atHighlighted: [], allAtUserIds: [], allAtList: [] });

        const {id, type} = window.store.getState().sessionActive;
        if (seedMsg && seedMsg.to == id) this.pushMessage(seedMsg, 2);
        util.yach.refreshConnect(seedMsg || {});
        
        if (atUserList.length && seedMsg && seedMsg.status == 'success') this.reportDingPeople(atUserList, seedMsg);
        // if (window.store.getState().serverRender.mode) util.yach.switchLocalMsgMode();

        // 1、群聊at人 2、私聊   触发自动回复
        try {
            if(seedMsg.status == 'success'){
                let accounts = [];
                if(seedMsg.apns && Array.isArray(seedMsg.apns.accounts)){
                    accounts = seedMsg.apns.accounts;
                }
                util.yach.checkAutoReply(seedMsg.to, seedMsg.scene, accounts)
            }
           
        } catch (error) { console.log('box-send-container.js -> sendMsg -> checkAutoReply error: ', error)}

        util.log('mayuanlong', 'sendMsg: end', id, type, seedMsg.idClient);
    };

    // @人上报
    reportDingPeople = async(list, seedMsg) => {
        const isAll = list.includes('-1');
        let atAll   = '',
            atList  = [];
        if (isAll) atAll = seedMsg.to;
        atList = isAll ? [] : list;

        const messageType = util.yach.getMsgType(seedMsg);
        let json = {
            sessionId:      seedMsg.to,
            serverId:       seedMsg.idServer,
            clientId:       seedMsg.idClient,
            fromAccount:    seedMsg.from,
            message:        seedMsg.text,
            time:           seedMsg.time,
            fromType:       'group',
            ext:            [],
            status:         '0',
            atAll,
            atList,
            messageType,
        }

        json = JSON.stringify(json);

        const params = {
            type : 'at',
            json
        }

        const res = await audioBusMessagePush(params);
        if (!res || res.code !== 200) util.log('mayuanlong', 'atReport', 'sessionId:clientId:fromAccount:messageType', seedMsg.to, seedMsg.idClient, seedMsg.from, messageType)
    }

   

    sendTextMsg = async (type, id, apns, text, pushContent, pushPayload) => {
        let seedMsg = {};
        try {
            seedMsg = await util.nim.sendText(
                type,
                id,
                text,
                apns,
                { atHighlighted: this.state.atHighlighted },
                pushContent,
                pushPayload,
                async (msg) => {
                    const obj = await util.nim.genMsgItem(msg);
                    this.props.dispatch(add(obj));
                    // util.log('mayuanlong', 'local:sendTextMsg:id:status:idClient:fromNick:to',id, obj.status, obj.idClient, obj.fromNick, obj.to);
                }
            );
            const { status, idClient, fromNick, to } = seedMsg;
            util.log('mayuanlong', 'net:sendTextMsg:id:status:idClient:fromNick:to',id, status, idClient, fromNick, to);
        } catch (error) {
            console.log('sendTextMsg:error', error);
            seedMsg = error.msg;
        }
        // 单聊发送给机器人
        if (this.props.sessionActive.type == 'p2p' && this.props.chatRobot) {
            util.log('zhangpeng', 'box-send-container', '单聊发送文本');
            await this.robotMessage({
                msgtype: 'text',
                content: seedMsg.text,
                create_at: seedMsg.time,
                conversation_type: 1,
                conversation_id: seedMsg.to,
                corp_id: this.props.userInfo.cp_id || 1,
                msg_id: seedMsg.idServer,
            });
        }
        // 群聊 艾特了机器人
        if (this.props.sessionActive.type == 'team') {
            let custom;
            let atHighlighted;
            try {
                custom = JSON.parse(seedMsg.custom);
                if (custom && custom.atHighlighted) {
                    atHighlighted = custom.atHighlighted.map((item) => {
                        return item.id;
                    });
                    const res = await util.nimUtil.getUsers(atHighlighted);
                    for (let i = 0; i < res.length; i++) {
                        if (res[i] && res[i].custom) {
                            try {
                                let customRobot = JSON.parse(res[i].custom);
                                if (customRobot.type == 0) {
                                    util.log('zhangpeng', 'box-send-container', '群聊艾特机器人');
                                    let resRobot = await this.robotMessage({
                                        msgtype: 'text',
                                        content: seedMsg.text,
                                        create_at: seedMsg.time,
                                        conversation_type: 2,
                                        conversation_id: seedMsg.to,
                                        corp_id: this.props.userInfo.cp_id || 1,
                                        msg_id: seedMsg.idServer,
                                        at_highlight: JSON.stringify(custom.atHighlighted),
                                    });
                                    break;
                                }
                            } catch (error) {
                                util.log('zhangpeng', 'box-send-container', '解析群聊天机器人出错');
                            }
                        }
                    }
                }
            } catch (error) {}
        }
        util.yach.msgUploadCloud(seedMsg);
        util.log('mayuanlong', 'sendTextMsg: end:status:idClient', seedMsg.status, seedMsg.idClient, seedMsg.time);
        return seedMsg;
    };

    TAClick = () => {
        let { atHighlighted } = this.state;
        if (!atHighlighted || !atHighlighted.length) return;
        const node = ReactDOM.findDOMNode(this.inputMessagesEndRef);
        const cursorIndex = node.selectionStart;
        for (let i = 0; i < atHighlighted.length; i++) {
            const el = atHighlighted[i];
            if (el.startIndex < cursorIndex && cursorIndex <= el.endIndex) {
                let median = el.startIndex + Math.floor((el.endIndex - el.startIndex) / 2);
                if (cursorIndex < median) util.yach.setSelectionRange(node, el.startIndex, el.startIndex);
                if (cursorIndex > median) util.yach.setSelectionRange(node, el.endIndex + 1, el.endIndex + 1);
                if (cursorIndex == median) util.yach.setSelectionRange(node, el.startIndex, el.startIndex);
            }
        }
    };

    resetAtHighIndex = (text, send) => {
        if (!text) return text;
        const { type } = this.props.sessionActive;
        const { atHighlighted } = this.state;
        if (!atHighlighted || !atHighlighted.length || type == 'p2p') return text;

        let newText = text,
            newAtHighlighted = [],
            atHighlightedLength = atHighlighted.length;
        for (let i = 0; i < atHighlightedLength; i++) {
            const el = atHighlighted[i];
            const atIndex = newText.indexOf(` ${el.atName}  `);
            if (atIndex === -1) continue;
            newText = newText.replace(` ${el.atName}  `, `${el.atName} `);
            newAtHighlighted.push({
                ...el,
                index: atIndex,
                atName: `${el.atName}`,
                startIndex: atIndex,
                endIndex: atIndex + ` ${el.atName}  `.length - 1,
            });
        }
        newAtHighlighted = newAtHighlighted.sort((a, b) => a.index - b.index);
        this.setState({ atHighlighted: newAtHighlighted });
        if (!send) return;
        return newText;
    };

    replyMsg = async (type, id, apns, text, pushContent, pushPayload) => {
        let content = {
            type: 6,
            data: this.filterData(this.props.reply.item),
        };
        const seedMsg = await util.nim.sendCustomMsg(
            type,
            id,
            JSON.stringify(content),
            apns,
            text,
            { atHighlighted: this.state.atHighlighted, isChatRobot: this.props.chatRobot },
            pushContent,
            pushPayload,
            async (msg) => {
                const obj = await util.nim.genMsgItem(msg);
                util.log('zhangyongchang', 'yach-im', 'box-send-container', 'replyMsg: start', type, id);
                this.props.dispatch(add(obj));
                this.props.dispatch(replyShow(false));
            }
        );
        // 单聊机器人回复
        if (this.props.sessionActive.type == 'p2p' && this.props.chatRobot) {
            if (this.props.reply.item.type == 'video' || this.props.reply.item.type == 'audio') {
                util.log('zhangpeng', 'box-send-container', '单聊回复视频音频');
                await this.sendRobotMessage(this.props.reply.item, seedMsg, this.props.reply.item.file.url, 1, undefined, undefined, this.props.reply.item.type);
            }
            if (this.props.reply.item.type == 'text') {
                util.log('zhangpeng', 'box-send-container', '单聊回复文字');
                await this.sendRobotMessage(this.props.reply.item, seedMsg, this.props.reply.item.text, 1);
            }
            try {
                let content = JSON.parse(this.props.reply.item.content);
                if (content.type == 8 && content.data) {
                    util.log('zhangpeng', 'box-send-container', '单聊回复图片');
                    await this.sendRobotMessage(this.props.reply.item, seedMsg, content.data.fileOriginUrl, 1, undefined, undefined, 'image');
                }
                // 回复markdown
                if (content.type == 15 && content.data) {
                    util.log('zhangpeng', 'box-send-container', '群聊回复markdown艾特机器人');
                    await this.sendRobotMessage(
                        this.props.reply.item,
                        seedMsg,
                        JSON.stringify(content),
                        1,
                        undefined,
                        undefined,
                        'markdown'
                    );
                }
            } catch (error) {}
        }
        // 群聊回复艾特机器人  看到下面的代码，忽然觉得人生苦短
        if (this.props.sessionActive.type == 'team') {
            let custom;
            let atHighlighted;
            try {
                custom = JSON.parse(seedMsg.custom);
                if (custom && custom.atHighlighted.length > 0) {
                    atHighlighted = custom.atHighlighted.map((item) => {
                        return item.id;
                    });
                    const res = await util.nimUtil.getUsers(atHighlighted);
                    for (let i = 0; i < res.length; i++) {
                        if (res[i] && res[i].custom) {
                            try {
                                let customRobot = JSON.parse(res[i].custom);
                                if (customRobot.type == 0) {
                                    if (
                                        this.props.reply.item.type == 'video' ||
                                        this.props.reply.item.type == 'audio'
                                    ) {
                                        util.log('zhangpeng', 'box-send-container', '群聊回复音视频艾特机器人');
                                        await this.sendRobotMessage(
                                            this.props.reply.item,
                                            seedMsg,
                                            this.props.reply.item.file.url,
                                            2,
                                            JSON.stringify(custom.atHighlighted),
                                            undefined,
                                            this.props.reply.item.type
                                        );
                                        break;
                                    }
                                    if (this.props.reply.item.type == 'text') {
                                        util.log('zhangpeng', 'box-send-container', '群聊回复文字艾特机器人');
                                        await this.sendRobotMessage(
                                            this.props.reply.item,
                                            seedMsg,
                                            this.props.reply.item.text,
                                            2,
                                            JSON.stringify(custom.atHighlighted)
                                        );
                                        break;
                                    }
                                    try {
                                        let content = JSON.parse(this.props.reply.item.content);
                                        if (content.type == 8 && content.data) {
                                            util.log('zhangpeng', 'box-send-container', '群聊回复图片艾特机器人');
                                            await this.sendRobotMessage(
                                                this.props.reply.item,
                                                seedMsg,
                                                content.data.fileOriginUrl,
                                                2,
                                                JSON.stringify(custom.atHighlighted),
                                                undefined,
                                                'image'
                                            );
                                            break;
                                        }
                                         // 回复markdown
                                        if (content.type == 15 && content.data) {
                                            util.log('zhangpeng', 'box-send-container', '群聊回复markdown艾特机器人');
                                            await this.sendRobotMessage(
                                                this.props.reply.item,
                                                seedMsg,
                                                JSON.stringify(content),
                                                2,
                                                JSON.stringify(custom.atHighlighted),
                                                undefined,
                                                'markdown'
                                            );
                                            break;
                                        }
                                    } catch (error) {
                                        console.log(error);
                                    }
                                }
                            } catch (error) {
                                console.log(error);
                            }
                        }
                    }
                } else if (custom && custom.atHighlighted.length == 0) {
                    try {
                        console.log('hh2');
                        let userInfo = await util.nimUtil.getUser(this.props.reply.item.from);
                        let customUserInfo = JSON.parse(userInfo.custom);
                        if (customUserInfo.type == 0) {
                            if (
                                this.props.reply.item.type == 'video' ||
                                this.props.reply.item.type == 'audio'
                            ) {
                                util.log('zhangpeng', 'box-send-container', '群聊回复音视频艾特机器人');
                                await this.sendRobotMessage(
                                    this.props.reply.item,
                                    seedMsg,
                                    this.props.reply.item.file.url,
                                    2,
                                    undefined,
                                    this.props.reply.item.from,
                                    this.props.reply.item.type
                                );
                            }
                            if (this.props.reply.item.type == 'text') {
                                util.log('zhangpeng', 'box-send-container', '群聊回复文字艾特机器人');
                                await this.sendRobotMessage(
                                    this.props.reply.item,
                                    seedMsg,
                                    this.props.reply.item.text,
                                    2,
                                    undefined,
                                    this.props.reply.item.from
                                );
                            }
                            try {
                                let content = JSON.parse(this.props.reply.item.content);
                                if (content.type == 8 && content.data) {
                                    util.log('zhangpeng', 'box-send-container', '群聊回复图片艾特机器人');
                                    await this.sendRobotMessage(
                                        this.props.reply.item,
                                        seedMsg,
                                        content.data.fileOriginUrl,
                                        2,
                                        undefined,
                                        this.props.reply.item.from,
                                        'image'
                                    );
                                }
                                if (content.type == 15 && content.data) {
                                    util.log('zhangpeng', 'box-send-container', '群聊回复markdown艾特机器人');
                                    await this.sendRobotMessage(
                                        this.props.reply.item,
                                        seedMsg,
                                        JSON.stringify(content),
                                        2,
                                        undefined,
                                        this.props.reply.item.from,
                                        'markdown'
                                    );
                                }
                            } catch (error) {
                                console.log(error);
                            }
                        }
                    } catch (error) {}
                }
            } catch (error) {}
        }
        util.log('zhangyongchang', 'yach-im', 'box-send-container', 'replyMsg: end', seedMsg.status, seedMsg.idServer, seedMsg.time);
        util.yach.msgUploadCloud(seedMsg);
        return seedMsg;
    };

    filterData = (obj) => {
        const { content } = obj;
        if (!content) return obj;
        try {
            const newContent = JSON.parse(content);
            if (newContent.type == 6) {
                obj.content = '';
                return obj;
            } else {
                return obj;
            }
        } catch (error) {
            return obj;
        }
    };

    async pushMessage(item, type) {
        util.log('mayuanlong', 'pushMessage:status:idClient:', item.status, item.idClient, item.time, type);
        if (item.status == 'fail') {
            let obj = Object.assign(item, { msg: item });
            this.props.dispatch(replace(obj));
        }
        let obj = await util.nim.genMsgItem(item);
        if (this.props.sessionActive.type == 'team') {
            //const teamMembers = await util.nimUtil.getTeamMembers(this.props.sessionActive.id);
            const teamMembers = await util.yach.isreadMsgReadInit(this.props.sessionActive.id, item.idServer);
            const {unreadAccounts } = teamMembers;
            //obj = Object.assign(obj, { read: 0, unread: teamMembers.members.length - 1 });
            obj = Object.assign(obj, { read: 0, unread: unreadAccounts.length});

        }
        if (type == 1) {
            this.props.dispatch(add(obj));
        } else {
            this.props.dispatch(replace(obj));
        }
    }

    clickEmojiItem = (emojiName) => {
        // const node = ReactDOM.findDOMNode(this.inputMessagesEndRef);
        // util.yach.insertAtCursor(
        //     node,
        //     emojiName,
        //     (value) => {
        //         this.setState({ textInputValue: value });
        //     },
        //     () => {
        //         this.resetAtHighIndex(this.state.textInputValue);
        //     }
        // );
        this.props.dispatch(draftAction.draftEditorStateTextAdd(emojiName))
        this.setState({ emojiContentVisible: false });
    };

    inputMessagesFocus = () => {
        this.inputMessagesEndRef && this.inputMessagesEndRef.focus();
    };

    screenshot = () => {
        util.electronipc.screenshot(this);
    };
   
    screenCutCallback = res => {
        const path = require('path');
        if (!res.type) return false;
        if (res.type == 'ok' || res.type == 'enter') {
            // this.screenCutSend(res.data);
            this.setState(
                {
                    sendFileAction: 'screencut',
                    sendFileBase64: res.data,
                    sendFileScreen: `${path.dirname(res.filePath).replace(/\\/g,'/')}/${path.basename(res.filePath)}`
                },
                () => {
                    this.setState({ sendFileAction: '' });
                }
            );
        } else {
            this.inputMessagesFocus();
        }
        this.screenCutSensors(res.type);
    }
    //截图神策
    screenCutSensors = (operation) => {
        if (operation == 'close') {
            util.sensorsData.track('Click_Chat_Element', {
                pageName: 207,
                $element_name: 360,
                submodule: 101,
                optMode: 101,
            });
        }
        if (operation == 'esc') {
            util.sensorsData.track('Click_Chat_Element', {
                pageName: 207,
                $element_name: 360,
                submodule: 101,
                optMode: 102,
            });
        }
        if (operation == 'ok') {
            util.sensorsData.track('Click_Chat_Element', {
                pageName: 207,
                $element_name: 361,
                submodule: 101,
                optMode: 101,
            });
        }
        if (operation == 'enter') {
            util.sensorsData.track('Click_Chat_Element', {
                pageName: 207,
                $element_name: 360,
                submodule: 101,
                optMode: 103,
            });
        }
        if (operation == 'download') {
            util.sensorsData.track('Click_Chat_Element', {
                pageName: 207,
                $element_name: 362,
                submodule: 101,
            });
        }
    };
    screenshotSend = () => {
        util.log('zhangyongchang', 'yach-im', 'box-send-container.js', 'screenshotSend');
        document.getElementById('sendBox').value = this.state.senBoxValue;
        if (!this.state.isFileImage) {
            let file = this.state.evenFile;
            this.clipboardDataUpload(file);
            this.setState({ modalShow: false, evenFile: null });
        } else {
            this.inputMessagesFocus();
            const hide = message.loading(`${this.state.localImageFile.name} ${util.locale('im_uploading')}...`, 0);
            this.sendLocalImageFile(this.state.localImageFile);
            hide();
            this.setState({ modalShow: false });
        }
    };
    screenshotSendLocalFile = () => {
        document.getElementById('sendBox').value = this.state.senBoxValue;
        const hide = message.loading(`${this.state.localImageFile.name} ${util.locale('im_uploading')}...`, 0);
        this.sendLocalImageFile(this.state.localImageFile);
        hide();
        this.setState({ modalShow: false });
        this.inputMessagesFocus();
    };
    screenshotModalOpen = () => {
        this.setState({ modalShow: true });
        this.inputMessagesFocus();
    };
    fileModalKeyDown = (ev) => {
        let that = this;
        if (ev.keyCode == 13) {
            if (that.state.isFileImage) {
                that.screenshotSendLocalFile();
            } else {
                that.screenshotSend();
            }
        }
        document.getElementById('sendBox') && document.getElementById('sendBox').blur();
        const node = ReactDOM.findDOMNode(that.inputMessagesEndRef);
        util.yach.insertAtCursor(node, '', (value) => {
            that.setState({ textInputValue: value }, () => {
                this.resetAtHighIndex(this.state.textInputValue);
            });
        });
    };
    screenshotModalClose = () => {
        this.setState({ modalShow: false });
        // this.inputMessagesFocus();
    };

    handleVisibleChange = (emojiContentVisible) => {
        this.setState({ emojiContentVisible });
    };

    videoSession = () => {
        const { userInfo } = this.props;
        console.log('videoSession', userInfo);
        const obj = {
            show: true,
            nickName: userInfo.name_nick,
            title: util.locale('media_initi_meeting'),
        };
        this.props.dispatch(videoSessionShow(obj));
        this.setState({ showVideoSession: true });
    };


    isShowVideoSession = () => {
        this.setState({ showVideoSession: false });
    };

    /**
     * @ 实现如果是群 判断是不是日程拉群
     */
    isNotScheduleMeeting = async () => {
        const { id, type ,serverCustom={}} = this.props.sessionActive;
        if (id && type == 'team') {
            try {
                // const team = await util.nimUtil.getTeam(this.props.sessionActive.id);
                // const { serverCustom = {} } = ;
                const isEmpty = Object.keys(serverCustom);
                if (!!isEmpty.length) {
                    const serverCustomJson = JSON.parse(serverCustom);
                    const { type, schedule = {} } = serverCustomJson;
                    this.setState((state) => ({
                        teamType: { type, attr: schedule },
                    }));
                }
            } catch (e) {
                console.error('isNotScheduleMeeting >>' + e);
            }
        }
    };

    isHiddenVideo = () => {
        const { sessionActive, userInfo } = this.props;
        const userId = userInfo.id;
        if (!sessionActive || !userId || sessionActive.type === 'team') return false;
        const sessionActiveId = sessionActive.id;
        return (
            sessionActiveId != userId &&
            sessionActiveId != '3002' &&
            sessionActiveId != '3013' &&
            this.state.teamType.type !== 9 &&
            !this.props.chatRobot
        );
    };
    checkingIsInternalMeeting = () => {
        util.electronipc.electronZoomCallFn('getMeetingID', null, (res) => {
            if (res == 7) return util.yach.platformConfigGetFun();
            if (res) return util.electronipc.electronZoomCallFn('backToMeeting');
            util.sensorsData.track('Click_Chat_Element', {
                ChatListType: '101',
                pageName: '135',
                $element_name: '01-133',
            });
            this.videoSession();
        });
    };
    startCall = () => {
        const { sessionActive } = this.props;
        const { id } = sessionActive;
        if (sessionActive && id) util.agoraFn.startCall(id, sessionActive);
        util.sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-130',target_user_id:id});
    }
    handleCopy = () => {
        if (this.state.selectedText) {
            copy(this.state.selectedText);
        }
    };
    handleScreenCutPopover = (value) => {
        this.setState({
            screenCutPopover: value,
        });
    };
    
    screenCutPopoverClick = (e,value) => {
        e.stopPropagation();
        this.setState({
            screenCutPopover: false,
        },()=>{this.screenCut(value)});
        util.sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: `01-16${value ? '7' : '6'}`});
    }

    toDo = async () => {
        const { id: selfId } = this.props.userInfo;
        const { type, id: targetId, showname: targetName } = this.props.sessionActive;
        
        let selfInfo = {};
        let targetInfo = {};
        let executorInfo = {};
        const [yachSelfInfo = {}, yachTargetInfo = {}] = await util.yach.transToThirdUserInfos([selfId, targetId]);
        selfInfo = {id: yachSelfInfo.userid, ...yachSelfInfo};
        if (type === 'p2p') {
            targetInfo = selfId === targetId ? {...selfInfo} : {id: yachTargetInfo.userid, ...yachTargetInfo};
            executorInfo = selfId === targetId ? {...selfInfo} : {...targetInfo};
        }
        if (type === 'team') {
            targetInfo = {type, id: targetId, name: targetName}
            executorInfo = {...selfInfo}
        }
        util.electronipc.electronOpenSinglewebview({
            window: {
                width: 480,
                height: 600,
                minWidth: 480,
                minHeight: 600,
                parentType: 'main',
            },
            data: {
                source: {type, ...targetInfo},
                executor: {...executorInfo}
            },
            // url: 'http://0.0.0.0:8080/'
            url: util.config.todo.createTask
        })
        util.sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-169'});
    };

    // 打开提醒
    remind = ()=>{
        let data = {come:'boxSend'};
        const {id, type, showname, showimg} = this.props.sessionActive;
        if(type == 'p2p'){
            data.user= {id,name: showname,pic: showimg}
            data.type = 'p2p'
        } else {
            data.type = 'team'
        }
        this.props.dispatch(remindWinAction({show:true,data}));
        util.sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-171'});
    }

    // 打开创建日程
    openCalendar = ()=>{
        let groupInfo={};
        const {id, showname,type} = this.props.sessionActive
        let user=[];

        if(type == 'p2p'){
            user=[id+'']
        } else if(type == 'team'){
            groupInfo={id, showname}
            user=[];
        }
        // 去重/过滤自己
        user=[...new Set(user)];
        user=user.filter(item=>item!=this.props.userInfo.id);

        imCreateCanlendar({user,groupInfo});
        util.sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-170'});
    }

    // 发起投票
    createVote=()=>{
        const {id} = this.props.sessionActive
        this.props.dispatch(showSlideModal('voteCreate', {id}));
    }

    joinMeetingGroupFn = () => {
        const { type } = this.props.teamType;
        if (type === 9) {
            this.enterSheduleMeeting();
        }else {
            const parameter = {
                show: true,
                nickName: '',
                title:util.locale('im_online_meeting')
            };
            this.props.dispatch(videoSessionShow(parameter));
            this.setState({showVideoSession:true})
            // this.meetingCreateJoinFun();
        }

        util.electronipc.electronZoomCallFn('getMeetingID', null, async res => {
            console.log(!res,"resresresresresresres")
            if (res == 7) return util.yach.platformConfigGetFun();
            if(!res) {
                util.sensorsData.track('Click_Chat_Element', {
                    ChatListType: '102',
                    pageName: '135',
                    $element_name: '01-136',
                });
            }
        });
    }

    /*
       @销毁所有的参数
    */
    reclearAllVariable = (stype = "uninstall") => {
        if (stype === "uninstall") {
            clearTimeout(this.onlineMeetingSwitch);
            this.setState({ meetingHasPeople: false });
            this.props.dispatch(switchOnlineState(''));
        }

        // 关闭当前会话的
        else if (stype === 'close-active') {
            this.onlineMeetingSwitch && clearTimeout(this.onlineMeetingSwitch);
            this.onlineMeetingSwitch = null;

        }

        else if (stype === 'close-global') {
            console.log('所在会议退出，全局定时关');
            window.enterMeetingList && clearTimeout(window.enterMeetingList);
            window.enterMeetingList = null;
        }
    }

    /*
      @ 群办初始化
    */
    meetingStateLoopInit = () => {
        this.eventLoopThisFun();
    }

    /**
     * 轮训 使用轮训来代替之前的状态接口  放弃之前的状态的接口
     * @memberof BoxInfoContainer
     */
    eventLoopThisFun = async () => {
        const { sessionActive } = this.props;
        const { type, id } = sessionActive;
        // 开启群办公室消息，并且在该群中的时候
        if (id && type === 'team') {
            this.onlineMeetingFullState()
        }
    }

    /**
     *@ 维护当前进入的会议室状态
      fk: 1：自己离开了，不一定定时器就要关闭，定时器只能有自身调用函数判断关闭
          2: 只要自己退出了，那么剩下的就是普通的，所以我来开我就马上关闭，但是还要开启会话定时器。
          3: 同2一样，只要我进入，并且在当前的会话内，那么就需要关闭会话内的定时器，开始我全局的定时器。
     * @memberof BoxInfoContainer
     */
    setEnterMeeting = async (es) => {
        const { sessionActive, isInMeeting } = this.props;
        const { id } = sessionActive;
        const { id: isInId } = isInMeeting;

        window.store.dispatch(setEnterMeetingStatus({ id, es }));

        if (!es) {
            this.reclearAllVariable('close-global'); // 这个时候再开启一次本地的定时器
        }
        else {
            this.reclearAllVariable('close-active');
        }

        // 注意开启的时候要判断，如果当前的会话和之前你进入的会话不是同一个，那么就没必要开启了
        const winds = window.store.getState().sessionActive;
        const wid = winds.id && Number(winds.id);

        // 自己退出 但是当前群内是否有人还不确定 需要再验证一下
        if (wid === Number(isInId)) {
            this.eventLoopThisFun();
        }
    }

    onlineMeeting = () => {
        const { teamType } = this.props;
        util.log('panghaojie', 'box-send-container.js', 'onlineMeeting',teamType.type);
        if (teamType.type == 9) { // 会议群
            this.enterSheduleMeeting()
        }
        else { // 普通群
            this.commonGroup(teamType.type);
        }
    }
    // 加入日程群会议
    enterSheduleMeeting = async () => {
        util.log('panghaojie', 'box-send-container.js', 'enterSheduleMeeting');
        const { showname = '' } = this.props.sessionActive;
        const title = !/\[会议群\]/.test(showname) ? showname : (showname.split('[会议群]')[1] || '');
        const parameter = {
            show: true,
            nickName: '',
            title
        };
        this.props.dispatch(videoSessionShow(parameter));
        this.setState({showVideoSession:true})
    }

    commonGroup = async (groupType) => {
        util.log('panghaojie', 'box-send-container.js', 'commonGroup');
        const { userInfo, sessionActive } = this.props;
        const meetState = await meetingFullScreenState({ source_type: 4, source_id: sessionActive.id });
        const { code, obj = {} } = meetState;
        if (code === 200) {
            const { five_list = [] } = obj;
            if (five_list.length > 0) return this.meetingCreateJoinFun();
        }else {
            util.sensorsData.track('Error_Chat', {
                error_code: 1001,
                submodule: '01-101'
            });
        }
        util.electronipc.electronZoomCallFn('getMeetingID', null, async res => {
            console.log('commonGroup-getMeetingID',res)
            if (res == 7) return util.yach.platformConfigGetFun();
            if (res) {
                return util.electronipc.electronZoomCallFn('backToMeeting');
            }
            const parameter = {
                show: true,
                nickName: userInfo.name_nick,
                title: util.locale('media_initi_meeting')
            };
            if(groupType == 1){
                //部门群，会议名称是：线上办公室
                parameter.nickName = ''
                parameter.title = util.locale('media_online_office')
            }
            this.props.dispatch(videoSessionShow(parameter));
            this.setState({showVideoSession:true})
            console.log('Click_Chat_Element,102')
            util.sensorsData.track('Click_Chat_Element', {
                ChatListType: '102',
                pageName: '135',
                $element_name: '01-133',
            });
        })
    }

    /*
      群会议室状态和全屏状态设置
    */
   onlineMeetingFullState = async () => {
    const { sessionActive, isInMeeting } = this.props;
    const { id } = sessionActive;
    const { type, attr: { meeting_id } } = this.props.teamType;
    const { es, id: isInId } = isInMeeting;

    let cid, source_type;

    try {
        // 获取当前在线会议室的用户头像 之前先判断下是否在当前群里面，因为定时器关闭不准确
        if (type === 9) {
            source_type = 3;
            cid = meeting_id;
        }
        else if (type === 1) {
            const { dept_id } = this.props.teamType;
            cid = dept_id;
            source_type = 6;
        }
        else {
            source_type = 4;
            cid = id;
        }

        const meetState = await meetingFullScreenState({ source_type, source_id: cid });
        const { code, msg, obj = [] } = meetState;


        if (code === 200) {
            const { five_list = [] } = obj;
            this.props.dispatch(showMeetingStateAction({ id, list: five_list }));

            if (five_list.length > 5) { this.setState({ loopfntime: 30 }) }

            if (five_list.length <= 0) {
                this.reclearAllVariable('close-active');
                this.setState({ meetingHasPeople: false });
                this.props.dispatch(showMeetingStateAction({ id:'', list: []}));
                return
            }

            this.setState({ meetingHasPeople: true });
            // 自己在某个在线会议中 当前进入的这个群 就是目前active的这个群
            if (es && isInId === id) {  
                // 也需要管制前的定时器
                // 从一个已经进入的群 切回到一个也正在有会议的群  这个时候就不能再关闭定
                clearTimeout(window.enterMeetingList);
                window.enterMeetingList = null;
                window.enterMeetingList = setTimeout(this.onlineMeetingFullState, this.state.loopfntime * 1000);
            }
            else {
                // 自己不在某个在线会议中
                clearTimeout(this.onlineMeetingSwitch);
                this.onlineMeetingSwitch = null;
                this.onlineMeetingSwitch = setTimeout(this.onlineMeetingFullState, this.state.loopfntime * 1000);
            }
        }
        else {
            message.warn(msg);
            util.sensorsData.track('Error_Chat', {
                error_code: 1001,
                submodule: '01-101'
            });
        }
    }
    catch (e) {
        console.log('群办公室横幅错误:onlineMeetingFullState', e);
    }

}

    meetingCreateJoinFun = async (title, isVideoOff, isAudioOff) => {
        let startTimer = new Date().getTime();
        title = typeof (title) == 'string' ? title : null;
        isVideoOff = typeof (isVideoOff) == 'boolean' ? isVideoOff : null;
        isAudioOff = typeof (isAudioOff) == 'boolean' ? isAudioOff : null;
        this.setState({
            showVideo: isVideoOff,
            showAudio: isAudioOff,
        })
        util.electronipc.electronZoomCallFn('getMeetingID', null, async res => {
            util.log('panghaojie', 'box-send-container.js', 'checkingIsInternalMeeting', res);
            if (res == 7) return util.yach.platformConfigGetFun();
            if (res) {
                return util.electronipc.electronZoomCallFn('backToMeeting');
            }
            const { messageLoading } = this.state;
            const hide = message.loading(`${util.locale('media_enter_meeting')}`, 0);
            if (messageLoading) messageLoading();
            this.setState({ messageLoading: hide });

            // 添加部门群进入的逻辑 兼容进来
            const { type, dept_id } = this.props.teamType;
            const s = await meetingCreateJoin({
                source_type: type === 1 ? 6 : 4,
                source_id: type === 1 ? dept_id : this.props.sessionActive.id,
                title,
                os: util.electron.isMac() ? 'mac' : 'windows'
            });

            if (s.code == 200 && s.obj) {
                this.props.dispatch(videoSessionlHide());
                this.setState({showVideoSession:false})
                const { token } = s.obj; //can yu ren
                const { online_meeting_id } = s.obj;
                this.setState({ onlineMeetingId: online_meeting_id });
                util.yachLocalStorage.ls('zoom_bangongshi_online_Id', { onlineMeetingId: online_meeting_id });
                this.addMeetingListen(s.obj, title, startTimer);
                if (token) { // 创建
                    s.obj.thisIsMeetingCreater = true
                    this.setState({ isCreat: true });
                    this.zoomStartUnlogin(s.obj);
                } else {    // 加入
                    this.setState({ isCreat: false });
                    this.zoomJoinUnlogin(s.obj);
                }
                
                await this.setEnterMeeting(true);
                this.eventLoopThisFun();

            } else {
                message.error(s.msg);
                util.sensorsData.track('Error_Chat', {
                    error_code: 1001,
                    submodule: '01-101'
                });
            }
            hide();
        });
    }

    // 进入会议总时长  埋点
    endTimerSensorsDataInit = (startTimer = 0) => {
        let endTimer = new Date().getTime();
        let sizeTimer =  (endTimer-startTimer) / 1000;
        console.log("kjkjkjkjkjkjkjkjk",+sizeTimer.toFixed(2));
        // 进入会议成功 埋点
        util.sensorsData.track('PageView_Chat', {
            pageName: '01-118',
            cost_time: +sizeTimer.toFixed(2)
        });
    }

    meetingLeaveEndFun = async (isMeetingEnd) => {
        util.log('panghaojie', 'box-send-container.js', 'meetingLeaveEndFun', isMeetingEnd);
        const sessionId = util.yachLocalStorage.ls('zoom_bangongshi_session_id') || {};
        // const onlineMeeting = util.yachLocalStorage.ls('zoom_bangongshi_online_Id') || {};
        const { messageLoading } = this.state;
        if (messageLoading) messageLoading();
        // isMeetingEnd 0：未结束  1：已结束
        util.log('panghaojie', 'box-send-container.js', 'meetingLeaveEnd', isMeetingEnd);
        const inviteMeetingIdObj = util.yachLocalStorage.ls('inviteMeetingId') || {}
        const { online_meeting_id } = inviteMeetingIdObj
        const s = await meetingLeaveEnd({
            online_meeting_id: online_meeting_id,
            is_meeting_end: isMeetingEnd,
            os: util.electron.isMac() ? 'mac' : 'windows'
        });
        util.log('panghaojie', 'box-send-container.js', 'meetingLeaveEnd', sessionId.sessionActiveId, this.props.sessionActive.id);
        if (s.code == 200 && s.obj) {
            const { status } = s.obj;
            if (status && status == 2 && sessionId.sessionActiveId == this.props.sessionActive.id) {
                this.props.dispatch(hideOnlineIcon({ show: false }));
            }
            //离开接口成功后，离开频道
            util.log('panghaojie','box-send-container.js','agoraRtmClearChannel')
            util.electronipc.agoraRtmClearChannel({channelId: `meeting_${online_meeting_id || ''}`})
        } else {
            message.error(s.msg);
        }
        util.yachLocalStorage.ls('zoom_bangongshi_login', '');
    }

    zoomJoinUnlogin = (data) => {
        const { showVideo, showAudio } = this.state;
        const { name_nick, name } = this.props.userInfo;
        let meetingnum = data.meeting_id;
        const password = data.password;
        delete data.password//日志脱敏
        let username = name_nick || name;
        let isvideooff = showVideo;
        let isaudiooff = showAudio;
        util.log('panghaojie', 'box-send-container.js', 'zoomJoinUnlogin', meetingnum, username, isvideooff, isaudiooff);
        if (util.electron.isMac()) {
            // mac端屏蔽zoom会议里点击邀请按钮后的默认弹框，必须进入会议之前处理
            // win端sdk里处理没有问题，mac端需要特殊处理
            util.electronipc.electronZoomCallFn('disableToolbarInviteButtonClickOriginAction', true, res => {
                util.log('panghaojie', 'box-send-container.js', 'disableToolbarInviteButtonClickOriginAction', res);
                if (res == 7) {
                    message.info(`${util.locale('im_video_conferencing_component_initializes_exception')}`);
                    util.yach.platformConfigGetFun();
                }
            });
        }
        util.electronipc.electronZoomCallFn('joinunlogin', {
            isvideooff,
            isaudiooff,
            meetingnum,
            username,
            password
        }, status => {
            if (status == 0 || !status) {
                util.log('panghaojie', 'box-send-container.js', 'joinunlogin', status);
                //存储会议id，供会议列表，呼叫，邀请弹窗使用
                util.yachLocalStorage.ls('inviteMeetingId',{ online_meeting_id: data.online_meeting_id, meeting_id: meetingnum })
            }else {
                util.sensorsData.track('Error_Chat', {
                    error_code: 1003,
                    submodule: '01-101'
                });
                //加入失败处理
                handleJoinFail({ online_meeting_id: data.online_meeting_id })
            }

        }) // api 调用结果，0为成功
    }

     // zoom创建会议
     zoomStartUnlogin = data => {
        const { showVideo, showAudio } = this.state;
        const { name_nick, name } = this.props.userInfo;
        let userid = data.third_user_id;
        let zoomaccesstoken = data.zak;
        let username = name_nick || name;
        let usertoken = data.token;
        let meetingnum = data.meeting_id;
        let isvideooff = showVideo;
        let isaudiooff = showAudio;
        util.log('panghaojie', 'box-send-container.js', 'zoomStartUnlogin', username, isvideooff, isaudiooff);
        if (util.electron.isMac()) {
            // mac端屏蔽zoom会议里点击邀请按钮后的默认弹框，必须进入会议之前处理
            // win端sdk里处理没有问题，mac端需要特殊处理
            util.electronipc.electronZoomCallFn('disableToolbarInviteButtonClickOriginAction', true, res => {
                util.log('panghaojie', 'box-send-container.js', 'disableToolbarInviteButtonClickOriginAction', res);
                if (res == 7) {
                    message.info(`${util.locale('im_video_conferencing_component_initializes_exception')}`);
                    util.yach.platformConfigGetFun();
                }
            });
        }
        util.electronipc.electronZoomCallFn('startunlogin', {
            isvideooff,
            isaudiooff,
            userid,
            zoomaccesstoken,
            username,
            usertoken,
            meetingnum
        }, status => {
            util.log('panghaojie', 'box-send-container.js', 'startunlogin',status);
            if (status == 0 || !status) {
                //存储会议id，供会议列表，呼叫，邀请弹窗使用
                util.yachLocalStorage.ls('inviteMeetingId',{ online_meeting_id: data.online_meeting_id, meeting_id: meetingnum })
            }else {
                util.sensorsData.track('Error_Chat', {
                    error_code: 1003,
                    submodule: '01-101'
                });
                //加入失败处理
                handleJoinFail({ online_meeting_id: data.online_meeting_id })

                this.meetingLeaveEndFun(0);//异常创建，通知后台结束会议
            }
        }) // api 调用结果，0为成功
    }

    loginSuccessful = async(data, title) => {
        const { meeting_id: meetingnum, online_meeting_id } = data
        const ls = util.yachLocalStorage.ls('zoom_bangongshi_session_id') || {};
        util.log('panghaojie', 'box-send-container.js', 'loginSuccessful', title,ls.sessionActiveId, this.props.sessionActive.id);
        if (ls.sessionActiveId == this.props.sessionActive.id) {
            this.props.dispatch(showOnlineIcon({ show: true })); // 图标高亮
        }

        util.yachLocalStorage.ls('zoom_bangongshi_login', {
            startTime: (new Date()).getTime(),
            meetingNum: meetingnum,
            meetingName: title || util.locale('media_online_office'),
        })
        util.sensorsData.track('PageView_Chat', {
            pageName: '01-103',
            meeting_type: '01-104',
            source: this.state.isCreat ? '01-101' : '01-102',
            meeting_id: meetingnum,
            meeting_name: util.locale('media_online_office'),
            submodule: '01-101'
        })

        //进入会议成功就初始化频道，保持会议中频道畅通
        agoraRTMChannelListen(`${online_meeting_id || ''}`);
        
        const { teamType } = this.props;

        //设置选人组件参数
        //先清除选人组件参数，避免异常离开会议没有清除掉
        util.yachLocalStorage.ls('inviteGroupInfo', null);
        if(teamType && teamType.type != 9){
            const {id, showname} = this.props.sessionActive;
            util.log('panghaojie', 'box-send-container.js', 'inviteGroupInfo',id, showname);
            if(id) await saveTid({id, showname})
        }

        //需要判断是否为主持人
        if(data.thisIsMeetingCreater && teamType && teamType.type != 9){
            //通过群进入会议，默认弹出选人组件弹窗
            //会议群的处理在video-session-container.js中
            canOpenZoomInvite = true
            window.setTimeout(() => {
                util.log('panghaojie', 'box-send-container.js', 'setTimeout',!canOpenZoomInvite);
                if(!canOpenZoomInvite) return
                util.electronipc.electronOpenZoomInvite();
                delete data.thisIsMeetingCreater
            },2000)
        }
    }

    enterSheduleMeetingSecond = (title, isVideoOff, isAudioOff) => {
        util.log('panghaojie', 'box-send-container.js', 'enterSheduleMeetingSecond');
        const { attr: { meeting_id, tags = [] } } = this.props.teamType;
        // const { messageLoading } = this.state;
        // if (messageLoading) messageLoading();
        // const hide = message.loading('正在进入线上会议', 0);
        // this.setState({ messageLoading: hide })
        meetingCreateJoinFun({
            daily_meeting: tags[0] && tags[0].text,
            title,
            id: meeting_id,
            type: 3,
            changeStatus: true,
            isVideoOff,
            isAudioOff,
            sessionActive: this.props.sessionActive,
            setEnterMeeting: this.setEnterMeeting
        }, async (flag) => {
            // hide();
            await this.setEnterMeeting(!!flag);
            this.eventLoopThisFun();
        });
    }

    reportVideoChange = () => {
        let userId, videoStatus;
        util.electronipc.electronChannelListen('zoomapivideostatuschangecb', obj => {
            if (!userId) {
                userId = obj.userId
            }
            if (userId === obj.userId && videoStatus !== obj.videoStatus) {
                const zoomInfo = util.yachLocalStorage.ls('zoom_bangongshi_login');
                // 摄像头打开
                try {
                    util.sensorsData.track('Click_Chat_Element', {
                        pageName: '01-103',
                        $element_name: '01-104',
                        OperateType: obj.videoStatus ? '01-101' : '01-102',
                        meeting_id: zoomInfo.meetingNum,
                        meeting_name: zoomInfo.meetingName
                    });
                } catch (error) {
                } finally {
                    videoStatus = obj.videoStatus
                }
            }
        })
    }

    addMeetingListen = (data, title, startTimer) => {
        util.log('panghaojie', 'box-send-container.js', 'addMeetingListen', title);
        util.electronipc.electronChannelListen('zoomapimeetingstatuscb', obj => {
            util.log('panghaojie', 'box-send-container.js', 'zoomapimeetingstatuscb', obj);
            const { result, status } = obj;
            if(status == 4 && result == 0 && data.token){
                //结束会议
                if(util.yachLocalStorage.ls('inviteUserNum') && util.yachLocalStorage.ls('inviteUserNum').len > 0){
                    //自己呼叫的有人
                    cancelAllCall({online_meeting_id: data.online_meeting_id})
                }
            }
            if (status == 7 && result == 0) { // 主动离开
                this.leaveMeeting();
                this.setEnterMeeting(false);
            }
            if (status == 7 && result == 2) { // 主持人结束
                //结束会议
                if(util.yachLocalStorage.ls('inviteUserNum') && util.yachLocalStorage.ls('inviteUserNum').len > 0){
                    //自己呼叫的有人
                    cancelAllCall({online_meeting_id: data.online_meeting_id})
                }
                this.leaveMeeting();
                this.setEnterMeeting(false);
            }
            if (status == 7 && result == 1) { // 被主持人移除出会议
                message.warning(util.locale("im_you've_been_moved_out_of_meeting_host"));
                this.setEnterMeeting(false);
            }
            if(status == 0 || status == 6 || status == 7){
                util.log('panghaojie', 'box-send-container.js', 'clearInviteGroupInfo');
                //离开会议，清除选人组件参数
                util.yachLocalStorage.ls('inviteGroupInfo', null);
                //进入会议，快速离开会议，不打开选人组件
                canOpenZoomInvite = false
            }
            if (status == 3 && result == 0){
                this.loginSuccessful(data, title); // 成功进入
                this.endTimerSensorsDataInit(startTimer);
            } 
        });
        
        this.reportVideoChange()
    }

    leaveMeeting = () => {
        const zoomInfo = util.yachLocalStorage.ls('zoom_bangongshi_login');
        this.meetingLeaveEndFun(0);
        util.log('panghaojie', 'box-send-container.js', 'leaveMeeting',!zoomInfo);
        if (!zoomInfo) return;
        const { startTime, meetingNum, meetingName } = zoomInfo;
        const {event_duration } = reportState;
        util.log('panghaojie', 'box-send-container.js', 'startTime',startTime, meetingNum, meetingName);
        if (!startTime || !meetingNum) return;
        try {
            util.sensorsData.track('PageClose_Chat', {
                pageName: '01-103',
                meeting_type: '01-104',
                event_duration: ((new Date()).getTime() - startTime) / 1000,
                meeting_id: meetingNum,
                meeting_name: meetingName
            });
            if (event_duration) {
                util.sensorsData.track('EventContinue_Chat', {
                    event_duration,
                    submodule: '01-101',
                    meeting_type: '01-104',
                    meeting_id: meetingNum,
                    meeting_name: meetingName
                });
                reportState = { talk_start: 0, notalk_start: 0, end_talk: 0, userid: '' };
            }
        } catch (error) {
            util.log('panghaojie', 'box-send-container.js', 'catch',error);
        }
    }

    onlineOffice = (title, isVideoOff, isAudioOff) => {
        this.setState({
            showVideoSession: false
        }, () => {
            const { teamType } = this.props;
            util.log('panghaojie', 'box-send-container.js', 'onlineOffice',teamType.type);
            if (teamType.type == 9){ // 会议群
                this.enterSheduleMeetingSecond(title, isVideoOff, isAudioOff)
            }else{
                this.meetingCreateJoinFun(title, isVideoOff, isAudioOff)
            }
        });
    }

    filesModleVisibleHandleOk  = ()=>{
        const type = this.state.filePreActionType; console.log('uuuu',this.state);
        console.time('filesModleVisibleHandleOk');
        this.setState((pre)=>({
            filesModleVisible: { show: false, num: pre.filesModleVisible.num || 0} 
        }),()=>{
            console.timeEnd('filesModleVisibleHandleOk');
        });

        setTimeout(()=>{
            util.eventBus.emit(`${type}UploadHandle`);
        },100);
    }

    filesModleVisibleHandleCancel = ()=>{
        this.setState( (preState)=>({
            filesModleVisible: { show: false, num: preState.filesModleVisible.num || 0} 
        }))

        const type = this.state.filePreActionType; 
        this.fileUplaodEventRegistryRemove(type);
    }

    render() {
        const isElectron = util.electron.isElectron();
        const { screenCutPopover,breakPaste,excelData,showChooseExcelModal,turnImg,excelTurnImgType } = this.state;
        const { sessionList, sessionActive } = this.props;
        const obj =
            sessionList.filter(item => {
                return item.id == sessionActive.id;
            })[0] || {};

        return (
            <div>
                <BoxSend
                    sendImageAndMsgAll={this.sendImageAndMsgAll}
                    textInputValue={this.state.textInputValue}
                    userAtShow={this.state.userAtShow}
                    userAtInput={this.state.userAtInput}
                    closeUserAt={this.closeUserAt}
                    textareaValue={this.textareaValue}
                    handleKeyPress={this.handleKeyPress}
                    inputMessagesEndEl={this.inputMessagesEnd}
                    getClickUser={this.getClickUser}
                    showUserCB={this.showUserCB}
                    fileChange={this.fileChange}
                    sendFileHndleClick = {this.sendFileHndleClick}
                    handleVisibleChangeFile= {this.handleVisibleChangeFile} 
                    visibleFileable={this.state.visibleFileable}
                    clickEmojiItem={(emojiName) => this.clickEmojiItem(emojiName)}
                    sessionActive={this.props.sessionActive}
                    videoSessioneModal={this.props.videoSessioneModal}
                    atAll={this.state.atAll}
                    isElectron={isElectron}
                    screenshot={this.screenshot}
                    screenCut={this.screenCut}
                    emojiContentVisible={this.state.emojiContentVisible}
                    handleVisibleChange={this.handleVisibleChange}
                    TAClick={this.TAClick}
                    startCall={this.startCall}
                    videoSession={this.checkingIsInternalMeeting}
                    isHiddenVideo={this.isHiddenVideo}
                    handlePasteClick={this.handlePasteClick}
                    handleCopy={this.handleCopy}
                    handlePaste={this.handlePaste}
                    selectedText={this.state.selectedText}
                    ismute={this.props.ismute}
                    ismanager={this.props.ismanager}
                    screenCutPopover={screenCutPopover}
                    handleScreenCutPopover={this.handleScreenCutPopover}
                    screenCutPopoverClick={this.screenCutPopoverClick}
                    isHiddenFile={!this.props.chatRobot}
                    boxSendHeight={this.props.boxSendHeight}
                    toDo={this.toDo}
                    sendType={this.state.sendType}
                    messageType={obj.type}
                    teamType={this.props.teamType}
                    onlineMeeting={this.onlineMeeting}
                    fileChange                     = { this.fileChange }
                    filesModleVisible              = { this.state.filesModleVisible }
                    filesModleVisibleHandleOk      = { this.filesModleVisibleHandleOk }
                    filesModleVisibleHandleCancel  = { this.filesModleVisibleHandleCancel }
                    remind={this.remind}
                    openCalendar={this.openCalendar}
                    createVote={this.createVote}
                    breakPaste={breakPaste}
                    excelData={excelData}
                    excelTurnImgType={excelTurnImgType}
                    showChooseExcelModal={showChooseExcelModal}
                    turnImg={turnImg}
                    excelTurnImg={this.excelTurnImg}
                    excelKeepText={this.excelKeepText}
                    excelModalCancel={this.excelModalCancel}
                />
                <SendFileModal
                    modalTile={this.state.modalTile}
                    modalVisible={this.state.modalShow}
                    setOKModal={this.screenshotSend}
                    setonCancelModal={this.screenshotModalClose}
                    modalContent={this.state.children || util.locale('im_confirm_to_sent_the_screenshot')}
                    wrapClassName={this.state.className}
                    fileModalKeyDown={this.fileModalKeyDown}
                />
                <BoxSendModal
                    sendFileAction={this.state.sendFileAction}
                    sendFileTarget={this.state.sendFileTarget}
                    sendFileBase64={this.state.sendFileBase64}
                    sendFileScreen={this.state.sendFileScreen}
                    sendFileCliped={this.state.sendFileCliped}
                    ismute={this.props.ismute}
                    ismanager={this.props.ismanager}
                    fileNumMore_10                 = { this.fileNumMore_10 }   
                    fileUplaodEventRegistryRemove  = { this.fileUplaodEventRegistryRemove } 
                />
                {obj.type != 'team' && this.state.showVideoSession && this.props.videoSessioneModal.show && (
                    <VideoSessione isShowVideoSession={this.isShowVideoSession} />
                )}
                {obj.type == 'team' && this.state.showVideoSession && this.props.videoSessioneModal.show && (
                    <VideoSessione onlineOffice = {this.onlineOffice}
                    teamType = {this.props.teamType} />
                )}
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        videoSessioneModal: state.videoSessioneModal,
        sessionActive: state.sessionActive,
        userInfo: state.userInfo,
        reply: state.reply,
        ismute: state.groupAll.ismute,
        ismanager: state.groupAll.ismanager,
        chatRobot: state.chatRobot,
        boxSendHeight: state.boxSendHeight,
        sessionList: state.sessionList,
        newMessageComing: state.calender.newMessageComing,
        isInMeeting: state.calender.isInMeeting,
        showMeetingState: state.calender.showMeetingState,
        draftEditorState: state.draftEditorState,
        messageList: state.messageList
    };
};

export default connect(mapStateToProps, null)(BoxSendContainer);