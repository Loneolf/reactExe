// react
import React from 'react';
import {connect} from 'react-redux';
// component
import BoxManagement from './box-management';
// redux
import {hideSlideModal, showSlideModal} from '@/redux/actions/commonModal';
import {sessionActiveSet} from '@r/actions/session.js';
import { setMuteAll } from '@r/actions/groupAll.js';
import { groupShutUpAll } from '@s/group/group-info.js';


import * as util from '@/utils/util';

import {groupInfoConfig, groupInfoDismiss, groupInfoGet, groupInfoOwnerChange} from '@/services/group/group-info';
// antd
import {message} from 'antd';

// BoxManagementContainer
class BoxManagementContainer extends React.Component {
    state = {
        modalVisible: false,
        delModalVisible: false,
        loading: false,
        show: false,
        disabledids: [],
        transferModalVisible: false,
        selectUser: {},
        userAddShow: false,
        settingInfoCheckedBut: false,
        atSettingCheckedBut: false,
        userType: '-1'
    };

    componentDidMount(){
        this.getManagerAndOwner();
        this.groupInfoGet();
    };

    groupInfoGet = async() => {
        const { id } = await this.props.sessionActive || {};
        const datas = await groupInfoGet({ tid:id });
        if(datas){
            const { code, obj = {} } = datas || {};
            if (code == 200) {
                this.setState({
                    userType: obj.user_type
                });
                if(obj.config_at_all == 1) this.setState({atSettingCheckedBut: true});
                if(obj.config_edite == 1) this.setState({settingInfoCheckedBut: true});
            }
        }
    };

    groupInfoOwnerChange = async(group_tid, new_owner) => {
        const datas = await groupInfoOwnerChange({ tid:group_tid,new_owner:new_owner });
        if(datas){
            const { code, obj = {} } = datas || {};
            if (code === 200) {
                util.sensorsData.track('Click_Chat_Element', {pageName: 146, $element_name: 129, chat_id: group_tid});
                return true;
            }else{
                message.success(util.locale("im_failed_to_transfer_group_administration")); 
                return false;
            }
        }
    };

    setOKModal = () => {
        this.setState({modalVisible: false, delModalVisible: true});
    };

    setonCancelModal = () => {
        this.setState({modalVisible: false})
    };

    delOKModal = async () => {
        let item = this.props.sessionActive;

        const res = await groupInfoDismiss({ tid: item.id });
        util.log('panghaojie','box-management-container.js','groupInfoDismiss' ,item.id);

        if(!res || res.code != 200){
            message.error(res.msg);
            return
        }
        message.success(util.locale("im_group_dismiss_successfully"));

        //1.4.4版本之后，解散群只走yach服务的接口，不再走云信解散群的逻辑
        // const obj = await util.nimUtil.dismissTeam(item.id);
        this.props.dispatch(sessionActiveSet({}));
        this.setState({delModalVisible: false});
        this.props.dispatch(hideSlideModal());
        let nimId = util.nim.getNimId(item.type, item.id);
        setTimeout(util.nim.deleteLocalSession.bind(null, nimId), 500)
    };

    delCancelModal = () => {
        this.setState({delModalVisible: false});
    };

    goConfig = () => {
        this.props.dispatch(showSlideModal('configuration'));
    };

    dissolution = () => {
        this.setState({modalVisible: true})
    };

    groupInfoSetting = (checked) => {
        if(checked){
            this.setState({settingInfoCheckedBut:true})
        }else{
            this.setState({settingInfoCheckedBut:false})
        }
        this.groupInfoConfig({config_edite:checked?1:0}, 1);
    };

    atSetting = (checked) => {
        if(checked){
            this.setState({atSettingCheckedBut:true})
        }else{
            this.setState({atSettingCheckedBut:false})
        }
        this.groupInfoConfig({config_at_all:checked?1:0}, 2);
    };

    /*
      全员shutup 普通级别
    */
    allShutUpFn = async c =>{
        const { id,type } = this.props.sessionActive;
        if(!id) return; 
        try{
            // let type = c?'normal':'none';
            // const config  =  await util.nimUtil.stopAllNoSpeaking(id,type);
            // console.log('config')
            // if(config){
            //     this.props.dispatch(setMuteAll(c)); 
            //     // wiki 我https://wiki.zhiyinlou.com/pages/viewpage.action?pageId=53774461
            //     const setGroupSpeak = await groupShutUpAll({tid:id,mute:c?1:0,mute_type:1});
            //     const {code,msg,obj=[]} = setGroupSpeak;
            //     if(code !== 200){
            //         message.warn(msg);
            //     }
            // }
            this.props.dispatch(setMuteAll(c)); 
            // wiki 我https://wiki.zhiyinlou.com/pages/viewpage.action?pageId=53774461
            const setGroupSpeak = await groupShutUpAll({tid:id,mute:c?1:0,mute_type:c?1:0});
            const {code,msg,obj=[]} = setGroupSpeak;
            if(code !== 200){
                message.warn(msg);
            }
        }
        catch(e){
            console.log('group allShutUpFn >>');
            console.log(e);
        }
    }

    groupInfoConfig = async(params, type) => {
        const { id } = await this.props.sessionActive || {};
        const datas = await groupInfoConfig(Object.assign({tid:id}, params));
        if(datas){
            const { code, obj = {} } = datas || {};
            if (code === 200) {
                if(params.hasOwnProperty('config_edite')) {
                    if(params.config_edite) {
                        util.sensorsData.track('Click_Chat_Element', {pageName: 138, $element_name: 182, chat_id: id});
                    } else {
                        util.sensorsData.track('Click_Chat_Element', {pageName: 138, $element_name: 183, chat_id: id});
                    } 
                }
                else if(params.hasOwnProperty('config_at_all')) {
                    if(params && params.config_at_all) {
                        util.sensorsData.track('Click_Chat_Element', {pageName: 138, $element_name: 184, chat_id: id});
                    } else {
                        util.sensorsData.track('Click_Chat_Element', {pageName: 138, $element_name: 185, chat_id: id});
                    } 
                }
                message.success(util.locale("im_successfully_modified"));
                // this.nimUpdateTeam(params, type);
            }
        }
    };

    // nimUpdateTeam = async(params, type) => {
    //     const { id } = this.props.sessionActive;
    //     if(type == 1){
    //         const edite = params.config_edite;
    //         await util.nimUtil.updateTeam(id, {inviteMode: edite?'manager':'all', updateTeamMode:edite?'manager':'all'});
    //     } else if(type == 2){
    //         const atAll = params && params.config_at_all;
    //         const customObj = {
    //             config:{type: 0, value: atAll?1:2}
    //         }
    //         await util.nimUtil.updateTeam(id, {custom: JSON.stringify(customObj)});
    //     }
    //     message.success(util.locale("im_successfully_modified"));
    // }

    getUsers = (value) => {
        this.setState({transferModalVisible: true, selectUser: value.users[0]});
    };

    setTransferCancelModal = () => {
        this.setState({transferModalVisible: false});
    };

    setTransferOKModal = async() => {
        console.log('setTransferOKModal', this.state.selectUser)
        try {
            const ownerObj = await this.groupInfoOwnerChange(this.props.sessionActive.id, this.state.selectUser.id);
            if(ownerObj){
                // const obj = await util.nimUtil.transferTeam(this.props.sessionActive.id, this.state.selectUser.id);
                // if(obj){
                //     message.success(util.locale("im_transfer_the_group_administration_to_")+this.state.selectUser.name); 
                //     this.props.dispatch(hideSlideModal());
                // }
                message.success(util.locale("im_transfer_the_group_administration_to_")+this.state.selectUser.name); 
                this.props.dispatch(hideSlideModal());
            }
        } catch (error) {
            message.error(error);
        }
    };

    closegetUser = async () => {
        this.setState({userAddShow: false})
    };

    transferTeam = () => {
        this.setState({userAddShow: true})
    };

     getManagerAndOwner = async() => {
        let owner = [];
        console.log('getManagerAndOwner');
        const obj = await util.nimUtil.getTeamMembers(this.props.sessionActive.id);
        owner = obj.members.filter(item=>{
            return item.type == 'owner';
        });
        this.setState({disabledids: owner[0].account});
    };

    render() {
        const userAddProps = {
            type: "group",
            check: 'radio',
            groupId: this.props.sessionActive.id,
            loading: this.state.loading,
            show: this.state.userAddShow,
            onOk: this.getUsers,
            onClose: this.closegetUser,
            disabledids: this.state.disabledids,
            title: util.locale("im_transfer_the_group_administration_to"),
            leftTitle: util.locale("im_group_administrator"),
            rightTitle: util.locale("im_choose_the_administrator_to_transfer"),
            userListTile: util.locale("im_select_group_administration")
        };
        return (
            <BoxManagement
                modalVisible={this.state.modalVisible}
                delModalVisible={this.state.delModalVisible}
                setOKModal={this.setOKModal}
                setonCancelModal={this.setonCancelModal}
                delOKModal={this.delOKModal}
                delCancelModal={this.delCancelModal}
                goConfig = {this.goConfig}
                dissolution = {this.dissolution}
                groupInfoSetting = {this.groupInfoSetting}
                atSetting = {this.atSetting}
                userAddProps = {userAddProps}
                transferTeam = {this.transferTeam}
                setTransferOKModal = {this.setTransferOKModal}
                setTransferCancelModal = {this.setTransferCancelModal}
                transferModalVisible = {this.state.transferModalVisible}
                settingInfoChecked = {this.state.settingInfoCheckedBut}
                atSettingChecked = {this.state.atSettingCheckedBut}
                allShutUp = {this.state.allShutUp}
                allShutUpFn = {this.allShutUpFn}
                selectUser = {this.state.selectUser}
                ismute = {this.props.ismute}
                userType = {this.state.userType} />
        );
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
        sessionActive: state.sessionActive,
        sessionList: state.sessionList,
        ismute: state.groupAll.ismute
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxManagementContainer);
