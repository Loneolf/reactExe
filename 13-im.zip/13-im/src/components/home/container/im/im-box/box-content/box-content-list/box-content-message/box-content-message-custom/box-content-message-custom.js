import React, { useMemo,useCallback} from 'react';
import { Tooltip } from 'antd';
import css from './index.scss';

import VoiceRead from '../box-content-message-audio/box-content-message-audio';
// util
import * as util from '@u/util.js';
import * as linkMsgHandler from '@u/nim/container/link-msg-handler.js';
import { urlRegExp } from '@/utils/yach';
// common
import ReplyEmots from '@c/common/reply-emots';
import FileDownloadProgress from '@c/common/filedownload-progress/filedownload-progress-container.js';
import MarkdownMsg from '@c/common/markdown';
import Translate from '@c/common/translate';
import TranslateState from '@c/common/translate-state';

// img
import pakageImg from '@a/imgs/redEnvelope/pakage.png';
import defImg from '@a/imgs/defImg.png';
import wordImg from '@a/imgs/custom/word.png';
import excelImg from '@a/imgs/custom/excel.png';
import formsImg from '@a/imgs/custom/forms.png';
import mindMapImg from '@a/imgs/custom/mind-map.png';
import pptImg from '@a/imgs/custom/ppt.png';
import whiteBoardImg from '@a/imgs/custom/white-board.png';
import LinkMessage from '@c/common/link-msg';
import LinkMsg from './link-msg/link-msg';
import VoteMsg from '@c/common/vote/vote-card';

import _ from 'lodash';

export default (props) => {
    let Message,
        data,
        type = '';
    const {
        translating,
        flow,
        translateAndReduction,
        isInAt,
        isSelf,
        replyMsg,
        isOriginal,
        translateText,
        isMultiSelect,
        type: propsType
        // getMsgImg
    } = props;

    /**
     * 消息下边的小组件
     */
    const getWidget = () => {

        return (
            <>
                {!isOriginal && !isMultiSelect && (
                    <Translate isCustom = {true} translating={translating} translateText={translateText} flow={flow} />
                )}
                {showEmots && <ReplyEmots {...props} />}
                {!isOriginal && !isMultiSelect && (
                    <div className={`${css.translateStateCustom} ${isInAt ? css.translateStateCustomIsInAt : ''}`}>
                        <TranslateState translating={translating} translateAndReduction={translateAndReduction} />
                    </div>
                )}
                {isInAt && (
                    <div className={css.reply} onClick={replyMsg}>
                        {util.locale('im_reply')} {/**回复： */}
                    </div>
                )}
            </>
        );
    };

    const noData = () => {
        return <div className={css.noData}>{util.locale('im_unsupported_message_type')}</div>;
    };

    try {
        const content = JSON.parse(props.content);
        data = content.data;
        type = content.type;
    } catch (error) {
        console.log('解析不了了');
        Message = noData();
    }

    const showEmots = props.emots&& !!props.emots.length;

    const getReplyBgColor = () => {
        const { flow } = props;
        if (flow == 'out') {
            return css.outReplyMessage;
        } else if (flow == 'in') {
            return css.inReplyMessage;
        } else {
            return '';
        }
    };

    // 计算语音长度
    const computedAudioLength = (duration) => {
        let time = parseInt(duration);
        let minLength = 170;
        let maxLength = 322;
        time = Math.min(duration, 59);
        let length = minLength + ((time - 1) * (maxLength - minLength)) / 58;
        return length;
    };

    const record = () => {
        return (
            <div className={css.boxrecord}>
                {/* <div className={css.title}>
                    <span>周报</span>
                    <span>{data.postTime}</span>
                </div> */}
                <div className={css.content}>
                    <span className={css.contentTitle}>{data.title}</span>
                    {data.worklogContent.map((v, index) => (
                        <div key={index}>
                            <div className={css.head}>{v.title}</div>
                            <div className={css.body}>{v.content}</div>
                        </div>
                    ))}
                    <span className={css.time}>{data.postTime}</span>
                </div>
                <div className={css.detail} onClick={props.gotoRecord.bind(null, data)}>
                    <span className={css.detailText}>{util.locale('im_view_details')}</span> {/** 查看详情*/}
                    <span className="iconfont-yach yach-kapian-chakanxiangqing-jinru-moren"></span>
                </div>
                {showEmots && (
                    <div className={css.recordEmots}>
                        <ReplyEmots {...props} />
                    </div>
                )}
            </div>
        );
    };

    const notice = () => {
        return (
            <div className={css.groupNotice}>
                <div className={css.title}>
                    <span>{util.locale('im_group_notice')}</span> {/**群公告 */}
                </div>
                <pre
                    dangerouslySetInnerHTML={{
                        __html: util.yach.textFiltering(data.content),
                    }}
                ></pre>
                {showEmots && <ReplyEmots {...props} isNotice />}
            </div>
        );
    };

    const focusReview = () => {
        return (
            <div className={css.focusReview} onClick={props.gotoRecord.bind(null, data)}>
                {/* <div className={css.title}>
                    <span>周报</span>
                </div> */}
                <div className={css.content}>
                    {`${data.content}`.replace(`[${util.locale('common_week_report')}]`, '')}
                </div>{' '}
                {/** 周报*/}
            </div>
        );
    };

    const fileMessage = () => {
        let isDownloadFlag = false;
        const downloadPath=util.cosfiles.fileDownloadStatusGet(data.relationId);

        if (downloadPath) isDownloadFlag = true;
        //if (props.againDownload) isDownloadFlag = false
        // 判断是否是在多选转发的聊天记录里打开的非PDF？ 若是，则不展示转在线文档的图标
        const isSlideOpen =
            !!(props.slideModal.kind === 'historicalRecord') ||
            util.yach.getFileType(data.fileUrl) === '_pdf' ||
            util.yach.getFileType(data.fileUrl) === '_ppt';
        // 是否大于 100M (!PDF类型)
        const isLargeFile = !!(data.fileSize > 100 * 1024 * 1024) && util.yach.getFileType(data.fileUrl) !== '_pdf';
        const TooltipTxt = isLargeFile ? util.locale('im_cannot_preview_files_over_100m') : util.locale('im_preview'); // 超过100m的文件不支持预览\预览
        const iconFontClass = util.yach.getFileType(data.fileUrl);
        const imgAddress = require(`@a/imgs/modelFileType/${iconFontClass}.svg`);
        let downloadstatus = props.fileDownloadProgress.find((v) => v.id == props.idClient);
        let filestatus = props.fileStatus.find((v) => v.id == props.idClient);
        const filePath =
            (filestatus && filestatus.downloadedPath) ||downloadPath;
        if (filestatus) isDownloadFlag = !!filestatus.isDownloaded;
        let fileBg = '',
            flowBg = '';
        if (showEmots) {
            fileBg = css.fileBg;
            if (props.flow == 'in') {
                flowBg = css.inBg;
            } else if (props.flow == 'out') {
                flowBg = css.outBg;
            }
        }
        const convertParams = {
            relationId: data.relationId,
            fileUrl: data.fileUrl,
            fileName: data.fileName,
            creatorId: props.from,
            receiver: props.target,
            type: props.isTeam ? 2 : 1,
            fileType: props.getOfficeType(data.fileUrl),
        };

        let fileName = data.fileName;
        if (fileName && fileName.length > 21)
            fileName = fileName.substr(0, 12) + '...' + fileName.substr(fileName.length - 8);
        return (
            <div>
                <div className={`${fileBg} ${flowBg}`}>
                    <div className={`${css.contentFile} ${css.fileMessageContent}`}>
                        <div className={css.svgContent}>
                            <img src={imgAddress} className={css.file_svg} />
                        </div>
                        <div className={css.fileNameBox}>
                            <Tooltip placement="topLeft" overlayClassName="fileNameTools" title={data.fileName}>
                                <span className={css.fileName}>{fileName}</span>
                            </Tooltip>
                        </div>
                        <div className={css.fileContent}>
                            <span className={css.fileSize}>
                                {util.yach.getFileSize(data.fileSize)}
                                {!!downloadstatus && <span></span>}
                                {!!downloadstatus && downloadstatus.speed}
                            </span>
                            <div className={css.operate}>
                                {isSlideOpen ? null : (
                                    <Tooltip placement="top" title={util.locale('im_turn_to_online_editing')}>
                                        {' '}
                                        {/**转在线编辑 */}
                                        <a onClick={() => props.convertOnlineDoc(convertParams, data.fileName)}>
                                            <span
                                                className={`${css.preview} iconfont-yach yach-zaixianwendang-zhuanweizaixianwendang`}
                                            />
                                        </a>
                                    </Tooltip>
                                )}
                                <Tooltip placement="top" title={TooltipTxt}>
                                    {!isLargeFile ? (
                                        <a onClick={() => props.showOffice(data.fileUrl, data.fileName,data.relationId)}>
                                            <span
                                                className={`${css.preview} iconfont-yach yach-kapian-wenjian-yulan-moren`}
                                            />
                                        </a>
                                    ) : (
                                        <a>
                                            <span
                                                className={`${css.preview} ${css.previewGray} iconfont-yach yach-kapian-wenjian-yulan-moren`}
                                            />
                                        </a>
                                    )}
                                </Tooltip>
                                <Tooltip
                                    placement="top"
                                    title={isDownloadFlag ? util.locale('im_open') : util.locale('im_download')}
                                >
                                    {' '}
                                    {/** 打开\下载*/}
                                    {isDownloadFlag ? (
                                        <a onClick={() => props.openFile({path:filePath, idClient:props.idClient,relation_id:data.relationId})}>
                                            <span
                                                className={`${css.download} iconfont-yach yach-zaixianwendang-dakaiwendangicon`}
                                            />
                                        </a>
                                    ) : (
                                        <a
                                            className={downloadstatus ? css.downloading : ''}
                                            onClick={() =>
                                                // props.fileDownload(
                                                //     data.fileUrl,
                                                //     props.idClient,
                                                //     data.fileName,
                                                //     !!downloadstatus
                                                // )
                                                props.fileDownload({
                                                    url:data.fileUrl,
                                                    idClient:props.idClient,
                                                    name:data.fileName,
                                                    isdownloading:!!downloadstatus,
                                                    relationId:data.relationId
                                                })
                                            }
                                        >
                                            <span
                                                className={`${css.download} iconfont-yach yach-kapian-wenjian-xiazai-moren`}
                                            />
                                        </a>
                                    )}
                                </Tooltip>
                                <Tooltip placement="top" title={util.locale('im_open_folder1')} arrowPointAtCenter>
                                    { isDownloadFlag && (
                                        <a onClick={() => props.openFileDir({path:filePath, idClient:props.idClient,relation_id:data.relationId})}>
                                            <span className='iconfont-yach yach-kapian-wenjian-chakanwenjianjia-moren' />
                                        </a>
                                    )}
                                </Tooltip>
                            </div>
                        </div>
                    </div>
                    {showEmots && <ReplyEmots {...props} />}
                </div>
                {downloadstatus && (
                    <FileDownloadProgress
                        percent={downloadstatus.percent}
                        speed={downloadstatus.speed}
                        cancel={props.fileDownloadCancel.bind(null, props.idClient)}
                    />
                )}
            </div>
        );
    };

    const customerMessage = (stype) => {
        let isDownloadFlag = false;
        const downloadPath=util.cosfiles.fileDownloadStatusGet(data.relationId);
        const isdir = stype === 26;

        let downloadstatus = props.fileDownloadProgress.find((v) => v.id == props.idClient);
        let filestatus = props.fileStatus.find((v) => v.id == props.idClient);

        if (downloadPath) isDownloadFlag = true;
        if (filestatus) isDownloadFlag = !!filestatus.isDownloaded; /*  */

        const filePath =
            (filestatus && filestatus.downloadedPath) ||downloadPath;
        const iconFontClass = util.yach.getFileType(data.fileOriginUrl);

        const imgAddress = isdir
            ? require(`@a/imgs/modelFileType/_dir.svg`)
            : require(`@a/imgs/modelFileType/${iconFontClass}.svg`);

        let fileBg = '',
            flowBg = '';
        if (showEmots) {
            fileBg = css.fileBg;
            if (props.flow == 'in') {
                flowBg = css.inBg;
            } else if (props.flow == 'out') {
                flowBg = css.outBg;
            }
        }

        let fileName = data.fileName;
        if (fileName && fileName.length > 21)
            fileName = fileName.substr(0, 11) + '...' + fileName.substr(fileName.length - 7);

        let isloading = () => {
            if (isdir) return downloadstatus || props.msgTempStats[props.idClient] ? css.downloading : '';
            return downloadstatus ? css.downloading : '';
        };


        return (
            <div>
                <div
                    className={`${fileBg} ${flowBg}`}
                    style={isdir ? { cursor: 'pointer' } : null}
                    onClick={
                        isdir
                            ? () => util.cosfiles.goFloderPreview({isMultiSelect:props.isMultiSelect,relation_id:data.relationId,fileName:data.fileName,type:props.sessionActive.type})
                            : () => {}
                    }
                >
                    <div className={css.contentFile}>
                        <div className={css.svgContent}>
                            <img src={imgAddress} className={css.file_svg} />
                        </div>
                        <div className={css.fileNameBox}>
                            <Tooltip placement="topLeft" overlayClassName="fileNameTools" title={data.fileName}>
                                <span
                                    className={css.fileName}
                                >
                                    {fileName}
                                </span>
                            </Tooltip>
                        </div>
                        <div className={css.fileContent}>
                            <span className={css.fileSize}>
                                {isdir?'':util.yach.getFileSize(data.fileSize)}
                                {!!downloadstatus && (!isdir) && <span></span>}
                                {!!downloadstatus && downloadstatus.speed}
                            </span>
                            <div className={css.operate}>
                                <Tooltip
                                    placement="top"
                                    title={isDownloadFlag ? util.locale('im_open') : util.locale('im_download')}
                                >
                                    {' '}
                                    {/** 打开\下载*/}
                                    {isDownloadFlag ? (
                                        <a
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                props.openFile({path:filePath, idClient:props.idClient, type:stype, fname:data.fileName,relation_id:data.relationId});
                                            }}
                                        >
                                            <span
                                                className={`${css.download} iconfont-yach yach-zaixianwendang-dakaiwendangicon`}
                                            />
                                        </a>
                                    ) : (
                                        <a
                                            className={isloading()}
                                            onClick={
                                                !isloading()
                                                    ? _.throttle((e) => {
                                                          e.stopPropagation();
                                                        //   props.fileDownload(
                                                        //       data.fileOriginUrl || data.fileUrl,
                                                        //       props.idClient,
                                                        //       data.fileName,
                                                        //       !!downloadstatus,
                                                        //       stype
                                                        //   );
                                                          props.fileDownload({
                                                            url:data.fileOriginUrl || data.fileUrl,
                                                            idClient:props.idClient,
                                                            name:data.fileName,
                                                            isdownloading:!!downloadstatus,
                                                            stype,
                                                            relationId:data.relationId
                                                          });
                                                      }, 800)
                                                    : () => {}
                                            }
                                        >
                                            <span
                                                className={`${css.download} iconfont-yach yach-kapian-wenjian-xiazai-moren`}
                                            />
                                        </a>
                                    )}
                                </Tooltip>
                                <Tooltip placement="top" title={util.locale('im_open_folder1')} arrowPointAtCenter>
                                    {isDownloadFlag &&(
                                        <a onClick={(e) => {
                                                e.stopPropagation()
                                                props.openFileDir({path:filePath, idClient:props.idClient, type:stype,relation_id:data.relationId})
                                            }
                                        }>
                                            <span className={`iconfont-yach yach-kapian-wenjian-chakanwenjianjia-moren`} />
                                        </a> 
                                    )}
                                </Tooltip>
                            </div>
                        </div>
                    </div>
                    {showEmots && <ReplyEmots {...props} />}
                </div>
                {downloadstatus && (
                    <FileDownloadProgress
                        record={props.slideModal.kind}
                        percent={downloadstatus.percent}
                        speed={downloadstatus.speed}
                        cancel={props.fileDownloadCancel.bind(null, props.idClient)}
                    />
                )}
            </div>
        );
    };

    const p2pAutoReplyMessage = () => {// 私聊 -> 个人状态 -> 自动回复
        const _content = data.content || {};
        let html = _content.reply_content
        if (Array.isArray(_content.at_users) && _content.at_users.length) {
            html = util.yach.atStr(html, _content.at_users);
        }
        const isIn = !isSelf && flow == 'in' && propsType != 'notification';
        return <div className={css.autoReply + ` ${isIn ? css.autoReplyIn : ''}`}>
            {/* {props.isSelf ?  */}
             <span onClick={() => {util.electronipc.electronOpenUserStatus();}} className={css.clickPannel}>[{util.locale('im_auto_reply')}]</span>
            {/* '[自动回复]'
            } */}
            <span style={{display: 'inline'}} dangerouslySetInnerHTML = {{__html: html}}></span>
            {getWidget()}
        </div>
    }
    const replyTextMessage = (text, replyText, tag) => {
        // 回复的如果是链接，则不可点击,截取链接地址
        //if (replyText.startsWith('<a href=')) replyText = replyText.split(' ')[1].slice(5);
        const { fromNick, fromYachNick } = data;
        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    {tag ? tag : `${util.locale('im_reply')}：`}
                    <pre className={css.replyText} />
                    {replyText}
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    const replyPositioningMessage = (text) => {
        const { goPositioning } = props;
        const { fromNick, fromYachNick } = data;
        try {
            const customData = JSON.parse(data.content);
            const { name, shareUrl } = customData.data;
            return (
                <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                    <pre className={css.replyItem}>
                        <p className={css.fromNick}>
                            {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                        </p>
                        <div className={css.replyLocation} onClick={() => goPositioning(shareUrl)}>
                            [{util.locale('im_location')}]<span>{name}</span>
                        </div>
                    </pre>
                    <pre className={css.replySendText}>{text}</pre>
                    {getWidget()}
                </div>
            );
        } catch (error) {
            return noData();
        }
    };

    const replyLinkMessage = (text, data, customContent) => {
        const { fromNick, fromYachNick } = data;
        const url = linkMsgHandler.normalizeUrl(customContent.data.url || customContent.data.messageUrl).match(urlRegExp());
        const linkString = `${util.locale('im_link')}：<a  class="aLink" target="_blank" href="${url}">${
            customContent.data.title || customContent.data.url || customContent.data.messageUrl
        } </a>`; // 链接

        let _html = util.yach.convertExpression(linkString, '34px', '34px');

        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    <pre
                        className={`${css.replyText} ${css.linkReply}`}
                        dangerouslySetInnerHTML={{
                            __html: _html,
                        }}
                    />
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    const replyMarkDownMessage = (text, data, customContent) => {
        const { fromNick, fromYachNick } = data;

        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                </pre>
                {markdown({...customContent.data,fType:'reply'})}
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    const replyOfficeMessage = (dec, text, customData) => {
        const { openFileExternal, goDocument } = props;
        const { fromNick, fromYachNick } = data;
        let fileUrl = null;
        // 文件回复
        if (customData && customData.fileUrl) {
            fileUrl = customData.fileUrl;
        }
        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    {`[${dec}]`}
                    {fileUrl ? (
                        <a onClick={openFileExternal.bind(null, fileUrl)} target="_blank" data-url={fileUrl}>
                            {customData.fileName}
                        </a>
                    ) : (
                        <a onClick={() => goDocument(customData)}>{customData.title}</a>
                    )}
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    // 临时处理下 不能播放的视频文件的回复 下一期做了处理以后就按照视频来回复了
    const replyFileMessageVideo = (dec, text) => {
        const { fromNick, fromYachNick } = data;
        const { content } = data;

        const jcontent = util.nimUtil.getJson(content);
        if (jcontent.type !== 30) return null;

        const vdata = jcontent.data;
        const fileUrl = vdata.fileUrl || '';

        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    {`[${dec}]`}
                    <a href={fileUrl + '?download=' + encodeURIComponent(vdata.fileName)} target="_blank">
                        {vdata.fileName.length > 20
                            ? vdata.fileName.slice(0, 7) + '...' + vdata.fileName.slice(-7)
                            : vdata.fileName}
                    </a>
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    const replyFileMessage = (dec, text) => {
        const { fromNick, fromYachNick } = data;
        const fileUrl = data.file && data.file.url ? data.file.url : '';
        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    {`[${dec}]`}
                    <a
                        href={
                            fileUrl.indexOf('?') > 0
                                ? data.file.url + '&download=' + encodeURIComponent(data.file.name)
                                : data.file.url +
                                  '?download=' +
                                  encodeURIComponent(data.file.name) +
                                  '.' +
                                  data.file.ext
                        }
                        target="_blank"
                    >
                        {data.file.name.length > 20
                            ? data.file.name.slice(0, 7) + '...' + data.file.name.slice(-7)
                            : data.file.name}
                    </a>
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };
    const replyVideoFileMessage = (dec, text, jcontent) => {
        let { fromNick, fromYachNick, file, idClient } = data;

        // flag
        let iscosVideo = false;
        jcontent && (iscosVideo = true);

        // arg
        let fileUrl = iscosVideo ? jcontent.data.fileUrl : file && file.url ? file.url : '';
        let csize = iscosVideo ? jcontent.data.fileSize : file.size;
        let cdur = iscosVideo ? jcontent.data.dur : file.dur;
        let fileName = iscosVideo ? jcontent.data.fileName : file.name;
        let fileExt = iscosVideo
            ? jcontent.data.ext || util.videoUtil.getFileExtendingName(jcontent.data.fileUrl)
            : file.ext;
        let coverUrl = iscosVideo ? jcontent.data.coverUrl : file.coverUrl;
        let taskId = iscosVideo ? jcontent.data.taskId : file.taskId;
        let relationId = iscosVideo ? jcontent.data.relationId : file.relationId;

        // style
        const replyItemInnerStyle = util.videoUtil.getReplyStyle(iscosVideo ? jcontent.data : file);
        if (replyItemInnerStyle.width < 140) replyItemInnerStyle.width = 140;
        if (replyItemInnerStyle.height < 140) replyItemInnerStyle.height = 140;

        // const videoWrapStyle = util.videoUtil.getReplyStyle(iscosVideo ? jcontent.data : file);
        // videoWrapStyle.width = replyItemInnerStyle.width + 11;
        // videoWrapStyle.height = replyItemInnerStyle.height + 25;

        const thisStyle = util.videoUtil.getReplyStyle(iscosVideo ? jcontent.data : file);
        const videoNoRadius =
            replyItemInnerStyle.width != thisStyle.width || replyItemInnerStyle.height != thisStyle.height;

        // download
        let isDownloadFlag = false;
        const downloadPath=util.cosfiles.fileDownloadStatusGet(relationId);
        if (downloadPath) isDownloadFlag = true;

        let filestatus = props.fileStatus.find((v) => v.id == idClient);
        if (filestatus) isDownloadFlag = !!filestatus.isDownloaded;
        const downloadstatus = props.fileDownloadProgress.find((v) => v.id == idClient);
        const filePath =
            (filestatus && filestatus.downloadedPath) ||downloadPath;

        // pic
        let pic = props.avatar;
        let newPic = props.sessitonActivePic && props.sessitonActivePic[props.id];
        if (newPic && newPic !== props.avatar) pic = newPic;

        return (
            <div className={`${css.videoReplyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.name}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    <div
                        className={`${css.replyItemInner} ${coverUrl ? css.replyItemInnerBackground : ''}`}
                        style={replyItemInnerStyle}
                    >
                        {coverUrl ? (
                            <img src={coverUrl} alt="" className={css.coverUrl} />
                        ) : (
                            <div className={css.videPosition} style={thisStyle}>
                                <video
                                    className={`${css.video} ${videoNoRadius ? css.videoNoRadius : ''}`}
                                    preload="meta"
                                    style={thisStyle}
                                >
                                    <source src={fileUrl} type="video/mp4" />
                                </video>
                            </div>
                        )}
                        <div className={css.videoFileContent}>
                            <span>{util.yach.getFileSize(csize)}</span>
                            <span className={css.videoTime}>{util.videoUtil.getVideoTime(cdur)}</span>
                        </div>
                        {/* <div className={css.videoPlayWrap} > */}
                        <div
                            className={css.videoPlayWrap}
                            onClick={() =>
                                props.clickVideo({
                                    fileUrl,
                                    idClient,
                                    fileName,
                                    fileExt,
                                    isdownloading: !!downloadstatus,
                                    fileSize: util.yach.getFileSize(csize),
                                    filePath,
                                    fileDur: cdur,
                                    msg: props.msg,
                                    isDownloadFlag,
                                    pic,
                                    taskId,
                                    relationId,
                                    coverUrl,
                                    csize,
                                    width: util.videoUtil.getWH(iscosVideo ? jcontent.data : file).width,
                                    height: util.videoUtil.getWH(iscosVideo ? jcontent.data : file).height,
                                })
                            }
                        >
                            <p className={css.videoPlayInner}></p>
                        </div>
                    </div>
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    const replyCustomerFileMessage = (dec, text, customContent) => {
        const { fromNick, fromYachNick } = data;
        const cData = customContent.data;

        let url = cData.fileOriginUrl || cData.fileUrl;
        let stype = '';
        try {
            stype = JSON.parse(data.content)['type'];
        } catch (e) {
            stype = '';
        }
        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    <a
                        onClick={props.openFileExternal.bind(null, url, stype, customContent, props)}
                        data-url={url}
                        target="_blank"
                    >
                        {`[${dec}]`+(cData.fileName.length > 20
                            ? cData.fileName.slice(0, 7) + '...' + cData.fileName.slice(-7)
                            : cData.fileName)}
                    </a>
                </pre>
                <pre className={css.replySendText}> {text}</pre>
                {getWidget()}
            </div>
        );
    };

    const replyImageMessageOld = (text) => {
        let imgScale = 1,
            _file = data.file,
            imgStyle = {};
        if (_file.h && _file.w) {
            imgScale = props.getImgScale(_file.h, _file.w);
            imgStyle = {
                width: imgScale * _file.w || 200,
                height: imgScale * _file.h || '100%',
            };
        } else {
            imgStyle = {
                maxWidth: 200,
            };
        }
        const { fromNick, fromYachNick } = data;
        const url =
            _file.url.includes('createTime')
                ? _file.url + '&imageView'
                : _file.url + '?imageView&createTime=' + data.time;
        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    <a onClick={() => props.showImg(url)}>
                        <img
                            style={imgStyle}
                            src={props.getMsgImg(_file.url)}
                            alt={util.locale('im_image_lost')}
                            onContextMenu={(e) => e.preventDefault()}
                        />
                    </a>
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    const replyImageMessage = (text, imgData) => {
        const { replyImageMessageShowImg } = props;
        let imgSize = props.getImgScale(imgData.height, imgData.width),
            a_box;
        const imgStyle = {
            width: `${imgSize.width}px`,
            height: `${imgSize.height <= 60 ? 60 : imgSize.height}px`,
            position: 'relative',
            top: `0px`,
            left: `-${(imgSize.width - 324) / 2}px`,
            borderRadius: '10px',
        };
        const normalImgStyle = {
            width: imgSize.width ? `${imgSize.width}px` : '200px',
            height: imgSize.height ? `${imgSize.height}px` : '100%',
            borderRadius: '10px',
        };
        switch (imgSize.typeNum) {
            case 1:
                a_box = css.a_box_wh;
                break;
            case 2:
                a_box = css.a_box_hw;
                break;
            default:
                a_box = '';
                break;
        }
        const url = props.getMsgImg(imgData.fileThumbnailUrl || imgData.fileOriginUrl);
        const { fromNick, fromYachNick } = data;
        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    <a onClick={() => replyImageMessageShowImg(imgData.fileOriginUrl, imgData)} className={a_box}>
                        <img
                            // className={imgType}
                            style={imgSize.typeNum === 2 ? imgStyle : normalImgStyle}
                            src={url}
                            alt={util.locale('im_image_lost')}
                            onContextMenu={(e) => e.preventDefault()}
                        />
                    </a>
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    const replyExpressionMessage = (text, imgData) => {
        const { imageLoadHandler } = props;
        const { fromNick, fromYachNick } = data;
        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    <div className={css.expressionImg}>
                        <img
                            className={imgData.isClick === '1' ? css.isClick : ''}
                            src={imgData.expressionUrl}
                            onClick={() => {
                                props.expressClick(imgData);
                            }}
                            onError={imageLoadHandler}
                        />
                    </div>
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    const replyAudioMessage = (text) => {
        const { flow, idClient } = props;
        const { fromNick, fromYachNick } = data;
        let audioLength = computedAudioLength(data.file.dur / 1000) + 'px';
        return (
            <div className={`${css.replyMessage} ${getReplyBgColor()}`}>
                <pre className={css.replyItem}>
                    <p className={css.fromNick}>
                        {util.yach.decodeUnicode(`${fromNick}${fromYachNick ? '(' + fromYachNick + ')' : ''}`)}
                    </p>
                    {/* [语音] */}
                    <VoiceRead
                        flow={flow}
                        audioLength={audioLength}
                        audioText={data.audioText}
                        audioUrl={data.file.mp3Url}
                        idClient={idClient}
                        replyMsg={data}
                        audioDur={data.file.dur / 1000}
                    />
                </pre>
                <pre className={css.replySendText}>{text}</pre>
                {getWidget()}
            </div>
        );
    };

    const multipleForwarding = (content) => {
        return (
            <div className={css.multipleForwarding} onClick={() => props.goHistoricalRecord(data)}>
                <p className={css.forwardingName}>{data.name}</p>
                <pre className={css.forwardingItem}>
                    {content &&
                        content.map((item,index) => (
                            <div key={index}>
                                <p>
                                    {item.fromNick}：{ item.customType == 38 ? `[${util.locale('im_auto_reply')}]` : ''}{item.text}{' '} {/*// 私聊 -> 个人状态 -> 自动回复  转发自动回复*/}
                                </p>
                            </div>
                        ))}
                </pre>
                {showEmots && <ReplyEmots {...props} />}
            </div>
        );
    };
    const filterText = (text) => {
        text = util.yach.textFiltering(text);
        // text = util.yach.urlFiltering(text);
        text = util.yach.convertExpression(text, '34px', '34px');
        return <span style={{ display: 'inline' }} dangerouslySetInnerHTML={{ __html: text }} />;
    };
    const replaceText = (text) => {
        let { messageExtraData, custom, flow, isTeam } = props;
        if (isTeam && custom) {
            messageExtraData = messageExtraData || {};
            const atCallback = messageExtraData['at_callback'] || {};
            const readFlag = flow == 'out';
            text = props.atHighlighted({ text, customContent: custom, readers: atCallback, readFlag });
        } else {
            text = filterText(text);
        }
        return text;
    };

    const getReplyOffice = () => {
        let Message = '';
        const { text } = props;
        if (data.content) {
            try {
                const customData = JSON.parse(data.content);
                if (customData.type == 5) {
                    Message = replyOfficeMessage(util.locale('im_files'), replaceText(text), customData.data);
                } else if (customData.type == 16) {
                    Message = replyOfficeMessage(
                        util.locale('im_online_documents'),
                        replaceText(text),
                        customData.data
                    );
                } else {
                    Message = replyTextMessage(replaceText(text), replaceText(data.text));
                }
            } catch (error) {
                console.log(error);
                Message = noData();
            }
        } else {
            Message = replyTextMessage(replaceText(text), replaceText(data.text));
        }
        return Message;
    };

    // imgMessage
    const imgMessage = () => {
        let fileBg = '',
            flowBg = '';
        fileBg = css.imgMessage;
        if (props.flow == 'in' && showEmots) {
            flowBg = css.inBg;
        } else if (props.flow == 'out' && showEmots) {
            flowBg = css.outBg;
        }
        let imgSize = props.getImgScale(data.height, data.width),
            a_box;
        const imgStyle = {
            width: `${imgSize.width}px`,
            height: `${imgSize.height <= 60 ? 60 : imgSize.height}px`,
            position: 'relative',
            top: `0px`,
            left: `-${(imgSize.width - 324) / 2}px`,
            borderRadius: '10px',
        };
        const normalImgStyle = {
            width: imgSize.width ? `${imgSize.width}px` : '200px',
            height: imgSize.height ? `${imgSize.height}px` : '100%',
            borderRadius: '10px',
        };
        switch (imgSize.typeNum) {
            case 1:
                a_box = css.a_box_wh;
                break;
            case 2:
                a_box = css.a_box_hw;
                break;
            default:
                a_box = '';
                break;
        }
        return (
            <div className={`${fileBg} ${flowBg} ${css.imgMessage}`}>
                {
                    props.imageDisabled ? 
                    (
                        <a
                            onClick={() => props.showImg(data.fileOriginUrl, props)}
                            className={a_box}
                        >
                            <img
                                id={props.idClient + 'img'}
                                // className={imgType}
                                style={imgSize.typeNum === 2 ? imgStyle : normalImgStyle}
                                src={props.getMsgImg(data.fileThumbnailUrl || data.fileOriginUrl)}
                                // onError={(e) => props.imgError(data.fileThumbnailUrl || data.fileOriginUrl)}
                                onContextMenu={(e) => e.preventDefault()}
                            />
                        </a>
                    ):(
                        <div className={css.defImg}>
                            <img
                                style={{
                                    width: '49px',
                                    height: '43px',
                                }}
                                src={defImg}
                                onContextMenu={(e) => e.preventDefault()}
                            />
                            <span className="icon iconfont iconshuaxin3" onClick={() => props.refreshImg()} />
                        </div>
                    )
                }

                {showEmots && <ReplyEmots {...props} />}
            </div>
        );
    };

    const redEnvelope = () => {
        return (
            <div className={css.redEnvelope}>
                <div className={css.content}>
                    <img src={pakageImg} />
                    <span>{data.title}</span>
                </div>
                <div className={css.bottomText}>{util.locale('im_please_check_red_bag_message_in_mobile')}</div>{' '}
                {/**请在手机版知音楼查看红包消息 */}
            </div>
        );
    };

    const onlineDocumentation = () => {
        const documentIcon = data.type;
        return (
            <div className={css.onlineDocumentationWrap}>
                <div className={css.onlineDocumentation} onClick={() => props.goDocument(data)}>
                    <div className={css.fileContent}>
                        <div className={css.fileInfo}>
                            <span className={css.fileName}>{data.title}</span>
                            <span className={css.fileSize}>
                                {util.locale('im_online_documents')} {/** 在线文档*/}
                            </span>
                        </div>
                        {documentIcon == 'newdoc' && <img className={css.iconImg} src={wordImg} />}
                        {documentIcon == 'mosheet' && <img className={css.iconImg} src={excelImg} />}
                        {documentIcon == 'form' && <img className={css.iconImg} src={formsImg} />}
                        {documentIcon == 'mindmap' && <img className={css.iconImg} src={mindMapImg} />}
                        {documentIcon == 'slide' && <img className={css.iconImg} src={pptImg} />}
                        {documentIcon == 'board' && <img className={css.iconImg} src={whiteBoardImg} />}  
                    </div>
                </div>
                {showEmots && <ReplyEmots {...props} />}
            </div>
        );
    };

    const meeting = (data) => {
        let isFinish = false;
        if (props.msg && props.msg.localCustom && props.msg.localCustom.isFinish) isFinish = true;
        const { real_from, tags = [] } = data;
        let schedule = false;
        if (real_from == 3 || real_from == 5) {
            // 来自日程 real_from==5||real_from==3
            schedule = real_from == 3 || real_from == 5;
        }

        return (
            <div className={`${css.meeting} ${schedule ? css.scheduleMetting : ''}`}>
                <div className={isFinish || props.meetingFinish ? css.finishContent : css.content}>
                    <p>{data.title}</p>
                    <div>
                        <span className={'iconfont-yach yach-pcduanjinruhuiyishikapian-zuocetubiao'} />
                        <span className={css.time}>
                            {util.locale('im_stat_time')}：
                            {util.formatDate.timetampFormat(`${data.zoomStartTime}`.padEnd(13, 0))} {/** 开始时间*/}
                        </span>
                    </div>
                </div>
                <div className={css.footer}>
                    {isFinish || props.meetingFinish ? (
                        <span className={css.inFinish}>
                            {util.locale('im_over')}
                            {/** 已结束*/}
                        </span>
                    ) : (
                        <span
                            onClick={() =>
                                props.showVideoSessione({
                                    schedule,
                                    daily_meeting: tags[0] && tags[0].text,
                                    title: data.title,
                                })
                            }
                            className={css.in}
                        >
                            {util.locale('im_join_meeting')}
                            {/** 加入会议*/}
                        </span>
                    )}
                </div>
            </div>
        );
    };

    const getReplyText = () => {
        let Message = '';
        let { text } = props;
        if (data.type == 'custom') {
            return customTypeMesaage();
        } else if (data.type == 'text') {
            // 149版本: 1. 回复消息中的带链接地址时 支持识别    2. 回复原消息去掉回复二字
            Message = replyTextMessage(replaceText(text), filterText(data.text), true);
        } else if (data.type == 'file') {
            Message = replyFileMessage(util.locale('im_files'), replaceText(text)); // 文件
        } else if (data.type == 'video') {
            const { file } = data;
            if (file && file.coverUrl) {
                Message = replyVideoFileMessage(util.locale('im_video'), replaceText(text));
            } else {
                if (['mp4', 'ogg', 'webm', 'mov'].includes(`${file.ext || ''}`.toLowerCase())) {
                    Message = replyVideoFileMessage(util.locale('im_video'), replaceText(text)); // 视频
                } else {
                    Message = replyFileMessage(util.locale('im_files'), replaceText(text)); // 文件
                }
            }
        } else if (data.type == 'image') {
            Message = replyImageMessageOld(replaceText(text));
        } else if (data.type == 'audio') {
            Message = replyAudioMessage(replaceText(text));
        } else {
            Message = noData();
        }
        return Message;
    };

    const customTypeMesaage = () => {
        const { text } = props;
        let Message = null,
            customContent = {};
        try {
            if (data && data.content) customContent = util.nimUtil.getJson(data.content) || {};
            const isLinkMsg = customContent.type == 23 || customContent.type == 24;
            if (customContent.type == 8) {
                Message = replyImageMessage(replaceText(text), customContent.data);
            } else if (customContent.type == 10) {
                Message = replyCustomerFileMessage(util.locale('im_files'), replaceText(text), customContent); // 文件
            } else if (customContent.type == 26) {
                Message = replyCustomerFileMessage(util.locale('im_folder'), replaceText(text), customContent);
            } else if (customContent.type == 25)
                Message = replyExpressionMessage(replaceText(text), customContent.data);
            else if (isLinkMsg) {
                Message = replyLinkMessage(replaceText(text), data, customContent);
            } else if (customContent.type == 15) {
                Message = replyMarkDownMessage(replaceText(text), data, customContent);
            } else if (customContent.type == 30) {
                let exts = customContent.data.ext || util.videoUtil.getFileExtendingName(customContent.data.fileUrl);
                if (customContent.data && customContent.data.coverUrl) {
                    //如果有首帧图，是新版本发的消息，可以按视频来展示
                    return replyVideoFileMessage(util.locale('im_video'), replaceText(text), customContent);
                }
                if (['mp4', 'ogg', 'webm', 'mov'].includes(`${exts || ''}`.toLowerCase()))
                    return replyVideoFileMessage(util.locale('im_video'), replaceText(text), customContent); // 视频
                return replyFileMessageVideo(util.locale('im_files'), replaceText(text)); // 文件
            } else if (customContent.type == 31) {
                Message = replyPositioningMessage(replaceText(text));
            } else if (customContent.type == 32) {
                Message = replyTextMessage(replaceText(text), customContent.data.title, `[${util.locale('im_vote')}] `);
            } else if (customContent.type == 38) {// 私聊 -> 个人状态 -> 自动回复 
                try {
                    const replyText = `[${util.locale('im_auto_reply')}]${customContent.data.content.reply_content}`
                    Message = replyTextMessage(replaceText(text), replyText);
                } catch (error) {
                    console.error('回复[自动回复]消息异常：', error)
                }
                
            } else {
                Message = getReplyOffice();
            }
        } catch (error) {
            console.log('customTypeMesaage', error);
        }
        return Message;
    };

    const markdown = (d = data) => {
        return (
            <MarkdownMsg
                title={d.title}
                image={d.image}
                content={d.content}
                buttons={d.buttons}
                cardUrl={d.clickUrl}
                showEmots={showEmots}
                props={props}
                fType={d.fType}
            />
        );
    };
       

    const callState = () => {
        let whereMessage, msg, clickText;
        let { answer_status, total_call_time, ext_status = '' } = data;
        answer_status = ext_status ? ext_status : answer_status;
        const { flow, isSelf, startCall } = props;

        if (flow == 'out') {
            whereMessage = css.outCallState;
        } else if (flow == 'in') {
            whereMessage = css.inCallState;
        }

        const handleTimeout = () => {
            if (isSelf) {
                msg = util.locale('im_other_no_response'); // 已取消
                clickText = util.locale('im_click_redial'); // 点击重拨
                return;
            }
            msg = util.locale('im_not_answer'); // 未接通
            clickText = util.locale('im_click_back'); // 点击回拨
        };

        const handleCancel = () => {
            if (isSelf) {
                msg = util.locale('im_cancelled'); // 已取消
                clickText = util.locale('im_click_redial'); // 点击重拨
                return;
            }
            msg = util.locale('im_other_cancelled'); // 对方已取消
            clickText = ''; // 点击回拨
        };

        //refuse 拒接 accept 接受 timeout 超时 cancel 取消
        switch (answer_status) {
            case 'refuse':
                if (isSelf) {
                    msg = util.locale('im_other_refused'); // 对方已拒绝
                    clickText = util.locale('im_click_redial'); // 点击重拨
                    break;
                }
                msg = util.locale('im_rejected'); // 已拒绝
                clickText = util.locale('im_click_back'); // 点击回拨
                break;
            case 'accept':
                msg = `${util.locale('im_duration')} ${total_call_time}`; // 通话时长
                break;
            case 'timeout':
                handleTimeout();
                break;
            case 'cancel':
                handleCancel();
                break;
            case 'busy':
                if (isSelf) {
                    msg = util.locale('im_other_refused_busy'); // 忙线无应答
                    clickText = util.locale('im_click_redial'); // 点击重拨
                    break;
                }
                msg = util.locale('im_not_answer'); // 未接通
                clickText = util.locale('im_click_back'); // 点击回拨
                break;
        }
        return (
            <div className={css.callState}>
                <div className={`${whereMessage} ${css.isClick}`} onClick={() => startCall()}>
                    <span className="iconfont-yach yach-pcduanyuyintonghuaxiaoxi-huihuaqipaoicon"></span>
                    <span className={css.msg}>{msg}</span>
                    <span className={css.clickText}>{clickText}</span>
                </div>
            </div>
        );
    };

    // 中间号消息
    const callStates = () => {
        let whereMessage, msg, clickText;
        let { answer_status, total_call_time } = data;
        const { startCall } = props;

        if (props.flow == 'out') {
            whereMessage = css.outCallState;
        } else if (props.flow == 'in') {
            whereMessage = css.inCallState;
        }

        const handleTimeout = () => {
            msg = util.locale('im_not_answers'); // 呼叫未接通
            if (props.isSelf) {
                clickText = util.locale('im_click_redial'); // 点击重拨
                return;
            }
            clickText = util.locale('im_click_back'); // 点击回拨
        };

        //accept 接受 timeout 超时
        switch (answer_status) {
            case 'accept':
                msg = `${util.locale('im_duration')} ${total_call_time}`; // 通话时长
                break;
            case 'timeout':
                handleTimeout();
                break;
        }
        return (
            <div className={css.callState}>
                <div className={`${whereMessage} ${css.isClick}`} onClick={() => startCall()}>
                    <span className="iconfont-yach yach-pcduanyuyintonghuaxiaoxi-huihuaqipaoicon"></span>
                    <span className={css.msg}>{msg}</span>
                    <span className={css.clickText}>{clickText}</span>
                </div>
            </div>
        );
    };

    const expression = () => {
        const { imageLoadHandler } = props;
        // const expressionBase = util.yach.base64ImgGetTmp(data.expressionUrl || '');
        let fileBg = css.expression,
            flowBg = '';
        if (props.flow == 'in' && showEmots) {
            flowBg = css.inBg;
        } else if (props.flow == 'out' && showEmots) {
            flowBg = css.outBg;
        }
        return (
            <div className={`${fileBg} ${flowBg} ${data.isClick === '1' ? css.expressionCursor : ''}`}>
                <div>
                    <img
                        src={data.expressionUrl}
                        onClick={() => {
                            props.expressClick(data);
                        }}
                        onError={imageLoadHandler}
                    />
                </div>
                {showEmots && <ReplyEmots {...props} />}
            </div>
        );
    };

    const meetingSummary = (data) => {
        const title = data.title || '日程';
        const timeStr = data.time || '';
        return (
            <div className={css.meetingSummaryWrap}>
                <p className={css.meetingSummaryTitle}>{util.locale('calendar_create_meeting_summary')}</p>
                <p className={css.scheduleTitle}>{title}</p>
                <p className={css.scheduleTime}>
                    <span className="iconfont-yach yach-jiyaokapian-shijian"></span>
                    <span>{timeStr}</span>
                </p>
                <p className={css.cutoffLine}></p>
                <p className={css.editBtn}>
                    <span onClick={props.editMeetingSummary.bind(null, data)}>
                        {util.locale('calendar_create_edit_meeting_summary1')}
                    </span>
                </p>
            </div>
        );
    };

    const editDocIcon = {
        folder: 'folder',
        sheets: 'mosheet',
        docs: 'newdoc',
        slides: 'slide',
        mindmaps: 'mindmap',
        forms: 'form',
        boards: 'board',
    };

    const editDocmentNotification = (info) => {
        let getIconFromLink = info.link.split('/')[3];
        const documentIcon = info.type || editDocIcon[getIconFromLink];

        return (
            <div className={css.onlineDocumentReply} onClick={() => props.goDocument(info)}>
                <div className={css.fileContent}>
                    <div className={css.fileInfo}>
                        <span className={css.fileName}>{info.title}</span>
                        <span className={css.fileSize}>
                            {util.locale('im_online_documents')} {/** 在线文档*/}
                        </span>
                    </div>
                    {documentIcon == 'newdoc' && <img className={css.iconImg} src={wordImg} />}
                    {documentIcon == 'mosheet' && <img className={css.iconImg} src={excelImg} />}
                    {documentIcon == 'form' && <img className={css.iconImg} src={formsImg} />}
                    {documentIcon == 'mindmap' && <img className={css.iconImg} src={mindMapImg} />}
                    {documentIcon == 'slide' && <img className={css.iconImg} src={pptImg} />}
                    {documentIcon == 'board' && <img className={css.iconImg} src={whiteBoardImg} />}
                </div>
                <div className={css.editDocmentDes}>
                    <span>{util.locale('im_edit_docment')}</span>
                </div>
            </div>
        );
    };

    const positioningMessage = () => {
        let flowBg = '';
        if (showEmots) {
            if (props.flow == 'in') {
                flowBg = css.inBg;
            } else if (props.flow == 'out') {
                flowBg = css.outBg;
            }
        }
        const { name, imageUrl, address, shareUrl } = data;
        return (
            <div className={`${css.positioningMessage} ${flowBg}`}>
                <div className={css.content}>
                    <div className={css.header}>
                        <p>{name}</p>
                        <span>{address}</span>
                    </div>
                    <div className={css.footer} onClick={() => props.goPositioning(shareUrl)}>
                        <img
                            src={imageUrl}
                            onError={(e) => {
                                e.target.style.display = 'none';
                            }}
                        />
                    </div>
                </div>
                {showEmots && <ReplyEmots {...props} />}
            </div>
        );
    };

    try {
        switch (type) {// 字段值说明：https://wiki.zhiyinlou.com/pages/viewpage.action?pageId=22899565
            case 2:
                Message = record();
                break;
            case 3:
                Message = notice();
                break;
            case 4:
                Message = focusReview();
                break;
            case 5:
                Message = fileMessage();
                break;
            case 6:
                Message = getReplyText();
                break;
            case 7:
                Message = multipleForwarding(data.content);
                break;
            case 8:
                Message = imgMessage();
                break;
            case 10:
                Message = customerMessage(10);
                break;
            case 12:
                Message = redEnvelope();
                break;
            case 14:
                Message = meeting(data);
                break;
            case 15:
                Message = markdown();
                break;
            case 16:
                Message = onlineDocumentation();
                break;
            case 19:
                Message = callState();
                break;
            case 23:
                const { target, idClient, time, flow, emots, clickEmot } = props;
                // 链接识别卡片类型
                Message = (
                    <LinkMsg key={props.idClient} flow={flow} className={css.linkMsg} customData={data}>
                        {showEmots && <ReplyEmots {...{ target, idClient, time, flow, emots, clickEmot }} />}
                    </LinkMsg>
                );
                break;
            case 24:
                Message = (
                    <LinkMessage className={css.linkMsg} customData={data}>
                        {showEmots && <ReplyEmots {...props} />}
                    </LinkMessage>
                );
                break;
            case 26:
                Message = customerMessage(26);
                break;
            case 25:
                Message = expression();
                break;
            case 27:
                Message = editDocmentNotification(data);
                break;
            case 28:
                Message = meetingSummary(data);
                break;
            case 30:
                Message = customerMessage(30);
                break;
            case 31:
                Message = positioningMessage();
                break;
            case 3004:
                Message = schedule();
                break;
            case 32:
                const voteMsgProps = {
                    target: props.target,
                    idClient: props.idClient,
                    time: props.time,
                    emots: props.emots,
                    clickEmot: props.clickEmot,
                };
                // 链接识别卡片类型
                Message = (
                    <VoteMsg sessionId={props.target} idClient={props.idClient} customData={data}>
                        {showEmots && <ReplyEmots {...voteMsgProps} />}
                    </VoteMsg>
                );
                break;
            case 35:
                Message = callStates();
                break;
            case 38:// 私聊 -> 个人状态 -> 自动回复 => https://wiki.zhiyinlou.com/pages/viewpage.action?pageId=22899565
                Message = p2pAutoReplyMessage();
                break;
            default:
                Message = noData();
                break;
        }
    } catch (error) {
        Message = noData();
        console.log('boxContentMessageCustom', error);
    }

    return Message;
};
