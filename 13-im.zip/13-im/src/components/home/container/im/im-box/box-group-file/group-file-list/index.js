// react
import React from 'react';
import {connect} from 'react-redux';

// service
import { folderPreviewList } from '@s/folder/index';
import { fileGroupSpaceList,fileAndFolderDelete } from '@s/group/group-file';

// util
import * as util from '@u/util.js';

import { message, Checkbox, Tooltip } from 'antd';

// component
import FileList from '../common/file-list/container';
import FileBreadcrum from '../common/file-breadcrum';
import GroupFileInput from '../group-file-input';
import CommonModal from '@/components/common/common-modal';

import debounce from 'lodash/debounce';
import { setGroupFileLastBreadcrumb } from '@r/actions/groupFile';

import css from './index.scss';

const maxRetry=100
const thisFolderName = util.locale('im_group_file_checked_all_download')
   
// 历史文件页面
class Index extends React.Component {
    state = {
        noData: '',
        fileList: [],
        hasMore: false,
        currentPage: 0,
        loading: false,
        delLoading: false,
        breadcrumbList:[],

        checkedId:[],
        newFolder: false,
        canHandleDel: true,
        modalVisible: false
    };
    retry=true;
    retryNum=0;

    componentDidMount() {
        const {getFileParams}=this.props;
        if(getFileParams) {
            this.getFileList(getFileParams);
        }else{
            this.searchFileList();
        }

        util.eventBus.addListener('group-file-create-input-show', (flag) => {
            this.setState({
                newFolder: flag
            })
        });
        util.eventBus.addListener('group-file-list-refresh', () => {
            const len = this.state.breadcrumbList.length
            this.handleAnyFolder(len?len-1:0)
        });
        util.eventBus.addListener('group-file-list-return-all', () => {
            const len = this.state.breadcrumbList.length
            this.handleAnyFolder(-1)
        });
        this.deleteAll = debounce(this.deleteAll,500);
        this.downloadAll = debounce(this.downloadAll,500);
    }

    componentWillUnmount(){
        this.retry=false;
        util.eventBus.removeListener('group-file-create-input-show');
        util.eventBus.removeListener('group-file-list-refresh');
        util.eventBus.removeListener('group-file-list-return-all');
    }

    // 查询接口
    searchFileList = async () => {
        this.setState({ loading: true });
        const { id, type } = window.session_active||{};
        const { currentPage, fileList } = this.state;
        let formData = {
            group_tid: id,
            page: currentPage + 1,
            size: 20,
            query_str: '',
        };

        const datas = await fileGroupSpaceList(formData);
        const { code, obj:{data} } = datas || {};
        let resArr = [];
        if(code==170001) {
            message.warn(this.locale('im_group_folder_delete'));
            this.handleAnyFolder(0);
            return;
        }
        if (code === 200) {
            resArr = util.cosfiles.fileDownloadStatusGetArr(data);
        }
        const arr = [...fileList, ...resArr];
        this.setState({
            breadcrumbList:[],
            fileList: arr,
            currentPage: currentPage + 1,
            loading: false,
            hasMore: resArr.length === 20,
            noData: arr.length? '': 'no_file',
        },()=>{
            this.props.dispatch(setGroupFileLastBreadcrumb({}))
        });
    };

    // 文件夹列表
    getFileList = async ({relation_id}) => {
        this.retryNum++;
        this.setState({ loading: true });
        const {  currentPage, fileList } = this.state;
        let formData = {
            relation_id,
            page: currentPage + 1,
            size: 20,
            source:2,
        };

        const datas = await folderPreviewList(formData);
        const { code, obj:{shouldTry,list=[],navigation=[]} } = datas || {};
        if(code==170001) {
            message.warn(this.locale('im_group_folder_delete'));
            this.handleAnyFolder(0);
            return;
        }
        util.log('lichao','group_file','list_file_load_retry',shouldTry,this.retry,this.retryNum,maxRetry);
        if (code != 200) return;
        if(shouldTry&&this.retry&&this.retryNum<maxRetry){
            // 请求重试
            setTimeout(()=>{  
                this.getFileList(formData);
            }, 1000);
            return;
        }
        const resArr=util.cosfiles.fileDownloadStatusGetArr(list);
        
        const arr = [...fileList, ...resArr];
        this.setState({
            fileList: arr,
            currentPage: currentPage + 1,
            loading: false,
            hasMore: resArr.length === 20,
            noData: arr.length ? '': 'no_file',
            breadcrumbList:navigation
        },() => {
            const breadcrumbObj = this.state.breadcrumbList[this.state.breadcrumbList.length-1] || {}
            this.props.dispatch(setGroupFileLastBreadcrumb(breadcrumbObj))
        });
    };

    // 滚动加载
    handleLoadMore=()=>{
        // 根目录用search接口
        const {breadcrumbList}=this.state;
        const {relation_id}=breadcrumbList[breadcrumbList.length-1]||{};
        relation_id?this.getFileList({relation_id}):this.searchFileList()
    }
    
    // 下一级
    handleNextFolder= (item)=>{
        const {relation_id}=item;
        this.setState(pre=>({
            noData: '',
            fileList: [],
            hasMore: false,
            currentPage: 0,
            loading: false,
            checkedId:[]
        }),()=>{
            this.getFileList({relation_id});
        })
    }
    
    // 上一级
    handlePreFolder= ()=>{
        let {breadcrumbList}=this.state;
        const {relation_id}=breadcrumbList[breadcrumbList.length-1-1]||{};
        this.setState({
            noData: '',
            fileList: [],
            hasMore: false,
            currentPage: 0,
            loading: false,
            checkedId:[]
        },()=>{
            relation_id?this.getFileList({relation_id}):this.searchFileList()
        })
    }

    // 去到某一级
    handleAnyFolder= (index)=>{
        const {breadcrumbList}=this.state;
        const {relation_id}=breadcrumbList[index]||{};
        this.setState({
            noData: '',
            fileList: [],
            hasMore: false,
            currentPage: 0,
            loading: false,
            checkedId:[]
        },()=>{
            relation_id?this.getFileList({relation_id}):this.searchFileList()
        })
    }

    // 重置msg状态
    resetLocalMsgState = ({relation_id, path}) => {
        const fileList = this.state.fileList.map((item) => {
            if (item.relation_id == relation_id) item.downloadPath = path;
            return item;
        });
        this.setState({
            fileList,
        });
        
        util.cosfiles.fileDownloadStatusUpdate({path,key:relation_id});
    };

    onCheckAllChange=(e)=>{
        this.setState({
            checkedId:e.target.checked?this.state.fileList.map(item=>item.relation_id):[]
        },()=>{
            this.setCanHandleDel()
        })
    }
    handleCheckboxChange=(value)=>{
        this.setState({
            checkedId:value
        },()=>{
            this.setCanHandleDel()
        })
    }

    // 取消部分选中状态
    handleCancelChecked=(arr)=>{
        this.setState(pre=>{
            const {checkedId}=pre;
            return {
                checkedId:checkedId.filter(item=>!checkedId.includes(item))
            }
        },()=>{
            this.setCanHandleDel()
        })
    }
    setCanHandleDel = () =>{
        if(this.props.ismanager) {
            return this.setState({
                canHandleDel: true
            })
        }
        this.setState({
            canHandleDel: !this.state.checkedId.some(value => {
                const itemValue = this.state.fileList.find(item => item.relation_id == value)
                return !!itemValue && !!itemValue.userInfo && itemValue.userInfo.id != util.yach.getAccount()
            })
        })
    }
    downloadAll = () =>{
        const tempArr = []
        this.state.checkedId.forEach(value => {
            const itemValue = this.state.fileList.find(item => item.relation_id == value)
            tempArr.push(itemValue)
        })
        util.electronipc.electronFileSaveDialog({
            apicaller: 'main',
            options: {
                title: util.locale('im_saveas'),
                showsTagField: false,
                defaultPath: thisFolderName,
                filters: [{ name: 'Custom File Type', extensions: [''] }]
            },
            callback: (pathRes)=>{
                if(!pathRes) return
                const thisPath = this.handlePath(pathRes)
                for (const downloadItem of tempArr) {
                    util.cosfiles.fileDownload({
                        path: this.getPath(thisPath,downloadItem.fileName),
                        idClient: downloadItem.relation_id,
                        relationId: downloadItem.relation_id,
                        url: downloadItem.fileUrl,
                        name: downloadItem.fileName,
                        stype: downloadItem.is_dir ==1 ? 26:10,
                        from:'slide',
                        resBack:(path)=>{
                            this.resetLocalMsgState({
                                path,
                                isDownloadFlag: true,
                                msgId: downloadItem.msgId,
                                relation_id: downloadItem.relation_id,
                            }
                        )
                    }});
                }
                this.handleChecked()
            }
        })
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-248' });
    }
    handleChecked = () => {
        this.setState({
            checkedId: []
        })
    }
    handlePath = (path) => {
        // C:\Users\TAL\Desktop\表单预览\Yach_新建文件夹
        if(/\\/.test(path)) {
            const arr = path.split('\\')
            if(arr[arr.length-1] != thisFolderName){
                path += `\\${thisFolderName}`
            }
        }else if(/\//.test(path)){
            const arr = path.split('\/')
            if(arr[arr.length-1] != thisFolderName){
                path += `\/${thisFolderName}`
            }
        }
        return path
    }
    getPath = (path,fileName) => {
        if(/\\/.test(path)) {
            path += `\\${fileName}`
        }else if(/\//.test(path)){
            path += `\/${fileName}`
        }
        return path
    }
    deleteAll = () =>{
        this.setState({
            modalVisible: true
        })
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-249' });
    }
    setOKModal = async() => {
        this.setState({
            modalVisible: false,
            delLoading: true
        })
        try {
            let res = await fileAndFolderDelete({
                relation_id: this.state.checkedId.join(',')
            })
            if(res && res.code == 200){
                const len = this.state.breadcrumbList.length
                this.handleAnyFolder(len?len-1:0)
            }
            this.setState({
                delLoading: false
            })
        } catch (error) {
            this.setState({
                delLoading: false
            })
        }
    }
    setonCancelModal = () =>{
        this.setState({
            modalVisible: false
        })
    }

    // // 取消部分选中状态
    // handleCancelChecked=(arr)=>{
    //     this.setState(pre=>{
    //         const {checkedId}=pre;
    //         return {
    //             checkedId:checkedId.filter(item=>!checkedId.includes(item))
    //         }
    //     })
    // }
    getFileSpeed = speed => {
        if (speed > 1024 * 1024) {
            return (speed / 1024 / 1024).toFixed(1) + ' MB/S';
        } else if (speed > 1024) {
            return (speed / 1024).toFixed(1) + ' KB/S';
        } else {
            return (speed / 1024).toFixed(1) + ' KB/S';
        }
    }

    render(){
        const {noData,hasMore,loading,delLoading,fileList,breadcrumbList,checkedId, newFolder, canHandleDel, modalVisible} =this.state;
        const FileBreadcrumProps={
            breadcrumbList,
            handleAnyFolder:this.handleAnyFolder,
            handlePreFolder:this.handlePreFolder,
        }
        const FileListProps={
            type:'pageList',
            noData,
            fileList,
            hasMore,
            loading,
            delLoading,
            checkedId,
            handleLoadMore:this.handleLoadMore,
            closedDownLoad:this.closedDownLoad,
            handleNextFolder:this.handleNextFolder,
            resetLocalMsgState:this.resetLocalMsgState,
            handleCheckboxChange:this.handleCheckboxChange,
            handleCancelChecked:this.handleCancelChecked
        }
        return (
            <div className={css.box}>
                <FileBreadcrum {...FileBreadcrumProps}/>
                {
                    !!fileList.length&&<div className={css.btnRow}>
                        <div className={css.boxOut}>
                            <Checkbox
                                indeterminate={checkedId.length&&checkedId.length<fileList.length}
                                onChange={this.onCheckAllChange}
                                checked={checkedId.length&&checkedId.length===fileList.length}
                            >
                            </Checkbox>
                            <div>
                                {checkedId.length?checkedId.length+this.locale('im_group_file_checked_num'):this.locale('im_group_file_checked_all')}
                            </div>
                        </div>
                        {!!checkedId.length &&
                            <div className={css.btn}>
                                <span onClick={this.downloadAll} className={css.hoverSpan}>{util.locale('im_download')}</span>
                                {(this.props.ismanager || canHandleDel) && <span className={css.btnDel} onClick={this.deleteAll}>{util.locale('im_delete_msg')}</span>}
                                {(!this.props.ismanager && !canHandleDel) &&
                                    <Tooltip placement="top"
                                        title={util.locale('im_group_file_can_not_delete')}
                                    >
                                        <span className={css.btnGray}>{util.locale('im_delete_msg')}</span>
                                    </Tooltip>
                                }
                            </div>
                        }
                    </div>
                }
                {newFolder ?<GroupFileInput />:null}
                <FileList {...FileListProps} />
                <CommonModal
                    closable={true}
                    modalTile={util.locale('im_reminder')}
                    okText={util.locale('common_make_sure')}
                    cancelText={util.locale('common_cancel')}
                    modalVisible={modalVisible}
                    setOKModal={this.setOKModal}
                    setonCancelModal={this.setonCancelModal}
                    maskClosable={false}
                    modalContent={
                        <div>
                            <p>{util.locale('im_group_file_delete_confirm1')}</p>
                            <p className="confirm2">{util.locale('im_group_file_delete_confirm2')}</p>
                        </div>
                    }
                />
                
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        ismanager: state.groupAll.ismanager
    };
};

export default connect(
    mapStateToProps,
    null
)(Index);
