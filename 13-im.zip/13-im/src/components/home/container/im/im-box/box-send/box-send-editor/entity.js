import React from 'react'
import css from './index.scss'

import * as util from '@u/util.js';
// 图片实体
const ENTITYIMAGE = {
    type: 'image',

    mutability: 'IMMUTABLE',

    component: props => {
        let entity = props.contentState.getEntity(props.entityKey)
        let data = entity.getData()
        return (
            <span className={css.entityimg} data-entity="image"
                data-name={entity.data.name}
                data-path={entity.data.path}>
                <img src={util.imageDealer.encodeImgPath(data.path)} path={data.path} />
                {props.children}
            </span>
        )
    },

    importer: (nodeName, node, createEntity) => {
        return createEntity('image', 'IMMUTABLE', { 
            //imgurl: node.getAttribute('data-url'),
            path: node.getAttribute('data-path'),
            name: node.getAttribute('data-name')
        })
    },

    exporter: (entity, text) => {
        return (
            <span data-entity="image" className={css.entityimg} 
                data-name={entity.data.name}
                data-path={entity.data.path}>
                <img src={entity.data.path} />{text}
            </span>
        )
    }
}

// at人实体
const ENTITYAT = {
    type: 'at',

    mutability: 'IMMUTABLE',

    component: props => {
        let entity = props.contentState.getEntity(props.entityKey)
        let data = entity.getData()
        return <span className={css.entityat}>{props.children}</span>
    },

    importer: (nodeName, node, createEntity) => {
        return createEntity('at', 'IMMUTABLE', { id: node.getAttribute('data-id'), text: node.getAttribute('data-text') })
    },

    exporter: (entity, text) => {
        return (
            <span data-entity="at" data-id={entity.data.id} className={css.entityat} data-text = {entity.data.text}>
                {text}
            </span>
        )
    }
}

export default {
    ENTITYIMAGE,
    ENTITYAT,
    CUSTOMENTITIES: [ENTITYIMAGE, ENTITYAT]
}