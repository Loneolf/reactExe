// react
import React from 'react';

// Component
import TeamToolsContainer from './team-tools/team-tools-container';
import P2pToolsContainer from './p2p-tools/p2p-tools-container';
import AssistTools from './assist-tools/assist-tools-container';

// 
export default props => {
    const { 
        id,
        messageType,
        singleType,
        is_robot,
        isHiddenSessionType,
        showRightModal,
        teamType,
        groupDocGuide,
        meetingSummaryClick,
        searchHistoryGuide,
        closeGroupDocTips,
        closeGroupFileTips,
        closeSearchHistoryTips,
        showname,
        fullSign,
        newDeptName,
        position,
        showNickName,
        yachNick,
        groupFileGuide
    } = props;

    const teamProps = {
        teamType,
        groupDocGuide,
        meetingSummaryClick,
        showRightModal,
        searchHistoryGuide,
        closeGroupDocTips,
        closeGroupFileTips,
        closeSearchHistoryTips,
        groupFileGuide
    }

    const p2pProps = {
        showname,
        fullSign,
        newDeptName,
        position,
        searchHistoryGuide,
        showNickName,
        yachNick,
        showRightModal,
        closeSearchHistoryTips
    }

    const p2pFlag = messageType == 'p2p' && id && `${id}`.length>4 && singleType && singleType.identification != 'squad' && !is_robot;

    let rightModalParams;
    if(isHiddenSessionType && singleType.identification != 'squad') { // 日历助手、周报助手、官方团队等助手
        rightModalParams = {type: 'scheduleSetting', name: showname };
    } 
    if (singleType.identification == 'squad') { // 小组
        rightModalParams = {type: 'squad'};
    }
    if (is_robot) { // 机器人
        rightModalParams = {type: 'scheduleSetting', name: '聊天'};
    }

    return(
        <>
            {/* 群组工具栏 */}
            { messageType == 'team' && 
                <TeamToolsContainer {...teamProps} /> 
            }

            {/* p2p工具栏 */}
            { p2pFlag && 
                <P2pToolsContainer {...p2pProps} /> 
            }

            {/* 助手类工具栏 */}
            { rightModalParams && 
                <AssistTools 
                    showRightModal   = {showRightModal} 
                    rightModalParams = {rightModalParams} 
                /> 
            }
        </>
    )
}
