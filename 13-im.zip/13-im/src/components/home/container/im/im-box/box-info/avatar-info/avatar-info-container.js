// react
import React from 'react';

// util
import { showUserinfo } from '@/utils/yach';

// component
import AvatarInfo from './avatar-info';

// AvatarInfoContainer
export default class AvatarInfoContainer extends React.PureComponent {
    constructor(props) {
        super(props);
    }
    
    goUserInfo = (type, id, is_robot) => {
        if (type == 'p2p' && id && `${id}`.length > 4) {
            let options = { id:id };
            if (is_robot) {
                options.width   = 340;
                options.height  = 210;
            }

            showUserinfo(options);
        }
    }

    render() {
        const { id, messageType, singleType, showimg, is_robot } = this.props

        let showTeamImgFlag = messageType == 'team' || (id && `${id}`.length == 4) || (singleType && singleType.identification == 'squad')
        
        const avatarProps = {
            showimg, 
            showTeamImgFlag,
            goUserInfo: this.goUserInfo
        }

        let isUserSession = messageType != 'team' && id != 3002 && id != 3013 && !is_robot && singleType && singleType.identification != 'squad'
        
        let goUserInfoParams = []
        if(isUserSession) {
            goUserInfoParams = [messageType, id]
        } 
        if (is_robot) {
            goUserInfoParams = [messageType, id, is_robot]
        }
        
        return <AvatarInfo {...avatarProps} goUserInfoParams={goUserInfoParams} />
    }
}