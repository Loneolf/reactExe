// react
import React from 'react';
import { connect } from 'react-redux';

// util
import { locale, sensorsData, nim } from '@u/util.js';

// css
import { message } from 'antd';

// component
import P2pTools from './p2p-tools';

import { groupInfoCreate, groupInfoRepeat, groupInfoGetMore } from '@s/group/group-info.js';

// 
class P2pToolsContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userAddShow: false,
            loading: false,
            showModal: false,
            groupInfo: null,
            repeatData: null,
            repeatLoading: false
        }
    }

    //打开新建群
    openGroupCreate = () => {
        this.setState({
            userAddShow: true,
            loading: false
        });
        sensorsData.track('Click_Top_Plus');
        sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-178'});
    };

    //关闭新建群
    closeGroupCreate = () => {
        this.setState({
            userAddShow: false,
            loading: false,
            showModal: false,
            repeatLoading: false
        });
    };

    //新建群组
    groupCreate = async data => {
        this.setState({ loading: true });
        const { id } = window.session_active;
        data.allDataUsers = [...data.allDataUsers, { id: id }];
        let allDataUserIds = data.allDataUsers.map(v => v.id);

        // 判断是否已经存在群
        try {
            let checkResult = await this.checkRepeatGroup(allDataUserIds);
            this.setState({ repeatData: data });
            if (checkResult) return;
        } catch (error) {
            console.log(error);
            return;
        }

        this.noRepeatCreateGroup(data)
    };

    // 创建群组
    noRepeatCreateGroup = async (data, flag = false) => {
        if (flag) this.setState({ repeatLoading: true })
        let orgLength = data.orgs.reduce((prev, curr) => prev + +curr.userNum, 0);
        let allDataUserIds = data.allDataUsers.map(v => v.id);

        let tname = (data.inputValue.trim().length || orgLength) ? data.inputValue : ''
        let GroupInfoCreate = await groupInfoCreate({
            tname,
            members: JSON.stringify(allDataUserIds)
        });

        if (GroupInfoCreate.code == 200) {
            const { obj } = GroupInfoCreate;
            await nim.activeRow('team', obj.tid + '');
            message.success(`${locale('im_new_group_set_up')}`);
            this.setState({ loading: false, repeatLoading: false });
            this.closeGroupCreate()
        } else {
            message.error(GroupInfoCreate.msg);
            this.setState({ loading: false, repeatLoading: false });
        }
    }

    // 判断是否已经存在群
    checkRepeatGroup = async (allDataUserIds) => {
        const groupRepeat = await groupInfoRepeat({
            members: JSON.stringify(allDataUserIds)
        })
        const { obj, code, msg } = groupRepeat;
        if (code !== 200) message.error(msg)

        if (!obj || !obj.group_tid.length) return false

        // 从左侧会话通过群ID过滤出存在的群组
        const existGroup = this.props.sessionList.filter(item => obj.group_tid.some(x => item.id == x));

        // 从重复群组ID中，筛选出左侧会话不存在的群
        const noExistGroup = obj.group_tid.filter(item => !existGroup.some(x => item == x.id));

        // 查询重复群组中不存在左侧回话中的群的基本信息
        if (!noExistGroup.length) {
            this.dealRepeatGroup(existGroup, []);
            return true;
        }
        const groupBaseInfo = await groupInfoGetMore({ tids: noExistGroup.join() });
        if (groupBaseInfo.code === 200) {
            this.dealRepeatGroup(existGroup, groupBaseInfo.obj);
        } else {
            message.error(groupBaseInfo.msg);
        }
        return true;
    }

    dealRepeatGroup = (info, baseInfo = []) => {
        // info 会话列表（本地）存在的群,排序;
        const sortInfo = info.sort((a, b) => b.lasttime - a.lasttime);
        if (baseInfo.length) {
            baseInfo.forEach(item => {
                sortInfo.push({
                    id: item.group_tid,
                    showname: item.group_name,
                    showimg: item.group_icon,
                })
            })
        }
        
        this.setState({ loading: false, showModal: true, groupInfo: sortInfo });
    }

    render() {
        const chat_id = window.session_active.id;
        const { userInfo } = this.props;

        let disabledids = chat_id == userInfo.id ? [`${chat_id}`] : [`${chat_id}`, `${userInfo.id}`];

        const userAddProps = {
            type: 'creatGroup',
            loading: this.state.loading,
            show: this.state.userAddShow,
            onOk: this.groupCreate,
            onClose: this.closeGroupCreate,
            disabledids: disabledids,
            input: locale("im_group_name"),
            title: locale("im_start_group_chat"),
            leftTitle: locale("im_group_member"),
            rightTitle: locale("im_choose_group_member"),
            maxLength: 2000
        };

        const showModalProps = {
            showModal: this.state.showModal,
            groupInfo: this.state.groupInfo,
            repeatData: this.state.repeatData,
            repeatLoading: this.state.repeatLoading,
            noRepeatCreateGroup: this.noRepeatCreateGroup,
            closeGroupCreate: this.closeGroupCreate,
        }

        return(
            <P2pTools 
                openGroupCreate = {this.openGroupCreate}
                userAddProps    = {userAddProps}
                showModalProps  = {showModalProps}
                {...this.props} 
            />
        )
    }
}
const mapStateToProps = state => ({
    userInfo: state.userInfo,
    sessionList: state.sessionList
});

export default connect(mapStateToProps)(P2pToolsContainer);