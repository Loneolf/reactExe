import React, { Component } from 'react';
import { message, Tooltip } from 'antd';
import * as _ from 'lodash';
import copy from 'copy-to-clipboard';
import * as util from '@u/util.js';

import { normalizeUrl, status } from '@u/nim/container/link-msg-handler';

import style from './style.scss';

const defaultIcon =
    'https://yach-static.zhiyinlou.com/yach/person/202004/191979/ef259e292ea5bb175d3c1e4603db5dff15862711697129790/%E5%8D%A1%E7%89%87_%E9%93%BE%E6%8E%A5%403x.png';
class LinkMsg extends Component {
    constructor(props) {
        super(props);
        this.copy = this.copy.bind(this);
        this.openLink = this.openLink.bind(this);
    }
    shouldComponentUpdate(nextProps, nextState) {
        return (
            !_.isEqual(nextProps.className, this.props.className) ||
            !_.isEqual(nextProps.customData, this.props.customData) ||
            !_.isEqual(nextProps.children.props, this.props.children.props) ||
            !_.isEqual(nextProps.flow, this.props.flow)
        );
    }
    get isSelf() {
        const { flow } = this.props;
        return flow == 'out';
    }
    openLink() {
        if(window.getSelection().toString()) return
        const { customData } = this.props;
        window.open(normalizeUrl(customData.url), '_blank');
    }
    get isPlaceholder() {
        // 占位
        const { customData } = this.props;
        return customData.status == status.PLACEHOLDER;
    }
    get isParserNoContent() {
        // 识别失败状态
        const { customData } = this.props;
        return customData.status == status.FAIL;
    }
    get isCommonLink() {
        // 识别完没东西
        const { customData } = this.props;
        return (
            customData.status != status.FAIL &&
            customData.status != status.PLACEHOLDER &&
            !customData.title &&
            !customData.description &&
            !customData.imageurl
        );
    }
    copy() {
        const { customData } = this.props;
        copy(customData.url);
        message.success(`${util.locale('media_copy_success')}`);
    }
    addDefaultSrc(ev) {
        ev.target.src = defaultIcon;
    }
    get statusText() {
        if (this.isPlaceholder) {
            return util.locale('media_link_recognition');
        }
        if (this.isParserNoContent) {
            return util.locale('media_no_link');
        }
        return '';
    }
    get isSuccessed() {
        // 识别成功, 不管是不是默认值
        const { customData } = this.props;
        return (
            customData.status != status.FAIL &&
            customData.status != status.PLACEHOLDER &&
            customData.title &&
            customData.description &&
            customData.imageurl
        );
    }
    render() {
        const { className, children, customData } = this.props;
        return (
            <div className={` ${children ? style.hasEmoji : ''} ${this.isSelf ? style.isSelf : ''}`}>
                <div
                    className={`link-msg ${style['link-msg-container']} ${className} ${
                        this.isSuccessed ? style.full : ''
                    }`}
                >
                    <div className={style.innerCard}>
                        {this.isSuccessed && (
                            <React.Fragment>
                                <a onClick={this.openLink} className={style.parserContent}>
                                    <div className={style.title}>{customData.title}</div>
                                    <div className={style.body}>
                                        <div className={`${style.desc} ${style['truncate-overflow']}`}>
                                            {customData.description}
                                        </div>
                                        <div className={style.logo}>
                                            <img
                                                onError={this.addDefaultSrc}
                                                style={{ objectFit: 'cover', minWidth: '48px', minHeight: '48px' }}
                                                width="48"
                                                height="48"
                                                src={customData.imageurl}
                                                alt=""
                                            />
                                        </div>
                                    </div>
                                </a>
                                <div className={style.seperator}></div>
                            </React.Fragment>
                        )}
                        <div className={`${style.linkContainer} ${this.isPlaceholder ? style['skeleton-box'] : null} `}>
                            <div className={style.link}>
                                <a onClick={this.openLink}>{customData.url}</a>
                            </div>
                            <div onClick={this.copy} className={style.copy}>
                                <Tooltip placement="top" title={util.locale('media_copy_link')}>
                                    <span
                                        className={`iconfont-yach yach-lianjieshibiekapianfuzhi ${style.copyIcon}`}
                                    ></span>
                                </Tooltip>
                            </div>
                        </div>
                        {this.isSuccessed || this.isCommonLink ? null : (
                            <React.Fragment>
                                <div className={style.seperator}></div>
                                <div className={style.status}>{this.statusText}</div>
                            </React.Fragment>
                        )}
                    </div>
                    {children && <div className={style.others}>{children}</div>}
                </div>
            </div>
        );
    }
}

export default LinkMsg;
