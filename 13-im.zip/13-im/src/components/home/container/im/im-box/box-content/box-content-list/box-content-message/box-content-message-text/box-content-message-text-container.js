import React from 'react';
import { connect } from 'react-redux';
import BoxContentMessageText from './box-content-message-text';

export default class BoxContentMessageTextContainer extends React.Component {

    render() {
        return <BoxContentMessageText {...this.props}/>
    }
}