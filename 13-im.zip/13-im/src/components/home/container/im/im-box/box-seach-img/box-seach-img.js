// react
import React from 'react';

// css
import css from './index.scss';

// antd
import { Row, Col } from 'antd';

// util
import * as util from '@/utils/util';

export default class BoxSeachImg extends React.Component{
    constructor(props){
        super(props)
    }
    render(){

        return(
            // ref={el => {props.setFileBoxRef(el)}}
            <div className={css.box} >
                <p>{this.props.title}</p>
                <Row>
                   {this.props.data && this.props.data.length>0 &&
                       this.props.data.map((item) => {
                            const fileUrl=item.fileUrl;
                            return (
                                <Col key={item.relation_id} span={6}>
                                    <a onClick={()=>this.props.showImg(item.fileUrl,item)}>
                                        <div className={css.fileBox}>
                                            <img className={css.fileImg} onContextMenu={(e)=> e.preventDefault()} src={item.videoInfo ? item.videoInfo.videoPic : (fileUrl.toLocaleUpperCase().endsWith('.HEIC') ? `${fileUrl}?imageMogr2/quality/20` : fileUrl)} alt=""/>
                                            { item.fileState == 2 && 
                                                <>
                                                    <img className={css.videoPlay} src={require('@/assets/imgs/videoPlay.png')}></img>
                                                    <span className={css.videoLength}>{item.videoInfo && this.props.formatDuring(item.videoInfo.duration)}</span>
                                                </>
                                            }
                                        </div>
                                    </a>
                                </Col>
                           )
                       })
                   }
                </Row>
            </div>
        )
    }
}