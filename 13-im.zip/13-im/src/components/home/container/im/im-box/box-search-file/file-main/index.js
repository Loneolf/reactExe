// react
import React, { useState } from 'react';
// connect
import * as util from '@u/util.js';
import css from './index.scss';
import { Input } from 'antd';
import SearchPage from './search-page';
import ListPage from './list-page';

// ImBoxContainer
export default (props) => {
    const [searchState, setSearchState] = useState(false);
    const [showListPage, setshowListPage] = useState(true);

    const { getFileParams } = props;
    const SearchPageProps = {
        hanleGoList: () => setSearchState(false),
        setshowListPage
    };
    return (
        <div className={css.box}>
            <div className={css.inputContent}>
                <Input
                    placeholder={util.locale('im_file_uoliad_dir_search_place')}
                    onFocus={() => setSearchState(true)}
                    allowClear
                    value=""
                    prefix={<span className="icon iconfont iconsousuo" style={{ color: 'rgba(0,0,0,.25)' }} />}
                />
            </div>
            {searchState && <SearchPage {...SearchPageProps} />}
            {
                showListPage && <ListPage getFileParams={getFileParams} />
            }
        </div>
    );
};
