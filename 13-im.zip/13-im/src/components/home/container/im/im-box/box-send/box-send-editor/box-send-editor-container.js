import React from 'react'
import { connect } from 'react-redux'
import Draft from './box-send-editor'
import { message } from 'antd'
import { EditorState, ContentState, getDefaultKeyBinding, RichUtils } from 'draft-js'
import draftfn from './draftfn'
import customEntity from './entity'
import { clipboard, nativeImage } from 'electron'
import * as util from '@u/util.js'
import * as draftAction from '@r/actions/draft'
// import Worker from './draft.worker.js'

class DraftContainer extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            menuType: 'text',
            pasteData:'',
            loading: true,
            isPastedText:false
        }
        this.timer = null;
        this.maxLength = 20
    }

    componentDidMount() {
        this.initState()
        window.addEventListener('click', this.props.userAtClose)
        util.eventBus.addListener('editTip', (value) => this.editDeletMsg(value)); 
        // this.createWorker()
    }

    componentWillUnmount() {
        window.removeEventListener('click', this.props.userAtClose)
        util.eventBus.removeListener('editTip');
        clearTimeout(this.timer)
    }

    componentDidUpdate(prevProps) {
        // if(!this.props.breakPaste && prevProps.breakPaste && this.state.isPastedText) {
        //     let {pasteData} = this.state
        //     this.setState({pasteData:'',isPastedText:false})
        //     if(!this.props.turnImg){
        //         this.handlePastedText(this.parseExcelTurnText(pasteData.html,pasteData.text), pasteData.html, pasteData.editorState)
        //     }
        // }
        if (prevProps.disabled != this.props.disabled) {
            this.disableEditor()
        }
    }

    componentDidCatch() {
        // 实体选中替换中文崩溃，可catch报错或监听CompositionStart
        // https://github.com/facebook/draft-js/issues/1320
        this.forceUpdate()
    }

    createWorker = () => {
        this.worker = new Worker()
        this.worker.onmessage = e => {
            let data = e.data
            if (data && data.type == 'update') {
                this.props.dispatch(draftAction.draftEditorStateSet(data.data))
            }
        }
    }

    sendToWorker = (type, data) => {
        this.worker.postMessage({ type, data })
    }

    // 获取dom实例
    getDraftRef = ref => {
        this.draftref = ref
        draftfn.setInstance(ref)
    }

    editDeletMsg = (data) => {
        let deleteMsg = util.yachLocalStorage.ls('deleteMsg')
        let backData = deleteMsg[data.idClient]
        let draft = draftfn.transToHtml(this.props.draftEditorState)
        util.log('qinqinghao','13-im','box-send-editor-container/editDeletMsg:开始编译撤回消息',data.text,data.idClient)
        if(!backData) return this.initState(`${draft.substring(0,draft.length-4)}${data.text}</p>`)
        let showText = backData.text
        let custom  = util.nimUtil.getJson(backData.custom);
        if(custom && custom.atHighlighted && custom.atHighlighted.length){
            let AH = custom.atHighlighted
            let temShowText = showText.substring(0,AH[0].index)
            AH.forEach((item,index)=>{
                let temStr = `<span data-entity="at" data-id="${item.id}" data-text="${item.atName}">${item.atName} </span>` 
                temShowText += `${temStr}${showText.substring(item.endIndex, AH[index+1] ? AH[index+1].index : showText.length)}`
            }) 
            showText = temShowText
        }
        util.log('qinqinghao','13-im','box-send-editor-container/editDeletMsg:编译撤回消息成功',data.text,data.idClient)
        this.initState(`${draft.substring(0,draft.length-4)}${showText}</p>`)
    };

    // 初始化数据
    initState = (value) => {
        let decorator = draftfn.setDecorator(customEntity.CUSTOMENTITIES)
        // let saveId = this.props.userInfo.id + '-' + this.props.sessionActive.id
        let saveId = this.props.userInfo.id + '-' + window.session_active.id
        let defaultHtml = value || util.yach.getUserStorage('yach_draft_html')[saveId] || ''
        let editorState = null

        if (defaultHtml && defaultHtml != '<p></p>') {
            let contentState = draftfn.createContentFromHtml(defaultHtml)
            editorState = EditorState.createWithContent(contentState, decorator)
        } else {
            editorState = EditorState.createEmpty(decorator)
        }
        this.props.dispatch(draftAction.draftEditorStateSet(editorState))

        this.timer = setTimeout(() => {
            editorState = draftfn.setFocusEnd(editorState)
            this.props.dispatch(draftAction.draftEditorStateSet(editorState))
            this.setState({ loading: false })
        }, 300);
    }

    // 是否禁用编辑器
    disableEditor = () => {
        if (this.props.disabled) {
            draftfn.blurEditor()
        } else {
            draftfn.focusEditor()
        }
    }

    // 清空数据
    clearState = () => {
        this.props.dispatch(draftAction.draftEditorStateSet(EditorState.createEmpty()))
    }

    // 内容变化更新
    change = editorState => {
        // this.sendToWorker('update', editorState)
        // console.timeEnd('draft-click-change')
        // console.time('draft-change-dispatch')
        editorState = draftfn.checkEntitySelection(editorState, this.leftKeyDown, this.rightKeyDown)
        this.props.dispatch(draftAction.draftEditorStateSet(editorState))
        this.leftKeyDown = false
        this.rightKeyDown = false
        // console.timeEnd('draft-change-dispatch')
        // console.time('draft-dispatch-update')
    }

    // 检查超出最大值
    checkOutofLength = () => {
        let text = this.props.draftEditorState.getCurrentContent().getPlainText()
        return text.length >= this.maxLength
    }

    // 聚焦
    focusEditor = () => {
        this.draftref.focus()
    }

    handleDroppedFiles = e => {
        return 'handled'
    }

    // 处理点击事件
    handleClick = e => {
        this.focusEditor()

        let editorState = this.props.draftEditorState
        let selectionState = editorState.getSelection()
        let blockkey = selectionState.getFocusKey()
        let dom = document.querySelector(`[data-offset-key="${blockkey}-0-0"]`)
        if (dom && dom.querySelector('img')) {
            draftfn.showFocusSelection(this.props.draftEditorState)
        }
    }

    // 处理输入前事件
    handleBeforeInput = chars => {
        //if (this.checkOutofLength()) return 'handled'
    }

    handleCompositionStart = e => {}

    handleCompositonUpdate = e => {}

    handleComonCompositionEnd = e => {}

    // 处理默认按键事件
    handleKeyDown = e => {
        // console.log('draft-click -------------------- begin', e)
        // console.time('draft')
        // console.time('draft-click-change')
        if (e.keyCode == 37) {
            this.leftKeyDown = true
        }
        if (e.keyCode == 39) {
            this.rightKeyDown = true
        }
        if (e.keyCode == 37 || e.keyCode == 38 || e.keyCode == 39 || e.keyCode == 40) {
            this.props.userAtShow && e.preventDefault()
        }
        this.focusEditor()
    }

    // 绑定键盘事件
    keyBindingFn = e => {
        const keyCode = e.which || e.keyCode
        const ctrlKey = e.ctrlKey
        const metaKey = e.metaKey
        const shiftKey = e.shiftKey

        const ctrlenter = ctrlKey && keyCode == 13
        const shiftenter = shiftKey && keyCode === 13
        const metaenter = metaKey && keyCode == 13
        const metaz = metaKey && keyCode == 90
        const metav = metaKey && keyCode == 86
        const ctrlv = ctrlKey && keyCode == 86

        let isReverse = this.props.sendType == 'reverse'

        if (ctrlv || metav) {
            let type = this.getClipboardInfo().type
            if (type == 'file') return 'pastefile'
        }

        if (ctrlenter || shiftenter || metaenter) {
            if (this.props.userAtShow) return 'kong'
            return isReverse ? 'send-msg' : getDefaultKeyBinding(e)
        }

        if (keyCode == 13) {
            if (this.props.userAtShow) return 'kong'
            return isReverse ? getDefaultKeyBinding(e) : 'send-msg'
        }

        if (keyCode == 27) {
            return 'cancel'
        }

        if (keyCode == 46) {
            return 'delete'
        }

        if (keyCode == 33 || keyCode == 34) {
            return 'kong'
        }

        return getDefaultKeyBinding(e)
    }

    // 处理键盘事件
    handleKeyCommand = (command, editorState) => {
        const newState = RichUtils.handleKeyCommand(editorState, command)

        if (command == 'pastefile') {
            this.props.handlePaste()
            return 'handled'
        }

        if (command == 'send-msg') {
            this.sendMessage()
            return 'handled'
        }

        if (command == 'cancel') {
            this.props.userAtClose()
        }

        if (command == 'delete') {
            let removeImg = this.deleteImgFromBefore()
            if (removeImg) return 'handled'
        }

        if (command == 'kong') {
            return 'handled'
        }

        if (newState) {
            this.change(newState)
            return 'handled'
        }

        return 'not-handled'
    }

    // 删除光标后面的图片实体
    deleteImgFromBefore = () => {
        let editorState = this.props.draftEditorState
        let contentState = editorState.getCurrentContent()
        let selectionState = editorState.getSelection()
        let anchorKey = selectionState.anchorKey
        let anchorOffset = selectionState.anchorOffset
        let contentBlock = contentState.getBlockForKey(anchorKey)
        let entityKey = contentBlock.getEntityAt(anchorOffset + 1)

        if (!entityKey) return false
        let entity = contentState.getEntity(entityKey)

        if (entity.type == customEntity.ENTITYIMAGE.type) {
            let newSelection = { anchorOffset, focusOffset: anchorOffset + 2 }
            let newState = draftfn.removeRange(this.props.draftEditorState, newSelection)
            this.props.dispatch(draftAction.draftEditorStateSet(newState))
            return true
        }
    }

    // 处理粘贴事件
    handlePastedText = (text, html, editorState) => {
        if(text && text.length >2000) text = text.slice(0,1999);

        setTimeout(() => {
            draftfn.showFocusSelection(this.props.draftEditorState)
        }, 0)

        // if(this.props.breakPaste){
        //     this.setState({pasteData:{'text':text,'html':html,'editorState':editorState},isPastedText:true}) 
        //     return 'handled'
        // }
        
        let isDraftPaste = html && html.includes('data-offset-key=') && html.includes('data-text')

        if (isDraftPaste && html) {
            editorState = draftfn.removeRange(editorState)
            let entitydata = draftfn.getEntityData(editorState)
            let imgdata = entitydata.filter(v => v.type == 'image')
            let htmlimgs = html.split('<img').length - 1

            if (imgdata.length + htmlimgs > 10) {
                message.warn(util.locale("im_send_maximg"))
                return 'handled'
            }

            html = html.replace(/<html>/, '')
            html = html.replace(/<\/html>/, '')
            html = html.replace(/<body>/, '')
            html = html.replace(/<\/body>/, '')
            html = html.replace(/<meta[^>]*>/g, '')
            html = '<p>' + html + '</p>'

            let contentState = draftfn.createContentFromHtml(html)
            let blockMap = contentState.blockMap
            this.change(draftfn.addFragment(editorState, blockMap))
            return 'handled'
        }

        if (!isDraftPaste && text) {
            //editorState = draftfn.addText(editorState, text)
            //this.change(editorState)
            html = draftfn.textToHtml(text)
            let contentState = draftfn.createContentFromHtml(html)
            let blockMap = contentState.blockMap
            this.change(draftfn.addFragment(editorState, blockMap))
            return 'handled'
        }
    }

    // 发消息
    sendMessage = () => {
        if (this.props.userAtShow) return false
        this.props.sendImageAndMsgAll()
    }

    // 处理右键
    handleMenu = e => {
        let nodename = e.target.nodeName
        let type = 'text'
        if (nodename == 'IMG') {
            type = 'image'
        }
        this.setState({ menuType: type })
        this.menuImgSrc = e.target.src
        this.menuImgPath = e.target.getAttribute('path')
    }

    // 获取base64
    getBase64 = async url => {
        if (url.startsWith('data:image')) return url
        return await util.imageDealer.imageSrcToBase64(url)
    }

    // 右键复制
    handleCopy = async () => {
        if (this.state.menuType == 'image') {
            let img = nativeImage.createFromPath(this.menuImgPath)
            let size = img.getSize()

            if (size && size.width < 8888 && size.height < 8888) {
                // 写入图片
                clipboard.writeImage(img)
            } else {
                // 写入html
                clipboard.write({
                    text: 'image.png',
                    html: `<span data-offset-key=1 data-text=1 
                    data-entity="${customEntity.ENTITYIMAGE.type}" 
                    data-name="image.png"
                    data-path="${this.menuImgPath}">
                        <img src="${this.menuImgPath}" />
                    </span>`
                })
            }
            
            message.success(util.locale('im_copy_complete'))
            //let base64 = await this.getBase64(this.menuImgSrc)
            //base64 && util.electronipc.electronWriteImageToClipBoard(base64)
        }
        if (this.state.menuType == 'text') {
            setTimeout(() => {
                this.draftref.focus()
                document.execCommand('copy')
                window.getSelection().removeAllRanges()
            }, 0)
        }
    }

    // 右键粘贴
    handlePaste = () => {
        let type = this.getClipboardInfo().type
        this.draftref.focus()
        if (type == 'text') {
            document.execCommand('paste')
        }
        if (type == 'file') {
            this.props.handlePaste()
        }
    }

    // 剪切板数据分析(text自己处理，其它情况就往上层抛处理)
    getClipboardInfo = () => {
        let platform = util.electron.isMac() ? 'mac' : 'windows'
        let image = clipboard.readImage()
        let text = clipboard.readText()
        let isimage = !image.isEmpty()

        // windows - 有文本没图片，则一定是纯文本，自己处理
        if (platform == 'windows' && text && !isimage) {
            return { type: 'text' }
        }

        // mac - 有文本没图片，且不是本地文件，则是纯文本，自己处理
        if (platform == 'mac') {
            let filepath = clipboard.read('public.file-url')
            if (text && !isimage && !filepath) return { type: 'text' }
        }
        
        // 其他情况全往上抛
        return { type: 'file' }
    }

    // 右键保存
    handleSave = async () => {
        //let base64 = await this.getBase64(this.menuImgSrc)
        //base64 = base64.replace(/^data:image\/\w+;base64,/, "")

        //let buffer = Buffer.from(base64, 'base64')
        let originPath = this.menuImgPath
        let name = 'image.png'

        util.electronipc.electronFileWrite({ originPath, name}, res => {
            if (res.code == 0) {
                message.success(`${util.locale('im_file_download_completed')}${name}`)
            }
            if (res.code == -2) {
                message.error(res.errormsg)
            }
        })
    }

    consoleEntity = () => {
        console.log(draftfn.getEntityData(this.props.draftEditorState))
    }

    render() {
        const props = {
            disabled: this.props.disabled,
            menuType: this.state.menuType,
            loading: this.state.loading,
            getDraftRef: this.getDraftRef,
            editorState: this.props.draftEditorState,
            change: this.change,
            focusEditor: this.focusEditor,
            keyBindingFn: this.keyBindingFn,
            handleKeyDown: this.handleKeyDown,
            handleCompositionStart: this.handleCompositionStart,
            handleCompositonUpdate: this.handleCompositonUpdate,
            handleComonCompositionEnd: this.handleComonCompositionEnd,
            handleBeforeInput: this.handleBeforeInput,
            handleKeyCommand: this.handleKeyCommand,
            handlePastedText: this.handlePastedText,
            handleMenu: this.handleMenu,
            handleCopy: this.handleCopy,
            handlePaste: this.handlePaste,
            handleSave: this.handleSave,
            handleClick: this.handleClick,
            handleDroppedFiles: this.handleDroppedFiles,
            consoleEntity: this.consoleEntity,
        }
        return <Draft {...props} />
    }
}

const mapStateToProps = state => ({
    userInfo: state.userInfo,
    // sessionActive: state.sessionActive,
    draftEditorState: state.draftEditorState,
})

export default connect(mapStateToProps)(DraftContainer)