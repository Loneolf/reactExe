/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-02 16:58:26
 * @LastEditors: olei<wangzheng_jzb@100tal.com>
 * @LastEditTime: 2020-04-17 21:38:24
 */
import React, { PureComponent } from 'react';
import { connect } from 'react-redux';

import { ROBOTS_INUSE_FETCH, ROBOTS_STATE_INIT } from '@r/actiontype/robots';
import RobotsSettings from './robots-settings';
import { robotInfoCleanup } from '@r/actions/robots';

import style from './index.scss';
// 侧边栏容器
class RobotsSettingsContainer extends PureComponent {
    constructor(props) {
        super(props);
        props.initState();
    }
    componentDidMount() {
        this.props.initRobots();
    }
    componentWillUnmount() {
        this.props.robotInfoCleanup();
    }
    render() {
        return (
            <div className={style.robotsSettingsContainer}>
                <RobotsSettings></RobotsSettings>
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => ({});

const mapDispatchToProps = dispatch => {
    return {
        initRobots: () => dispatch({ type: ROBOTS_INUSE_FETCH }),
        initState: () => dispatch({ type: ROBOTS_STATE_INIT }),
        robotInfoCleanup: () => dispatch(robotInfoCleanup())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(RobotsSettingsContainer);
