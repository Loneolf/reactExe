// react
import React from 'react';
// css
import FileList from '../../common/file-list/container';
import FileBreadcrum from '../../common/file-breadcrum';
import { folderPreviewList } from '@s/folder/index';
import { fileGroupList } from '@s/file/file-list';
import css from './index.scss';
import * as util from '@u/util.js';
import {message} from 'antd';


const maxRetry=100
   
// 历史文件页面
export default class Index extends React.Component {

    state = {
        noData: '',
        fileList: [],
        hasMore: false,
        currentPage: 0,
        loading: false,
        breadcrumbList:[]
    };
    retry=true;
    retryNum=0;

    componentDidMount() {
        const {getFileParams}=this.props;
        let breadcrumbList=[{relation_id:'',fileName:util.locale('im_group_doc_all')}]
        if(getFileParams) {
            this.getFileList(getFileParams);
            breadcrumbList.push(getFileParams);
        }else{
            this.searchFileList();
        }

        this.setState({
            breadcrumbList
        })
    }

    componentWillUnmount(){
        this.retry=false;
    }

    // 查询接口
    searchFileList = async () => {
        this.setState({ loading: true });
        const { id, type } = window.store.getState().sessionActive;
        const { currentPage, fileList } = this.state;
        let formData = {
            group_tid: id,
            page: currentPage + 1,
            size: 20,
            type: 'file',
            receive_type: type === 'team' ? 0 : 1,
            searchWorld: '',
        };

        const datas = await fileGroupList(formData);
        const { code, obj = [] } = datas || {};
        let resArr = [];
        if(code==170001) {
            message.warn(this.locale('im_group_folder_delete'));
            this.handleAnyFolder(0);
            return;
        }
        if (code === 200) {
            // todo:获取回话本地状态
            resArr = util.cosfiles.fileDownloadStatusGetArr(obj);
            // if (resArr.length !== 20) {
            //     if (loadMore) message.info(util.locale('im_all_files_loaded'));
            // }
        }
        const arr = [...fileList, ...resArr];
        this.setState({
            fileList: arr,
            currentPage: currentPage + 1,
            loading: false,
            hasMore: resArr.length === 20,
            noData: arr.length? '': 'no_file',
        });
    };

    // 文件夹列表
    getFileList = async ({relation_id}) => {
        this.retryNum++;
        this.setState({ loading: true });
        const {  currentPage, fileList } = this.state;
        let formData = {
            relation_id,
            page: currentPage + 1,
            size: 20,
            source:1,
        };

        const datas = await folderPreviewList(formData);
        const { code, obj:{shouldTry,list} } = datas || {};
        if(code==170001) {
            message.warn(this.locale('im_group_folder_delete'));
            this.handleAnyFolder(0);
            return;
        }
        util.log('lichao','group_file','list_file_load_retry',shouldTry,this.retry,this.retryNum,maxRetry);
        if (code != 200) return;
        if(shouldTry&&this.retry&&this.retryNum<maxRetry){
            // 请求重试
            setTimeout(()=>{  
                this.getFileList(formData);
            }, 1000);
            return;
        }
        const resArr = util.cosfiles.fileDownloadStatusGetArr(list);

        // todo:获取回话本地状态
        // if (resArr.length !== 20) {
        //     if (loadMore) message.info(util.locale('im_all_files_loaded'));
        // }
        const arr = [...fileList, ...resArr];
        this.setState({
            fileList: arr,
            currentPage: currentPage + 1,
            loading: false,
            hasMore: resArr.length === 20,
            noData: arr.length ? '': 'no_file',
        });
    };

    // 滚动加载
    handleLoadMore=()=>{
        // 根目录用search接口
        const {breadcrumbList}=this.state;
        const {relation_id}=breadcrumbList[breadcrumbList.length-1];
        relation_id?this.getFileList({relation_id}):this.searchFileList()
    }
    
    // 下一级
    handleNextFolder= (item)=>{
        const {relation_id,fileName}=item;
        this.setState(pre=>({
            breadcrumbList:[...pre.breadcrumbList,{relation_id,fileName}],
            noData: '',
            fileList: [],
            hasMore: false,
            currentPage: 0,
            loading: false,
        }),()=>{
            this.getFileList({relation_id});
        })
    }
    
    // 上一级
    handlePreFolder= ()=>{
        let {breadcrumbList}=this.state;
        breadcrumbList=breadcrumbList.slice(0,breadcrumbList.length-1);
        const {relation_id}=breadcrumbList[breadcrumbList.length-1];

        this.setState({
            breadcrumbList:breadcrumbList,
            noData: '',
            fileList: [],
            hasMore: false,
            currentPage: 0,
            loading: false,
        },()=>{
            relation_id?this.getFileList({relation_id}):this.searchFileList()
        })
    }

    // 去到某一级
    handleAnyFolder= (index)=>{
        const {breadcrumbList}=this.state;
        const {relation_id}=breadcrumbList[index];
        this.setState({
            breadcrumbList:breadcrumbList.slice(0,index+1),
            noData: '',
            fileList: [],
            hasMore: false,
            currentPage: 0,
            loading: false,
        },()=>{
            relation_id?this.getFileList({relation_id}):this.searchFileList()
        })
    }

    // 重置msg状态
    resetLocalMsgState = ({relation_id, path}) => {
        const fileList = this.state.fileList.map((item) => {
            if (item.relation_id == relation_id) item.downloadPath = path;
            return item;
        });
        this.setState({
            fileList,
        });
        
        util.cosfiles.fileDownloadStatusUpdate({path,key:relation_id});
    };

    render(){
        const {noData,hasMore,loading,fileList,breadcrumbList} =this.state;
        const FileBreadcrumProps={
            breadcrumbList,
            handleAnyFolder:this.handleAnyFolder,
            handlePreFolder:this.handlePreFolder,
        }
        const FileListProps={
            type:'preview',
            noData,
            fileList,
            hasMore,
            loading,
            handleLoadMore:this.handleLoadMore,
            closedDownLoad:this.closedDownLoad,
            handleNextFolder:this.handleNextFolder,
            resetLocalMsgState:this.resetLocalMsgState
        }
        return (
            <div className={css.box}>
                <FileBreadcrum {...FileBreadcrumProps}/>
                <FileList {...FileListProps} />
            </div>
        )
    }
}
