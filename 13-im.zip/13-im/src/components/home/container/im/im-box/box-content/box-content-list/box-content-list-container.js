// react
import React from 'react';
// BoxContentList
import BoxContentList from './box-content-list';
// util
import * as util from '@u/util.js';
import * as linkMsgHandler from "@u/nim/container/link-msg-handler.js"
// antd
import {message} from 'antd';
// redux
import {connect} from 'react-redux';
import {item as setItem, show as replyShow} from '@r/actions/reply';
import {add, del, replace} from '@r/actions/messageList';
import {selectList as selectListAdd, showCheckbox} from '@r/actions/messageListState';
// import {hideMessageState, showMessageState} from '@r/actions/boxContentMessageState'
// import { sessionActiveSet } from '@r/actions/session';

import { groupUsersListGet } from '@s/group/group-info';

import {fileUpdateRevoke} from '@s/file/file-update';
import {fileShareAdd} from '@s/file/file-share';
import {groupDocumentDel, groupDocumentBind} from '@s/group/group-doc';
// import {ucenterMultiuserInfoGet} from '@s/ucenter/ucenter-multiuser.js';
// import { ucenterUserInfoGet } from "@/services/ucenter/ucenter-user";
import { audioBusMessageDel } from '@/services/session/session'

import {remindWin as remindWinAction} from '@r/actions/remind';
// import * as fileRedux from '@/redux/actions/file'

import {imCreateCanlendar} from '@c/home/container/coordination/schedule/common/common.js'
import { getPushObj, saveFileData } from '@c/common/upload-file-control/tool';
let successArr = []

// BoxContentListContainer
export class BoxContentListContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showForwardModal: false,
            loading: false,
            selectUser: {},
            selectItem: [],
            idServer: '',
            target: '',
            customTypes: [5, 7, 8, 10, 16,26,30],
            isEffective:true,
            deleteDialog: false,
            itemMsg: {},
            sendVideoMsgFlag: false,
            sendVideoData:{}
        }
    }

    componentDidMount =()=>{
        this.videoEventListen();
    };

    videoEventListen = () => {
        //转发
        util.electronipc.electronOnVideoWindowShare(obj => {
            util.log('panghaojie','box-content-list-container.js','videoSharecb')
            console.log('phj-handleMsg',obj)
            if(obj.msg){
                this.forwardMsg(obj.msg)
                return
            }
            this.setState({
                sendVideoMsgFlag: true,
                showForwardModal: true,
                sendVideoData: obj
            })
        })
    }
    handleMsg = async(obj) => {
        //组装视频转发的消息
        const { teams, users } = obj
        const allObj = []
        if(Array.isArray(teams)) {
            teams.forEach(item => {
                allObj.push({
                    id: item.group_tid || '',
                    type: 'team',
                    showname: item.group_name || ''
                })
            })
            
        }
        if(Array.isArray(users)) {
            users.forEach(item => {
                allObj.push({
                    id: item.id || '',
                    type: 'p2p',
                    showname: item.name || item.name_nick
                })
            })
        }
        
        const {sendVideoData} = this.state
        successArr = []
        for (const item of allObj) {
            await this.sendVideoMsg(item,sendVideoData)
        }
        if(allObj.length == successArr.length){
            this.forwardMsgOver();
        }
    }
    sendVideoMsg = async (sessionActive,sendVideoData) =>{
        const pushtext = `[${util.locale("im_video")}]`;

        //获取relationId
        const saveFileDataParams = {
            fileurl: sendVideoData.fileurl || '',
            type: 'video',
            filename: sendVideoData.filename || '',
            size: sendVideoData.size || 0,
            sessionActive: sessionActive,
            duration: sendVideoData.dur || 0,
            processMedia: 1,
            processMediaId: 20,
            width: sendVideoData.width || 0,
            height: sendVideoData.height || 0
        }
        const savedata = await saveFileData(saveFileDataParams);
        if(!savedata || savedata.code != 200 || !savedata.obj){//接口请求失败
            console.log('savedata-err',savedata)
            return message.error(util.locale("im_failed_to_forward"));
        }

        let videoPicWH = {}
        let videoImage = sendVideoData.coverUrl || ''
        if(!videoImage && savedata.obj.videoInfo && savedata.obj.videoInfo.videoPic) videoImage = savedata.obj.videoInfo.videoPic
        if(videoImage){
            try {
                videoPicWH = await util.imageDealer.getImageInfo(videoImage)
            } catch (error) {}
        }
        const contentData =  {
            messageType : 'video',
            relation_id: sendVideoData.relationId,
            pushtext,
            pushobj : getPushObj(pushtext, sessionActive),
            apns : { forcePush: false },
            custom : {
                type: 30,
                data: {
                    fileName:   sendVideoData.filename,
                    name:       sendVideoData.filename,//兼容老版本字段
                    fileSize:   sendVideoData.size,
                    size:       sendVideoData.size,//兼容老版本字段
                    fileUrl:    sendVideoData.fileurl,
                    url:        sendVideoData.fileurl,//兼容老版本字段
                    id:         sendVideoData.idClient,
                    relationId: savedata.obj.relation_id || sendVideoData.relationId,
                    width:      videoPicWH.width  || sendVideoData.width,
                    height:     videoPicWH.height || sendVideoData.height,
                    dur:        sendVideoData.dur,
                    ext:        sendVideoData.ext || util.videoUtil.getFileExtendingName(sendVideoData.fileurl),//兼容老版本字段
                    codeh264:   sendVideoData.codeh264,
                    coverUrl:   sendVideoData.coverUrl,
                    taskId:     (savedata.obj.videoInfo && savedata.obj.videoInfo.taskId) || sendVideoData.taskId
                }
            }
        }
        //发送消息
        try {
            const customMsg = await util.nim.sendCustomMsg(
                sessionActive.type,
                sessionActive.id,
                JSON.stringify(contentData.custom),
                contentData.apns,
                contentData.pushobj.pushContent,
                '',
                contentData.pushobj.pushContent,
                contentData.pushobj.pushPayload,
                async (msg) => {
                    if(this.props.sessionActive.id == sessionActive.id){
                        //转发到当前会话，需要更新数据
                        let obj = await util.nim.genMsgItem(msg);
                        if(this.props.sessionActive.type == 'team'){
                            const teamMembers = await util.nimUtil.getTeamMembers(this.props.sessionActive.id);
                            obj = Object.assign(obj, {read: 0, unread: teamMembers.members.length-1, status: 'success'});
                        }
                        this.props.dispatch(add(obj));
                    }
                    console.log('发送视频中',msg)
                }
            );
            if(customMsg && customMsg.status === 'success'){
                successArr.push(1)
            }else{
                console.log('customMsg-err',customMsg)
                message.error(util.locale("im_failed_to_forward"));
            }
        } catch(err) {
            if (err.code == 'serverError') return message.error(util.locale("im_network_abnormal_upload_failed"));
            message.error(err.message);
        }
    }

    saveDeleteMsg = (data)=>{
        let list = window.store.getState().messageList
        let deleteMsg = (list.filter(item => item.idClient === data.idClient))[0]
        let allDeleteMsgData = util.yachLocalStorage.ls('deleteMsg') || {}
        let now =  new Date().getTime();
        for (const key in allDeleteMsgData) {
            if (now - allDeleteMsgData[key].time > 120 * 1000) {
                delete allDeleteMsgData[key]
            }
        }
        allDeleteMsgData[deleteMsg.idClient] = deleteMsg
        util.log('qinqinghao','13-im','box-content-list-container/saveDeleteMsg:暂时保存撤回消息',data.text,data.idClient)
        util.yachLocalStorage.ls('deleteMsg',allDeleteMsgData)
    }

    // 撤回 msg  16、在线文档
    deleteMsg = async item => {
        try {
            const {type, content, } = item;
            if(type == 'custom'){
                const newContent = JSON.parse(content);
                // 在线文档
                if(newContent.type == 16){
                    return this.groupDocumentDelFun([newContent.data.guid], item);
                }
                else if(newContent.data.relationId && this.state.customTypes.includes(newContent.type)){
                    this.fileUpdateRevokeFun(newContent.data.relationId, item);
                }
                else{
                    this.nimDeleteMsg(item); 
                }
            }else{
                this.nimDeleteMsg(item);
            }
        } catch (error) {
            message.warning(util.locale('im_failed_to_operate'));
        }
        
        audioBusMessageDel({ clientId:  item.idClient})
    };


    nimDeleteMsg = async item => {
        try {
            this.saveDeleteMsg(item) 
            const obj = await util.nimUtil.deleteMsg({ item });

            if(obj){
                await this.sendTipMsg(obj);
            }
        } catch (error) {
            if (error.code === 508) {
                message.warning(util.locale('im_the_message_cannot_be_recalled_when_sent_out_over_24_hours'));
            } else {
                message.warning(error.message || util.locale('im_failed_to_operate'));
            }
        }
        util.log('qiuyanlong','yach-im','revork msg');
        util.sensorsData.track('Click_ChatWindow_MessageOperate',{OperateType: 106, isWithdrawOthers: 102});
    }

    groupDocumentDelFun = async (guids, item) => {
        const id = this.props.sessionActive.id;
        const {scene} = item;
        let option = {
            guid: guids,
            groupId: scene === 'team' ? id : null,
            userId: scene === 'p2p' ? id : null
        }
        const datas = await groupDocumentDel(option);
        const {code, msg} = datas || {};
        if (code == 200) {
            this.nimDeleteMsg(item);
        } else {
            message.error(msg);
        }
    }

    fileUpdateRevokeFun = async (fileId, item) => {
        let option = {
            relation_id: fileId,
            //uniq:fileId,
            is_del: 1
        }
        const datas = await fileUpdateRevoke(option);
        const {code, msg} = datas || {};
        if (code == 200) {
            this.nimDeleteMsg(item);
        } else {
            message.error(msg);
        }
    };

    // resend msg
    resendMsg = async item => {
        const obj = await util.nimUtil.resendMsg(item);
        const {status, idClient, fromNick, to} = obj;
        util.log('mayuanlong', 'resendMsg:status:idClient:fromNick:to', status, idClient, fromNick, to);
        util.yach.msgUploadCloud(obj);
        const {id, type} = this.props.sessionActive;
        if(obj){
            let newObj = await util.nim.genMsgItem(obj);
            if(type == 'team'){
                const teamMembers = await util.nimUtil.getTeamMembers(id);
                newObj = Object.assign(newObj, {read: 0, unread: teamMembers.members.length-1});
            }
            this.props.dispatch(replace(newObj));
        }
    }

    sendTipMsg = async obj  => {
        const delTipText = this.getDelTipText(obj.msg);
        let sendTipMsg = await util.nim.sendTipMsg(Object.assign(obj.msg, {targetType: 2, ...delTipText}));
        let delMsgItem = this.getDelMessage(sendTipMsg, delTipText.text);
        this.props.dispatch(del(delMsgItem));
    }

    getDelMessage = (sysMsg, text) => {
       return Object.assign(sysMsg, {tip: text, text: text});
    }

    getDelTipText = msg => {
        let tipObj = {};
        const {from, type, text} = msg;
        if(from != util.yach.getAccount()){
            tipObj['text'] = util.locale('im_group_administrator_recalled_one_message');
        }else{
            tipObj['text'] = util.locale("im_You've_recalled_one_message");
            if(type == 'text') {
                tipObj['custom'] = {
                    text,
                    newTime: new Date().getTime()
                };
            }
        }
        return tipObj;
    }

    forwardMsg = async item => {
        util.log('qiuyanlong', 'forwardMsg:start');
        try {
            //处理会议纪要卡片，转发时需要按在线文档格式转发出来
            if(item.content){
                const content = JSON.parse(item.content)
                if(content.type == 28 && content.data){
                    content.type = 16;
                    const contentData = {
                        guid: content.data.guid,
                        link: content.data.link,
                        title: content.data.title,
                        type: 'newdoc',//固定时word类型
                        pushContent: `${(item.pushContent && item.pushContent.split(':')[0].split('(')[0]) || ''}: [${util.locale('common_doc_online')}]`,
                        pushTitle: item.pushPayload && JSON.parse(item.pushPayload).pushTitle
                    }
                    content.data = contentData

                    item.content = JSON.stringify(content)
                }
            }
        } catch (error) {
            util.log('panghaojie','box-content-list-container.js','forwardMsg-error', error);
        }

        if(item.custom) item = Object.assign(item, {custom: ''});
        item = Object.assign(item, {apns: {forcePush: false}, needMsgReceipt: true});
        this.setState({showForwardModal: true, forwardItem: item});
        util.sensorsData.track('Click_ChatWindow_MessageOperate',{OperateType: 107});
    }

    forwardOk = data => {
        console.log('forwardOk', data);
        util.log('qiuyanlong', 'forwardMsg:success');
    }

    /*
       转发权限判断
    */
    forwardVoteCheck = async (arr)=>{
        try{
           return await util.yach.msgForwardingVoteCheck(arr);
        }
        catch(e){
            console.log('forwardVoteCheck',e);
        }
     }

    getUsers = async(value) => {
        this.setState({loading: true});
        const{forwardItem} = this.state;
        const {teams} = value;
        console.log('qiuyanlong','forwardItem转发的数据',forwardItem)
        // 只拿回针对群组的判断
        if( teams.length === 1){
            const vote = await this.forwardVoteCheck(teams);
            if(!vote){
                message.error(util.locale("im_failed_forward_goup_has_been_Muted"));
                this.setState({loading: false,isEffective:false});
            } 
        }

        if(forwardItem.type == 'custom'){
            try {
                const content = JSON.parse(forwardItem.content);
                const { idClient } = forwardItem
                if(content && content.type && this.state.customTypes.includes(content.type)){
                    this.batchForward(value, 0, content.type, content,idClient,forwardItem);
                    return;
                }
            } catch (error) {
                console.log(util.locale("im_failed_to_forward"));
            }
        }

        this.batchForward(value, 1);
    };

    getSendUsers = async(value) => {
        //视频转发，实际是发送逻辑
        this.setState({loading: true});
        let { teams, users } = value;
        // 只拿回针对群组的判断
        if(teams.length == 1){
            const vote = await this.forwardVoteCheck(teams);
            if(!vote){
                message.error(util.locale("im_failed_forward_goup_has_been_Muted"));
                this.setState({loading: false});
            }
        }
        this.handleMsg({
            teams,
            users
        })
    }

    batchForward = async(value, tag, type, content,idClient,forwardItem) => {
        console.log('value, tag, type, content',value, tag, type, content)
        const { textareaValue, teams, teamids,allDataUsers } = value;
        let shareObj
        if(tag){
           this.forwardMsgLogicFun(teams, allDataUsers, textareaValue);
        }else{
            if(type == 16){
                shareObj = await this.groupDocumentBindSingle(teams, content, allDataUsers);
                if(!shareObj) return message.error(util.locale("im_failed_to_forward"));
                this.forwardMsgLogicFun(teams, allDataUsers, textareaValue);
            }else if(type == 7){
                this.forwardMsgLogicFun(teams, allDataUsers, textareaValue);
            }else{
                shareObj = await this.fileShareAddApi(allDataUsers, teamids, idClient);
                if(!shareObj) return message.error(util.locale("im_failed_to_forward"));
                const {person, group} = shareObj;
                if(person && person.length>0){
                    for (let i = 0; i < person.length; i++) {
                        const item = person[i];
                        await this.forwardMsgLogic(textareaValue, 2, item.receive_id, '', item.relation_id, type,item,forwardItem);
                    }
                }
                if(group && group.length>0){
                    for (let j = 0; j < group.length; j++) {
                        const item = group[j];
                        await this.forwardMsgLogic(textareaValue, 1, item.receive_id, item.group_name, item.relation_id,type,item,forwardItem);
                    }
                }
            }
        }

       
        if(!this.state.isEffective && teams.length === 1){
            this.setState({showForwardModal: false, loading: false});
            return 
        }

        this.forwardMsgOver();
    };


    forwardMsgLogicFun = async(teams, allDataUsers, textareaValue) => {
        if(teams && teams.length>0){
            for (let i = 0; i < teams.length; i++) {
                const item = teams[i];
                try{
                    await this.forwardMsgLogic(textareaValue, 1, item.group_tid, item.group_name);  
                }catch(error){
                    console.log('----forwardMsgLogicFun-->>', error);
                    const {type, id} = this.props.sessionActive;
                    if(!util.yach.checkVoteReplay()){ //群禁言
                        util.nim.pushMessageList(type, id); //群禁言后要发一条失败信息
                    } 
                }
                
            }
        }
        
        if(allDataUsers && allDataUsers.length>0){
            for (let y = 0; y < allDataUsers.length; y++) {
                const item = allDataUsers[y];
                await this.forwardMsgLogic(textareaValue, 2, item.id);
            }
        }
    }

    groupDocumentBindSingle = async (teams, content, allDataUsers) => {
        const option = {
            groupId: teams.map(item=>item.group_tid),
            document: [JSON.stringify(content.data)],
            userId: allDataUsers.map(item=>item.id)
        }
        const data = await groupDocumentBind(option);
        if(data && data.code == 200){
            return data.obj;
        }
        return false;
    }
    

    fileShareAddApi = async(users, teamids,idClient) => {
        let customContent = {};
        try {
            customContent = JSON.parse(this.state.forwardItem.content);
        } catch (error) {
            return null;
        }
        util.log('qiuyanlong', 'fileShareAddApi:/share/add start','users:teamids', users.map(item=>item.id).join(), teamids.join());
        const option = {
            file_id: customContent.data.id,
            msg_id: idClient || '',
            receive_group_id: teamids.join(),   //teams.map(item=>item.group_tid).join(),
            receive_user_id: users.map(item=>item.id).join(),
            relation_id:customContent.data.relationId

        }
        const data = await fileShareAdd(option);
        if(data && data.code == 200){
            return data.obj;
        }
        util.log('qiuyanlong', 'fileShareAddApi:/share/add fail');
        return null;
    };

    forwardMsgOver =  () => {
        message.success(util.locale("im_forward_successfully"));
        this.setState({showForwardModal: false, loading: false});        
    };
      
    /**
     * 转发消息处理
     * 改动原因：添加文件夹转发重命名的逻辑，新增item字段
     */
    forwardMsgLogic = async(textareaValue, sessionType, sessionID, sessionName, relationId, messageType,item,forwardItem) => {
        util.log('qiuyanlong', 'forwardMsgLogic:one msg forward',textareaValue, sessionType, sessionID, sessionName, relationId, messageType);
        const { name, name_nick } = this.props.userInfo;
        let scene = '',
            pushContentText = '',
            pushPayload = {};
        let { pushContent = '', apns = {}, text, type } = this.state.forwardItem;
        if(pushContent){
            pushContentText = pushContent.substring(pushContent.indexOf(':')+1)
        }
        if(sessionType == 1){
            scene = 'team';
            pushPayload = {
                pushTitle: util.yach.decodeUnicode(sessionName),
                sessionType: 1,
                sessionID: sessionID
            }
            if(this.isCustom() == 2) {
                pushContent = `${name}${name_nick?'('+name_nick+')':''} ${util.locale('common_pushcontent1')}`;
            } else if(this.isCustom() == 31) {
                pushContent = `${name_nick ? name_nick : name}${util.locale('im_SLGC')}`;
                text = `${util.locale('im_SLGC')}`.trim();
            }else {
                pushContent = `${name}${name_nick?'('+name_nick+')':''}:${pushContentText}`;
            }
        } else if(sessionType == 2){
            scene = 'p2p';
            pushPayload = {
                pushTitle: util.yach.decodeUnicode(name_nick || name),
                sessionType: 0,
                sessionID: sessionID
            }
            if(this.isCustom() == 2) {
                pushContent = util.locale('common_pushcontent1');
            } else if(this.isCustom() == 31) {
                pushContent = `${name_nick ? name_nick : name}${util.locale('im_SLY')}`;
                text = `${util.locale('im_SLY')}`.trim();
            } else {
                pushContent = pushContentText;
            }
        }
        apns = Object.assign(apns, {
            content: pushContent
        });
        const newForwardItem = Object.assign(this.state.forwardItem, {
            apns,
            text,
            isPushable: sessionID == this.props.userInfo.id ? false : true,
            pushPayload: JSON.stringify(util.yach.handlePushPayload({ pushPayload,apns: apns || {} }) || {}),
            pushContent: pushContent,
            needPushNick: false,
            content: this.customContent(relationId,item)
        });

        if(type == "text" && linkMsgHandler.isUrl(text) ){
            // 如果是在支持 link msg 消息之前的老消息被转发,需要解析处理
           await linkMsgHandler.parserAndSend({type:scene,id:sessionID},text,pushContent,pushPayload,apns, this.props.dispatch)
        }else{
            let obj
            console.log('newForwardItem',newForwardItem)
            // fileUpdateRevoke 去调同步调用接口原因：
            // 分组模式下，转发视频，如果这个接口是同步的，会阻塞云信 onupdatesession 回调。从而会阻塞 分组模式 render渲染 
            if(sessionID == this.props.sessionActive.id) {
                obj = await util.nimUtil.forwardMsg(newForwardItem, scene, sessionID);
                await this.addMessage(obj);
                if (messageType == 5 || messageType == 10 || messageType == 26 || messageType == 30) {
                    fileUpdateRevoke({msg_id: obj.idClient, relation_id: relationId});
                }
                //obj.idClient
            }else{
                obj = await util.nimUtil.forwardMsg(newForwardItem, scene, sessionID);
                if (messageType == 5 || messageType == 10 || messageType == 26 || messageType == 30) {
                    fileUpdateRevoke({msg_id: obj.idClient, relation_id: relationId});
                }
            }
            util.yach.msgUploadCloud(obj);
            if(obj){
                util.yachLocalStorage.ls('message_id',{message_id:obj.idClient,id:obj.to})
                util.yach.sendMessageSensorsData(108);
                util.yachLocalStorage.ls('message_id',{message_id:obj.idClient})

                // if( forwardItem && forwardItem.localCustom && forwardItem.localCustom.isDownloadFlag ){
                //     let { path='' } =  forwardItem.localCustom;
                //     let { idClient } = obj;
                //     this.props.dispatch(fileRedux.fileStatusUpdate(idClient,  {
                //         id: idClient,
                //         isDownloaded: true,
                //         downloadedPath:path
                //     }));
                //     util.nimUtil.updateLocalMsg(idClient, { isDownloadFlag: true, path }); 
                // }
            }
        }

        if(textareaValue) {
            let pushPayloadText = {},
            pushContentText,
            apnsText={},
            sendText = '';
            if(sessionType == 1){
                pushPayloadText = {
                    pushTitle: util.yach.decodeUnicode(sessionName),
                    sessionType: 1,
                    sessionID: sessionID
                }
                pushContentText = `${name}${name_nick?'('+name_nick+')':''}:${textareaValue}`;
            } else if(sessionType == 2){
                pushPayloadText = {
                    pushTitle: util.yach.decodeUnicode(name_nick || name),
                    sessionType: 0,
                    sessionID: sessionID
                }
                pushContentText = textareaValue;
                apnsText = {
                    content: pushContentText,
                    forcePush: false
                };
            }

            try {
                if( linkMsgHandler.isUrl(textareaValue) ){
                  return linkMsgHandler.parserAndSend({type:scene,id:sessionID},textareaValue,pushContentText,pushPayloadText,apnsText, this.props.dispatch)
                }
                if(sessionID == this.props.sessionActive.id){
                    sendText = await util.nim.sendText(scene, sessionID, textareaValue, apnsText, '', pushContentText, pushPayloadText);
                    await this.addMessage(sendText);
                }else{
                    util.nim.sendText(scene, sessionID, textareaValue, apnsText, '', pushContentText, pushPayloadText);
                }
            } catch (error) {
                console.log('error', error);
            }
        }
        // 单条转发(转发给单人、多人) 触发 自动回复 
        util.yach.checkAutoReply(sessionID, scene)

        util.yach.getEffectForwadSession(sessionID);
    };

    customContent = (relationId,item) => {
        const{forwardItem, customTypes} = this.state;
        if(forwardItem.type == 'custom'){
            try {
                const content = JSON.parse(forwardItem.content);
                const temp = {};
                if(customTypes.includes(content.type)){
                     // 文件夹 rename
                    if(item && item.file_name && content.type === 26) temp.fileName = item.file_name;
                     temp.relationId = relationId;
                }
                return JSON.stringify({
                    type: content.type,
                    data: Object.assign(content.data,temp)
                });
            } catch (error) {
                console.log('customContent', error);
            }
        }
        return '';
    };

    isCustom = () => {
        let { forwardItem } = this.state;
        if(!forwardItem) return 0;
        if(forwardItem.type == 'custom'){
            if(forwardItem.content){
                let content = '';
                try {
                    content = JSON.parse(forwardItem.content);
                } catch (error) {
                    console.log('isCustom', error);
                }
                return content.type;
            }
        }
        return 0;
    }

    addMessage = async(item) => {
        let obj = await util.nim.genMsgItem(item);
        if(this.props.sessionActive.type == 'team'){
            const teamMembers = await util.nimUtil.getTeamMembers(this.props.sessionActive.id);
            obj = Object.assign(obj, {read: 0, unread: teamMembers.members.length-1});
        }
        this.props.dispatch(add(obj));
    }

    closegetUser = async () => {
        this.setState({showForwardModal: false, loading: false})
    };

    isInAt = item => {
        if(item && item.apns && item.apns.accounts){
            return item.apns.accounts.includes(this.props.userInfo.id);
        }else{
            return false;
        }
    }

    replyMsg = item => {
        this.props.dispatch(replyShow(true));
        this.props.dispatch(setItem(item));
        util.eventBus.emit('sendMsg', item);
        util.sensorsData.track('Click_ChatWindow_MessageOperate',{OperateType: 107});
    }

    multiSelect = item => {
        this.props.dispatch(showCheckbox(true));
        util.sensorsData.track('Click_ChatWindow_MessageOperate',{OperateType: 108});
        setTimeout(() => {
            this.labelClick(item);
            util.log('zhangyongchang','box-content-list-container','multiSelect');
        }, 100);
    }

    onCheckboxChange = (e, item) => {
        if(!e) return;
        let { selectList } = this.props.messageListState;
        if (!selectList) return;
        const boxBg = document.getElementById(`${item.idClient}boxBg`);
        if(e.target.checked){
            if (selectList.length > 99) {
                e.target.checked = false;
                message.warning(util.locale('im_select_length'));
                return;
            }
            boxBg.style.background = '#EDEFF5';
            selectList.push(e.target.value);
            this.props.dispatch(selectListAdd(selectList));
        } else {
            boxBg.style.background = '';
            let selectItem = selectList.filter(i => i != e.target.value);
            this.props.dispatch(selectListAdd(selectItem));
        }
        util.log('zhangyongchang','box-content-list-container','onCheckboxChange');
    }

    labelClick = (item) => {
        if(!this.props.messageListState.showCheckbox) return;
        const boxBg = document.getElementById(`${item.idClient}box`);
        boxBg && boxBg.click();
    }

    // 调起已读未读人数
    showUnreadPersion = async (value, idServer, target, unread, read, item,option) => {
        util.sensorsData.track('Click_Chat_Element', { pageName: '135', $element_name: '01-146'});
        util.log('qiuyanlong','yach-unread','click:unread:robotNum:memberNum',option.unread, option.robotNum, option.memberNum);
        util.log('qiuyanlong','yach-unread','store:robotNum',window.store.getState().getRobotNum);
        target && util.electronipc.electronOpenIsRead({target,idServer,unread,read,item})
        try{
            console.log('hh4');
            const userInfo = await util.nim.getNimInfo('team',item.to);
            util.log('qiuyanlong','yach-unread','store:userInfo',userInfo.memberNum);
        }
        catch(e){}
    }

    // 调起提醒弹窗
    remind = async (item) => {
        let data = {...item};
        const {id, type, showname, showimg} = this.props.sessionActive
        if(type == 'p2p'){
            data.user= {
                id,
                name: showname,
                pic: showimg
            }
            data.remindSource = `${util.yach.getAccount()},${data.target}`
        } else {
            if(data.msg.apns && data.msg.apns.accounts && Array.isArray(data.msg.apns.accounts)){
                let accounts = data.msg.apns.accounts
                let index = accounts.indexOf(this.props.userInfo.id)
                if(index != -1) accounts.splice(index,1)
                if(accounts.length >= 1){
                    let userInfo = await util.nimUtil.getUsers(accounts);
                    let userList = []
                    userInfo.forEach((sonItem)=>{
                        userList.push({id:sonItem.account,name:sonItem.nick,pic:sonItem.avatar})
                    })
                    data.user = userList
                }
            } 
            data.remindSource = data.target;
        }
        // 链接卡片类型 提醒处理
        linkMsgHandler.remindContent(item);

        if(data.type == 'custom') data = this.getCustomText(data);

        this.props.dispatch(remindWinAction({show:true, edit:false, data}));

        util.sensorsData.track('Click_ChatWindow_MessageOperate', { OperateType: '01-105'});
    }

    getCustomText = (data) => {
        let text = data.text;
        const newContent = util.nimUtil.getJson(data.content);
        if(newContent.type == 32){
            text = `${this.locale('im_vote')}：${newContent.data.title}`;
        }
        if(newContent.type === 38){
            text = `[${util.locale('im_auto_reply')}]${newContent.data.content.reply_content}`
        }
        return {...data, text}
    }
    
    // 获取未读用户列表  勿删
    getUnReadUsers = async (id, idServer) => {
        try {
            const unReadIds = await util.yach.isreadMsgReadInit(id, idServer)
            const unReadUsers = await groupUsersListGet({tid: id})
            if (unReadUsers.code !== 200 || !unReadUsers.obj || !unReadUsers.obj.list) return false
            const allUsers = []
            const users = []
            const listData = unReadUsers.obj.list
            for (const key in listData) {
                listData[key].forEach(item => {
                    if (item.value.length) Array.prototype.push.apply(allUsers, [...item.value])
                })
            }

            allUsers.forEach(item => {
                if (unReadIds.unreadAccounts.includes(item.id)) users.push({
                    id: item.id,
                    name: item.name,
                    pic: item.pic
                })
            })

            return users.length ? users : false

        } catch(err) {
            message.error(err)
        }
    }
    
    schedule=async item=>{
        let groupInfo={};
        const {id, showname} = this.props.sessionActive
        const {scene,from,to,text,custom}=item||{};
        let user=[from+''];

        let data = {...item}
        if(data.type == 'custom') data = this.getCustomText(data);

        let title=text.slice(0,30) || data.text;

        if(scene==='p2p'){
            user=from==to?[]:[to+'',from+''];
        } else if(scene==='team'){
            groupInfo={id, showname}
            const {atHighlighted=[]} = util.nimUtil.getJson(custom,{})
            if(atHighlighted.length>0){
                const arr_at=atHighlighted.map(item=>item.id+'').filter(item=>item!=='-1');
                user=[...arr_at,...user]
            }
        }
        // 去重/过滤自己
        user=[...new Set(user)];
        user=user.filter(item=>item!=this.props.userInfo.id);

        imCreateCanlendar({title,user,groupInfo});
        util.sensorsData.track('Click_ChatWindow_MessageOperate', { OperateType: '01-104'});
    }

    toDo = async item => {
        const data = await this.getTodoInfo(item);

        util.electronipc.electronOpenSinglewebview({
            window: {
                width: 480,
                height: 600,
                minWidth: 480,
                minHeight: 600,
                parentType: 'main',
            },
            data,
            // url: 'http://0.0.0.0:8080/'
            url: util.config.todo.createTask
        })
        util.sensorsData.track('Click_ChatWindow_MessageOperate', { OperateType: '01-103'});
    }

    getTodoInfo = async item => {
        const { id: selfId } = this.props.userInfo;
        const {
            from: senderId,
            target: targetId, // 私聊为对方 id，群聊为群 id
            scene: sourceType, // 群聊：team 私聊：p2p
            text, 
            content = '{}',
            pushPayload = '{}'
        } = item.msg;
        const { pushTitle: title} = util.nimUtil.getJson(pushPayload, ''); // 群名称
        const { type: subType, data: msgData = {} } = util.nimUtil.getJson(content, ''); // 消息类型及内容
        const msgType = subType === 23 ? 'link' : 'text'; // 目前只有 链接、消息、回复 可创建任务
        let msgCont = '';
        if(subType == 38){// 自动回复消息类型
            msgCont =this.getCustomText(item).text;
        }else{
            msgCont = msgType === 'text' ? text : msgData.url;
        }
        

        let senderInfo = {};
        let targetInfo = {};
        let executorInfo = {};
        let sourceInfo = {};
        if(sourceType === 'p2p') {
            const [yachSelfInfo = {}, yachTargetInfo = {}] = await util.yach.transToThirdUserInfos([selfId, targetId]);
            // 自己与别人对话并且别人发送给自己的消息 sender 为 对方（target）
            senderInfo = targetId !== selfId && senderId === targetId ? {...yachTargetInfo} : {...yachSelfInfo};
            // 自己与自己的对话 target 为 self，自己与别人的对话，target 为 对方（target）
            targetInfo = targetId === selfId ? {...yachSelfInfo} : {...yachTargetInfo};
            sourceInfo = {id: targetInfo.userid, ...targetInfo};
            executorInfo = {...targetInfo};
        }
        if (sourceType === 'team') {
            const [yachSelfInfo = {}, yachSenderInfo = {}] = await util.yach.transToThirdUserInfos([selfId, senderId]);
            const selfInfo = {...yachSelfInfo};
            senderInfo = senderId === selfId ? {...yachSelfInfo} : {...yachSenderInfo};
            sourceInfo = {id: targetId, name: title, avatar: ''}
            executorInfo = {...selfInfo};
        }

        return {
            msg: {
                id: item.idClient,
                type: msgType,
                content: msgCont
            },
            source: {type: sourceType, ...sourceInfo},
            sender: {id: senderInfo.userid, ...senderInfo},
            executor: {id: executorInfo.userid, ...executorInfo}
        }
    }

    // del Self Msg
    delSelfMsg = (msg) => {
        this.setState({deleteDialog: true, itemMsg: msg})
    }

    deleteSelectMsgOk = () => {
        util.yach.handleDelUpdateSelf(this.state.itemMsg);
        this.setState({deleteDialog: false})
        // audioBusMessageDel({ clientId:  this.state.itemMsg.idClient, idDel: 1})
        util.yach.messageDelReport(this.state.itemMsg.idClient)
    }

    deleteSelectMsgCan = () => {
        this.setState({deleteDialog: false})
    }

    render() {
        const forwardMsgProps = {
            type: "forward",
            placeholder: util.locale("im_search_contact/group"),
            loading: this.state.loading,
            show: this.state.showForwardModal,
            onOk: this.state.sendVideoMsgFlag ? this.getSendUsers: this.getUsers,
            onClose: this.closegetUser,
            title: util.locale("im_forward_message"),
            rightTitle: util.locale("im_recent_contact"),
            showButtonNumber: true,
            disabledids: [-1, -2],
            maxLength: 50 + 2,
            noNeedLeaveWord: this.state.sendVideoMsgFlag
        };
        let {messageExtraData, sessionActive, isAutotranslation} = this.props;
        messageExtraData = messageExtraData[sessionActive.id] || {};
        return (
            <BoxContentList
                isHiddenSessionType={this.props.isHiddenSessionType}
                schedule={this.schedule}
                list = {this.props.list}
                remind = {this.remind}
                deleteMsg = {this.deleteMsg} 
                resendMsg = {this.resendMsg}
                forwardMsg = {this.forwardMsg}
                forwardMsgProps = {forwardMsgProps}
                isInAt = {this.isInAt}
                replyMsg = {this.replyMsg}
                setVoiceReadHeigth = {this.props.setVoiceReadHeigth}
                //shouldScroll = {this.props.shouldScroll}
                // firstActive={this.props.firstActive}
                forwardOk = {this.forwardOk}
                multiSelect = {this.multiSelect}
                onCheckboxChange = {this.onCheckboxChange}
                showCheckbox = {this.props.messageListState.showCheckbox}
                showUnreadPersion = {this.showUnreadPersion}
                showBoxContentMessageState = {this.props.boxContentMessageState.show}
                idServer = {this.state.idServer}
                target = {this.state.target}
                box = {this.props.box}
                // workStatus = {this.props.workStatus}
                //teamInfo = {this.props.teamInfo}
                robot_user={this.props.robot_user}
                emotList = {this.props.emotList}
                toDo = {this.toDo}
                messageExtraData = {messageExtraData}
                delSelfMsg = {this.delSelfMsg} 
                deleteDialog = {this.state.deleteDialog}
                deleteSelectMsgOk = {this.deleteSelectMsgOk}
                deleteSelectMsgCan = {this.deleteSelectMsgCan}
                labelClick = {this.labelClick}
                isAutotranslation = {isAutotranslation}
               // targetLanguage = {targetLanguage}
            />
        );
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
        sessionActive: state.sessionActive,
        messageListState: state.messageListState,
        boxContentMessageState: state.boxContentMessageState,
        messageExtraData: state.messageExtraData
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxContentListContainer);
