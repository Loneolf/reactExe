// react
import React from 'react';
// BoxOperation
import BoxOperation from './box-operation';
// api
import {groupInfoEdit, groupInfoGet} from '@s/group/group-info.js';
// react-redux
import {connect} from 'react-redux';
import { hideSlideModal } from '@r/actions/commonModal';
// util
import * as util from '@u/util.js';

import {message} from 'antd';

import {add} from '@r/actions/messageList.js';

import ReactDOM from 'react-dom';
// debounce
import debounce from 'lodash/debounce';

// BoxOperationContainer
export class BoxOperationContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state = {
        creatOperation: false,
        textAreaValue: '',
        textEditAreaValue: '',
        configEdite: '',
        userType: '',
        editExit:false // 是否编辑了群公告，如果编辑了群公告，点击侧边栏以外的地方有确认是否退出弹框
    };

    componentDidMount() {
        this.groupInfoGet();
        this.creatRelease = debounce(this.creatRelease, 500);
    }

    // 获取群信息
    async groupInfoGet() {
        let GroupInfoGet = await groupInfoGet({
            tid: this.props.sessionActive.id
        });

        if (GroupInfoGet.code == 200) {
            this.setState({
                textAreaValue: GroupInfoGet.obj.announce.group_announcement,
                udate: GroupInfoGet.obj.announce.udate,
                uname: GroupInfoGet.obj.announce.last_update_announcement_name,
                configEdite : GroupInfoGet.obj.config_edite,
                userType : GroupInfoGet.obj.user_type
            });
            return;
        } else {
            message.error(GroupInfoGet.msg);
            return;
        }
    }

    creatOperation = () => {
        this.setState({creatOperation: true,textEditAreaValue: this.state.textAreaValue},()=>{
            const node = ReactDOM.findDOMNode(this.messagesEndRef);
            const strLength = this.state.textAreaValue.length;
            util.yach.setSelectionRange(node, strLength, strLength)
        });
    };



    textareaValue = value => {
        let temValue = value.target.value
        if(temValue.length > 1000){
           message.error(util.locale('im_editNotice_maxLenght_warning'),1.5) 
           temValue = temValue.slice(0,1000)
        }
        this.setState({ textEditAreaValue: temValue });
    };

    creatCancel = () => {
        this.setState({ modalVisible: true });
    };

    creatRelease = async () => {
        let GroupInfoEdit = await groupInfoEdit({
            tid: this.props.sessionActive.id,
            group_announcement: this.state.textEditAreaValue
        });

        if (GroupInfoEdit.code == 200) {
            let id = this.props.sessionActive.id;
            this.setState({ creatOperation: false, editExit:false, textAreaValue: this.state.textEditAreaValue});
            this.sendCustomOperation();
            this.groupInfoGet();
            util.sensorsData.track('Click_Chat_Element', {pageName: 140, $element_name: 129, chat_id: id});
            return;
        } else {
            return;
        }
    };

    //发送群公告
    sendCustomOperation = async () => {
        let content = {
            type: 3,
            data: {
                content: this.state.textEditAreaValue
            }
        };
        if(this.state.textEditAreaValue!=='') {
            const { userInfo, sessionActive } = this.props;
            const pushContent = `${userInfo.name}${util.locale('im_posted_an_announcement')}`;
            const pushPayload = {
                pushTitle : util.yach.decodeUnicode(sessionActive.showname),
                sessionType : 1,
                sessionID : sessionActive.id
            }

            // util.nimUtil.updateTeam(this.props.sessionActive.id, {announcement: this.state.textEditAreaValue});

            let SendCustomMsg = await util.nim.sendCustomMsg(
                this.props.sessionActive.type,
                this.props.sessionActive.id,
                JSON.stringify(content),
                '',
                pushContent,
                '',
                pushContent,
                pushPayload,
                '',
                {
                    apns:{
                        forcePush: false
                    },
                }
            ).catch(()=>{
                const {type, id} = this.props.sessionActive;
                if(!util.yach.checkVoteReplay()){ //群禁言
                    util.nim.pushMessageList(type, id); //群禁言后要发一条失败信息
                }
            });
            
            if (SendCustomMsg) {
                message.success(util.locale("im_announcement_updated_successfully"));
                this.updataMessageListProps(SendCustomMsg);
            }
        }

    };

    // 更新
    updataMessageListProps = async msg => {
        let obj = await util.nim.genMsgItem(msg);

        const teamMembers = await util.yach.isreadMsgReadInit(this.props.sessionActive.id, msg.idServer);
        const { unreadAccounts } = teamMembers;
        obj = Object.assign(obj, { read: 0, unread: unreadAccounts.length});

        this.props.dispatch(add(obj));
    };

    setOKModal = () => {
        if(this.state.editExit) this.props.dispatch(hideSlideModal());
        this.setState({
            modalVisible: false,
            creatOperation: false,
            editExit:false
        });
    };

    setonCancelModal = () => {
        if(this.state.editExit) return this.setState({ modalVisible: false });
        this.setState({ modalVisible: false ,editExit:false});
    };

    messagesEndFn = ref => {
        this.messagesEndRef = ref;
    };

    getConfigEdite = () => {
        if(this.state.configEdite < 2){
            return this.state.userType < 2;
        }
        if(this.state.configEdite == 2) return true;
        return false;
    }

    maskClick = (e)=>{
        e.stopPropagation();
        const {creatOperation,textAreaValue,textEditAreaValue} = this.state
        if(creatOperation && textAreaValue !== textEditAreaValue){
            this.setState({ modalVisible: true,editExit:true });
        } else {
            this.props.dispatch(hideSlideModal());
        }
    }

    render() {
        const {editExit, creatOperation, textAreaValue, modalVisible, uname, udate,textEditAreaValue } = this.state
        return (
            <BoxOperation
                uname={uname}
                udate={udate}
                creatOperation={creatOperation}
                textAreaValue={textAreaValue}
                textEditAreaValue={textEditAreaValue}
                modalVisible={modalVisible}
                editExit={editExit}
                creatOperationFn={this.creatOperation}
                messagesEnd={this.messagesEndFn}
                textareaValueFn={this.textareaValue}
                creatRelease={this.creatRelease}
                creatCancel={this.creatCancel}
                setOKModal={this.setOKModal}
                setonCancelModal={this.setonCancelModal}
                getConfigEdite={this.getConfigEdite}
                maskClick={this.maskClick}
            />
        );
    }
}

const mapStateToProps = state => {
    return {
        sessionActive: state.sessionActive,
        slideModal: state.slideModal,
        userInfo: state.userInfo
    };
};

export default connect(mapStateToProps)(BoxOperationContainer);
