import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Button } from 'antd';

import { DetailType, ListType, PageType } from '@r/reducers/robots';
import { robotChangeState, robotDetailModalSet } from '@r/actions/robots';
import { ROBOTS_ADD_ROBOT_FETCH, ROBOTS_DEL_ROBOT_FETCH, ROBOTS_INUSE_FETCH } from '@r/actiontype/robots';
import CommonModal from '@/components/common/common-modal';
import * as util from '@/utils/util';
import style from './style.scss';
class NoticeCommonRobotDetail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modalInfo: {
                title: util.locale("im_delete_robot"),
                content: util.locale("im_confirm_delete_robot"),
                okText: util.locale("im_yes"),
                cancelText: util.locale("im_no"),
                onOk: this.props.delRobot,
                onCancel: () => this.hideModal()
            }
        };
        this.goEditList = this.goEditList.bind(this);
    }
    showModal = () => {
        this.props.robotDetailModalSet(true);
    };

    hideModal = () => {
        this.props.robotDetailModalSet(false);
    };
    goEditList() {
        this.props.inUseRobotsFetch();
        this.props.robotChangeState({
            pageType: PageType.LIST,
            listType: ListType.MODIFY,
            selectedRobot: null
        });
    }
    get isEdit() {
        const { detailType } = this.props;
        return detailType == DetailType.MODIFY;
    }
    get isAdd() {
        const { detailType } = this.props;
        return detailType == DetailType.ADD;
    }

    get isReadOnly() {
        const { detailType } = this.props;
        return detailType == DetailType.READ;
    }

    render() {
        const { item, modalVisible, addRobot, loading } = this.props;
        return (
            <div className={style.commonNotice}>
                <div style={{ height: '370px', overflow: 'auto', paddingBottom: '20px' }}>
                    <div className={style.avatar}>
                        <img src={item.robot_icon_bigger} alt="" />
                    </div>
                    <div className={style.row}>
                        <div className={`${style.label} ${style.name}`}>{util.locale("im_name_robot")}</div>
                        <div className={style.text}>{item.name}</div>
                    </div>
                    <div className={`${style.row}`}>
                        <div className={`${style.label}`}>{util.locale("im_type_of")}</div>
                        <div className={style.text}>{item.type_name}</div>
                    </div>
                    <div className={`${style.row} ${style.chatDesc}`}>
                        <div className={`${style.label}`}>{util.locale("im_robot_discription")}</div>
                        <div className={style.text}>{item.robot_desc}</div>
                    </div>

                    {this.isEdit || this.isReadOnly ? (
                        <div className={style.row}>
                            <div className={`${style.label}`}>{util.locale("im_add_by")}</div>
                            <div className={style.text}>{item.cuser_name}</div>
                        </div>
                    ) : null}
                </div>
                {this.isAdd ? (
                    <div className={`${style.noticeFooter} ${style.add}`}>
                        <div className={style.left}></div>
                        <div className={style.btnGroup}>
                            <button className={`${style.btn}`} onClick={this.goEditList}>
                                {util.locale("im_cancel")}
                            </button>
                            <Button
                                loading={loading}
                                style={{ marginLeft: '30px' }}
                                className={`${style.primary} ${style.btn}`}
                                onClick={addRobot}
                            >
                                {util.locale("im_add")}
                            </Button>
                        </div>
                    </div>
                ) : null}

                {this.isEdit || this.isReadOnly ? (
                    <div className={`${style.noticeFooter} ${style.edit}`}>
                        <div className={style.left}>
                            {this.isEdit ? (
                                <div className={style.delSec}>
                                    <span
                                        style={{ fontSize: '14px' }}
                                        className="iconfont-yach yach-bianjijiqiren-shanchujiqiren"
                                    ></span>
                                    <span onClick={this.showModal} className={style.delText}>
                                        {util.locale("im_delete_robot")}
                                    </span>
                                </div>
                            ) : null}
                        </div>
                        <div className={style.btnGroup}>
                            <button className={`${style.btn}`} onClick={this.goEditList}>
                                {util.locale("im_cancel")}
                            </button>
                        </div>
                    </div>
                ) : null}

                <CommonModal
                    modalTile={this.state.modalInfo.titile}
                    okText={this.state.modalInfo.okText}
                    cancelText={this.state.modalInfo.cancelText}
                    modalVisible={modalVisible}
                    setOKModal={this.state.modalInfo.onOk}
                    setonCancelModal={this.hideModal}
                    modalContent={this.state.modalInfo.content}
                />
            </div>
        );
    }
}
const mapDispatchToProps = dispatch => {
    return {
        robotChangeState: v => dispatch(robotChangeState(v)),
        robotDetailModalSet: v => dispatch(robotDetailModalSet(v)),
        addRobot: () => dispatch({ type: ROBOTS_ADD_ROBOT_FETCH }),
        delRobot: () => dispatch({ type: ROBOTS_DEL_ROBOT_FETCH }),
        inUseRobotsFetch: () => dispatch({ type: ROBOTS_INUSE_FETCH })
    };
};
const mapStateToProps = (state, ownProps) => ({
    modalVisible: state.robots.modalVisible,
    loading: state.robots.loading
});

export default connect(mapStateToProps, mapDispatchToProps)(NoticeCommonRobotDetail);
