import React from 'react';
import { connect } from 'react-redux';

import css from '../index.scss';

// util
import * as util from '@u/util.js';

import ReplyEmots from '@c/common/reply-emots';

import Translate from '@c/common/translate';

import TranslateState from '@c/common/translate-state';

import _ from 'lodash';

export default class BoxContentMessageText extends React.Component {

    shouldComponentUpdate(nextProps, nextState) {
        if (_.isEqual(this.props, nextProps)) return false;
        return true;
    }

    render() {
        let { 
            text, messageExtraData, custom, flow, isTeam, target, idClient, time, emots, type, content, isInAt, atHighlighted, filterText, clickEmot, replyMsg,
            translating, translateAndReduction, isOriginal, translateText,
        } = this.props;

        const emotsProps = {
            target, idClient, time, flow, emots, type, content,clickEmot
        }

        if(isTeam && custom) {
            messageExtraData = messageExtraData || {};
            const atCallback= messageExtraData['at_callback'] || {};
            const readFlag = flow == 'out';
            text = atHighlighted({text, customContent: custom, readers: atCallback, readFlag});

        }else{
            text = filterText(text);
        }

        return (
            <div className={css.content}>
                {text}
                {!isOriginal && <Translate translating = {translating} translateText = {translateText} flow = {flow}/>}
                {emots && !!emots.length && <ReplyEmots {...emotsProps}/>}
                {!isOriginal && 
                    <div className={`${css.translateState} ${isInAt ? css.translateIsInAt : ''}`}>
                        <TranslateState translating = {translating} translateAndReduction = {translateAndReduction}/>
                    </div>
                }
                {isInAt && util.yach.checkVoteReplay() &&
                    <div className={css.reply} onClick={replyMsg}>
                        {util.locale('im_reply')}
                    </div>
                }
            </div>
        );
    }
}