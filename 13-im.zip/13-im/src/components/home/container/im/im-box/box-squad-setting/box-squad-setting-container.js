/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-04-16 14:36:32
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-09-17 16:44:13
 */
/** 
 *  此文件为小组设置，已废弃。小组设置跟群聊走的统一设置(../setting-bottom.js), 暂时没有删除此文件。
*/
// react
import React from 'react';
import {connect} from 'react-redux';
import {message} from 'antd';

// component
import BoxSquadSetting from './box-squad-setting';
import * as util from '@/utils/util';

//services
import { squadDetails } from '@s/squad/squad';
import {sessionTopAdd, sessionTopCancel} from "@/services/session/session";

// BoxSquadSettingContainer
class BoxSquadSettingContainer extends React.Component {
    state = {
        squadDetails: ''
    };

    componentDidMount() {
        this.squadDetailsGet();
    }

    squadDetailsGet = async () => {
        // const {id} = await this.props.sessionActive || {};
        const { id } = window.session_active;
        // 请求details接口
        const datas = await squadDetails({squad_id: id});
        if (datas) {
            const {code, obj = {}} = datas || {};
            if (code === 200) {
                this.setState({
                    squadDetails: obj.data
                });
            }
        }
    };

    // 置顶
    handleFixtop = async value => {
        // const {id} = this.props.sessionActive;
        const { id } = window.session_active;
        if (value) {
            await util.nim.handleFixtop(id,true);
            sessionTopAdd({top_id: id});
        } else {
            await util.nim.handleFixtop(id,false);
            sessionTopCancel({top_id: id});
        }
    };

    // 消息免打扰
    handleNodisturb = async value => {
        // const {id, type} = this.props.sessionActive;
        const { id, type } = window.session_active;
        if (value) {
            await util.nim.handleMuteList(type, id, true);
        } else {
            await util.nim.handleMuteList(type, id, false);
        }
    }

    render() {
        const {squadDetails} = this.state;
        // const {sessionList, sessionActive} = this.props;
        const { sessionList } = this.props;
        const sessionActive = window.session_active;

        const {isTop, showimg, showname, disnotice} =
        sessionList.filter(item => {
            return item.id == sessionActive.id;
        })[0] || {};
        const props = {
            isTop,
            showimg,
            showname,
            squadDetails,
            disnotice,
            onFixtop: this.handleFixtop,
            onNodisturb: this.handleNodisturb
        };
        return <BoxSquadSetting {...props} />;
    }
}

const mapStateToProps = state => {
    return {
        userInfo: state.userInfo,
        // sessionActive: state.sessionActive,
        sessionList: state.sessionList
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxSquadSettingContainer);
