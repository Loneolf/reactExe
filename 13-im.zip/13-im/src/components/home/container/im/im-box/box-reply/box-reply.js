import React from 'react';

import css from './index.scss';
import * as util from '@/utils/util';
export default props => (
    <div className={css.box} ref={ref=>props.setBoxReplyRef(ref)}>
        <div className={css.replyContent} onClick={props.goMessagePlace}>
            <p>{props.name}</p>
            <pre>
                {(props.customContent && props.customContent.type === 6) ? util.locale('media_reply')+'：' : ''}{props.content}
            </pre>
        </div>
        <span className={`iconfont-yach yach-goutong-wenzihuifulan-guanbiicon-moren ${css.iconguanbi}`} onClick={props.closeReply}></span>
    </div>
);
