// react
import React from 'react';
import { Input } from 'antd';

// css
import css from './index.scss';

import moment from 'moment';
import * as util from '@/utils/util';
export default class BoxSeachHistory extends React.Component{
    constructor(props){
        super(props)
    }
    
    render(){
        return(
            <div className={css.box}>
                <div className={css.inputContent}>
                    <Input
                        placeholder={util.locale("im_search_history_messages")} 
                        allowClear
                        value={this.props.slideSearch}
                        onChange={this.props.seachData}
                        prefix={<span className={`${css.input_icon} iconfont-yach yach-goutong-sousuoliaotianjilu`} />}
                        onKeyDown = {this.props.keyDownhandle}
                    />
                </div>
                {
                    !this.props.noData && this.props.textList.length === 0 &&
                    <div className={css.noData}>
                        <span className={`${css.noData_icon} iconfont-yach yach-sousuowujieguo`}></span>
                        <p className={css.adjust_place}>{util.locale("im_search_information_from_chat_messages")}</p>
                    </div>
                }
                {!this.props.noData &&
                    <ul>
                    {this.props.textList && this.props.textList.length >0 &&
                        this.props.textList.map(item=>(
                            <li key={item.idClient} onClick={()=>this.props.setIdClient(item.idClient, item.time)}>
                                <div className={css.item}>
                                    <div className={css.info}>
                                        <img src={item.avatar} />
                                    </div>
                                    <div>
                                        <div className={css.infoBox}>
                                            <span>{item.fromNick}</span>
                                            <span>{moment(parseInt(item.time)).format(
                                            'YYYY-MM-DD HH:mm:ss'
                                            )}</span>
                                        </div>
                                        <p  dangerouslySetInnerHTML={{__html:item.text}}></p>
                                    </div>
                                </div>
                            </li>
                        ))
                    }
                </ul>
                }
                {this.props.noData &&
                    <div className={css.noData}>
                        <span className={`${css.noData_icon} iconfont-yach yach-sousuowujieguo`}></span>
                        <p>{this.props.noData}</p>
                    </div>
                }
            </div>
        )
    }
}