// react
import React from 'react';

// css
import css from './index.scss';

// component
import UserAdd from '@c/common/user-add/user-add-container';

import CommonModal from '@/components/common/common-modal';
import * as util from '@u/util.js';

import { Modal } from 'antd';

// BoxSend
export default class BoxMultipleForwarding extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        let iconClass = '';
        const { selectList } = this.props;
        if(!selectList || selectList.length == 0){
            iconClass = 'icon-stateless';
        }
        return (
            <div className={css.box} id='boxMultipleForwarding'>
                <div className={css.forwarding}>

                    <div className={css.icon}>
                         <div className={css.forwardBut+' '+css.common}>
                             <span className={`iconfont-yach yach-duoxuanzhuanfa-fasong-hebingzhuanfa-moren ${iconClass}`} onClick={this.props.forwarding}/>
                             <p className={css.iconClassText}>{util.locale("im_merge_forward")}</p>   
                         </div>

                         <div className={css.mutilDel+' '+css.common}>
                             <span className={`iconfont-yach yach-pcduanduoxuanzhuanfashanchu ${iconClass}`} onClick={this.props.deleteSelectMsg}/>
                             <p className={css.iconClassTex}>{util.locale("im_message_action_delete_text")}</p> 
                         </div>
                    </div>
                    <a className="iconfont-yach yach-duoxuanzhuanfa-fasong-guanbi-moren" onClick={this.props.forwardingClose}/>
                </div>

                <UserAdd {...this.props.forwardMsgProps} />
                <CommonModal
                    modalTile={''}
                    modalVisible={this.props.warnVisible}
                    setOKModal={this.props.warnCancelModal}
                    setonCancelModal={this.props.warnCancelModal}
                    modalContent={this.props.warnContent}
                    cancelButtonProps={{ style: {backgroundColor: ' #326FEF', color: '#FFFFFF'} }}
                    okButtonProps={{ style: { display: 'none' } }}
                    cancelText={util.locale("im_get_it")}
                />

                {/* 删除交互框 */}
                <Modal
                    visible       = {this.props.deleteDialog}
                    onOk          = {this.props.deleteSelectMsgOk}
                    onCancel      = {this.props.deleteSelectMsgCan}
                    centered      = {true}
                    closable      = {!1}
                    maskClosable  = {!1}
                    bodyStyle     = {{fontSize:14, fontWeight:500, color:'#2F3238' }}
                    wrapClassName = {css.wrapClassName}
                >
                   <p>{util.locale("im_message_action_delete_dialog")}</p>
                </Modal>


            </div>
        );
    }
}
