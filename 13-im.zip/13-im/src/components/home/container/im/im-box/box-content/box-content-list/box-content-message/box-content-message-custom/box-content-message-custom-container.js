import React from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { message } from 'antd';

import MessageCustom from './box-content-message-custom';

import { showSlideModal } from '@r/actions/commonModal';
import { recordDetailCurridSet } from '@r/actions/record';
// redux
import { showPreviewModal } from '@r/actions/commonModal.js';
import { showMeetingStateAction, switchOnlineState, setEnterMeetingStatus } from '@/redux/actions/calender';
//import { fileDownloadProgressAdd, fileDownloadProgressUpdate, fileDownloadProgressRemove } from '@/redux/actions/file'
import * as fileRedux from '@/redux/actions/file'
import * as messageUploadAction from '@r/actions/messageListUploadState';


// service
import { fileRangeList } from '@s/file/file-list';
import { fileView } from '@s/file/file-info'
// util
import * as util from '@u/util.js';
// server
import { convertOnlineDoc, convertProgress} from '@s/group/group-doc';
// debounce
import {debounce,throttle} from 'lodash';

import { meetingGroupUserJoin, meetingLeaveEnd, meetingGroupUserLeave, meetingFullScreenState, meetingHeart } from '@/services/meeting/meeting.js';

import VideoSessione from '@c/common/video-session/video-session-container';
import { videoSessionlHide, videoSessionShow } from '@/redux/actions/commonModal';

import { agoraRTMChannelListen } from '@u/lib/agora/agora-rtm-listen.js';
import { saveTid, handleJoinFail, cancelAllCall, meetingCreateJoinFun } from '@u/lib/zoom/zoomFn';


let reportState = {
    userid: '', //当前账号对应的zoom userid
    event_duration: 0, //说话时长
    talk_start: 0,
    end_talk: 0,
    notalk_start: 0
};
window.enterMeetingList = null;
let heartTimer = null;
class MessageCustomContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            imageDisabled: true,
            imgUrl: '',
            meetingFinish: false,
            onlineMeetingId: null,
            sourceType: null,
            sourceId: null,
            leave: false,
            os: util.electron.isMac() ? 'mac' : 'windows',
            isDownload: false,
            filePath: null,
            againDownload: false,
            isLoading: false,
            loopfntime: 20,             // 定时器的循环时间
            meetingHasPeople: false,    // 会议室是否有人临时变量
            teamInfo: null,
            showVideo: false,
            params:{},
        }
        this.convertOnlineDocInterval = null
    }

    componentDidMount() {
        this.startCall = debounce(this.startCall, 500);
        this.clickVideo = debounce(this.clickVideo, 500);
        this.editMeetingSummary = debounce(this.editMeetingSummary, 500);
        this.openDocment = debounce(this.openDocment, 500);
        this.expressClick = throttle(this.expressClick, 500);

        //util.electronipc.electronDownloadFileDestory({channelid: '9mgl8a1wet'});
    }

    // detail
    gotoRecord = async data => {
        let id = data.id || data.workLogId
        let params = data.params
        this.props.dispatch(recordDetailCurridSet(id));
        this.props.dispatch(showSlideModal('record', { params }));
        // util.sensorsData.track('PageView_WeeklyReportDetail',{source: 105,WeeklyReport_Id:id});
    };

    goHistoricalRecord = (value) => {
        // console.log('点击了我', value);
        this.props.dispatch(showSlideModal('historicalRecord', {...value, type:1}));
    }


    /**
     * type,customContent,props 暂时只针对回复文件夹消息，其他类文件等暂时没这个需求，不处理
     */
    openFileExternal = async (fileUrl,type,customContent,props) => {
        if(type === 26){
            const replyMsg = props.msg && props.msg.content && JSON.parse(props.msg.content);
            let isDownloadFlag = false;
            if(replyMsg && replyMsg.type && replyMsg.type === 6){
                // let idClient = replyMsg.data && replyMsg.data.idClient;
                // let local = replyMsg.data && replyMsg.data.localCustom;
                // let downloadstatus = props.fileDownloadProgress.find(v => v.id ==idClient);
                // (local && local.isDownloadFlag) && (isDownloadFlag = true);
                // // 已经下载好的打开
                //  this.fileDownload(fileUrl, idClient,customContent.data.fileName, !!downloadstatus,type,'dirReply')
                const params={
                    isMultiSelect:this.props.isMultiSelect,relation_id:customContent.data.relationId,fileName:customContent.data.fileName,
                    type:this.props.sessionActive.type
                }
                util.cosfiles.goFloderPreview(params);
            }
            return false;
        }

        const ext = fileUrl.substring(fileUrl.lastIndexOf('.') + 1);
        // 地址签名
        let signurldata = await util.cosfiles.getCosSignUrl(fileUrl)

        // office
        if (/doc|docx|xls|xlsx|pptx|ppt/i.test(ext)) {
            fileUrl = signurldata.signurlpreview || fileUrl
            let url = encodeURIComponent(decodeURIComponent(fileUrl))
            fileUrl = util.config.preview.office + url
            window.open(fileUrl)
            return false
        }

        // pdf
        if (/pdf/i.test(ext)) {
            fileUrl = signurldata.signurlpreview || fileUrl
            let pdfprepath = util.config.preview.pdf
            let url = encodeURIComponent(decodeURIComponent(fileUrl))
            if (fileUrl.includes('yach-xstatic.zhiyinlou.com')) pdfprepath = util.config.preview.pdfx
            fileUrl = pdfprepath + url
            window.open(fileUrl)
            return false
        }

        // other file
        fileUrl = signurldata.signurl || fileUrl
        window.open(fileUrl)
    }

    showOffice = async (url, fileName, id) => {
        // let signurldata = await util.cosfiles.getCosSignUrl(url)
        // url = signurldata.signurlpreview || url

        let resurl = { signurlpreview: url };
        let param = {};
        let data = await fileView({relation_id:id});

        if(!data || data.code !== 200 || !data.obj) return;

        // office
        if(Object.keys(data.obj.wps).length === 0){
            resurl.signurlpreview = data.obj.default.presignet_url_view;
            util.electronipc.electronOpenFilepreview({
                file: resurl.signurlpreview,
                name: fileName,
            })
            return;
        }

        // wps
        if( data.obj.wps.code == 0){
            resurl.signurlpreview = data.obj.wps.path;
        } else {
            const { fileInfo3rd,wpsUrl } = data.obj.wps.requestData
            resurl.signurlpreview = wpsUrl;
            param = fileInfo3rd;
        }

        util.electronipc.electronOpenFilepreview({
            file: resurl.signurlpreview,
            name: fileName,
            param
        })
    };

    getFileSpeed = speed => {
        if (speed > 1000000) {
            return (speed / 1024 / 1024).toFixed(2) + ' MB/S';
        } else if (speed < 1000000) {
            return (speed / 1024).toFixed(2) + ' KB/S';
        }
    }

    // fileDownload = async (url, idClient, name, isdownloading,stype,from) => {
    fileDownload = async ({url, idClient, name, isdownloading,stype,from,relationId}) => {

        util.log('qiuyanlong','fileDownload chat:url, idClient, name, isdownloading,stype',url, idClient, name, isdownloading,stype)
        if (isdownloading) return false
        if(stype === 26){
            this.props.dispatch(messageUploadAction.setDownloadingState({[idClient]:true}));
        }
        // util.cosfiles.fileDownload(idClient, url, name,stype,from);
        util.cosfiles.fileDownload({idClient, url, name,stype,from,relationId});
    }


    fileDownloadCancel = id => {
        this.props.dispatch(fileRedux.fileDownloadProgressRemove(id))
        let file = this.props.fileDownloadProgress.find(v => v.id == id)
        if (!file) return false
        util.electronipc.electronDownloadFileDestory({channelid: file.channelid});
        util.log('qiuyanlong', 'yach-im', 'upload:cancel',id, file && file.channelid||'');
        this.props.dispatch(messageUploadAction.setDownloadingState({[id]:false}));

    }

    openFile = ({path, idClient,type,fname,relation_id}) => {
        util.log('qiuyanlong','openFile chat:path:idClient:type',path, idClient,type);
        if (!path) return
        util.electronipc.electronCheckFile({ path }, (res) => {
            console.log('qiuyanlong','openfile res',res);
            if (res) {
                // type === 26 ? util.electronipc.electronOpenDirectory({ path }) : util.electronipc.electronOpenFile({ path });
                util.electronipc.electronOpenFile({ path }) // 11中已把打开文件/文件夹、 打开文件/文件夹所在目录单独处理
            } else {
                type === 26 &&  message.warning(`${util.locale('im_file_uoliad_dir_xxx_moved').replace('[xxx]',fname)}`);
                let filestatus = {
                    id: idClient,
                    isDownloaded: false,
                    downloadedPath: ''
                }
                this.props.dispatch(fileRedux.fileStatusUpdate(idClient, filestatus))
                // util.nimUtil.updateLocalMsg(idClient, { isDownloadFlag: false, path: null });
                util.cosfiles.fileDownloadStatusUpdate({path:null,key:relation_id});

            }
        })
    }

    // 打开文件所在的文件夹
    openFileDir = ({path, idClient, type,relation_id}) => {
        console.log('baogumei-path', path, idClient, type)
        if (!path) return;

        util.electronipc.electronCheckFile({ path }, (res) => {
            if (res) {
                util.electronipc.electronOpenDirectory({ path })
            } else {
                message.warning(`${util.locale('im_open_folder_err_msg')}`);
                let filestatus = {
                    id: idClient,
                    isDownloaded: false,
                    downloadedPath: ''
                }
                this.props.dispatch(fileRedux.fileStatusUpdate(idClient, filestatus))
                // util.nimUtil.updateLocalMsg(idClient, { isDownloadFlag: false, path: null });
                util.cosfiles.fileDownloadStatusUpdate({path:null,key:relation_id});
            }
        });
    }

    convertOnlineDoc = async (data, title) => {
        util.log('panghaojie', 'box-content-message-custom-container.js', 'convertOnlineDoc', title);
        //需要先获取签名地址，才能生成可打开的在线文档，保证在线文档的有效期
        const hide = message.loading(this.locale('im_converting'), 0); // 转换中
        let signUrlData = await util.cosfiles.getCosSignUrl(data.fileUrl)

        //调用接口的方法里已做过接口返回错误的处理
        if (signUrlData && signUrlData.signurl) data.fileUrl = signUrlData.signurl;

        //由于复杂的excel文件转换为在线文档时耗时较长，会出现超时，提示用户转换失败，实际已经转换成功，故对excel文件专门处理
        //轮询请求转换进度，进度达到100并且文档url不为空，即转换完成

        if(data.fileType == 3){
            data.new = true//只有excel才添加这个字段
            let convertRes = await convertOnlineDoc(data)
            if(convertRes.code != 200){
                hide();
                message.error(convertRes.msg);
                return;
            }
            if(convertRes.obj && convertRes.obj.url && !convertRes.obj.taskId){
                //已转换过的excel
                hide()
                this.goShimo(convertRes.obj, title)
                return;
            }
            if(convertRes.obj && !convertRes.obj.url && convertRes.obj.taskId && convertRes.obj.key && convertRes.obj.interval){
                await this.convertProgress({
                    relationId: data.relationId,
                    creatorId: data.creatorId,
                    receiver: data.receiver,
                    type: data.type,
                    taskId: convertRes.obj.taskId,
                    key: convertRes.obj.key
                },convertRes.obj.interval,hide,title)
            }
        }else{
            let res = await convertOnlineDoc(data)
            if (res.code != 200 || !res.obj || !res.obj.url) {
                hide();
                message.error(res.msg);
                return;
            }
            hide()
            this.goShimo(res.obj, title)
        }
    }

    convertProgress = async(params,interval,hide,title) => {
        clearInterval(this.convertOnlineDocInterval)
        this.convertOnlineDocInterval = null
        this.convertOnlineDocInterval = setInterval(async ()=>{
            util.log('panghaojie', 'box-content-message-custom-container.js', 'setInterval');
            let res = await convertProgress(params)
            if(res.code != 200 || !res.obj){
                hide();
                message.error(res.msg);

                clearInterval(this.convertOnlineDocInterval)
                this.convertOnlineDocInterval = null
                return
            }
            if(res.obj.url && res.obj.progress == 100){
                clearInterval(this.convertOnlineDocInterval)
                this.convertOnlineDocInterval = null
                hide()
                this.goShimo(res.obj, title)
            }
        },+interval*1000)
    }

    goShimo = (data, title) => {
        let token = btoa(util.yachLocalStorage.ls('yach_usertoken'))
        const url = util.summaryUtil.handleShimoUrl({
            sessionActive: this.props.sessionActive,
            link: data.url
        })
        util.electronipc.electronAddWebview({
            url: `${util.config.shimoHost}document/index?url=${url}&token=${token}`,
            name: title,
            disableClose: true
        })
    }

    getOfficeType = (file) => {
        util.yach.getFileType(file)
        switch (util.yach.getFileType(file)) {
            case '_word':
                return 1;
            case '_ppt':
                return 2;
            case '_excel':
                return 3;
        }
    }

    showImg = (url, data) => {
        try {
            if (util.electron.isElectron()) {
                if (JSON.parse(data.content).data.hasOwnProperty('relationId')) {
                    let relation_id = JSON.parse(data.content).data.relationId;
                    this.getFileList(relation_id, data);
                } else {
                    let content = JSON.parse(data.content)
                    this.setState({
                        data: {
                            success: true,
                            data: [{
                                name: content.data.fileName,
                                url: this.getMsgImg(content.data.fileOriginUrl),
                                id: content.data.relationId,
                                curr: true,
                                width: content.data.width,
                                height: content.data.height
                            }],
                            id: ''
                        }
                    }, () => {
                        util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                            this.getFileList(id, data)
                        });
                    });
                }
            } else {
                this.props.dispatch(showPreviewModal({ type: 'img', url: url }));
            }
        } catch (error) {
            console.log('MessageCustomContainer', error);
        }
    };
    replyImageMessageShowImg = (url, data) => {
        try {
            if (util.electron.isElectron()) {
                if (data.hasOwnProperty('relationId')) {
                    let relation_id = data.relationId;
                    this.replyImageMessageGetFileList(relation_id, data);
                } else {
                    this.setState({
                        data: {
                            success: true,
                            data: [{ url: data.fileOriginUrl, name: data.fileName, id: data.relationId, curr: true }],
                            id: ''
                        }
                    }, () => {
                        util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                            this.replyImageMessageGetFileList(id, data)
                        });
                    });
                }
            } else {
                this.props.dispatch(showPreviewModal({ type: 'img', url: url }));
            }
        } catch (error) {
            console.log('MessageCustomContainer', error);
        }
    }
    replyImageMessageGetFileList = async (relation_id, wdata) => {
        let formData = {
            receive_id: this.props.sessionActive.id,
            relation_id,
            max: 30,
            img: 'img'
        }
        try {
            const data = await fileRangeList(formData)
            if (data && data.code === 200) {
                const { obj } = data;
                let largeFileInfo = obj.largeFileInfo.map((item) => {
                    return {
                        url: this.getMsgImg(item.file_url),
                        name: item.file_name,
                        id: item.relation_id,
                        curr: false,
                        width: item.width,
                        height: item.height
                    }
                })
                let lessFileInfo = obj.lessFileInfo.reverse().map((item) => {
                    return {
                        url: this.getMsgImg(item.file_url),
                        name: item.file_name,
                        id: item.relation_id,
                        curr: false,
                        width: item.width,
                        height: item.height
                    }
                });
                let currentFileInfo = {
                    url: this.getMsgImg(wdata.fileOriginUrl),
                    name: wdata.fileName,
                    id: wdata.relationId,
                    curr: true,
                    width: wdata.width,
                    height: wdata.height
                }
                let allPicFiles = [...lessFileInfo, currentFileInfo, ...largeFileInfo];
                this.setState({
                    data: {
                        success: true,
                        data: allPicFiles,
                        id: wdata.relationId
                    }
                }, () => {
                    util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                        this.getFileList(id, wdata)
                    });
                })
            } else {
                this.setState({
                    data: {
                        success: false,
                        data: [{ url: wdata.fileOriginUrl, name: wdata.fileName, id: wdata.relationId, curr: true }],
                        id: wdata.relationId
                    }
                }, () => {
                    util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                        this.getFileList(id, wdata)
                    });
                });
                message.error(`${this.locale('im_failed_to_get')}`); // 获取失败
            }
        } catch (err) {
            this.setState({
                data: {
                    success: false,
                    data: [{ url: wdata.fileOriginUrl, name: wdata.fileName, id: wdata.relationId, curr: true }],
                    id: wdata.relationId
                }
            }, () => {
                util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                    this.getFileList(id, wdata)
                });
            });
        }
    }
    getFileList = async (relation_id, wdata) => {
        let formData = {
            receive_id: this.props.sessionActive.id,
            relation_id,
            max: 30,
            img: 'img'
        }
        try {
            const data = await fileRangeList(formData)
            if (data && data.code === 200) {
                const { obj } = data;
                let largeFileInfo = obj.largeFileInfo.map((item) => {
                    return {
                        url: item.file_url,
                        name: item.file_name,
                        id: item.relation_id,
                        curr: false,
                        width: item.width,
                        height: item.height
                    }
                })
                let lessFileInfo = obj.lessFileInfo.reverse().map((item) => {
                    return {
                        url: item.file_url,
                        name: item.file_name,
                        id: item.relation_id,
                        curr: false,
                        width: item.width,
                        height: item.height
                    }
                });
                let currentFileInfo = {
                    url: JSON.parse(wdata.content).data.fileOriginUrl,
                    id: JSON.parse(wdata.content).data.relationId,
                    name: JSON.parse(wdata.content).data.fileName,
                    curr: true,
                    width: JSON.parse(wdata.content).data.width,
                    height: JSON.parse(wdata.content).data.height
                }
                let allPicFiles = [...lessFileInfo, currentFileInfo, ...largeFileInfo];
                this.setState({
                    data: {
                        success: true,
                        data: allPicFiles,
                        id: JSON.parse(wdata.content).data.relationId
                    }
                }, () => {
                    util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                        this.getFileList(id, wdata)
                    });
                })
            } else {
                let content = JSON.parse(wdata.content)
                this.setState({
                    data: {
                        success: false,
                        data: [{
                            url: content.data.fileOriginUrl,
                            name: content.data.fileName,
                            id: content.data.relationId,
                            curr: true,
                            width: content.data.width,
                            height: content.data.height
                        }],
                        id: content.data.relationId
                    }
                }, () => {
                    util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                        this.getFileList(id, wdata)
                    });
                });
                message.error(`${this.locale('im_failed_to_get')}`); // 获取失败
            }
        } catch (err) {
            let content = JSON.parse(wdata.content)
            this.setState({
                data: {
                    success: false,
                    data: [{
                        url: content.data.fileOriginUrl,
                        name: content.data.fileName,
                        id: content.data.relationId,
                        curr: true,
                        width: content.data.width,
                        height: content.data.height
                    }],
                    id: content.data.relationId
                }
            }, () => {
                util.electronipc.electronOpenImage(this.state.data, undefined, (id) => {
                    this.getFileList(id, wdata)
                });
            });
        }
    }


    // 说明： 说明，下面逻辑 if 判断，  2/3  和 6/7 可以合并。 由于上线前临时修改，时间比较紧张，没优化。。。
    /**
     * url: 源地址
    */
    getImgScale = (height, width) => {
        if (!height || !width) {
            return {typeNum: 3}
        }
        let WHFlag = width > height ? true : false,
            COMMON_SCALE_WH = 0.18, // (9 / 50)
            scaleWH = width / height,
            scaleHW = height / width,
            isSmallFlag = width <= 10 && height <= 10,
            imgSize = {};
        imgSize.typeNum = 0
        //宽高比例 几中情况: (高大于宽)
        // 1, scaleWH 介于 1:1 - 9:50 之间
        if (!isSmallFlag && !WHFlag && (1 >= scaleWH >= COMMON_SCALE_WH) && width > 10) {
            // （height <= 200，是判断图片原始尺寸是否大于索要设置的 max-height= 2000）
            if (height <= 200) {
                imgSize.width = width;
                imgSize.height = height;
            } else {
                imgSize.width = parseInt(width * 200.0 / height);
                imgSize.height = 200;
            }
        }


        // 2，scaleWH 超过 9:50 (高度如果不大于 200px，max-height: 200px;width: 60px;)
        if (!isSmallFlag && !WHFlag && scaleWH < COMMON_SCALE_WH && height <= 200 || (width <= 10 && height > 10)) {
            imgSize.width = 60
            imgSize.height = parseInt(60.0 * height / width)
            imgSize.typeNum = 1
        }
        // 3，scaleWH 超过 9:50 (高度如果大于 200px,则从上截取200px,width: 60px;)
        if (!isSmallFlag && !WHFlag && scaleWH < COMMON_SCALE_WH && height > 200) {
            imgSize.width = 60;
            imgSize.height = parseInt(60.0 * height / width);
            imgSize.typeNum = 1
        }

        //高宽比例 几中情况: (高小于宽)   10 * 6
        // 5, scaleHW 介于 1:1 - 9:50 之间
        if (!isSmallFlag && WHFlag && (1 >= scaleHW >= COMMON_SCALE_WH) && height > 10) {
            if (width <= 324) {
                imgSize.width = width;
                imgSize.height = height;
            } else {
                imgSize.width = 324;
                imgSize.height = parseInt(height * 324.0 / width);
            }
        }
        // 6，scaleHW 超过 9:50  （max-width: 324px, height: 60px;）
        if (!isSmallFlag && WHFlag && scaleHW < COMMON_SCALE_WH && width <= 324 || (height <= 10 && width > 10)) {
            imgSize.height = 60;
            imgSize.width = parseInt(width * 60.0 / height)
            if (imgSize.width >= 324) imgSize.typeNum = 2
        }
        // 7，scaleHW 超过 9:50  （max-width: 324px,中间截取 (width:324,height:60)）
        if (!isSmallFlag && WHFlag && scaleHW < COMMON_SCALE_WH && width > 324) {
            imgSize.height = 60;
            imgSize.width = parseInt(width * 60.0 / height)
            if (imgSize.width >= 324) imgSize.typeNum = 2
        }

        if (isSmallFlag) {
            imgSize.width = 60;
            imgSize.height = 60;
        }

        //  ------   改版之前最初的逻辑    ---------
        // if (!width || !height) return;
        // let scale = 1,
        //     maxWidth = 200,
        //     maxHeight = 200;
        // if(width*scale > maxWidth) {
        //     scale = maxWidth/width;
        // }
        // if(height*scale > maxHeight){
        //     scale = maxHeight / height;
        // }
        return imgSize;
    }

    imgError = (imgUrl) => {
        this.setState({ imageDisabled: false, imgUrl });
    }

    refreshImg = () => {
        const node = document.getElementById(this.props.idClient + 'img');
        if (!node) return;
        node.src = this.state.imgUrl;
        node.onload = () => {
            this.setState({ imageDisabled: true });
        }
    }

    reportVideoChange = () => {
        let userId, videoStatus;
        util.electronipc.electronChannelListen('zoomapivideostatuschangecb', obj => {
            if (!userId) {
                userId = obj.userId
            }
            if (userId === obj.userId && videoStatus !== obj.videoStatus) {
                const zoomInfo = util.yachLocalStorage.ls('zoom_login');
                // 摄像头打开
                try {
                    util.sensorsData.track('Click_Chat_Element', {
                        pageName: '01-103',
                        $element_name: '01-104',
                        OperateType: obj.videoStatus ? '01-101' : '01-102',
                        meeting_id: zoomInfo.meetingNum,
                        meeting_name: zoomInfo.meetingName
                    });
                } catch (error) {
                } finally {
                    videoStatus = obj.videoStatus
                }
            }
        })
    }

    joinMeeting = (params,textInputValue,isvideooff,isaudiooff) => {
        util.log('panghaojie', 'box-content-message-custom-container.js', 'joinMeeting', );
        const { schedule = false, daily_meeting } = params
        let Stype = '';
        if (schedule) {
            if (daily_meeting) {
                //日会日程
                Stype = '01-102';
            } else {
                //普通日程
                Stype = '01-101';
            }
        }
        let newContent = {};
        try {
            newContent = JSON.parse(this.props.content);
            this.setState({
                onlineMeetingId: newContent.data.online_meeting_id,
                sourceType: newContent.data.source_type,
                sourceId: newContent.data.source_id,
                Stype,
                showVideo: false
            },() => {
                if (newContent && newContent.data && newContent.data.zoomId) {
                    this.zoomJoinUnlogin(newContent,textInputValue,isvideooff,isaudiooff,daily_meeting);
                }
            });
        } catch (error) {
            util.log('panghaojie', 'box-content-message-custom-container.js', 'joinMeeting-err',error);
        }
    }

    addMeetingListen = (newContent, startTimer = 0) => {
        util.electronipc.electronChannelListen('zoomapimeetingstatuscb', obj => {
            const { result, status } = obj;
            util.log('panghaojie', 'box-content-message-custom-container.js', 'zoomapimeetingstatuscb', result, status);
            if ((status == 6 && result == 6) || (status == 6 && result == 8)) { // 会议结束
                this.meetingFinish();
            }
            if (status == 6 && result) {
                message.warning(util.locale.getLang() === "en-US"?util.zoomErrorCode.zoomMeetingFailCodeEn[`${result}`]:util.zoomErrorCode.zoomMeetingFailCode[`${result}`]);
                util.sensorsData.track('Error_Chat', {
                    error_code: 1004,
                    submodule: '01-101'
                })
            }
            if (status == 7 && result == 0) { // 主动离开
                if (newContent.data.zoomId) {
                    this.leaveMeeting(newContent.data.zoomId);
                    this.setMeetingStatus(false);
                }
            }
            if (status == 7 && result == 2) { // 主持人结束
                //结束会议
                if(util.yachLocalStorage.ls('inviteUserNum') && util.yachLocalStorage.ls('inviteUserNum').len > 0){
                    //自己呼叫的有人
                    cancelAllCall({online_meeting_id: newContent.data.online_meeting_id})
                }
                if (newContent.data.zoomId) {
                    this.leaveMeeting(newContent.data.zoomId);
                    this.setMeetingStatus(false);
                }
            }
            if ((status == 3 && result == 0) && newContent && newContent.data) {
                this.loginSuccessful(newContent.data);
                this.endTimerSensorsDataInit(startTimer);
            }
            if (status == 7 && result == 1) {
                message.warning(this.locale("im_you've_been_moved_out_of_meeting_host")); // 你被主持人移除出会议
                this.setMeetingStatus(false);
            }
            if (status == 0 || status == 6 || status == 7) { //参考zoom/setting.js ZoomMeetingStatus
                util.log('panghaojie', 'box-content-message-custom-container.js', 'clearInviteGroupInfo');
                //离开会议，清除选人组件参数
                util.yachLocalStorage.ls('inviteGroupInfo', null);

                util.log('panghaojie', 'box-content-message-custom-container.js', 'clearInterval');
                //清除心跳计时器
                window.clearInterval(heartTimer)
                heartTimer = null

                this.leaveFeedback();
            }
        });
    }

    leaveFeedback = async() => {
        const {os, leave } = this.state;
        util.log('panghaojie', 'box-content-message-custom-container.js', 'meetingGroupUserLeave', leave);
        const online_meeting_id = util.yachLocalStorage.ls('inviteMeetingId').online_meeting_id
        if (online_meeting_id && !leave) {
            await meetingGroupUserLeave({ //离开会议室通知后台
                online_meeting_id,
                os
            });
            //离开接口成功后，离开频道
            util.log('panghaojie','box-content-message-custom-container.js','agoraRtmClearChannel')
            util.electronipc.agoraRtmClearChannel({channelId: `meeting_${online_meeting_id || ''}`})
            this.setState({ leave: true });
        }
    }

    leaveMeeting = (zoomId) => {
        const zoomInfo = util.yachLocalStorage.ls('zoom_login');
        if (!zoomInfo) return;
        const { startTime, meetingNum, meetingName } = zoomInfo;
        const { userid, event_duration } = reportState;
        console.log('+++leaveMeeting2+++', startTime, meetingNum, meetingName, zoomId);
        if (!startTime || !meetingNum) return;
        if (meetingNum != zoomId) return;
        try {
            const { Stype } = this.state;
            util.sensorsData.track('PageClose_Chat', {
                pageName: '01-103',
                meeting_type: Stype ? Stype : '01-103',
                event_duration: ((new Date()).getTime() - startTime) / 1000,
                meeting_id: meetingNum,
                meeting_name: meetingName
            });
            if (event_duration) {
                console.log('---->>>zoom会议时长event_duration-->>', userid, event_duration);
                util.sensorsData.track('EventContinue_Chat', {
                    event_duration,
                    submodule: '01-101',
                    meeting_type: Stype ? Stype : '01-103',
                    meeting_id: meetingNum,
                    meeting_name: meetingName
                });
            }
            reportState = { talk_start: 0, notalk_start: 0, end_talk: 0, userid: '' };
        } catch (error) {
            console.log('leaveMeeting', error);
        }
        util.yachLocalStorage.ls('zoom_login', '');
    }

    meetingFinish = async () => {
        const { idClient } = this.props;
        let obj = await util.nimUtil.updateLocalMsg(idClient, { isFinish: true });
        if (obj) this.setState({ meetingFinish: true });
    }


    setMeetingStatus = (es) => {

        const { sessionActive, isInMeeting } = this.props;
        const { id } = sessionActive;
        const { id: isInId } = isInMeeting;

        window.store.dispatch(setEnterMeetingStatus({ id, es }));

        if (!es) {
            this.reclearAllVariable('close-global');
            // 这个时候再开启一次本地的定时器
        }
        else {
            this.reclearAllVariable('close-active');
        }

        // 注意开启的时候要判断，如果当前的会话和之前你进入的会话不是同一个，那么就没必要开启了
        const winds = window.store.getState().sessionActive;
        const wid = winds.id && Number(winds.id);

        // 自己退出 但是当前群内是否有人还不确定 需要再验证一下
        if (wid === Number(isInId)) {
            this.eventLoopThisFun();
        }
    }

    /*
        @销毁所有的参数
     */
    reclearAllVariable = (stype = "uninstall") => {
        if (stype === "uninstall") {
            clearTimeout(this.onlineMeetingSwitch);
            this.setState({ meetingHasPeople: false });
            this.props.dispatch(switchOnlineState(''));
        }

        // 关闭当前会话的
        else if (stype === 'close-active') {
            this.onlineMeetingSwitch && clearTimeout(this.onlineMeetingSwitch);
            this.onlineMeetingSwitch = null;

        }

        else if (stype === 'close-global') {
            console.log('所在会议退出，全局定时关');
            window.enterMeetingList && clearTimeout(window.enterMeetingList);
            window.enterMeetingList = null;
        }
    }

    /* 轮询 使用轮询来代替之前的状态接口  放弃之前的状态的接口
    */
    eventLoopThisFun = async () => {
        const { sessionActive } = this.props;
        const { type, id } = sessionActive;
        // 开启群办公室消息，并且在该群中的时候
        if (id && type === 'team') {
            this.onlineMeetingFullState()
        }
    }


    onlineMeetingFullState = async () => {
        let { type, schedule = {} } = this.state.teamInfo;
        if (type === 1) return
        const { sessionActive, isInMeeting } = this.props;
        const { id } = sessionActive;
        const { es, id: isInId } = isInMeeting;
        let cid, source_type;
        try {
            if (type === 9) {
                source_type = 3;
                cid = schedule.meeting_id;
            } else {
                source_type = 4;
                cid = id;
            }
            const meetState = await meetingFullScreenState({ source_type, source_id: cid });
            const { code, msg, obj = {} } = meetState;
            if (code === 200) {
                const { five_list = [] } = obj;
                this.props.dispatch(showMeetingStateAction({ id, list: five_list }));
                if (five_list.length > 5) { this.setState({ loopfntime: 30 }) }

                if (five_list.length <= 0) {
                    this.reclearAllVariable('close-active');
                    this.setState({ meetingHasPeople: false });
                    return
                }
                this.setState({ meetingHasPeople: true });
                // 自己在某个在线会议中 当前进入的这个群 就是目前active的这个群
                if (es && isInId === id) {
                    // 也需要管制前的定时器
                    // 从一个已经进入的群 切回到一个也正在有会议的群  这个时候就不能再关闭定
                    clearTimeout(window.enterMeetingList)
                    window.enterMeetingList = null
                    window.enterMeetingList = setTimeout(this.onlineMeetingFullState, this.state.loopfntime * 1000);
                }
                else {
                    // 自己不在某个在线会议中
                    clearTimeout(this.onlineMeetingSwitch);
                    this.onlineMeetingSwitch = null
                    this.onlineMeetingSwitch = setTimeout(this.onlineMeetingFullState, this.state.loopfntime * 1000);
                }
            } else {
                message.warn(msg);
                util.sensorsData.track('Error_Chat', {
                    error_code: 1001,
                    submodule: '01-101'
                });
            }
        } catch (e) {
            console.log('群办公室横幅错误:onlineMeetingFullState', e);
        }
    }

    zoomJoinUnlogin = async (newContent,textInputValue,isvideooff,isaudiooff,daily_meeting) => {
        let startTimer = new Date().getTime();
        const { id, type} = this.props.sessionActive;
        const { name_nick, name } = this.props.userInfo;
        let { zoomId, online_meeting_id, source_type, source_id, password } = newContent.data;
        delete newContent.data.password;//日志脱敏
        let meetingnum = zoomId;
        let username = name_nick || name;
        let os = this.state.os;
        util.log('panghaojie', 'box-content-message-custom-container.js', 'zoomJoinUnlogin', newContent, meetingnum, username);

        if (util.electron.isMac()) {
            // mac端屏蔽zoom会议里点击邀请按钮后的默认弹框，必须进入会议之前处理
            // win端sdk里处理没有问题，mac端需要特殊处理
            util.electronipc.electronZoomCallFn('disableToolbarInviteButtonClickOriginAction', true, res => {
                util.log('panghaojie', 'box-content-message-custom-container.js', 'disableToolbarInviteButtonClickOriginAction', res);
                if (res == 7) {
                    message.info('视频会议组件初始化异常，请重试！');
                    util.yach.platformConfigGetFun();
                }
            });
        }

        this.setState({ leave: false });
        //从群聊天的卡片进入会议，皆用meetingGroupUserJoin接口，无需根据source_type的值再做判断
        let s = await meetingGroupUserJoin({//通知后台创建会议，以便显示工作状态
            online_meeting_id,
            source_id,
            source_type,
            os
        });
        try {
            util.log('panghaojie', 'box-content-message-custom-container.js', 'meetingGroupUserJoin', JSON.stringify(s));
        } catch (error) {}
        if(!s || s.code != 200 || !s.obj) return
        if(s.obj.is_live == 0){
            //会议已结束，直接调用结束会议接口
            //145版本后端伙伴强调不能调用结束会议接口，会产生脏数据
            // this.leaveMeeting(zoomId);
            // const leaveRes = await meetingLeaveEnd({
            //     online_meeting_id: online_meeting_id,
            //     is_meeting_end : 1,
            //     os
            // });
            this.meetingFinish();
            message.info(`${util.locale('media_meeting_over')}`);
            return
        }
        if (s.obj.token){
            //优化等待主持人的逻辑
            //卡片进入会议，如果接口返回token，说明是该会议的创建人，直接走zoom创建会议的逻辑
            meetingCreateJoinFun({
                id: source_id,
                title: textInputValue || '',
                online_meeting_id,
                daily_meeting,
                changeStatus: true,
                isVideoOff: isvideooff,
                isAudioOff: isaudiooff,
                type: source_type,
                sessionActive: this.props.sessionActive,
                forceGroupJoin: true
            },() => {
                util.log('panghaojie', 'box-content-message-custom-container.js', 'meetingCreateJoinFun-callback');
            });
            return
        }
        util.log('panghaojie', 'box-content-message-custom-container.js', 'judge-return');
        if (source_type !== 1) { // 除去单聊
            let teamInfo = type == 'team' ? await util.yach.teamTypeIsWhat(id) : {type:0};
            this.setState({ teamInfo })
            await this.setMeetingStatus(true);
            this.eventLoopThisFun();
        }
        util.electronipc.electronZoomCallFn('joinunlogin', {
            isvideooff,
            isaudiooff,
            meetingnum,
            username,
            password
        }, async status => {
            util.log('panghaojie', 'box-content-message-custom-container.js', 'joinunlogin', status);
            this.props.dispatch(videoSessionlHide());
            this.setState({showVideo: false})
            if (status == 0 || !status) {
                //存储会议id，供会议列表，呼叫，邀请弹窗使用
                util.yachLocalStorage.ls('inviteMeetingId',{ online_meeting_id, meeting_id: meetingnum })
                this.addMeetingListen(newContent, startTimer);
                // // 统计摄像头
                this.reportVideoChange();
                // 单聊 / 群聊 卡片 埋点
                let sensorsChatListType = this.props.sessionActive.type == 'p2p' ? '101' : '102';
                util.sensorsData.track('Click_Chat_Element', {
                    ChatListType: sensorsChatListType,
                    pageName: '135',
                    $element_name: '01-134',
                });
            }else if (status == 2) {
                util.electronipc.electronZoomCallFn('backToMeeting');
            }else{
                util.sensorsData.track('Error_Chat', {
                    error_code: 1003,
                    submodule: '01-101'
                });
                //加入失败处理
                handleJoinFail({ online_meeting_id })
            }
        }) // api 调用结果，0为成功
    }

    // 进入会议总时长  埋点
    endTimerSensorsDataInit = (startTimer = 0) => {
        let endTimer = new Date().getTime();
        let sizeTimer =  (endTimer-startTimer) / 1000;
        console.log("kjkjkjkjkjkjkjkjk",+sizeTimer.toFixed(2));
        // 进入会议成功 埋点
        util.sensorsData.track('PageView_Chat', {
            pageName: '01-118',
            cost_time: +sizeTimer.toFixed(2)
        });
    }

    loginSuccessful = async(data) => {
        util.log('panghaojie', 'box-content-message-custom-container.js', 'loginSuccessful');
        const { zoomId: meetingnum, title, online_meeting_id, source_type } = data
        const { Stype } = this.state;
        util.yachLocalStorage.ls('zoom_login', {
            startTime: (new Date()).getTime(),
            meetingNum: meetingnum,
            meetingName: title
        });
        util.sensorsData.track('PageView_Chat', {
            pageName: '01-103',
            source: '01-102',
            meeting_type: Stype ? Stype : '01-103',
            meeting_id: meetingnum,
            meeting_name: title,
            submodule: '01-101'
        });

        //进入会议成功就初始化频道，保持会议中频道畅通
        agoraRTMChannelListen(`${online_meeting_id || ''}`);

        //设置选人组件参数
        //先清除选人组件参数，避免异常离开会议没有清除掉
        util.yachLocalStorage.ls('inviteGroupInfo', null);
        if(source_type != 1){
            const {id, showname} = this.props.sessionActive;
            util.log('panghaojie', 'box-content-message-custom-container.js', 'inviteGroupInfo',id, showname);
            if(id) await saveTid({id, showname})
        }

        //心跳计时器,30s上报一次,会议结束，计时器停止
        window.clearInterval(heartTimer)
        heartTimer = null
        const { os, teamInfo } = this.state;
        const { type } = teamInfo;
        util.log('panghaojie', 'box-content-message-custom-container.js', 'setInterval', type);
        if(type == 1){
            //单聊上报心跳
            heartTimer = window.setInterval(async() => {
                util.log('panghaojie', 'box-content-message-custom-container.js', 'heartTimer');
                let res = await meetingHeart({
                    online_meeting_id,
                    os
                })
            },30000)
        }
    }

    goDocument = data => {
        let token = btoa(util.yachLocalStorage.ls('yach_usertoken'))
        const url = util.summaryUtil.handleShimoUrl({
            sessionActive: this.props.sessionActive,
            link: data.link
        })

        util.electronipc.electronAddWebview({
            url: `${util.config.shimoHost}document/index?url=${url}&token=${token}`,
            name: data.title,
            disableClose: true
        })
    }

    /**
     * 打电话
     */
    startCall = () => {
        const { sessionActive } = this.props;
        const { id } = sessionActive;
        if(id && sessionActive) util.agoraFn.startCall(id, sessionActive);
    }

    showVideoSessione = (params) => {
        const parameter = {
            show: true,
            nickName: '',
            title: params.title
        };
        this.props.dispatch(videoSessionShow(parameter));
        this.setState({
            showVideo: true,
            params,
        })
        util.sensorsData.track('Click_Chat_Element', { pageName: '01-102', $element_name: '01-135'});
    }

    imageLoadHandler = e => {
        e.target.src = require("@a/imgs/expression_default.png");
    }
    clickVideo = (data) => {
        util.log('panghaojie','box-content-message-custom-container.js','clickVideo')
        const {fileUrl, idClient, fileName, fileExt, isdownloading, fileSize, filePath, fileDur, msg, isDownloadFlag, pic,taskId,relationId, coverUrl,width,height,csize} = data
        util.electronipc.electronOpenVideoPreview({
            url: fileUrl,
            name: fileName,
            idClient,
            videoSize: fileSize,
            ext: fileExt,
            isDownloadFlag,
            filePath,
            fileDuration: util.videoUtil.getVideoTime(fileDur || 0),
            msg: msg || '',
            isdownloading,
            pic,
            taskId,
            relationId,
            width,
            height,
            coverUrl,
            csize,
            fileDur,
            history: true
        });
    }

    // 点击动态表情，跳转到表情故事
    expressClick= (data)=>{
        if(!data || !data.expressionUrl) return
        let { expressionUrl } = data
        let localeExpression = util.yachLocalStorage.ls('expression')
        let list
        try {
            list = localeExpression.obj.tabList[1].expressionList
        } catch (error) { return util.log('qinqinghaoaaa','yach-im','box-content-message-custom-container','expressClick','本地数据库无gif表情')}
        for (let i = 0; i < list.length; i++) {
            if(list[i].expressionUrl === expressionUrl && data.isClick === '1'){
                let language = util.locale.getLang() === 'en-US' ? 'EN' : 'ZN'
                util.log('qinqinghaoaaa','yach-im','box-content-message-custom-container:experssClick','请求表情故事地址：',util.config.museDingUrl)
                this.props.dispatch(showSlideModal('link',{ url:`${util.config.museDingUrl}expression?gif_id=${list[i].expressionId}&pc_slide=true&language=${language}&time=${new Date().getTime()}`} ));
                // window.location.href = `yach://yach.zhiyinlou.com/session/webview?url=${encodeURIComponent(util.config.museDingUrl+'expression?gif_id='+list[i].expressionId)}&pc_slide=true&language=${language}&time=${new Date().getTime()}`
                return
            }
        }

    }

    editMeetingSummary = async() => {
        //请求接口，如果有会议纪要文档地址，直接打开，如果没有，服务端会创建一个新文档
        const { id } = this.props.sessionActive
        const data = await util.summaryUtil.meetingSummaryGetUrl({
            group_tid: id
        })
        data.title = util.locale('calendar_create_meeting_summary')
        data.sessionActive = this.props.sessionActive
        util.summaryUtil.goDocument(data)

        //卡片点击埋点
        util.sensorsData.track('Click_Chat_Element', {
            pageName: 135,
            $element_name: '01-194'
        })
    }
    openDocment = async(data) => {
        if(!data) return
        this.goDocument({
            link: data.link,
            title: data.title
        })
    }

    /**
     * 跳转定位
     */
    goPositioning = (shareUrl) => {
        // let locationHost = util.yachLocalStorage.ls('platformConfigLocation') || {};

        // let url = `${locationHost[100090001]}?lng=${lng}&lat=${lat}&name=${name}`;
        window.open(shareUrl);
    }

    getMsgImg(imgUrl){
        // 针对苹果的HEIC格式进行转码
        return imgUrl && imgUrl.toLocaleUpperCase().endsWith('.HEIC') ? `${imgUrl}?imageMogr2/quality/20` : imgUrl;
    }

    render() {
        const MessageCustomProps = {
            ...this.props,
            getMsgImg: this.getMsgImg,
            gotoRecord: this.gotoRecord,
            convertOnlineDoc: this.convertOnlineDoc,
            getOfficeType: this.getOfficeType,
            openFileExternal: this.openFileExternal,
            fileDownload: this.fileDownload,
            fileDownloadCancel: this.fileDownloadCancel,
            showOffice: this.showOffice,
            openFile: this.openFile,
            openFileDir: this.openFileDir,
            isDownload: this.state.isDownload,
            againDownload: this.state.againDownload,
            filePath: this.state.filePath,
            imgError: this.imgError,
            refreshImg: this.refreshImg,
            joinMeeting: this.joinMeeting,
            imageDisabled: this.state.imageDisabled,
            meetingFinish: this.state.meetingFinish,
            showImg: this.props.showImg,
            goDocument: this.goDocument,
            startCall: this.startCall,
            goHistoricalRecord: this.goHistoricalRecord,
            getImgScale: this.getImgScale,
            replyImageMessageShowImg: this.replyImageMessageShowImg,
            showVideoSessione: this.showVideoSessione,
            imageLoadHandler: this.imageLoadHandler,
            clickVideo: this.clickVideo,
            expressClick: this.expressClick,
            editMeetingSummary: this.editMeetingSummary,
            openDocment: this.openDocment,
            msgTempStats:this.props.msgTempStats,
            goPositioning: this.goPositioning,
        };
        return <div>
            <MessageCustom {...MessageCustomProps} />
            {this.state.showVideo?
              <VideoSessione
                onlineOffice =  {(textInputValue,isvideooff,isaudiooff)=>{this.joinMeeting(this.state.params,textInputValue,isvideooff,isaudiooff)}}
                teamType = 'schedule'/> :null}
            </div>
    }
}

const mapStateToProps = state => ({
    sessionActive: state.sessionActive,
    isInMeeting: state.calender.isInMeeting,
    userInfo: state.userInfo,
    slideModal: state.slideModal,
    videoSessioneModal: state.videoSessioneModal,
    fileDownloadProgress: state.fileDownloadProgress,
    fileStatus: state.fileStatus,
    msgTempStats:state.msgTempStats.downloadLoadingStatus
});

export default connect(mapStateToProps)(withRouter(MessageCustomContainer));
