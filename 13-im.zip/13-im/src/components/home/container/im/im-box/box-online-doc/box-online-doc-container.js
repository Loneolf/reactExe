// react
import React from 'react';
// ImBox
import BoxOnlineDoc from './box-online-doc';
// connect
import {connect} from 'react-redux';
// debounce
import debounce from 'lodash/debounce';
// redux
import {hideSlideModal} from '@/redux/actions/commonModal';
import {slideSearchValue} from '@r/actions/slideSearchValue';

// server
import {groupDocumentSearch} from '@s/group/group-doc';

import * as util from '@u/util.js';

// ImBoxContainer
class BoxOnlineDocContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state = {
        noData: '',
        docList: [],
        loading: false,
        hasMore: true,
        currentPage: 1,
        total: 0,
        keyword: ''
    }

    componentDidMount() {
        this.initData(1, this.props.slideSearch || '')
        window.addEventListener('keydown', this.closeSlideCard)
    }

    componentWillUnmount() {
        window.removeEventListener('keydown', this.closeSlideCard)
    }

    // 监听按键 esc
    closeSlideCard = (ev) => {
        let code = ev.keyCode
        if (code === 27) { //触发esc
            if (this.props.slideSearch) {
                window.store.dispatch(slideSearchValue(''));
                this.initData(1)
            } else {
                this.props.hiddenModal()
            }
        }
    }

    initData = async (page, keyword) => {
        const s = await this.getDocList(page, keyword);
        const {docList, total, currentPage} = s || {};
        console.log('++initData++', s);
        if(keyword && docList.length == 0) {
            this.setState({noData: util.locale('im_no_related_documents_found')});
        }else{
            this.setState({noData: ''});
        }
        this.setState({
            docList,
            total,
            currentPage,
            keyword
        });
    }

    getDocList = async (page, keyword) => {
        const {typeName} = this.props;
        // const id = this.props.sessionActive.id;
        const { id } = window.session_active;
        if(!id) return;
        const datas = await groupDocumentSearch({
            groupId: typeName === 'group' ? id : null,
            page, 
            pageSize: 50, 
            keyword,
            userId: typeName === 'single' ? id : null
        });
        const {code, obj = {}} = datas || {};
        let docList = [],
            total = 0,
            currentPage = 1;
        if (code === 200) {
            docList = obj.list;
            total = obj.total;
            currentPage = obj.currentPage;
        }
        return {
            docList,
            total,
            currentPage,
        }
    }

    seachData = value => {
        this.initData(1, value.target.value);
        window.store.dispatch(slideSearchValue(value.target.value));
    }

    goShimo = data => {
        let token = btoa(util.yachLocalStorage.ls('yach_usertoken'))
        const url = util.summaryUtil.handleShimoUrl({
            // sessionActive: this.props.sessionActive,
            sessionActive: window.session_active,
            link: data.url
        })
        
        util.electronipc.electronAddWebview({
            url: `${util.config.shimoHost}document/index?url=${url}&token=${token}`,
            name: data.title,
            disableClose: true
        })
    }

    handleInfiniteOnLoad = async () => {
        let {docList, total, currentPage, keyword} = this.state;
        this.setState({
            loading: true,
        });
        if (docList.length >= total) {
            this.setState({
                hasMore: false,
                loading: false,
            });
            return;
        }
        const datas = await this.getDocList(currentPage + 1, keyword)
        this.setState({
            docList: docList.concat(datas.docList),
            total: datas.total,
            currentPage: datas.currentPage,
            loading: false,
        },()=>{console.log(this.state.docList)});

        if(datas.docList.length == 0){
            this.setState({
                hasMore: false,
            });
        }
    }
    render() {
        return(
            <BoxOnlineDoc
                goShimo = {this.goShimo}
                seachData = {this.seachData}
                handleInfiniteOnLoad = {this.handleInfiniteOnLoad}
                docList = {this.state.docList}
                noData = {this.state.noData}
                loading = {this.state.loading}
                hasMore = {this.state.hasMore}
                slideSearch = {this.props.slideSearch}
            />
        )
    }
}

const mapStateToProps = state => {
    return {
        // sessionActive: state.sessionActive,
        slideSearch: state.slideSearch
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxOnlineDocContainer);
