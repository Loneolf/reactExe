// react
import React from 'react';

// css
import css from './index.scss';

// no img
import noImg from '@a/imgs/no-img.png';

// ImBox
import BoxSeachImg from './box-seach-img';

// connect
import { connect } from 'react-redux';

// redux
import { showPreviewModal } from '@r/actions/commonModal.js';

// util
import * as util from '@/utils/util';

// debounce
import debounce from 'lodash/debounce';

// antd
import { Spin, message } from 'antd';

import { searchFileGroupList, fileRangeList } from '@s/file/file-list';

// ImBoxContainer
class BoxSeachImgContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    state={
        newImgList: [],
        oldImgList: [],
        showLoading: false,
        noData: false,
        fileListPage: 1,
        size: 100, // 每页加载的数据大小
        pageLastFileTime: 0, //每页最后一条数据的时间戳
        isLastFile: false // 判断是否加载到了最后一条
    }

    componentDidMount(){
       this.getFileList();
       setTimeout(()=>{
        this.box.scrollTop = this.box && this.box.scrollHeight || 0;
       },100);

        this.handleScroll = debounce(this.handleScroll, 100);
        this.box.addEventListener('scroll', this.handleScroll);
    }

    componentWillUnmount(){
        this.box.removeEventListener('scroll', this.handleScroll);
    }

    handleScroll = e => {
        if (!this.box) return;
        if (e.target !== this.box) return;
        const {scrollTop, clientHeight, scrollHeight} = this.box;
        if (scrollTop + clientHeight >= scrollHeight) { //上拉加载更多
            if (this.state.isLastFile) return;
            this.loadMore();
        }
    }

    getFileList = async() => {
        const {typeName} = this.props;
        let formData = {
            // group_tid: this.props.sessionActive.id,
            group_tid: window.session_active.id,
            page: this.state.fileListPage,
            size: this.state.size,
            type: 'img',
            receive_type: typeName === 'group' ? 0 : 1
          }
          try {
                const data = await searchFileGroupList(formData)
                if (data && data.code === 200) {
                    const {obj} = data;
                    let lastInfoFlag = this.lastFileHandle(obj); // 处理最后一条数据 避免多次加载
                    if (lastInfoFlag) this.getImgList(obj);
                } else {
                    message.error(util.locale("im_failed_to_get"));
                }
           } catch (err) {
               message.error(util.locale("im_failed_to_get"));
           }
    }

    // 处理最后一条数据 
    lastFileHandle = (obj) => {
        if (!obj.length) {
            this.setState({isLastFile: true})
            return false;
        }
        if (obj.length < this.state.size) {
            this.setState({isLastFile: true})
            if ((this.state.pageLastFileTime > 0) && (obj[obj.length-1].time >= this.state.pageLastFileTime)) return false;
            
            return true;
        }
        if (obj.length == this.state.size) {
            this.setState({pageLastFileTime: obj[obj.length-1].time})
            return true;
        }
        return true;
    }

    getImgList = (imgList) => {
        let imgListConcat = this.state.oldImgList.concat(imgList);
        // let imgSortList = imgListConcat.sort((a, b) => a.time-b.time);
        let {latestWeekImgArr, outherArr} = util.formatDate.getLatestWeekImg(imgListConcat);
        let formatDate = util.formatDate.formatDate(outherArr);

        if(latestWeekImgArr && latestWeekImgArr.length>0){
            formatDate = [{ date: util.locale("im_this_week"), data: latestWeekImgArr }].concat(formatDate)
        }
        this.setState({
                newImgList: formatDate,
                oldImgList: imgListConcat,
                showLoading: false
            },()=>{
                if(!imgList || imgList.length==0){
                    this.setState({noData: false})
                    return;
                }
                if(this.state.oldImgList.length>=this.state.size) this.setState({noData: true})
            })
    }

    loadMore = () => {
        this.setState({showLoading: true});
        if(this.state.oldImgList && this.state.oldImgList.length>0){
            this.setState({fileListPage: this.state.fileListPage+1},()=>{
                this.getFileList();
            })
        }else{
            this.setState({showLoading: false})
        }
    }

    showVideoWindow = async(itemImg) => {
        let {msgId, fileUrl, fileName, relation_id, videoInfo, file_extension, userInfo} = itemImg
        let data = {}
        let imageinfo = {}
        if(msgId) {
            try {
                data = await util.nimUtil.getLocalMsgByIdClient(msgId)
            } catch (error) {}
        }
        if(videoInfo.videoPic){
            try {
                imageinfo = await util.imageDealer.getImageInfo(videoInfo.videoPic)
            } catch (error) {}
        }

        util.electronipc.electronOpenVideoPreview({
            url: fileUrl,
            name: fileName,
            idClient: relation_id,
            videoSize: isNaN(videoInfo.size) ? videoInfo.size : util.yach.getFileSize(videoInfo.size),
            ext: file_extension,
            isDownloadFlag: false,
            filePath: '',
            fileDuration: util.videoUtil.getVideoTime(videoInfo.duration || 0),
            msg: data.msg || '',
            isdownloading: false,
            pic: userInfo.pic,
            taskId: videoInfo.cos_task_id,
            relationId: relation_id,
            width: imageinfo.width || 325,
            height: imageinfo.height || 140,
            coverUrl: videoInfo.videoPic,
            csize: videoInfo.size,
            fileDur: videoInfo.duration || 0
        });
    }
    showImg = (url, itemImg) => {
        if(itemImg.fileState == 2) {
            this.showVideoWindow(itemImg)
        }
        if(itemImg.fileState == 1) {
            if(util.electron.isElectron()) {
                if(itemImg.hasOwnProperty('relation_id')){
                    let relationId = itemImg.relation_id;
                    this.getFileListPrePost(relationId, itemImg);
                } else {
                    this.setState({
                        data:{
                            success: true,
                            data: [{url: itemImg.fileUrl, id: itemImg.relation_id, curr: true}],
                            id: ''
                        }  
                    }, ()=>{
                        util.electronipc.electronOpenImage(this.state.data, undefined, (id)=>{
                            this.getFileListPrePost(id, itemImg);
                        });
                    }); 
                }
            } else {
                this.props.dispatch(showPreviewModal({type: 'img', url: url})); 
            }
        }
    };
    getFileListPrePost = async(relation_id, wdata) => {
        let formData = {
            // receive_id: this.props.sessionActive.id,
            receive_id: window.session_active.id,
            relation_id,
            max: 30,
            img: 'img'
          }
          try {
               const data = await fileRangeList(formData)
               if (data && data.code === 200) {
                    const {obj} = data;
                    let largeFileInfo = obj.largeFileInfo.map((item)=>{
                        return {
                            url: item.file_url,
                            id: item.relation_id,
                            curr: false
                        }
                    })
                    let lessFileInfo =  obj.lessFileInfo.reverse().map((item)=>{
                        return {
                            url: item.file_url,
                            id: item.relation_id,
                            curr: false
                        }
                    });
                    let currentFileInfo = {
                        url: wdata.fileUrl,
                        id:  wdata.relation_id,
                        curr: true
                    }
                    let allPicFiles = [...lessFileInfo, currentFileInfo, ...largeFileInfo];
                    this.setState({
                        data:{
                            success: true,
                            data: allPicFiles,
                            id: wdata.relation_id
                        }
                    }, ()=>{
                        util.electronipc.electronOpenImage(this.state.data, undefined, (id)=>{
                            this.getFileList(id, wdata)
                        });
                    })
               } else {
                    this.setState({
                        data:{
                            success: false,
                            data: [{url: wdata.fileUrl, id: wdata.relation_id, curr: true}],
                            id: wdata.relation_id
                        }
                    }, ()=>{
                        util.electronipc.electronOpenImage(this.state.data, undefined, (id)=>{
                            this.getFileList(id, wdata)
                        });
                    });
                    message.error(util.locale("im_failed_to_get"));
               }
           } catch (err) {
                this.setState({
                    data:{
                        success: false,
                        data: [{url: wdata.fileUrl, id: wdata.relation_id, curr: true}],
                        id: wdata.relation_id
                    }
                }, ()=>{
                    util.electronipc.electronOpenImage(this.state.data, undefined, (id)=>{
                        this.getFileList(id, wdata)
                    });
                });
           }
    }

    // 毫秒转为时分秒
    formatDuring = (msTime) => {
        let minutes = parseInt((msTime % (1000 * 60 * 60)) / (1000 * 60));
        minutes = minutes < 10 ? '0' + minutes : minutes
        let seconds = parseInt((msTime % (1000 * 60)) / 1000);
        seconds = seconds < 10 ? '0' + seconds : seconds

        if(msTime >=  60 * 60 * 1000) { // 大于1小时，显示时分秒
            let hours = parseInt((msTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            hours = hours < 10 ? '0' + hours : hours
            return hours + ":" + minutes + ":" + seconds;
        }

        return minutes + ":" + seconds;
    }

    render() {
        // const loadDataText = (
            
        //     <div className={css.loadMore} onClick={this.loadMore}>
        //         <span className={`${css.load_icon} iconfont-yach yach-goutong-tupiansousuo-chakangengduo`}></span>
        //         <span>{util.locale("common_msg26")}</span>
        //     </div>
        // );
        // const loadDataLoding = (
        //     <Spin className={css.spin} spinning={this.state.showLoading} />
        // );
        // const loadData = this.state.showLoading ? loadDataLoding : loadDataText;
        return(
            <div className={css.boxConent} ref={el => this.box = el}>
                {this.state.newImgList && this.state.newImgList.length>0 &&
                    this.state.newImgList.map((item, index)=>(
                        <BoxSeachImg
                            key={index}
                            title={item.date}
                            data={item.data}
                            showImg={this.showImg}
                            formatDuring={this.formatDuring}
                            // setFileBoxRef={this.setFileBoxRef}
                        />
                    ))
                }
                {/*   改为滚动加载 */}
                {/* {this.state.noData && loadData} */}

                {!this.state.newImgList || this.state.newImgList.length==0 &&
                <div className={css.noImg}>
                    <img src={noImg}/>
                    <p>{util.locale("im_no_pic_content")}</p>
                </div>
                }
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        // sessionActive: state.sessionActive,
    };
};

export default connect(
    mapStateToProps,
    null
)(BoxSeachImgContainer);
