import React, { PureComponent } from 'react';
import { Tabs } from 'antd';
import { connect } from 'react-redux';
import flattenDeep from 'lodash/flattenDeep';

import { toggleAddRobotWindow, setRobotsListType, robotChangeState } from '@r/actions/robots';
import { DetailType, ListType, PageType } from '@r/reducers/robots';
import { ROBOTS_AVALIBLE_LIST_FETCH, ROBOTS_ROBOT_DETAIL } from '@r/actiontype/robots';
import RobotDetail from './robot-detail/robot-detail';
import RobotCard from '../robot-card/robot-card';

import style from './style.scss';
import * as util from '@u/util.js';
const { TabPane } = Tabs;

const titleMap = {
    [DetailType.ADD]: util.locale("im_add_robot"),
    [DetailType.ADDSUCCESS]: util.locale("im_add_robot"),
    [DetailType.MODIFY]: util.locale("im_edit_robot"),
    [DetailType.READ]: util.locale("im_robot_details")
};
const listTitleMap = {
    [ListType.ADD]: util.locale("im_add_robot"),
    [ListType.MODIFY]: util.locale("im_edit_robot")
};
class AddRobotContainer extends PureComponent {
    constructor(props) {
        super(props);
    }
    close = () => {
        this.props.toggleAddWindow();
    };
    onMask = e => {
        this.stopEventBroadcast(e);
        this.close();
    };
    goList(t) {
        if (t == ListType.ADD) {
            // 有可能从没请求过
            this.props.fetchList(1);
        }
        this.props.changeListType(t);
    }
    tabChange(t) {
        // 切换 tab 需要获取对应数据
        this.props.fetchList(t);
    }
    goDetail(item, category) {
        const { robotChangeState } = this.props;
        const randID = Math.random() * 100;
        //新建的话可能不存在 robot_id,希望 react 从新创建组件
        robotChangeState({
            selectedRobot: {
                categoryID: category.categoryID,
                ...item,
                robot_id: item.robot_id || randID
            },
            pageType: PageType.DETAIL,
            detailType: this.isListAdd ? DetailType.ADD : '' // 此时不确认权限
        });
        if (!this.isListAdd) {
            // 从 编辑列表进入的时候,需要更多详情数据
            this.props.fetchDetail({
                robot_id: item.robot_id
            });
        }
    }
    stopEventBroadcast(e) {
        e.persist();
        e.stopPropagation();
    }
    get dialogTitle() {
        const { detailType, pageType, listType } = this.props;
        if (pageType == PageType.DETAIL) {
            // 几种详情状态的 title
            return titleMap[detailType];
        } else {
            return listTitleMap[listType];
        }
    }
    get isListPage() {
        const { pageType } = this.props;
        return pageType == PageType.LIST;
    }
    get isListAdd() {
        const { listType } = this.props;
        return this.isListPage && listType == ListType.ADD;
    }
    get isListEdit() {
        const { listType } = this.props;
        return this.isListPage && listType == ListType.MODIFY;
    }
    componentDidMount() {
        if (this.isListPage) {
            // 直接从侧边栏进来的时候需要上来就请求
            this.props.fetchList(1);
        }
    }
    render() {
        const { avaList, detailType, inUseList } = this.props;
        const list = this.isListAdd ? avaList : inUseList;
        const inUseCount = flattenDeep(inUseList.map(c => c.items || [])).length;
        const isFull = inUseCount >= 10;

        return (
            <div onMouseDown={this.onMask} className={style.dialogMask}>
                <div onMouseDown={this.stopEventBroadcast} className={style.dialogContent}>
                    <div className={style.title}>
                        {this.isListAdd ? (
                            // 左上角返回按钮
                            <span
                                onClick={() => this.goList(ListType.MODIFY)}
                                style={{ float: 'left' }}
                                className={`${style.icon} iconfont-yach yach-tianjiajiqiren-fanhuianniu`}
                            ></span>
                        ) : null}
                        {this.dialogTitle}
                        <span
                            onClick={this.close}
                            style={{ float: 'right' }}
                            className={`${style.icon} iconfont-yach yach-quanju-xuanren-jianqunguanbi`}
                        />
                    </div>
                    {this.isListPage && this.isListAdd ? (
                        // 添加列表
                        <div className={`${style.tabs} ${style.add}`}>
                            <Tabs onChange={e => this.tabChange(e)} defaultActiveKey="1">
                                {list.map(r => {
                                    return (
                                        <TabPane className={style.tabContent} tab={r.category} key={r.categoryID}>
                                            <div className={style.cardsContainer}>
                                                {(r.items || []).map((i, index) => (
                                                    <RobotCard
                                                        item={i}
                                                        onClick={() => this.goDetail(i, r)}
                                                        key={index}
                                                    ></RobotCard>
                                                ))}
                                            </div>
                                        </TabPane>
                                    );
                                })}
                            </Tabs>
                        </div>
                    ) : this.isListPage && this.isListEdit ? (
                        // 编辑列表
                        <div>
                            <div className={`${style.tabs} ${style.edit}`}>
                                {list
                                    .filter(c => (c.items || []).length > 0)
                                    .map(r => {
                                        return (
                                            <React.Fragment key={r.categoryID}>
                                                <div className={style.categoryName}>{r.category}</div>
                                                <div className={`${style.tabContent} `}>
                                                    <div className={style.cardsContainer}>
                                                        {(r.items || []).map(i => (
                                                            <RobotCard
                                                                item={i}
                                                                onClick={() => this.goDetail(i, r)}
                                                                key={i.robot_id}
                                                            ></RobotCard>
                                                        ))}
                                                    </div>
                                                </div>
                                            </React.Fragment>
                                        );
                                    })}
                            </div>
                            <div className={style.footer}>
                                <span className={style.tip}>{util.locale("im_there_are")}{inUseCount}{util.locale("im_robots_in_the_group")}</span>
                                <button
                                    onClick={isFull ? null : () => this.goList(ListType.ADD)}
                                    className={`${style.btn} ${style.primary} ${isFull ? style.disabled : ''}`}
                                >
                                    {util.locale("im_add_robot")}
                                </button>
                            </div>
                        </div>
                    ) : (
                        // 详情页
                        <RobotDetail detailType={detailType}></RobotDetail>
                    )}
                </div>
            </div>
        );
    }
}

const mapDispatchToProps = dispatch => {
    return {
        toggleAddWindow: () => dispatch(toggleAddRobotWindow()),
        changeListType: v => dispatch(setRobotsListType(v)),
        robotChangeState: v => dispatch(robotChangeState(v)),
        fetchList: (id = 1) => dispatch({ type: ROBOTS_AVALIBLE_LIST_FETCH, payload: id }),
        fetchDetail: p => dispatch({ type: ROBOTS_ROBOT_DETAIL, payload: p })
    };
};
const mapStateToProps = (state, ownProps) => {
    return {
        detailType: state.robots.detailType,
        avaList: state.robots.avaList,
        inUseList: state.robots.inUseList,
        pageType: state.robots.pageType,
        listType: state.robots.listType
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(AddRobotContainer);
