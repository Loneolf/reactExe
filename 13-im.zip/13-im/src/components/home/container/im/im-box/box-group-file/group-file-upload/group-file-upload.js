import React, { useState, useEffect } from 'react';
import {connect} from 'react-redux';
import * as util from '@u/util.js';
import { message, Modal } from 'antd';
import BoxSendModal from '@c/home/container/im/im-box/box-send/box-send-modal';
import CommonModal from '@/components/common/common-modal';
import { fileAndFolderHasDelete } from '@s/group/group-file';
import css from './index.scss';

function GroupFileUpload(props) {
  const [sendFileTarget,setSendFileTarget] = useState([])
  const [sendFileAction,setSendFileAction] = useState('')
  const [needBell,setNeedBell] = useState(false)
  const [modalVisible,setModalVisible] = useState(false)
  const [stateFilePaths,setStateFilePaths] = useState([])
  const [filesModleVisible,setFilesModleVisible] = useState({ show: false, num:0 })

  useEffect(() => {
    //监听之前先清除之前的事件和数据
    util.eventBus.removeListener('group-file-upload')
    setSendFileAction('')
    //监听上传触发
    util.eventBus.addListener('group-file-upload', (stype, groupFileLastBreadcrumb) => {
      fileChange(stype, groupFileLastBreadcrumb)
    });
    return ()=>{
      //卸载组件
      util.eventBus.removeListener('group-file-upload')
    }
  }, []);

  const fileNumMore_10 = (list) => {
    let len = list.length || 0;
    if(len>100)  return  message.warning(util.locale('im_group_file_uoliad_dir_once_sender'));  
  }

  const fileChange = async (stype,groupFileLastBreadcrumb) => {
    //groupFileLastBreadcrumb在回调函数内，需要传入，直接从state中取，某些场景下不更新
    const {relation_id} = groupFileLastBreadcrumb
    if(relation_id){
      const res = await fileAndFolderHasDelete({relation_id})
      if(!res || res.code != 200 || !res.obj) return util.eventBus.emit('group-file-list-return-all')
      if(res.obj.result) {
        message.error(util.locale('im_group_file_judge_can_upload'))
        util.eventBus.emit('group-file-list-return-all')
        return
      }
    }
    util.electronipc.electronOpenDialog(stype,(res)=>{
      const {canceled,filePaths} = res;
      const len = filePaths.length;

      if(canceled && !len ) return;
      setSendFileAction('')
      setStateFilePaths(filePaths)
      if(len && len <=10){
        setModalVisible(true)
        return;
      }
      if(len>10 && len <=100 ) return setFilesModleVisible({show: true,num:len})
      fileNumMore_10(filePaths);
    });
  };
  const setOKModal = () =>{
    setNeedBell(true);
    handleUpload();
    util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-246' });
  }
  const setonCancelModal = () =>{
    setNeedBell(false);
    handleUpload();
    util.sensorsData.track('Click_Chat_Element', { pageName: '01-138',$element_name: '01-247' });
  }
  const handleUpload = () =>{
    setModalVisible(false)
    setSendFileAction('');
    setSendFileTarget(stateFilePaths);
    setSendFileAction('input');
  }

  const filesModleVisibleHandleOk  = ()=>{
    setFilesModleVisible({ show: false, num: 0})
    setModalVisible(true)
  }

  const filesModleVisibleHandleCancel = ()=>{
    setFilesModleVisible({ show: false, num: 0})
    setModalVisible(false)
  }

  return (
    <div className={css.fileUploadWrap}>
      <BoxSendModal
        sendFileAction={sendFileAction}
        groupFileUpload={ true }
        sendFileTarget={ sendFileTarget }
        sendFileCliped={[]}
        ismute={props.ismute}
        ismanager={props.ismanager}
        fileNumMore_10 = { fileNumMore_10 }   
        fileUplaodEventRegistryRemove  = { () => {} }
        needBell={needBell}
        foldRelationId={props.groupFileLastBreadcrumb.relation_id || 0}
        noDraftEditorStateImgAdd={true}
      />
      <CommonModal
        closable={false}
        modalTile={util.locale('im_group_file_input_upload_tip_title')}
        okText={util.locale('calendar_toast_notify_button')}
        cancelText={util.locale('calendar_toast_dont_Notify_button')}
        modalVisible={modalVisible}
        setOKModal={setOKModal}
        setonCancelModal={setonCancelModal}
        modalContent={util.locale('im_group_file_input_upload_tip_content')}
        noTitleIcon={true}
        className="groupFileModal"
        maskClosable={false}
      />
      <Modal 
        visible      = { filesModleVisible.show }
        onOk         = { filesModleVisibleHandleOk } 
        onCancel     = { filesModleVisibleHandleCancel }
        maskClosable = {!1}
        width        = {416}
        closable     = {!1}
        style        = {{height: 144, borderRadius:6 }}
        bodyStyle    = {{fontSize:14, fontWeight:500, color:'#2F3238' }}
        centered
      > 
        <p>{util.locale('im_group_file_more_than_10').replace('[x]',filesModleVisible.num)}</p>
      </Modal>
    </div>
  );
};
const mapStateToProps = state => {
  return {
    ismute: state.groupAll.ismute,
    ismanager: state.groupAll.ismanager,
    groupFileLastBreadcrumb: state.groupFileLastBreadcrumb
  };
};

export default connect(
  mapStateToProps,
)(GroupFileUpload);
