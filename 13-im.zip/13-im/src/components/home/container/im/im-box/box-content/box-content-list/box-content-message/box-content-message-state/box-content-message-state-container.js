// react
import React from 'react';

import BoxContentMessageState from './box-content-message-state';
import BoxContentMessage from '@/components/home/container/im/im-box/box-content/box-content-list/box-content-message/box-content-message';

export default class BoxContentMessageStateContainer extends React.Component {
    render() {
        return (
            <BoxContentMessageState
                idServer={this.props.idServer}
                target={this.props.target}
                showUnreadPersion={e =>
                    this.props.showUnreadPersion(false)
                }
            />
        );
    }
}
