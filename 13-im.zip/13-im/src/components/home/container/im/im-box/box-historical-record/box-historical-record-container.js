import React, { Fragment } from 'react'
import { connect } from 'react-redux'

import BoxHistoricalRecord from './box-historical-record'

import css from './index.scss';

// util
import * as util from '@u/util.js';

import moment from 'moment';

// redux
import { showPreviewModal } from '@r/actions/commonModal.js';
import * as fileRedux from '@/redux/actions/file'

// services
import { forwardMsgList } from '@/services/forward/forward';
import {massageGroupInfo} from '@/services/message/message';

// antd
import { message } from 'antd';

// debounce
import debounce from 'lodash/debounce';

// encode
import {aesDecrypt} from 'yach.util.encode';

import InfiniteScroll from 'react-infinite-scroller';

class BoxHistoricalRecordContainer extends React.Component {

    componentDidMount(){
        this.getHistorical();
        this.clickVideo = debounce(this.clickVideo,500);
        this.addWatermarkPower();
    }

    state = {
        recordLsit: [],
        timeRange: '',
        isDownload: false,
        filePath: null,
        againDownload: false,
        moreLoading: false,
        hasMore: true,
        page: 1,
        count: 0,
        tid: '',
        str: ''
    }

    //添加水印
    addWatermarkPower = () => {
        util.yach.addWatermarkPower('boxHistoricalRecord');
    }

    getHistorical = () => {
        const {type} = this.props.slideModal;
        if(type == 1) return this.getHistoricalRecord(); // 普通群
        if(type == 2) return this.getApprovalChatRecord(); // 审批群
    }

    /**
     * 获取审批群数据
     */
    getApprovalChatRecord = async() => {
        const {tid, str} = this.props.slideModal;
        if(tid) this.setState({tid});
        if(str) this.setState({str});

        const value = await massageGroupInfo({tid, str, limit: 30, page: 1});
        const {code, msg, obj} = value;
        if(code != 200) return message.error(msg);

        let {page, count, data} = obj;
        data = this.getDecodeData(data);
        
        this.getTimeRange(data);
        let newData = await this.dataFusion(data);
        this.setState({page, count, recordLsit: newData});
    }

    /**
     * 审批群数据解密
     */
    getDecodeData = (data) => {
        if(!data) return [];
        let platformConfig = util.yachLocalStorage.ls('platformConfig') || {};
        let key = platformConfig[100000013];
        if(!key) return [];
        try {
            return JSON.parse(aesDecrypt(data, key));
        } catch (error) {
            return [];
        }
    }
    getHistoricalRecord = async() => {
        let reqS;
        // 新的消息转发逻辑
        if(this.props.slideModal.uniq){
            reqS= await this.getForwardingData({uniq:this.props.slideModal.uniq});
        }
        else{
           // 旧的消息转发逻辑 
           let idClients = this.props.slideModal.content.map(item=>
              item.idClient
           );
           reqS = await this.getForwardingData(idClients);
        }

        let {obj} = reqS  || {};
        if(!obj) return;
        
        let newObj = []
        try {
            newObj = JSON.parse(obj.data);
        } catch (error) {
            return;
        }

        const filterMsgs = newObj.sort((a, b) => {
            return a['time'] - b['time'];
        });

        let newMsgs = await this.dataFusion(filterMsgs);
        if(!newMsgs || newMsgs.length==0) return;
        this.getTimeRange(newMsgs);
        this.setState({recordLsit: newMsgs});
    }

    dataFusion = async(filterMsgs) => {
        let newMsgs = [];
        for (let index = 0; index < filterMsgs.length; index++) {
            const element = filterMsgs[index];
            console.log('hh5');
            const nimInfo = await util.nim.getNimInfo('p2p', element.from);
            const avatar = util.nim.getNimImg(nimInfo);
            let data  = await util.nimUtil.getLocalMsgByIdClient(element.idClient)

            // 兼容ios等非法消息体 content类型不统一  兼容视频多选转发 丢失msg 导致无法播放
            if( !data.msg && (element.type === 'video' || (element.content && util.nimUtil.getJson(element.content).type === 30))){
                console.log('+++++++','element',element);
                data = element
                console.log('phj-video')
            }
            console.log('phj-element',element,data)
            
            // 兼容安卓端file字段是字符串
            if (typeof element.file == 'string') {
                try {
                    element.file = JSON.parse(element.file)
                    element.file.name = element.file.name || element.file.fileName
                    element.file.ext = element.file.ext || element.file.extension
                }
                catch(err){}
            }
            newMsgs.push(Object.assign(element, {avatar: avatar, msg: data.msg}));
        }
        return newMsgs;
    }

    getForwardingData = async(idClients) => {
        let arg = Array.isArray(idClients)?{msg_ids: JSON.stringify(idClients)}:idClients;
        const datas = await forwardMsgList(arg);
        const {code} = datas || {};
        if (code === 200) {
            return datas;
        }
        message.error(util.locale("im_forwarding_message_failed"));
    }

    getTimeRange = (msgs) => {
        if(!msgs || !msgs.length) return;
        let startTime = util.locale.getLang() === 'en-US' ? moment(parseInt(msgs[msgs.length-1].time)).format('YYYY/MM/DD') : moment(parseInt(msgs[0].time)).format('YYYY年MM月DD日')
        let endTime = util.locale.getLang() === 'en-US' ? moment(parseInt(msgs[0].time)).format('YYYY/MM/DD') : moment(parseInt(msgs[msgs.length-1].time)).format('YYYY年MM月DD日')
        if(startTime == endTime) return this.setState({timeRange: startTime});
        if(startTime.substr(0, 4) == endTime.substr(0, 4)){
            endTime = endTime.substr(5);
        }
        this.setState({timeRange: `${startTime}-${endTime}`});
    };

    showUserinfo = (id) => {
        util.yach.showUserinfo(id)
    };
    
    showOffice = (url) => {
        util.electronipc.electronOpenFilepreview({
            file: url
        })
    };

    showImg = (url) => {
        let imageList = this.state.recordLsit.filter((item)=>{
            return item.content && JSON.parse(item.content).type == 8;
        }).map((item)=>{
            return {curr: false, url: JSON.parse(item.content).data.fileOriginUrl}           
        });
        let index = imageList.findIndex((val)=>{
            return (url).indexOf(val.url) > -1
        })    
        imageList[index] = {
            url: url,
            curr: true       
        };
        let data = {
            success: true,
            data: imageList
        };
        if(util.electron.isElectron()) {
            util.electronipc.electronOpenImage(data);
        } else {
            this.props.dispatch(showPreviewModal({type: 'img', url: url})); 
        }
    };

    // fileDownload = async (url, idClient,name='',ext='') => {
    //     util.cosfiles.fileDownload(idClient, url, name)
    // }

    fileDownload = async (url, idClient,name='',ext='',relationId) => {
        util.cosfiles.fileDownload({idClient, url, name,relationId})
    }

    openFile = ({path, idClient,relation_id}) => {
        if (!path) return
        util.electronipc.electronCheckFile({ path }, (res) => {
            if (res) {
                util.electronipc.electronOpenFile({ path })
            } else {
                let filestatus = {
                    id: idClient,
                    isDownloaded: false,
                    downloadedPath: ''
                }
                this.props.dispatch(fileRedux.fileStatusUpdate(idClient, filestatus))
                // util.nimUtil.updateLocalMsg(idClient, { isDownloadFlag: false, path: null });
                util.cosfiles.fileDownloadStatusUpdate({path:null,key:relation_id});
            }
        })
    }
    clickVideo = (data) => {
        util.log('panghaojie','box-historical-record-container.js','clickVideo')
        let {fileUrl, idClient, fileName, fileExt, isdownloading, fileSize, filePath, fileDur, msg, isDownloadFlag, pic, taskId, relationId, coverUrl, width, height,csize} = data
        if(!filePath){
            //再次确认是否已下载文件
            const filestatus = this.props.fileStatus.find(v => v.id == idClient)
            if(filestatus && filestatus.downloadedPath) filePath = filestatus.downloadedPath
        }
        util.electronipc.electronOpenVideoPreview({
            url: fileUrl,
            name: fileName,
            idClient,
            videoSize: fileSize,
            ext: fileExt,
            isDownloadFlag,
            filePath,
            fileDuration: util.videoUtil.getVideoTime(fileDur || 0),
            msg: msg || '',
            isdownloading,
            pic,
            taskId,
            relationId,
            width,
            height,
            coverUrl,
            csize,
            fileDur,
            history: true
        });
    }

    /**
     * 审批群聊天记录分页加载
     */
    handleInfiniteOnLoad = async () => {
        let {recordLsit, count, page, tid, str} = this.state;
        this.setState({
            moreLoading: true,
        });
        if (recordLsit.length >= count) {
            this.setState({
                hasMore: false,
                moreLoading: false,
            });
            return;
        }

        const value = await massageGroupInfo({page: page + 1, tid, str});
        const {code, msg, obj} = value;
        if(code != 200) return message.error(msg);

        let {data} = obj;
        data = this.getDecodeData(data);

        let newRecordLsit = [...recordLsit, ...data];
        newRecordLsit = util.yach.arrayUnique2(newRecordLsit, 'idClient');
        newRecordLsit = await this.dataFusion(newRecordLsit);
        this.setState({
            recordLsit: newRecordLsit,
            count: obj.count,
            page: obj.page,
            moreLoading: false,
        }, ()=> this.getTimeRange(this.state.recordLsit));

        if(!data.length){
            this.setState({
                hasMore: false
            });
        }
    };

    getHistoryItem = item => {
        return <BoxHistoricalRecord
                id = {item.from}
                key = {item.idClient}
                idServer = {item.idServer}
                idClient = {item.idClient}
                flow = {item.flow}
                status = {item.status}
                text = {item.text}
                custom = {item.custom}
                content = {item.content}
                time = {item.time}
                fromNick = {item.fromNick}
                avatar = {item.avatar}
                type = {item.type}
                file = {item.file ? item.file : ''}
                fromClientType = {item.fromClientType}
                showTeamMsg = {item.showTeamMsg}
                target = {item.target}
                msg = {item.msg}
                showUserinfo = {this.showUserinfo}
                showOffice = {this.showOffice}
                showImg = {this.showImg}
                fileDownload = {this.fileDownload}
                openFile = {this.openFile}
                isDownload = {this.state.isDownload}
                filePath = {this.state.filePath}
                againDownload = {this.state.againDownload}
                clickVideo={this.clickVideo}
                itemValue={item}
            />
    }

    render(){
        const {type} = this.props.slideModal;
        const {recordLsit, timeRange, moreLoading, hasMore} = this.state;
        const {handleInfiniteOnLoad} = this;
        return (
            <div className={css.box} id='boxHistoricalRecord'>
                <p className={css.timeRange}>{timeRange}</p>
                {type == 1 && recordLsit.map(item =>this.getHistoryItem(item))}
                {type == 2 && 
                <Fragment>
                    {recordLsit.length > 0 ? 
                        <InfiniteScroll
                                initialLoad={false}
                                pageStart={0}
                                loadMore={handleInfiniteOnLoad}
                                hasMore={!moreLoading && hasMore}
                                useWindow={false}
                        >
                            {recordLsit.map(item =>this.getHistoryItem(item))}
                        </InfiniteScroll> : ''
                    }
                </Fragment>
                }
            </div>
        )
    }
}

const mapStateToProps = state => ({
    userInfo: state.userInfo,
    slideModal: state.slideModal,
    fileStatus: state.fileStatus
})

export default connect(mapStateToProps)(BoxHistoricalRecordContainer)