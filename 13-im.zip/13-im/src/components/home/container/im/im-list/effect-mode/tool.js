 
import React from 'react'; 

import CommonModal from '@/components/common/common-modal';

// util
import * as util from '@/utils/util';

/**
 *  7: 异常会话处理
 */
 export const abnormalSession = (props)=>{
    const { modalKind } = props;
    let content = '';

     // 该群已解散，会话入口将被删除
    if(modalKind == 'dismissTeam'){
        content = util.locale("im_group_disbanded");                 
    } 
    // 你已被移除此群
    else if (modalKind == 'removeTeamMembers'){
        content = util.locale("in_you_have_been_removed_from_group"); 
    } 

    // 你已退出该群
    else if (modalKind == 'leaveTeamMembers') {
        content = util.locale("im_quit_group");                       
    }

    return (
            <CommonModal
            modalTile        = { modalKind === 'dismissTeam' ? '' : util.locale("im_reminder") }
            modalVisible     = { props.modalVisible }
            setOKModal       = { props.removeSession }
            setonCancelModal = { props.removeSession}
            modalContent     = { content }
            cancelButtonProps= {{ style: {backgroundColor: ' #326FEF', color: '#FFFFFF'} }}
            okButtonProps    = {{ style: { display: 'none' } }}
            cancelText       = { util.locale("im_get_it")}
        />
    )
 };

