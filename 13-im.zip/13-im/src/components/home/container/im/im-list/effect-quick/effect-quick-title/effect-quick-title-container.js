import React from 'react'
import { connect } from 'react-redux'

import EffectQuickTitle from './effect-quick-title'

import { setEffectQuickAtingChange, setEffectQuickPageChange } from '@r/actions/effectMode'
import { audioBusHignlightDel } from '@/services/session/session'

class EffectQuickTitleContainer extends React.Component {
    constructor(props) {
        super(props)
    }

    // AT不高亮
    dealAtHighLight = async () => {
        let data = await audioBusHignlightDel({ type: 'at' })
        if (data && data.code == 200) {
            this.props.dispatch(setEffectQuickAtingChange(false))
        }
    }

    // 处理tab页点击
    handleTabClick = async tab => {
        if (tab == 'at') {
            this.dealAtHighLight()
        }

        if (tab == 'later') {

        }

        this.props.dispatch(setEffectQuickPageChange(tab))
    }

    render() {
        const props = {
            ating: this.props.effectQuickStatus.ating,
            latering: this.props.effectQuickStatus.latering,
            handleTabClick: this.handleTabClick
        }
        
        return <EffectQuickTitle {...props} />
    }
}

const mapStateToProps = state => ({
    effectQuickStatus: state.effectQuickStatus
})

export default connect(mapStateToProps)(EffectQuickTitleContainer)

