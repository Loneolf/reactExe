// React
import React, { Component } from 'react';
import { connect } from 'react-redux';

// utils
import * as util from '@/utils/util';

import { setEffectGroupDetailsList, setEffectGroupDetailsType,setEffectGroupDetailsId, setManageDialog,addEffectAdd, setEffectGroupDetailsTypeNum} from '@r/actions/effectMode';

// componets
import GroupManagementModal from '../effect-management-modal';
import EffectBanner from './effect-banner';
import UserAdd from '@c/common/user-add/user-add-container';
import DissolutionGroup from './dissolution-group';
import OperateGroup from './operate-group';
import ImItem from '../im-item/im-item-container';
import {genGroupTitleMenu} from '../group-menu';

// tool
import { getData as getNimData } from 'yach.nim.on';

// lodash
import _ from 'lodash';

// antd
import {message,Dropdown } from 'antd';

// css
import css from './../index.scss';

// img
import noSessions from '@a/imgs/no-sessions.png';



class EffectContainer extends Component {
    constructor(props) {
        super(props);
        this.state={
            isinit         : true,
            loading        : false,
            userAddShow    : false,
            rightClickId   : '',     // 外层点击拿到当前点击的分类的id
            rightClickName : '',     // 外层点击拿到当前点击的分类的name
            isSystemGroup  : false,
            isDetails      : !!this.props.details,  // 下一期删除这个依赖
            scrollBom      : 0,
            detailSearchId : '',
        }
    }

    componentDidMount() {
        this.refreshHandleSessionList = _.debounce(this.refreshHandleSessionList, 800, {
            leading: true,
            trailing: false,
        });
        util.eventBus.addListener('effect:refresh:event', this.refreshHandleSessionList);
        util.eventBus.addListener('effect:home:go:item', () => this.backToSession(true));
    }

    componentWillUnmount() {
        util.eventBus.removeListener('effect:refresh:event');
        util.eventBus.removeListener('effect:home:go:item');
    }

    /**
     * 1： 初始化加载分组
     * @param {*}  
     */
    initSessionListAndEffectmode = () => {
        const { effectMode, sessionList: list } = this.props;
        if (effectMode) return this.renderSessionListOfEffectMode();
        return this.renderSessionListOfNormal(list);  
    };

   
    /**
     *  4: sessionList 渲染函数
     */
    renderSessionListOfEffectMode = () => {
        const allData = [];
        const keywords = util.yach.effectSessionList(); 
        const list = this.props.effectlist;
        const dtype = util.yach.effectDefaultKeyVal(false);

        for(let i=0; i<list.length; i++){
            let isCustom = list[i].type >5 ? true: false;
            let obje;
            if(!isCustom){
                let item = dtype.get(list[i].type);
                obje = keywords[item];
                allData.push(
                    <div className={css.effectmodel} key={item}>
                        <Dropdown overlay={()=>genGroupTitleMenu({show:this.addNewSession,id:list[i].id,name:list[i].name,type:list[i].type})} trigger={['contextMenu']}>
                            <div className={css.effeckeytTitle}
                                 onClick={() => { this.enterDetailOfType(item, list[i].id, list[i].type, obje)}}
                            >
                                <h1>{ util.locale(item)? util.locale(item):`${item}` }</h1>
                                <span className={`iconfont-yach yach-youjiantou ${css.rightArrow}`}></span>
                            </div>
                        </Dropdown>
                        <div className={css.commonLine}></div>
                        <div className={css.content}>{this.renderSessionListOfNormal(obje,true,item)}</div>
                         { this.getFilterLength(obje).length ? <div className={css.commonLine}></div> : null}
                    </div>
                );
            }
            else{
                obje = keywords[list[i].name];
                allData.push(
                    <div className={css.effectmodel} key={list[i].name}>
                        <Dropdown overlay={()=>genGroupTitleMenu({show:this.addNewSession,id:list[i].id,name:list[i].name,type:list[i].type})} trigger={['contextMenu']}>
                            <div
                                className={css.effeckeytTitle}
                                onClick={() => { this.enterDetailOfType(list[i].name, list[i].id, list[i].type, obje)}}
                            >
                                <h1>{list[i].name}</h1>
                                <span className={`iconfont-yach yach-youjiantou ${css.rightArrow}`}></span>
                            </div>
                        </Dropdown>
                        <div className={css.commonLine}></div>
                        <div className={css.content}>{this.renderSessionListOfNormal(obje,true,list[i].name)}</div>
                        { this.getFilterLength(obje).length ? <div className={css.commonLine}></div> : null}
                    </div>
                );
            }
        }
        return allData;
    };

    enterDetailOfType = (item, id, type, list =[]) => {
       const scrollNode = document.querySelector('#mainList');
        this.setState({isDetails: true,scrollBom: scrollNode && scrollNode.scrollTop||0 });
        this.props.dispatch(setEffectGroupDetailsType(item));
        this.props.dispatch(setEffectGroupDetailsList(list));
        this.props.dispatch(setEffectGroupDetailsId(id));
        this.props.dispatch(setEffectGroupDetailsTypeNum(type));

        if (+type <= 5) {
            this.setState({isSystemGroup: true})
        } else {
            this.setState({isSystemGroup: false})
        }

        setTimeout(()=>scrollNode.scrollTop = 10,10);
        util.log('qiuyanlong','effect',2,'enterDetailOfType:list.length',id, type,item);
    };

    addNewSession = (e,hasid,name)=>{       
        this.setState(pre=>({
            userAddShow: true, 
            rightClickId: hasid || '',   // out
            rightClickName: name || ''   // out
        }),()=>{
            util.log('qiuyanlong','effect',3,'addNewSession',hasid,name);
        });
    }


    closeUserAdd = () => {
        this.setState({
            userAddShow    : false,
            loading        : false,
            rightClickId   : '',
            rightClickName : ''
        });
        util.eventBus.removeListener('effect:adduser:callback');
    };

    okUserAdd = async (value) => {
        util.eventBus.removeListener('effect:adduser:callback');
        this.setState({loading:true});
        const {rightClickName,rightClickId } = this.state;
        const {effectGroupDetailsId:detailId,sessionList} = window.store.getState();
        const personal =  value.allDataUsers.map(i=> `${i.id}`);
        const group    =  value.teamids;
        const allData  = [...personal,...group];
        const sessionAarray = sessionList.map(i=>i.id);

        util.eventBus.addListener('effect:adduser:callback', async()=>{
            util.log('qiuyanlong','effect',4,'effect:adduser:callback');
            for(let i=0; i<allData.length;i++){
                let  tem = allData[i];
    
                //  not local msg and append an msg
                if(!sessionAarray.includes(tem)){
                    let t = tem.length <= 6 ? 'p2p' : 'team';
                    let nimId = util.nim.getNimId(t,tem);
                    let session = await util.nimUtil.getLocalSession(nimId);
    
                    if (!session || (session && !session.scene)) {
                          await util.nim.deleteLocalSession(nimId);
                          util.nimUtil.insertLocalSession(t,tem);
                    }
                }
            }     
            if(rightClickName && rightClickId){
                let befordata = util.yach.gd('temp_once_session');
                let beforList = (befordata && befordata.list) || [];
                util.yach.sd('temp_once_session', {list:Array.from(new Set([...allData,...beforList]))});
            }
        });
        this.props.dispatch(addEffectAdd({personal,group,to: rightClickId || detailId }));
        setTimeout(()=>{ this.setState({ loading:false, userAddShow:false }) },300);
    }


    /**
     * detail data render
     */
    routeDeatilRender = () => {
        const {effectGroupDetailsId:detailId} = window.store.getState();
        const isdefault = this.props.details ? util.yach.effectDefaultType.includes(this.props.details):false;
        const list = util.yach.getTypeOfSessionList(this.props.details, isdefault ? '' : detailId);
        const detailList = this.renderSessionListOfNormal(list, false);

        return (
            <div className={css.detailMode}>
                <div className={css.detailEffeckeytTitle}>
                    <div className={css.leftWrap} onClick={() => {this.backToSession();}}>
                        <span
                            className={`iconfont-yach yach-zuojiantou ${css.leftArrow}`}
                            
                        ></span>
                        <h1> {util.locale(this.props.details)?util.locale(this.props.details):`${this.props.details}`}</h1>
                    </div>
                    {
                        isdefault ? null : (
                            <Dropdown overlay={()=>genGroupTitleMenu({show:this.addNewSession, isDetails: true})} trigger={['hover']}>
                                <span className={`iconfont-yach yach-gengduogongneng ${css.setting}`} />
                            </Dropdown>
                        )
                    }
                </div>
                <div className={css.commonLine +' ' + css.detailLine}></div>
                {detailList && detailList.length ? (<div className={css.content}>{detailList}</div>):(
                    <div className={css.noSessionsBox}>
                        <img src={noSessions} />
                        {!isdefault ? <div className={css.btn} onClick={this.addNewSession}>{util.locale('im_effect_mode_text_9')}</div>:<p>{util.locale('im_effect_mode_text_20')}</p>}
                    </div>
                )}
            </div>
        );
    };


    // beforeBackToSession = ()=>{
    //     const {id} = window.store.getState().sessionActive;
    //     const { isDetails }  = this.state;
    //     const { effectlist } = this.props;
    //     return isDetails && !effectlist.map(i=>i.id).includes(id) ? id : '';
    // }

    backToSession = (flag = false) => {
        const { id }     = window.store.getState().sessionActive;
        const scrollDom  = document.querySelector('#mainList');
        
        util.yach.handleEffectModeDetails();

        // if (!flag) {
        //     this.setState(()=>({isDetails: false}), () => {scrollDom.scrollTop = 0});
        //     return;
        // }

        // const detailSearchId = this.beforeBackToSession();

        this.setState(p=>({
            isDetails: false
        }),()=>{
            setTimeout(() => scrollDom.scrollTop = this.state.scrollBom,50);
            // if(detailSearchId) {
            //     setTimeout(() => scrollDom.scrollTop = this.state.scrollBom,50);
            // }
            // else{
            //     const sc = this.sessionActiveHight(id); 
            //     setTimeout(() =>scrollDom.scrollTop = sc,50);
            // }
        });
    };

    /**
     * 返回会话列表-定位激活会话高度
     * @param {*} id 
     */
    sessionActiveHight = (id) => {
        const effectSessionList = util.yach.effectSessionList();
        const effectShowList = util.yach.getEffectShowList(effectSessionList);
        const num = util.yach.getTargetIdInGroupNum(id, effectSessionList);
        const index = effectShowList.findIndex(item => item.id == id);
        const scrollTop = index * 68 + num * 38;
        return scrollTop;
    }

    commonItemlist = (item) => {
        if (item.id && !item.hideSession && !item.isSecret) {
            let iconType = '';
            return (
                <ImItem
                    {...this.props}
                    iconType=       {iconType}
                    iconName=       {item.showimg}
                    id=             {item.id}
                    key=            {item.id}
                   // index=           {index}
                    type=           {item.type}
                    isTop=          {item.isTop}
                    disnotice=      {item.disnotice}
                    msgTop=         {item.yachNick || item.showname}
                    msgBottom=      { item.showmsg }
                    time=           {!!item.showtime && item.lasttime}
                    num=            {item.showunread}
                    realUnread=     {item.realUnread}
                    isSquad=        {item.isSquad}
                    origindata=     {item}
                    idClient=       {(item.lastMsg && item.lastMsg.idClient) || ''}
                />
            );
        }
        return null;
    };


    renderSessionListOfNormal = (p_list = [], isfilter = true, type = '') => {
        const {effectMode} = this.props;
        const list = effectMode ? this.sortHandleList(p_list) : p_list;
        const { effectMode: flag } = this.props;
        const { id = '' } = window.store.getState().sessionActive;
        const nimData = getNimData();
        const {sessionActived = []} = nimData || {};
        const isAtu = util.yach.checkSomeOneAtU();
        const restArry = [];
        
        if (!flag) return list.map(this.commonItemlist);

        const sessionDisnotice = util.yach.gd('session_refreshed_disnotice') || [];

        for(let i=0; i<list.length; i++){
            const tempVotaData              = util.yach.gd('temp_once_session');
            const osSendMsg                 = util.yach.gd('more_os_send_msg') || []; 
            const disconectData             = util.yach.gd('disconnect_data') || {list:[]}; 
            const had_refresh_effect_mode   = util.yach.gd('had_refresh_effect_mode');   // 是否刷新过 也就是已经设置过滤条件了
            const moveDisDate               = util.yach.gd('move_dis_data') || {list:[]}; 
            const item                      = list[i];
            const hasRefreshed              = had_refresh_effect_mode && had_refresh_effect_mode.status;
            const updateSession             = disconectData.list.includes(item.id);
            const moveSession               = moveDisDate.list.includes(item.id);
            
            if ( isfilter && (
                item.showunread                                     ||    
                id == item.id                                       || 
                sessionActived.includes(item.id)                    || 
                util.yach.checkIsHasDraft(item.id)                  ||
                osSendMsg.includes(item.id+'')                      ||
                tempVotaData && tempVotaData.list.includes(item.id)  
             )){

             // dis init first fresh handle
              if(  hasRefreshed                          && 
                   type ==='im_effect_mode_text_8'       &&
                  ( !isAtu  || !isAtu.includes(item.id)) && 
                  !updateSession                         && 
                  !moveSession                           &&
                  !sessionDisnotice.includes(item.id)    &&
                  !util.yach.checkIsHasDraft(item.id)
              ) continue;

              util.yach.getOutAllData(item.id);
              restArry.push(this.commonItemlist(item));
          }

          else if (!isfilter) restArry.push(this.commonItemlist(item));
        }
        return restArry;
    };

    
    getFilterLength = (list = []) => {
        const { id = '' } = window.store.getState().sessionActive;
        const nimData = getNimData();
        const {sessionActived = []} = nimData || {};
        return list.filter(item => item.showunread || id == item.id || sessionActived.includes(item.id) || util.yach.checkIsHasDraft(item.id))
    }

   
    getNumOfEffectModeRefresh = () => { 
        const { sessionList: list } = this.props;
        const { id = '' } = window.store.getState().sessionActive;
        const nimData = getNimData();
        const {sessionActived = []} = nimData || {};
        const osSendMsg = util.yach.gd('more_os_send_msg') || [];
        const {list:tempList} = util.yach.gd('temp_once_session') || {list: []};
        const {list:moveList} = util.yach.gd('move_dis_data') || {list: []};

        const originNum = list.filter(
            (item) => item.showunread || id == item.id || sessionActived.includes(item.id) || util.yach.checkIsHasDraft(item.id) || osSendMsg.includes(item.id) || tempList.includes(item.id) || moveList.includes(item.id)
        );

        util.nimUtil.resetCurrSession();

        const {status = false} = util.yach.gd('had_refresh_effect_mode') || {};
        const isAtu = status ? [] : util.yach.checkSomeOneAtU() || [];

        const handleNum = list.filter((item) => item.showunread || util.yach.checkIsHasDraft(item.id));
        const num = originNum.length + util.yach.getUnreadNumOfDisnect() - handleNum.length - isAtu.length;
        const isClearAll = originNum.length === num;

        return {
            num,
            isClearAll,
        };
    };

    
    refreshHandleSessionList = () => {
        const { num, isClearAll } = this.getNumOfEffectModeRefresh();

        if ( isClearAll || !num ){
            message.warning(`${util.locale('im_effect_mode_text_3')}`);
        } else {
            message.success(`${util.locale('im_effect_mode_text_2').replace('[x]', num)}`);
        }

        util.yach.sd('disconnect_data',{list:[] });  // 
        util.yach.sd('had_refresh_effect_mode',{status: true});  // had refresh 
        util.yach.sd('more_os_send_msg',[]); 
        util.yach.sd('temp_once_session',{list:[]});
        util.yach.sd('move_dis_data',{list:[]});
        util.yach.sd('session_refreshed_disnotice', []);
        util.yach.sd('all_out_data',{list: []});
        util.yach.handleCurrentActiveSession();
        util.yach.handleClearActiveSession();

        this.initSessionListAndEffectmode();
        this.forceUpdate(); 
    };

    /**
     *  sort function way 
     * @param {*} list 
     */
    sortHandleList = (list) =>{
        if(!list) return [];
        return list.sort( (a, b) => {
            let temA=0,temB=0;
            if(a.lastMsg) temA = a.lastMsg.time;
            if(b.lastMsg) temB = b.lastMsg.time;
            return temB - temA
        });
    }

    showAdminDialog = (data)=>{
        this.props.dispatch(setManageDialog({show: true}));
    }

    closeAdminDialog = ()=>{
        this.props.dispatch(setManageDialog({show: false}));
    }

    render() {
        const { effectMode: flag, details, effectAdminDialog} = this.props;
        const { rightClickName } = this.state;
        const GroupManagementModalProps={ closeAdminDialog:this.closeAdminDialog};
        const {effectGroupDetailsType:detailType} = window.store.getState();
        const detailSession = util.yach.getTypeOfSessionList(rightClickName || detailType);
        const disabledids =  detailSession ? detailSession.map(i=>i.id): [];
        const {userAddShow,loading, isDetails} = this.state;

        const userAddProps = {
            type             : 'forward',
            loading          : loading,
            show             : userAddShow,
            onOk             : this.okUserAdd,
            onClose          : this.closeUserAdd,
            disabledids,
            showButtonNumber : true,
            title            : util.locale('im_effect_mode_text_26'),
            rightTitle       : util.locale("im_recent_contact"),
            noNeedLeaveWord  : true,
            maxLength        : Math.max(50 + disabledids.length,0)
        };

        return (
            <div className={css.sessionWrap}>
               <EffectBanner fresh={this.refreshHandleSessionList}  details={details} effectMode={flag} />

                {/* 渲染容器 */}
                <div className={`${css.listBox} ${!details && flag ? css.effectPb : ''}`} id="mainList">
                    {!!isDetails ? this.routeDeatilRender() : this.initSessionListAndEffectmode()}  
                    {flag && !isDetails ? (
                        <div className={css.effectSetting} onClick={this.showAdminDialog}>
                            <span className="iconfont-yach yach-pcxiaoxiliebiao-fenzuguanli"></span>      
                            <p>{util.locale('im_effect_mode_text_10')}</p>     
                        </div>
                    ) : null
                    }  
                </div>
              
               {effectAdminDialog.show && <GroupManagementModal {...GroupManagementModalProps}/> } 

                <UserAdd {...userAddProps} />
                <DissolutionGroup />
                <OperateGroup />
                
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        sessionList       : state.sessionList,
        effectMode        : state.effectMode,
        details           : state.effectGroupDetailsType,
        effectAdminDialog : state.effectAdminDialog,
        effectlist        : state.effectInterfaceDate,
        sessionActiveId   : state.sessionActiveId,
        sessionList_p2p_statue   : state.sessionList_p2p_statue,
    };
};

export default connect(mapStateToProps)(EffectContainer);
