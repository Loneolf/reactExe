import React, { useEffect, useState, useRef }  from 'react';
import {connect} from 'react-redux'
// util
import * as util from '@u/util.js';

// antd
import { Input,Tooltip, message, Spin } from 'antd';

import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
// redux
import {setEffectOperateGroupData,
		setSessionGroupSort,
		setEffectGroupDelData,
		setEffectGroupDelLoading
} from '@r/actions/effectMode';

// serverce
import { audioDivSessionCreate, audioDivSessionSyncSort} from '@s/session/session';

// css
import css from './index.scss';

// lodash
import debounce from 'lodash/debounce';


const GroupManagementModal = (props) => {

	//console.log('....', props);
	const { closeAdminDialog, effectInterfaceDate, effectOperateGroupData, loading } = props;

	const [groupValue, setGroupValue] = useState('');

	const [operateBtn, setOperateBtn] = useState(false);

	const [isNameOut, setIsNumOut] = useState(false);

	const [isNameRepeat, setIsNameRepeat] = useState(false);

	const [effectModeList, setEffectModeList] = useState(effectInterfaceDate.slice(1));

	const createRef = useRef();

	useEffect(() => {
		if(!_.isEqual(effectInterfaceDate.slice(1)), effectModeList){
			setEffectModeList(effectInterfaceDate.slice(1))
			props.setEffectGroupDelLoading(false);
		}

	}, [effectInterfaceDate])


	/**
	 * input change
	 * @param {*}
	 */
	const handleOnchange = (e)=>{
		setGroupValue(e.target.value.trim());
		props.setEffectOperateGroupData(Object.assign(effectOperateGroupData, { name: e.target.value}));
	}

	/**
	 * input keydown
	 * @param {*}
	 */
	const handleOnKeyDown = (e)=>{
		if (e.keyCode !== 27) return;
		handleClearData();
		createRef.current.blur();
	}

	/**
	 * input focus
	 * @param {*}
	 */
	const handleOnFocus = ()=>{
		if (effectInterfaceDate.length >= 35) {
			message.warning(util.locale('im_effect_mode_text_15'));
			createRef.current.blur();
			return;
		}
		setOperateBtn(true);
	}

	/**
	 * input enterPresss
	 * @param {*}
	 */
	const handleInputOk = ()=>{
		handleCreateGroup({name: groupValue})
	}

	/**
	 * 确定按钮
	 * @param {*}
	 */
	const handleBtnOk = () => {
		handleCreateGroup({name: groupValue})
	}

	const handleCreateGroup = debounce(async (params) => {
		if (!groupValue || isNameOut) return;
		try {
			const res = await audioDivSessionCreate(params);

			if (![900006, 900008, 200].includes(res.code)) return message.warning(util.locale('common_errorMsg5'));
			if (res.code === 900006) {
				createRef.current.focus();
				return setIsNameRepeat(true);
			}
			if (res.code === 900008) return message.warning(util.locale('im_effect_mode_text_15'));

			handleClearData();
			createRef.current.blur();
			setIsNameRepeat(false)
		} catch (error) { 
			message.warning(util.locale('common_errorMsg5'));
			console.log(error) 
		}
	}, 600, {
		'leading': true,
		'trailing': false
	})

	const handleClearData = () => {
		createRef.current.state.value = '';
		setGroupValue('');
		setOperateBtn(false);
	}

	// 删除分组
	const handleDelGroup = (id, name) => {
		if (loading) return;
		let list = [];
		try {
			list = util.yach.getTypeOfSessionList(name);
			if (!list.length) {
				props.setEffectGroupDelLoading({payload: true});
				props.setEffectGroupDelData({type: 'immediate', id});
				return;
			}
		} catch (error) {}
		props.setEffectGroupDelData({modalVisible: true, id, name});
	}

	// 重命名分组
	const handleRenameGroup = (id, name) => {
		props.setEffectOperateGroupData({modalVisible: true, id, name});
	}

	useEffect(() => {
		setIsNumOut(util.yach.checkStrNum(groupValue, 20));
		setIsNameRepeat(false);
	}, [groupValue])

	const handleGroupSort = async (list = []) => {
		let sg_ids = [effectInterfaceDate[0].id];
		list.forEach(item => sg_ids.push(item.id));
		// props.setSessionGroupSort({sg_ids: sg_ids.join()});

		try {
			const res = await audioDivSessionSyncSort({sg_ids: sg_ids.join()});
			if (!res || res.code !== 200) {
				message.warning(util.locale('common_errorMsg5'));
				util.log('qiuyanlong','effect-mode','setSessionGroupSort:error',data.code, data.msg);
			}
		} catch (error) {
			message.warning(util.locale('common_errorMsg5'));
			console.log(error);
		}
	}

	const reorder = (list, startIndex, endIndex) => {
		const result = Array.from(list);
		const [removed] = result.splice(startIndex, 1);
		result.splice(endIndex, 0, removed);

		return result;
	  };

	const onDragEnd = async (result) => {
		if (!result.destination) {
			return;
		  }

		  const items = reorder(
			effectModeList,
			result.source.index,
			result.destination.index
		  );
		  handleGroupSort(items);
		  setEffectModeList(items);
	}


    return (
        <div
            className={css.boxModal}
            onMouseDown={(e) => e.stopPropagation()}
        >
            <div className={css.mask}></div>
            <div className={css.box}>
				<span className={`${css.close} iconfont-yach yach-pcfenzuguanlidanchuang-guanbi` } onClick={closeAdminDialog}></span>
                <div className={css.title}>{util.locale('im_effect_mode_text_10_a')}</div>
				<span className={css.tips}>{util.locale('im_effect_mode_text_13')}</span>
                <div className={css.main}>
                    <ul>
						{/* { loading && <div className={css.loadings}><Spin/></div>} */}
						<li className={ css.stick }>
							<span className={css.grayGroupName + ' '+ css.groupName}>{ effectInterfaceDate && effectInterfaceDate.length && effectInterfaceDate[0].name }</span>
						</li>
						{
							<li className={ css.addGroupInput }  >
								<Input placeholder={util.locale('im_effect_mode_text_14')}
									onPressEnter={handleInputOk}
									onChange={handleOnchange}
									onFocus={handleOnFocus}
									ref={createRef}
									onKeyDown={handleOnKeyDown}
									/>
								{
									operateBtn ? (
										<>
											<span className='iconfont-yach yach-pcfenzuguanlidanchuang-quxiao' onClick={() => handleClearData()} />
											<span className='iconfont-yach yach-pcfenzuguanlidanchuang-wancheng' onClick={handleBtnOk} />
										</>

									) : null
								}
						   </li>
						}

						{ isNameOut ? <div className={css.repeatTips}>{util.locale('im_effect_mode_text_18')}</div> : null}
						{isNameRepeat ? <div className={css.repeatTips}>{util.locale('im_effect_mode_text_17')}</div> : null}

						{/* <div className={css.dragBox +' '+ isNameOut?css.nameOutBox:''}> */}
							{
								<DragDropContext onDragEnd={onDragEnd} >
									<Droppable 
									droppableId="droppable">
										{(providedP) => (
											<div
											{...providedP.droppableProps}
											ref={providedP.innerRef}
											className={isNameOut || isNameRepeat ?css.nameOutBox:css.dragBox}
											>
											{effectModeList.map((tag, index) => (
												<Draggable key={tag.id} draggableId={tag.id} index={index}>
												{(provided) => (
													<li ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps} key={tag.type} className={ css.item }>
														<span className={`${css.dragIcon} iconfont-yach yach-tuozhuai`}></span>
														<span className={css.groupName}>{tag.name}</span>
														{
															+tag.type > 5 ? (
																<div className={css.hoverDiv}>
																	<Tooltip mouseLeaveDelay={0} placement="top" title={util.locale('im_effect_mode_text_11')}>
																		<span className={`iconfont-yach yach-zhongmingming1`} onClick={() => handleRenameGroup(tag.id, tag.name)}></span>
																	</Tooltip>
																	<Tooltip mouseLeaveDelay={0} placement="top" title={util.locale('im_effect_mode_text_12')}>
																		<span className={`iconfont-yach yach-shanchu2`} onClick={() => handleDelGroup(tag.id, tag.name)}></span>
																	</Tooltip>
																</div>
															) : null
														}
													</li>
												)}
												</Draggable>
											))}
											{providedP.placeholder}
											</div>
										)}
									</Droppable>
								</DragDropContext>
							}
						{/* </div> */}
                    </ul>
                </div>
				{/* <div className={css.time}>
					<span>回话收起时间</span>
					<Select style={{width:222}}>
						<Option value=''>hhh</Option>
					</Select>
				</div> */}
            </div>
        </div>
    );
}

const mapStateToProps = state => ({
    effectInterfaceDate: state.effectInterfaceDate,
    effectOperateGroupData: state.effectOperateGroupData,
    effectGroupDelData: state.effectGroupDelData,
    loading: state.effectGroupDelLoading,
});

const mapDispatchToProps = dispatch => {
    return {
		setEffectOperateGroupData: v => dispatch(setEffectOperateGroupData(v)),
		setSessionGroupSort: v => dispatch(setSessionGroupSort(v)),
		setEffectGroupDelData: v => dispatch(setEffectGroupDelData(v)),
		setEffectGroupDelLoading: v => dispatch(setEffectGroupDelLoading(v)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(GroupManagementModal);
