
import React, { useEffect, useState, useRef }  from 'react';
import {connect} from 'react-redux'

// util
import * as util from '@u/util.js';

// redux
import { setEffectGroupDetailsType } from '@r/actions/effectMode';

// serverce
import { audioDivSessionCreate, audioDivSessionUpdate} from '@s/session/session';

// actions
import { setEffectOperateGroupData, effectMoveSession } from '@r/actions/effectMode';

// antd
import { Modal, Input, message } from 'antd';

// css
import css from './index.scss';

// lodash
import debounce from 'lodash/debounce';

const OperateGroup = (props) => {

    const {effectOperateGroupData = {}, details } = props;

    const {name, type: modalType, from: fromId, sessionId} = effectOperateGroupData;
    const [modalVisible, setModalVisible] = useState(false);
    const [inputValue, setInputValue] = useState('');
    const [isNameOut, setIsNumOut] = useState(false);
    const [isNameRepeat, setIsNameRepeat] = useState(false);

    const inputRef = useRef();

    useEffect(() => {
        setInputValue(name);
        setIsNameRepeat(false);
        setModalVisible(effectOperateGroupData.modalVisible);
    }, [effectOperateGroupData])

    useEffect(() => {
        setIsNumOut(util.yach.checkStrNum(inputValue, 20));
    }, [inputValue])

    // rename
    const setSessionGroupUpdate = async(params) => {
        try {
            const res = await audioDivSessionUpdate(params);
            if (![200, 900006].includes(res.code)) return message.warning(util.locale('common_errorMsg5'));

            if (res.code === 900006) {
                inputRef.current.focus();
                return setIsNameRepeat(true);
            }
            
            if (!!details) props.setEffectGroupDetailsType(inputValue);

            setModalVisible(false);
            props.setEffectOperateGroupData({modalVisible: false});
        } catch (error) { 
            message.warning(util.locale('common_errorMsg5'));
            console.log(error) 
        }
    }

    // create
    const setSessionGroupCreate = async(params) => {
        try {
            const res = await audioDivSessionCreate(params);
            if (![900006, 900008, 200].includes(res.code)) return message.warning(util.locale('common_errorMsg5'));

            if (res.code === 900006) {
                inputRef.current.focus();
                return setIsNameRepeat(true);
            }

            if (res.code === 900008) return message.warning(util.locale('im_effect_mode_text_15'));

            // 创建分组成功后移动
            const {obj = []} = res || {};
            props.effectMoveSession({sessionid:sessionId,from:fromId,to:obj[0]});

            setModalVisible(false);
            props.setEffectOperateGroupData({modalVisible: false, type: 'create'});
        } catch (error) { 
            message.warning(util.locale('common_errorMsg5'));
            console.log(error) 
        }
    }

    /**
	 * input OK
	 * @param {*} 
	 */ 
    const handleRenameOK = debounce(() => {
        if (!inputValue || isNameOut) return;
        if (modalType === 'create') {
            const params = {name: inputValue};
            setSessionGroupCreate(params);
        } else {
            const params = {sg_id: effectOperateGroupData.id, name: inputValue};
            setSessionGroupUpdate(params);
        }
    }, 600, {
		'leading': true,
		'trailing': false
	})

    /**
	 * input cancel
	 * @param {*} 
	 */ 
    const handleRenameCancel = () => {
        setModalVisible(false);
        props.setEffectOperateGroupData({modalVisible: false, type: modalType === 'create' ? 'create': ''});
    }

    /**
	 * input change
	 * @param {*} 
	 */ 
    const handleOnchange = (e) => {
        setInputValue(e.target.value.trim());
        setIsNameRepeat(false);
        inputRef.current.focus();
    }

    /**
	 * input onPressEnter
	 * @param {*} 
	 */ 
    const handleOnPressEnter = (e) => {
        handleRenameOK()
    }

    return (
        modalVisible ? (
        <Modal
            okText={util.locale('common_ok')}
            cancelText={util.locale('common_cancel')}
            className={`effect-common-modal ${!inputValue || isNameRepeat || isNameOut ? 'inputValueNull' : ''}`}
            title={modalType === 'create' ? util.locale('im_effect_mode_text_25') : util.locale('im_effect_mode_text_11')}
            centered
            visible={true}
            onOk={ handleRenameOK }
            onCancel={ handleRenameCancel }
            closable={false}
        >
            <div className={css.inputBox}>
                <Input 
                style={{width:352,height:40}} 
                allowClear={true} 
                value={inputValue}
                onChange={handleOnchange}
                onPressEnter={handleOnPressEnter}
                placeholder={util.locale('im_effect_mode_text_16')}
                ref={inputRef}
                autoFocus
                /> 

                {
					isNameOut ? <div className={css.outTips}>{util.locale('im_effect_mode_text_16')}</div> : null
                }
                
                {
					isNameRepeat ? <div className={css.outTips}>{util.locale('im_effect_mode_text_17')}</div> : null
                }
            </div>
        </Modal>) : null
    )
}

const mapStateToProps = state => ({
    effectOperateGroupData  : state.effectOperateGroupData,
    effectInterfaceDate     : state.effectInterfaceDate,
    details                 : state.effectGroupDetailsType,
});

const mapDispatchToProps = dispatch => {
    return {
		setEffectGroupDetailsType: v => dispatch(setEffectGroupDetailsType(v)),
		setEffectOperateGroupData: v => dispatch(setEffectOperateGroupData(v)),
		effectMoveSession: v => dispatch(effectMoveSession(v)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(OperateGroup);
