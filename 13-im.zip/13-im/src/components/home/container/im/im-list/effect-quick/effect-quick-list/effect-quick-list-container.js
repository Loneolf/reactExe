import React from 'react'
import { connect } from 'react-redux'

import * as util from '@u/util.js'

import { message } from 'antd'
import EffectQuickList from './effect-quick-list'

import { setEffectQuickPageChange, setEffectQuickAtingChange, setEffectQuickLateringChange } from '@r/actions/effectMode'
import { audioBusHignlightDel, audioBusAtList, audioBusMessageDeal, audioBusWaitList, audioBusMessageDel } from '@/services/session/session'

class EffectQuickListContainer extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            boxStyle: { top: '100%' },
            atlist: [],
            laterlist: [],
            atHasMore: true,
            laterHasMore: true,
            isunread: util.yachLocalStorage.ls('effect-quick-isunread'),
            resolveAllShow: false,
        }
        this.listloading = false
    }

    componentDidMount() {
        window.addEventListener('keydown', this.handleKeyDown)
    }

    componentWillUnmount() {
        window.removeEventListener('keydown', this.handleKeyDown)
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.effectQuickPage != this.props.effectQuickPage) {
            if (this.props.effectQuickPage) {
                this.showList()
            }
            if (!this.props.effectQuickPage) {
                this.hideList()
            }
            this.refreshList()
        }
        if (prevState.isunread != this.state.isunread) {
            this.refreshList()
        }
    }

    // 展示列表
    showList = () => {
        let boxStyle = {...this.state.boxStyle}
        boxStyle.top = '68px'
        this.setState({ boxStyle })
    }

    // 隐藏列表
    hideList = () => {
        let boxStyle = {...this.state.boxStyle}
        boxStyle.top = '100%'
        this.setState({ boxStyle })
    }

    // 刷新列表
    refreshList = () => {
        let effectQuickPage = this.props.effectQuickPage
        let pageName = ''

        this.lastid = ''
        this.lastudata = ''
        this.setState({
            atlist: [],
            laterlist: []
        })

        if (effectQuickPage == 'at') {
            this.setAtList()
            pageName = '01-139'
        }
        if (effectQuickPage == 'later') {
            this.setLaterList()
            pageName = '01-140'
        }

        this.setState({
            atHasMore: true,
            laterHasMore: true
        })

        util.sensorsData.track('PageView_Chat', {
            pageName,
        })
    }

    // 获取at列表数据
    getAtList = async () => {
        this.listloading = true

        let data = await audioBusAtList({
            count: 20,
            last_id: this.lastid,
            read: this.state.isunread ? 0 : 2
        })

        this.listloading = false

        if (data && data.code == 200) {
            let arr = data.obj.data || []
            this.lastid = arr.length ? arr[arr.length - 1].id : this.lastid
            return arr
        }
        return []
    }

    // 设置at列表数据
    setAtList = async () => {
        let data = await this.getAtList()
        this.setState({ atlist: data })
    }

    // 增加at列表数据
    pushAtlist = arr => {
        let atlist = [...this.state.atlist]
        atlist = [...atlist, ...arr]
        this.setState({ atlist })
    }

    // 删除at列表数据
    deleteAtlist = clientId => {
        let atlist = [...this.state.atlist]
        atlist = atlist.filter(v => v.clientId != clientId)
        this.setState({ atlist })
    }

    // 修改at列表数据
    modifyAtList = (clientId, mergedata) => {
        let atlist = [...this.state.atlist]
        let currIndex = atlist.findIndex(v => v.clientId == clientId)
        if (currIndex != -1) {
            atlist[currIndex] = {
                ...atlist[currIndex],
                ...mergedata
            }
        }
        this.setState({ atlist })
    }

    // 获取later列表数据
    getLaterList = async () => {
        this.listloading = true

        let data = await audioBusWaitList({
            count: 20,
            last_id: this.lastid,
            udate: this.lastudata,
            read: 0
        })

        this.listloading = false

        if (data && data.code == 200) {
            let arr = data.obj.data || []
            this.lastid = arr.length ? arr[arr.length - 1].id : this.lastid
            this.lastudata = arr.length ? arr[arr.length - 1].udate : this.lastudata
            return arr
        }
        return []
    }

    // 设置later列表数据
    setLaterList = async () => {
        let data = await this.getLaterList()
        this.setState({ laterlist: data })

        if (!data.length) {
            let highdata = await audioBusHignlightDel({ type: 'later' })
            if (highdata && highdata.code == 200) {
                this.props.dispatch(setEffectQuickLateringChange(false))
            }
        }
    }

    // 增加later列表数据
    pushLaterlist = arr => {
        let laterlist = [...this.state.laterlist]
        laterlist = [...laterlist, ...arr]
        this.setState({ laterlist })
    }

    // 删除later列表数据
    deleteLaterlist = clientId => {
        let laterlist = [...this.state.laterlist]
        laterlist = laterlist.filter(v => v.clientId != clientId)
        this.setState({ laterlist })
    }

    // 修改later列表数据
    modifyLaterList = (clientId, mergedata) => {
        let laterlist = [...this.state.laterlist]
        let currIndex = laterlist.findIndex(v => v.clientId == clientId)
        if (currIndex != -1) {
            laterlist[currIndex] = {
                ...laterlist[currIndex],
                ...mergedata
            }
        }
        this.setState({ laterlist })
    }

    // 清空later列表数据
    clearLaterList = () => {
        this.setState({ laterlist: [] })
    }

    // 计算会话时间
    computedShowTime = time => {
        return util.yach.getMsgShowTime(time)
    }

    // 处理按键事件
    handleKeyDown = e => {
        if (e.keyCode === 27) {
            this.handleFoldClick()
        }
    }

    // 处理滚动at列表
    handleAtLoadMore = async () => {
        if (this.listloading) return false

        let nextAtList = await this.getAtList()

        if (!nextAtList.length) {
            return this.setState({ atHasMore: false })
        }

        this.pushAtlist(nextAtList)
    }

    // 处理滚动later列表
    handleLaterLoadMore = async () => {
        if (this.listloading) return false

        let nextLaterList = await this.getLaterList()

        if (!nextLaterList.length) {
            return this.setState({ laterHasMore: false })
        }

        this.pushLaterlist(nextLaterList)
    }

    // 处理收起点击
    handleFoldClick = () => {
        // this.props.changeTabCallBack('')
        this.props.dispatch(setEffectQuickPageChange(''))
    }

    // 处理tab点击
    handleTabClick = async tab => {
        const dealAtHighLight = async () => {
            let data = await audioBusHignlightDel({ type: 'at' })
            if (data && data.code == 200) {
                this.props.dispatch(setEffectQuickAtingChange(false))
            }
        }

        if (tab == 'at') {
            dealAtHighLight()
            this.refreshList()
        }

        if (tab == 'later') {
            this.refreshList()
        }

        this.props.dispatch(setEffectQuickPageChange(tab))
    }

    // 处理未读点击
    handleUnreadChange = e => {
        let checked = e.target.checked
        this.setState({ isunread: checked })

        util.yachLocalStorage.ls('effect-quick-isunread', checked)

        util.sensorsData.track('Click_Chat_Element', {
            pageName: '01-139',
            $element_name: checked ? '01-266' : '01-267'
        })
    }

    // 处理at卡片点击
    handleAtCardClick = async card => { 
        audioBusMessageDeal({
            type: 'at',
            clientId: card.clientId
        })

        this.modifyAtList(card.clientId, {
            read: 1
        })

        const { clientId = '', time = Date.now(), sessionId} = card
        let res = await util.yach.locationSessionUseIdClient(clientId, time, true, sessionId, true, true, 'quick')

        if (res && res.error) {
            this.deleteAtlist(clientId)
            // audioBusMessageDel({ clientId, idDel: 1})
            util.yach.messageDelReport(clientId)
        }

        util.sensorsData.track('Click_Chat_Element', {
            pageName: '01-139',
            $element_name: '01-265'
        })
    }

    // 处理later卡片点击
    handleLaterCardClick = async card => {
        const { clientId = '', time = Date.now(), sessionId} = card
        let res = await util.yach.locationSessionUseIdClient(clientId, time, true, sessionId, true, true, 'quick')

        if (res && res.error) {
            this.deleteLaterlist(clientId)
            // audioBusMessageDel({ clientId, idDel: 1})
            util.yach.messageDelReport(clientId)
        }

        util.sensorsData.track('Click_Chat_Element', {
            pageName: '01-140',
            $element_name: '01-265'
        })
    }

    // 处理单个处理点击
    handleResolveClick = async (id, e) => {
        e.stopPropagation()
        let data = await audioBusMessageDeal({
            type: 'later',
            clientId: id
        })
        if (data && data.code == 200) {
            this.modifyLaterList(id, { none: true })
            setTimeout(() => {
                this.deleteLaterlist(id)
                !this.state.laterlist.length && this.refreshList()
            }, 200);
        } else {
            message.error(util.locale('im_operate_error'))
        }

        util.sensorsData.track('Click_Chat_Element', {
            pageName: '01-140',
            $element_name: '01-268'
        })
    }

    // 处理全部处理点击
    handleResolveAllClick = () => {
        this.setState({ resolveAllShow: true })

        util.sensorsData.track('Click_Chat_Element', {
            pageName: '01-140',
            $element_name: '01-269'
        })
    }

    // 处理确定全部处理点击
    handleSureResolveAll = async () => {
        let data = await audioBusMessageDeal({
            type: 'later',
            is_all: '1'
        })
        if (data && data.code == 200) {
            this.clearLaterList()
            let data = await audioBusHignlightDel({ type: 'later' })
            if (data && data.code == 200) {
                this.props.dispatch(setEffectQuickLateringChange(false))
            }
        } else {
            message.error(util.locale('im_operate_error'))
        }
        this.setState({ resolveAllShow: false })

        util.sensorsData.track('Click_Chat_Element', {
            pageName: '01-140',
            $element_name: '01-270'
        })
    }

    // 处理取消全部处理点击
    handleCancelResolveAll = () => {
        this.setState({ resolveAllShow: false })

        util.sensorsData.track('Click_Chat_Element', {
            pageName: '01-140',
            $element_name: '01-271'
        })
    }

    render() {
        const props = {
            boxStyle: this.state.boxStyle,
            atlist: this.state.atlist,
            laterlist: this.state.laterlist,
            isunread: this.state.isunread,
            resolveAllShow: this.state.resolveAllShow,
            effectQuickPage: this.props.effectQuickPage,
            ating: this.props.effectQuickStatus.ating,
            latering: this.props.effectQuickStatus.latering,
            atHasMore: this.state.atHasMore,
            laterHasMore: this.state.laterHasMore,
            handleFoldClick: this.handleFoldClick,
            handleTabClick: this.handleTabClick,
            computedShowTime: this.computedShowTime,
            handleResolveAllClick: this.handleResolveAllClick,
            handleSureResolveAll: this.handleSureResolveAll,
            handleCancelResolveAll: this.handleCancelResolveAll,
            handleAtCardClick: this.handleAtCardClick,
            handleLaterCardClick: this.handleLaterCardClick,
            handleResolveClick: this.handleResolveClick,
            handleUnreadChange: this.handleUnreadChange,
            handleAtLoadMore: this.handleAtLoadMore,
            handleLaterLoadMore: this.handleLaterLoadMore,
        }

        return <EffectQuickList {...props} />
    }
}

const mapStateToProps = state => ({
    effectQuickPage: state.effectQuickPage,
    effectQuickStatus: state.effectQuickStatus
})

export default connect(mapStateToProps)(EffectQuickListContainer)

