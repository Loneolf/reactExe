// react
import React, { useEffect, useState, useRef }  from 'react';
import {connect} from 'react-redux'

// actions
import { setEffectGroupDelData } from '@r/actions/effectMode';

// util
import * as util from '@u/util.js';

// serverce
import { audioDivSessionDel } from '@s/session/session';

// components
import CommonModal from '@/components/common/common-modal';

// antd
import { message } from 'antd';

const DissolutionGroup = (props) => {

    const {effectGroupDelData = {}, effectGroupDetailsType} = props;
    const [modalVisible, setModalVisible] = useState(false);

    useEffect(() => {
        setModalVisible(effectGroupDelData.modalVisible);
        if (effectGroupDelData.type === 'immediate') setSessionGroupDel({sg_id: effectGroupDelData.id})
    }, [effectGroupDelData])

    // 解散自定义分组
    const setSessionGroupDel = async(params) => {
        try {
            const res = await audioDivSessionDel(params);
            
            if(res.code === 900002) return message.warning(res.msg);
            if (res.code !== 200) return message.warning(util.locale('common_errorMsg5'));
            if (effectGroupDetailsType) util.eventBus.emit('effect:home:go:item');
            props.setEffectGroupDelData({modalVisible: false});
        } catch (error) {
            message.warning(util.locale('common_errorMsg5'));
            console.log(error)
        }
    }

    // OK
    const handleDelOK = () => {
        setSessionGroupDel({sg_id: effectGroupDelData.id})
        setModalVisible(false);
    }

    // cancel
    const handleDelCancel = () => {
        setModalVisible(false);
        props.setEffectGroupDelData({modalVisible: false, name: effectGroupDelData.name});
    }
    return (
        <CommonModal
            modalTile        = {util.locale('im_effect_mode_text_12')}
            modalVisible     = { modalVisible }
            setOKModal       = { handleDelOK }
            setonCancelModal = { handleDelCancel }
            modalContent     = {util.locale('im_effect_mode_text_19').replace('[xxx]', effectGroupDelData.name)}
            closable         = {false}
        />
    )
}

const mapStateToProps = state => ({
    effectGroupDelData: state.effectGroupDelData,
    effectGroupDetailsType: state.effectGroupDetailsType,
});

const mapDispatchToProps = dispatch => {
    return {
		setEffectGroupDelData: v => dispatch(setEffectGroupDelData(v)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(DissolutionGroup);
