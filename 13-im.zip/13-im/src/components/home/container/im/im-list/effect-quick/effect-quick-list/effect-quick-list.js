import React from 'react'

import css from './index.scss'
import * as util from '@u/util.js'

import { Tooltip, Tabs, Checkbox } from 'antd'
import CommonModal from '@c/common/common-modal'
import InfiniteScroll from 'react-infinite-scroller'

const TabPane = Tabs.TabPane

export default props => (
    <div className={css.box} style={props.boxStyle}>
        <div className={css.hide}>
            <Tooltip title={util.locale('im_effect_quick_hide')}>
                <span onClick={props.handleFoldClick}>
                    <span className="iconfont-yach yach-149_xiaoxisulan_shouqi"></span>
                </span>
            </Tooltip>
        </div>
        <div className={css.content}>
            <Tabs activeKey={props.effectQuickPage} onTabClick={props.handleTabClick}>
                <TabPane 
                    tab={<Tooltip title={props.ating ? util.locale('im_effect_quick_hasnew') : ''}>
                        <span className={css.at + ' ' + (props.ating ? css.active : '')}>
                            <span className="iconfont-yach yach-149_xiaoxisulan_wode"></span>
                        </span>
                    </Tooltip>} 
                    key="at"
                >
                    <div className={css.title}>
                        <span>{!!props.atlist.length && util.locale('im_effect_quick_last7msg')}</span>
                        <label className={css.unread}>
                            <input type="checkbox" checked={props.isunread} onChange={props.handleUnreadChange}/>
                            <span className={css.checkbox}>
                                {!props.isunread && <span className="iconfont-yach yach-weixuanzhong"></span>}
                                {props.isunread && <span className="iconfont-yach yach-xuanzhong"></span>}
                            </span>
                            <span>{util.locale('common_unread')}</span>
                        </label>
                        {/* <Checkbox checked={props.isunread} onChange={props.handleUnreadChange}>
                            {util.locale('common_unread')}
                        </Checkbox> */}
                    </div>
                    <div className={css.list}>
                        <InfiniteScroll
                            initialLoad={false}
                            loadMore={props.handleAtLoadMore}
                            hasMore={props.atHasMore}
                            useWindow={false}
                        >
                            {props.atlist.map(v => <div className={css.card} key={v.clientId} onClick={props.handleAtCardClick.bind(null, v)}>
                                <div className={css.img}>
                                    <img src={v.pic} alt=""/>
                                </div>
                                <div className={css.msg}>
                                    <div className={css.name}>
                                        <span>{v.from_name}</span>
                                        <span>{props.computedShowTime(v.time)}</span>
                                    </div>
                                    <div className={css.text}>
                                        <span>{v.message}</span>
                                        {!v.read && <div className={css.icon + ' ' + css.hong}>
                                            <span></span>
                                        </div>}
                                    </div>
                                    {v.from_type == 'group' && 
                                        <div className={css.from}>
                                            <span>
                                                <span className="iconfont-yach yach-xiezuo-richeng-xiangqing-canyuren"></span>
                                            </span>
                                            <span>{v.session_name}</span>
                                        </div>
                                    }
                                </div>
                            </div>)}
                        </InfiniteScroll>
                        {!props.atlist.length && 
                            <div className={css.kong}>
                                <p></p>
                                {props.isunread && <span>{util.locale('im_effect_quick_nounreadat')}</span>}
                                {!props.isunread && <span>{util.locale('im_effect_quick_noat')}</span>}
                            </div>
                        }
                    </div>
                </TabPane>
                <TabPane 
                    tab={<Tooltip title={props.latering ? util.locale('im_effect_quick_hasnew') : ''}>
                        <span className={css.later + ' ' + (props.latering ? css.active : '')}>
                            <span className="iconfont-yach yach-149_xiaoxisulan_shaohouchuli"></span>
                        </span>
                    </Tooltip>} 
                    key="later"
                >
                    {!!props.laterlist.length && <div className={css.title}>
                        <span></span>
                        <span className={css.resolveall} onClick={props.handleResolveAllClick}>
                            {util.locale('im_effect_quick_resolveall')}
                            <span className="iconfont-yach yach-149_xiaoxisulan_yichuli"></span>
                        </span>
                    </div>}
                    <div className={css.list}>
                        <InfiniteScroll
                            initialLoad={false}
                            loadMore={props.handleLaterLoadMore}
                            hasMore={props.laterHasMore}
                            useWindow={false}
                        >
                            {props.laterlist.map(v => <div className={css.card + ' ' + (v.none ? css.none : '')} key={v.clientId} 
                            onClick={props.handleLaterCardClick.bind(null, v)}>
                                <div className={css.img}>
                                    <img src={v.pic} alt=""/>
                                </div>
                                <div className={css.msg}>
                                    <div className={css.name}>
                                        <span>{v.from_name}</span>
                                        <span className={css.hoverhide}>{props.computedShowTime(v.udate * 1000)}</span>
                                    </div>
                                    <div className={css.text}>
                                        <span>{v.message}</span>
                                        <Tooltip title={util.locale('im_effect_quick_resolve')}>
                                            <div className={css.icon + ' ' + css.resolve} onClick={props.handleResolveClick.bind(null, v.clientId)}>
                                                <span className="iconfont-yach yach-149_xiaoxisulan_yichuli"></span>
                                            </div>
                                        </Tooltip>
                                    </div>
                                    {v.from_type == 'group' && 
                                        <div className={css.from}>
                                            <span>
                                                <span className="iconfont-yach yach-xiezuo-richeng-xiangqing-canyuren"></span>
                                            </span>
                                            <span>{v.session_name}</span>
                                        </div>
                                    }
                                </div>
                            </div>)}
                        </InfiniteScroll>
                        {!props.laterlist.length && 
                            <div className={css.kong}>
                                <p></p>
                                {<span>{util.locale('im_effect_quick_nolater')}</span>}
                            </div>
                        }
                    </div>
                </TabPane>
            </Tabs>
        </div>
        <CommonModal
            modalTile={util.locale('im_effect_quick_alllaterconfirm')}
            modalVisible={props.resolveAllShow}
            setOKModal={props.handleSureResolveAll}
            setonCancelModal={props.handleCancelResolveAll}
        />
    </div>
)