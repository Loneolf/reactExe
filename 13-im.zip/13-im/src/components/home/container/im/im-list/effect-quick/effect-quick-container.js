import React from 'react'
import { connect } from 'react-redux'

import EffectQuick from './effect-quick'

import { setEffectQuickPageChange } from '@r/actions/effectMode'

class EffectQuickContainer extends React.Component {
    constructor(props) {
        super(props)
    }

    componentDidMount() {
        if (this.props.effectQuickPage.startsWith('last-')) {
            let lastpage = this.props.effectQuickPage.split('last-')[1]
            this.props.dispatch(setEffectQuickPageChange(lastpage))
        }
    }

    componentWillUnmount() {
        this.props.dispatch(setEffectQuickPageChange(`last-${this.props.effectQuickPage}`))
    }

    componentDidUpdate(prevProps) {
        if(prevProps.effectQuickMode != this.props.effectQuickMode){
            this.handleEffectQuickMode(this.props.effectQuickMode);
        }
        // if(prevProps.sessionActive != this.props.sessionActive){
        //     this.handleEffectQuickMode(false)
        // }
    }

    handleEffectQuickMode = status => {
        if (status) {
            console.log('速览模式开启')
        } else {
            console.log('速览模式关闭')
            this.props.dispatch(setEffectQuickPageChange(''))
        }
    }

    render() {
        const props = {}

        return <EffectQuick {...props} />
    }
}

const mapStateToProps = state => ({
    effectQuickPage: state.effectQuickPage,
    effectQuickMode: state.effectQuickMode,
    sessionActive: state.sessionActive,
})

export default connect(mapStateToProps)(EffectQuickContainer)

