/**
 *  专注模式横幅
 */

import React from 'react';
import * as util from '@/utils/util';

import { Tooltip } from 'antd';
import css from './../index.scss';


export default React.memo(({details,effectMode,fresh})=>{
     return (
        !details && effectMode && (
            <div className={css.effectTitle}>
                <p>{util.locale('im_effect_mode_text_0')}</p>
                <Tooltip
                    align={{ offset: [0, -6] }}
                    placement="bottom"
                    title={`${util.locale('im_effect_mode_text_1')}${
                        util.electron.isMac() ? '(⌘+R)' : '(Ctrl+R)'
                    }`}
                >
                    <span
                        className={`iconfont-yach yach-shuaxin`}
                        onClick={ fresh }
                    ></span>
                </Tooltip>
            </div>
        )
    )
 }) 
