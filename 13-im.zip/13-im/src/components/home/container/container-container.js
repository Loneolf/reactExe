// react
import React from 'react';

// util
import * as util from '@u/util.js';

// Container
import Container from './container';

// ContainerContainer
export default function(props){

    const [maxed, setMaxed] = React.useState(false)

    function close(){
        util.electronipc.hide();
    }

    function max(){
        util.electronipc.max();
        setMaxed(!maxed)
    }
    
    function min(){
        util.electronipc.min();
    }

    return <Container maxed={maxed} min={min} max={max} close={close} />;
}