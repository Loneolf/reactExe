// react
import React from 'react';
import {Route} from 'react-router-dom';
// css
import css from './index.scss';
// components
import Im from './im/im-container.js';
import AddressList from './address-list/addresslist-container.js';
import Schedule from './coordination';
import OnlineOffice from './online-office/container.js';
import * as util from '@u/util.js';
const isElectronAndWin = util.electron.isElectron() && util.electron.isWin();

export default function({maxed, max, min, close}){
    return (
        <div className={css.box}>
            {isElectronAndWin ? <div className={css.windowsBanner}>
                <span onClick={min} className="iconfont-yach yach-win-zuixiaohua"></span>
                {
                    maxed ? <span onClick={() => max()} className="iconfont-yach yach-win-quanpingqiehuan"></span> 
                          : <span onClick={() => max()} className="iconfont-yach yach-win-quanping"></span>
                }
                <span onClick={close} className="iconfont-yach yach-win-guanbi"></span>
            </div> : ''}
            <div className = { isElectronAndWin ? css.isWindown : css.normal}>
                <Route path="/im"  component={Im} />
                <Route path="/address-list" component={AddressList} />
                <Route path="/schedule" component={Schedule}/>
                <Route path="/online-office" component={OnlineOffice}/>
            </div>
        </div>
    ); 
}