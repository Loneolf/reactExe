/*
 * @Descripttion: 协同功能开发入口文件
 * @version: 0.4
 */

import React from 'react';
import { Icon, message, Select } from 'antd';
import { connect } from 'react-redux';
import DateCalender from './schedule/schedule-date/date-container';

import MonthCalender from './schedule/schedule-month';

import DayGraphy from './schedule/schedule-daygraph';
import WeeklyContainer from './schedule/schedule-week/weekly-container';
import TopSchedule from './schedule/schedule-topswitch';
import { setMonthDialog } from '@r/actions/calender';
import {
    hideScheduleAdd,
    showScheduleAdd,
    changeTodayState,
    shareModelState,
    getEventList,
    initViewDate,
    setDotEventList,
    toggleCalenderType,
    toggleNunclick,
    toggleSelectCard,
    createSchdule,
    addSheduleList,
    setEnterMeetLoading,
} from '@r/actions/calender';
import sloarToLunar from './lib/unti.nun';
import { scheduleLittleDot, sheduleEventList, scheduleGetAudiece } from '@/services/schedule/schedule';
import * as sUtil from './lib/until';
import Selectcard from './schedule/component/selectcard';
import _ from 'lodash';
import c from './index.scss';
import * as util from '@u/util.js';
import MountScheduleList from './schedule/schedule-mycalender';
import SheduleShareContainer from './schedule/schedule-share/shedule-share-container';
import ScheculeSubscriptionContainer from './schedule/schedule-subscription/shedule-subscription-container';
import Remind from './remind/remind-container';
import { remindWin, remindListRequest } from '@r/actions/remind';

import CommonSpain from '@/components/common/common-spin';
import { meetingCreateJoinFun } from '@u/lib/zoom/zoomFn';
import VideoSessione from '@c/common/video-session/video-session-container';
import { videoSessionlHide, videoSessionShow } from '@/redux/actions/commonModal';
import * as unitCore from './lib/unit-core';

message.config({
    top: 80,
    duration: 2,
  });

class IndexCalender extends React.Component {
    constructor(props) {
        super(props);
        this.monthChildCalder = React.createRef();
        this.state = {
            day_isloading: false,
            type: 'date', //date remind
            showSubscriptionModal: false,
            showWeektip: false,
            showVideo: false,
            selectcard: {},
        };
    }

    async componentWillMount() {
        let { nday, nmonth, nyear } = sUtil.getTodayStance();
        await this.props.dispatch(
            initViewDate({
                year: nyear,
                month: nmonth,
                day: nday,
            })
        );
    }

    async componentDidMount() {
        this.setCreateAddShowOrHide('load');
        // 同步用户设置 挂载日历状态
        this.initUserSetting();

        await this.getShareShedule();

        this.props.dispatch(changeTodayState(false));
         
        if(window.location.pathname == '/schedule'){
            util.electronipc.browserf(async (v) => {
                // 切换屏幕 如果是超过12点就进行切换
                let { year, month, day } = this.props.initDate;
                let td = new Date();
                if (td.getFullYear() !== year || td.getMonth() !== month || td.getDate() !== day) {
                    await this.props.dispatch(
                        initViewDate({ year: td.getFullYear(), month: td.getMonth(), day: td.getDate() })
                    );
                }
            });
        }

        this.getLittleDot();

        !!this.props.monthAndDayList.day && this.getEventListTime();

        if (!util.yachLocalStorage.ls('subweekGuild')) {
            this.setState({ showWeektip: true });
        }

        document.addEventListener('click', this.bindWeeklocal, false);
        document.addEventListener('click', this.monthcardHandle,false);
        document.addEventListener('click', this.monthcardShow,false);
        window.getShareShedule = this.getShareShedule;
    }

    componentDidUpdate(prvprops, prvstate) {
        const { month, day } = this.props.monthAndDayList;
        if (this.props.refreshv && prvprops.refreshv.value !== this.props.refreshv.value) {
            month ? this.monthChildCalder.asyncMonthlist() : this.getEventListTime();
            if (!month && !day) {
                util.eventBus.emit('getWeekTime');
                util.eventBus.emit('setWeekLoading', true);
            }
            if (this.props.refreshv.type === 'all') this.getLittleDot();
        }
        //统计日志
        if (this.props != prvprops && prvprops.remindList.curType != this.props.remindList.curType) {
            const { remindList } = this.props;
            this.reportPageViewData({ 0: 101, 1: 108, 2: 111 }[remindList.curType], remindList.request ? 102 : 101);
        }
    }

    componentWillUnmount() {
        try {
            this.setCreateAddShowOrHide('unload');  
            this.props.dispatch(toggleSelectCard({}));
            this.props.dispatch(setMonthDialog({ show: false, datatime:"", list: []}));
            document.removeEventListener('click', this.selecCard);
            document.removeEventListener('click', this.bindWeeklocal, false);
            document.removeEventListener('click', this.monthcardHandle,false);
            document.removeEventListener('click', this.monthcardShow,false);
        } catch (e) {
            console.log(e);
        }
        this.setState = (state, callback) => {
            return;
        };
    }

    monthcardHandle = ()=>{
        this.props.dispatch(toggleSelectCard({}))
        util.eventBus.emit('click:month:card');
    }
    monthcardShow=()=>{
        this.props.dispatch(setMonthDialog({ show: false, datatime:"", list: []}));
    }

    bindWeeklocal = () => {
        if (this.state.showWeektip && !util.yachLocalStorage.ls('subweekGuild')) {
            util.yachLocalStorage.ls('subweekGuild', true);
            this.setState({ showWeektip: false });
        }
    };

    setCreateAddShowOrHide = (isflag) => {
        const { show } = this.props.scheduleAdd;
        const createSchedule = document.getElementById('createScheduleOut');
        if (isflag === 'unload' && show) {
            window.createDialog = 1;
            createSchedule && (createSchedule.style.display = 'none');
        }

        if (isflag === 'load' && show) {
            //this.props.dispatch(hideScheduleAdd({}));
            createSchedule && (createSchedule.style.display = 'block');
        }
    };

    // 显示音频视频控制弹窗
    showVideoSessioneModal = (e, selectcard, iscard) => {
        const parameter = {
            show: true,
            nickName: '',
            title: selectcard.title,
        };
        this.props.dispatch(videoSessionShow(parameter));
        this.setState({
            showVideo: true,
            selectcard: selectcard,
        });

        // 日程主页列表  日程简化卡片 -  加入会议按钮点击 埋点
        util.electronipc.electronZoomCallFn('getMeetingID', null, async (res) => {
            console.log(!res, 'resresresresresresres');
            if (res == 7) return util.yach.platformConfigGetFun();
            if (!res) {
                let pageName = iscard == 'iscard' ? '128' : '104';
                util.sensorsData.track('Click_Schedule_Element', {
                    pageName,
                    $element_name: '01-135',
                });
            }
        });

        e.stopPropagation();
    };

    // 加入会议
    handleJoinMeeting = (prams) => {
        console.log('加入会议参数是：', prams);
        this.setState({
            showVideo: false,
        });
        this.props.dispatch(videoSessionlHide());
        this.props.dispatch(
            setEnterMeetLoading({
                commonLoading: true,
                commonLoadingText: this.locale('calendar_notification_jionmeeting'),
            })
        );

        meetingCreateJoinFun(prams, () => {
            this.props.dispatch(
                setEnterMeetLoading({
                    commonLoading: false,
                    commonLoadingText: ' ',
                })
            );
        });
        // e.stopPropagation();
    };

    onlineOffice = (title, isVideoOff, isAudioOff) => {
        const { selectcard } = this.state;
        const params = {
            daily_meeting: selectcard.tags[0] && selectcard.tags[0].text,
            id: selectcard.meeting.id,
            type: 3,
            title: selectcard.title,
            isVideoOff,
            isAudioOff,
        };
        this.handleJoinMeeting(params);
    };

    initUserSetting = () => {
        let id = window.store.getState().userInfo.id || util.yachLocalStorage.ls('yach_userinfo').id;
        const lsSetting=util.yachLocalStorage.ls(`setUserSettingOfCalender-${id}`);
        if(!lsSetting) return;

        const {cancelschedule = true, nuncheckbox = true, refuseschedule = false,selfschedule=true}=lsSetting;
        this.props.dispatch(toggleNunclick({ cancelschedule,nuncheckbox,refuseschedule,selfschedule }));
    };

    scheduleAdd = () => {
        this.props.dispatch(showScheduleAdd({ id: '' }));
        util.sensorsData.track('Click_Schedule_Element', { pageName: 104, $element_name: 131 });
    };

    scheduleAddBtn = () => {
        this.props.dispatch(createSchdule({ from: 'create', time: [] }));
        this.scheduleAdd();
    };

    scheduleEdit = (id) => {
        this.props.dispatch(showScheduleAdd({ id }));
    };

    //切换subscriptionModal
    toggleSubscriptionModal = () => {
        this.setState((pre) => ({
            showSubscriptionModal: !pre.showSubscriptionModal,
        }));
    };

    // 获取共享给我日程的人的列表
    getShareShedule = async () => {
        const sharlist = await scheduleGetAudiece();
        const { code, msg, obj = [] } = sharlist || {};
        if (code === 200) {
            this.props.dispatch(addSheduleList(obj));
        } else {
            message.error('getShareShedule>>' + msg);
        }
    };

    // 请求参数准备
    paramPareFn = ({y,m,d,type})=>{ 
        let { year,month,day } = this.props.initDate;
        let { nuncheckbox,cancelschedule,refuseschedule ,selfschedule} = this.props.mountcalender;
        let { shareScheduleList } = this.props;

        this.setState((state) => ({ day_isloading: false }));
        y && (year = y) && d && (day = d) && m && (month = m);

        let trad = !!nuncheckbox? {has_holiday:1}:{};
        let has_cancel = !!cancelschedule?{has_cancel:0}:{has_cancel:1};
        let has_refuse = !!refuseschedule?{has_refuse:0}:{has_refuse:1};
        let has_self=!!selfschedule?{has_self:1}:{has_self:0};   
        // 第一次请求的时候需要传递这个参数 标识后端需要从服务器判断依赖 然后拉去最新鲜的数据
        let sharList = shareScheduleList.filter((item) => item.selected);
        let uids = sharList.map((item) => item.uid).join();

        let timezone = sUtil.gZone();
        let start_time, end_time;
        let  a=2;
        //console.log('当前的请求类型是',type);

        if(type === 'dot'){
            start_time = sUtil.timemillions(year,month,1-7);   
            end_time = sUtil.timemillions(year,month,day+37); 
            return {start_time,end_time,timezone,...trad,...has_cancel,...has_refuse,...has_self,uids,a};
           
        }
        else if(type === 'dlist'){
            start_time =  sUtil.timemillions(year,month,day,0,0,0);
            end_time =  sUtil.timemillions(year,month,day,23,59,59);
            return {start_time,end_time,timezone,...trad,...has_cancel,...has_refuse,...has_self,uids}; 
        }
        else{
            return {timezone,...trad,...has_cancel,...has_refuse,...has_self,uids};
        }
    }
    

    // 按照时间段获取日程数据  has_cancel,has_refuse
    getEventListTime = async (y, m, d) => {
        try {
            console.time('-ca-day-getEventListTime');
            let list = await sheduleEventList(this.paramPareFn({ y: y, m: m, d: d, type: 'dlist' }));
            const { code, msg, obj = {} } = list || {};
            if (code !== 200) {
                message.error(msg);
                this.setState({ day_isloading: true });
                return;
            }

            await this.props.dispatch(getEventList(obj));
            this.setState((state) => ({ day_isloading: true }));
            console.timeEnd('-ca-day-getEventListTime');
        } catch (e) {
            console.log('getEventListTime>>', e);
        }
    };

    // 小黑点
    getLittleDot = async (y, m, d) => {
        let { year, month, day } = this.props.initDate;
        try {
            console.time('-ca-getLittleDot--');
            let list = await scheduleLittleDot(this.paramPareFn({ y: y, m: m, d: d, type: 'dot' }));
            
            const { code, msg, obj = {} } = list || {};
            if (code !== 200) {
                message.error(msg);
                return;
            }
            let _tem = {};
            _tem[year + '-' + sUtil.fm(month + 1)] = obj.days; // 黑点 月份 表意+1即12个月，全局其他均是 11个月类型。
            this.props.dispatch(setDotEventList(_tem));
            console.timeEnd('-ca-getLittleDot--');
        } catch (e) {
            console.log('getLittleDot', e);
        }
    };

    /*月日切换*/
     DadMhandleChange= async (v)=> {
        let key = 192;
        if (v === 'month') {
            this.props.dispatch(toggleCalenderType({ month: true, day: false }));
        } else if (v === 'day') {
            key = 134;
            this.props.dispatch(toggleCalenderType({ month: false, day: true }));
            this.getEventListTime();
            return;
        } else {
            this.props.dispatch(toggleCalenderType({ month: false, day: false }));
        }
        util.sensorsData.track('Click_Schedule_Element', { pageName: 104, $element_name: key });
    }

    setTodayData = (v) => {
        let { year, month, day } = this.props.initDate;
        let { nday, nmonth, nyear } = sUtil.getTodayStance();
        // nyear === year && nmonth === month && nday === +day + v
        nyear === year && nmonth === month && nday === day
            ? this.props.dispatch(changeTodayState(false))
            : this.props.dispatch(changeTodayState(true));
    };

    /*顶部日月箭头来回切换*/
     changeCalender= async(v)=> {
        let { monthAndDayList } = this.props;
        let { year, month, day } = this.props.initDate;
        let { day: mday, month: mmonth } = monthAndDayList;

        if (mday) {
            let newD = new Date(year, month, +day + v);
            this.props.dispatch(
                initViewDate({ year: newD.getFullYear(), month: newD.getMonth(), day: newD.getDate() })
            );

            newD.getMonth() !== month && this.getLittleDot(); // 不相等，说明开始从天切换了一个月了，小黑点跟进
            this.getEventListTime();
        }

        if (mmonth) {
            this.monthChildCalder.changeMonth(v);
            this.monthChildCalder.asyncMonthlist(v);
            this.getLittleDot();
        }

        if (!mmonth && !mday) {
            let tm = util.moment({ year, month, day });
            Number(v) > 0 ? tm.add(7, 'days') : tm.subtract(7, 'days');
            let y = tm.year(),
                m = tm.month(),
                d = tm.date();
            await this.props.dispatch(initViewDate({ year: y, month: m, day: d }));
            util.eventBus.emit('setWeekLoading', true);
            util.eventBus.emit('getWeekTime');
        }

        this.setTodayData(v);
        util.sensorsData.track('Click_Schedule_Element', { pageName: 104, $element_name: 193 });
    }

    // 返回今天
     gototoday=()=>{
        //  console.log(1);
        let {day:mday,month:mmonth} =  this.props.monthAndDayList;
        let { nday,nmonth,nyear } =  sUtil.getTodayStance();

        this.props.gotoToday && this.props.dispatch(initViewDate({year:nyear,month:nmonth,day:nday})); 
        this.props.dispatch(changeTodayState(false)); 

        if(mday){
            sUtil.setScrollDayViewHeight();
            this.getEventListTime(nyear,nmonth,nday);
        }
        if(mmonth){
            this.monthChildCalder.asyncMonthlist();
        }

        if(!mmonth && !mday){
            util.eventBus.emit('setWeekLoading',true);
            util.eventBus.emit('getWeekTime');
            sUtil.setScrollDayViewHeight(1);
        }

        this.getLittleDot(nyear,nmonth,nday);
        util.sensorsData.track('Click_Schedule_Element',{pageName: 104, $element_name: 191});

    }

    // 添加共享人 触发函数
    showShareModle = async () => {
        await this.props.dispatch(shareModelState(true));
        util.sensorsData.track('Click_Schedule_Element', { pageName: 115, $element_name: 200 });
    };

    //添加提醒
    addRemind = () => {
        this.props.dispatch(remindWin({ show: true }));
        this.reportClickData(131);
    };
    // 改变提醒列表
    remindChange = (v) => {
        this.props.dispatch(remindListRequest({ remind_type: v }));
        this.reportClickData({ 0: 226, 1: 349, 2: 350 }[v]);
    };
    //改变类型
    changeType = (type) => {
        this.setState({ type });
        if (type === 'remind') {
            const { remindList } = this.props;
            this.reportPageViewData({ 0: 101, 1: 108, 2: 111 }[remindList.curType], remindList.request ? 102 : 101);
        }
    };

    addBtn = (event) => {
        const { type } = this.state;
        if (type === 'date') this.scheduleAddBtn();
        if (type === 'remind') this.addRemind();
        this.props.dispatch(setMonthDialog({ show: false, datatime:"", list: []}));
    };

    reportPageViewData(TabName, isFeedback) {
        //console.log(TabName, isFeedback)
        util.sensorsData.track('PageView_TiXing', { pageName: 204, TabName, isFeedback });
    }

    reportClickData($element_name) {
        util.sensorsData.track('Click_TiXing_Element', { pageName: 204, $element_name });
    }

    selectTypeOfSchedule = () => {
        const { monthAndDayList } = this.props;
        const { month, day } = monthAndDayList;

        if (month) return <MonthCalender c={c} onRef={(ref) => (this.monthChildCalder = ref)}  />;

        if (day)
            return (
                <DayGraphy
                    {...{
                        c,
                        scheduleAdd: this.scheduleAdd,
                        day_isloading: this.state.day_isloading,
                        getEventListTime: this.getEventListTime,
                        handleJoinMeeting: this.handleJoinMeeting,
                        showVideoSessioneModal: this.showVideoSessioneModal,
                    }}
                />
            );

        return <WeeklyContainer paramPareFn={this.paramPareFn} />;
    };

    getFormatTime = (data, isday) => {
        return unitCore.formatTime(data, isday ? '' : 'noday');
    };

    render() {
        const { type, showVideo } = this.state;
        let { year, month, day } = this.props.initDate;

        let nun = sloarToLunar(year, month + 1, day);
        let subnun = `${nun.lunarMonth}月${nun.lunarDay}`;
        let shownun = sUtil.getLunarHoliday(subnun);
        let { commonLoading, commonLoadingText } = this.props.enterMeeting;

        const { monthAndDayList } = this.props;

        const istype = () => {
            const { day, month } = monthAndDayList;
            if (day) return 'day';
            if (month) return 'month';
            return 'week';
        };

        return (
            <div className={c.wraplist} id="coordinationOut">
                <div className={c.wrapheader}>
                    <ul className={c.type}>
                        <li
                            className={type === 'date' ? c.active : ''}
                            onClick={() => {
                                this.changeType('date');
                            }}
                        >
                            <span>{this.locale('calendar_top_tab_schecule')}</span>
                        </li>
                        <li
                            className={type === 'remind' ? c.active : ''}
                            onClick={() => {
                                this.changeType('remind');
                            }}
                        >
                            <span>{this.locale('calendar_top_tab_remind')}</span>
                        </li>
                    </ul>

                     <div className = {c.dateselect} style = {{display: type !=='remind' ? 'none' : ''}}>
                        <Select suffixIcon={<Icon type="caret-down" />} defaultValue={0} style={{ width: 96 }} onChange={this.remindChange.bind(this)}>
                            <Select.Option value={0} >{this.locale('remind_top_select_all')}</Select.Option>
                            <Select.Option value={1}>{this.locale('remind_top_select_send')}</Select.Option>
                            <Select.Option value={2}>{this.locale('remind_top_select_receive')}</Select.Option>
                        </Select>
                    </div>
                </div>
                {type === 'remind' ? <Remind /> : null}

                <div className={c.contentlist} style={{ display: type !== 'date' ? 'none' : '' }}>
                    <div className={c.leftdate}>
                        <DateCalender
                            {...{
                                getAsyncMonthlist: this.monthChildCalder.asyncMonthlist,
                                getEventListTime: this.getEventListTime,
                                getLittleDot: this.getLittleDot,
                            }}
                        />

                        <MountScheduleList
                            {...{
                                locale: this.locale,
                                mountcalender:this.props.mountcalender,
                                dispatch:this.props.dispatch,
                                getEventListTime: this.getEventListTime,
                                asyncMonthlist: this.monthChildCalder.asyncMonthlist,
                                getLittleDot: this.getLittleDot,
                                showShareModle: this.showShareModle,
                                toggleSubscriptionModal: this.toggleSubscriptionModal,

                                ...this.props,
                            }}
                        />
                    </div>
                    <div className={c.rightContent}>
                        <TopSchedule
                            type={this.state.type}
                            monthAndDayList={this.props.monthAndDayList}
                            gotoToday={this.props.gotoToday}
                            gototoday={this.gototoday}
                            changeCalender={this.changeCalender}
                            initDate={this.props.initDate}
                            shownun={sUtil.getLunarHoliday(subnun)}
                            DadMhandleChange={this.DadMhandleChange}
                            istype={istype}
                            mountcalender={this.props.mountcalender}
                            locale={this.locale}
                            choiseTime={ util.moment(year + '-' + (month + 1) + '-' + day)}
                            getFormatTime={this.getFormatTime}
                        />

                        {this.selectTypeOfSchedule()}
                    </div>
                </div>
                <Selectcard c={c} showVideoSessioneModal={this.showVideoSessioneModal} />
                {(showVideo&&this.props.videoSessioneModal.show) && <VideoSessione onlineOffice = {this.onlineOffice} teamType = 'schedule'/>}
                
                {/* <ScheduleCardContainer {...this.props.scheduleCard} /> */}

                { this.props.shareModelState?<SheduleShareContainer />:null }
                
                { commonLoading?<CommonSpain text={commonLoadingText} />:null } {/* 视频会议loading*/}
                
                {
                   this.state.showSubscriptionModal?<ScheculeSubscriptionContainer toggleSubscriptionModal={this.toggleSubscriptionModal}/>:null
                }
                <div className={c.creatSchedule} style={monthAndDayList.day&&type !== 'remind'?{right:212}:null} onClick={this.addBtn}>
                    <span className={'iconfont-yach yach-0428_richengxiangqing-chuangjianricheng-tianjiajiahao '+" "+c.creaticon}></span>
                </div>
            </div>

       );
    }
}

const mapStateToProps = (state) => {
    return {
        initDate            : state.calender.initDate,
        gotoToday           : state.calender.gotoToday,
        refreshv            : state.calender.refreshv,
        mountcalender       : state.calender.mountcalender,
        monthAndDayList     : state.calender.monthAndDayList,
        selectcard          : state.calender.selectcard,
        dotlist             : state.calender.dotlist,
        shareModelState     : state.calender.shareModelState,
        shareScheduleList   : state.calender.shareScheduleList,
        remindList          : state.remindList,
        enterMeeting        : state.calender.enterMeeting,
        scheduleAdd         : state.calender.scheduleAdd,
        scheduleCard        : state.calender.scheduleCard,
        videoSessioneModal  : state.videoSessioneModal,
    };
};

export default connect(mapStateToProps, null)(IndexCalender);
