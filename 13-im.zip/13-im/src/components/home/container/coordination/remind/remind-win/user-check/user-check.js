// react
import React from 'react';
// css
import css from './user-check.scss';
import * as util from '@/utils/util';
import {Checkbox, Col, Row} from 'antd';

class UserCheck extends React.Component {
  constructor(props) {
    super(props);
  }

  render () {
    const { loadingText,usersMessage,userChecked,isCheckedAll,checkItem,checkAll } = this.props;

    const userListDom = usersMessage.map(user => {
      return (
          <Col span={8} key={user.id}>
            <Checkbox onChange={checkItem} value={user.id}>
              <span className={css.userInfo}>
                <img src={user.avatar || util.config.nim.showimg} alt="" />
                <span className={css.userName}>{user.nick}</span>
              </span>
            </Checkbox>
          </Col>
      )
    });

    return (
        <div className = {css.userContainer}>
          <div  className = {css.userList}>
            <Row className={css.item}>
              <Checkbox onChange={checkAll} checked={isCheckedAll}>
                <span className={css.name}>{util.locale('common_select_all')}</span>
              </Checkbox>
            </Row>
            <Checkbox.Group style={{ width: '100%' }} value={userChecked.map(v => v.id)}>
              { userListDom }
              { loadingText  && <p className={css.userLoading}>{util.locale('calendar_info_section_user_loading')}</p>}
            </Checkbox.Group>
            <p id="checkIsIns" className={css.checkIsIn}></p>
          </div>
        </div>
    )
  }
}

export default UserCheck;
