// react
import React, {Fragment} from 'react';
import {connect} from 'react-redux';
import {message} from 'antd';
import {withRouter} from 'react-router';
// action/service
import {remindFeedGet, remindUserList, remindFeedInvite, remindUserCheck} from "@/services/remind/remind";
import {hideSlideModal} from "@/redux/actions/commonModal";
import * as remindAction from '@r/actions/remind';
// component
import RemindInfo from './remind-info';
import UserAdd from "@/components/common/user-add/user-add-container";
import TipModal from "@/components/common/tip-modal";
import {
    closeRemindNotification
} from '@c/home/container/coordination/remind/common'
import * as util from '@u/util.js';
import { async } from 'q';

class RemindInfoContainer extends React.Component {
    state = {
        inFo: {},
        userList: {},
        peopleStage: 0, // 未读， 已读
        openMore: false, // 展开更多人
        userAddShow: false,
        loading: false,
        showDialog: false,
        tipModalContent: '',
        tipVisible: false,
        defaultIds: []
    };

    componentDidMount() {
        const {id} = this.props.slideModal;
        closeRemindNotification({id});
        this.getDetail(id);
        util.sensorsData.track('PageView_TiXing', {pageName: 206});
    }

    // 弹出加人组件
    handleShowUserAdd = () => {
        this.setState({
            userAddShow: true,
        });
        this.uploadClickSensorsData(358);
    }

    // 关闭加人弹框
    closeUserAdd = () => {
        this.setState({
            userAddShow: false,
        });
    };

    // 加人确认回调
    okUserAdd = async (value) => {
        const {id} = this.props.slideModal;
        this.setState({ loading: true })
        const {allDataUsers} = value;
        const newAdd=allDataUsers.map(item=>item.id+'');
        const o = await remindFeedInvite({rid: id, uids:newAdd.join()});
        if(o.code==200){
            message.success(this.locale('calendar_toast_add_success'))
            // 请求新详情数据
            this.getUserList(id);
            this.setState({
                userAddShow: false,
                loading: false
            })
        }else{
            message.warning(o.msg);
            this.initialize();
            this.setState({
                userAddShow: false,
                loading: false
            })
        }
    }

    // 获取信息
    getDetail=(id)=>{
        remindFeedGet({rid: id}).then(o => {
            const {code, obj} = o || {};
            if (code === 200) {
                this.getUserList(id);
                this.setState({inFo: obj});
                util.nimUtil.publishEvent(10003, {type:3,data:{rid: id}});
                this.uploadShowSensorsData(obj);
            }else{
                this.initialize(); 
                message.warning(o.msg); 
            }
        })
    }

    // 获取用户列表
    getUserList=(id)=>{
        remindUserList({rid: id, type: 0}).then(async (o) => {
            let {code, obj} = o || {};
            if (code === 200) {
                let {unread,read}=obj;
                unread= await util.yach.base64ImgArrGetTmp(unread,'pic');
                read= await util.yach.base64ImgArrGetTmp(read,'pic');
                obj={...obj,unread,read};
                this.setState({
                    userList: obj ,
                    defaultIds: [...obj.read, ...obj.unread].map(item=>item.id+'')
                });
            }else{
                message.warning(o.msg);
            }
        })
    }

    // 展开更多
    changeOpenMore=()=>{
        this.setState({
            openMore:true,
        })
    }

    // 切换状态
    changePeopleStage=(value)=>{
        this.setState({
            peopleStage: value,
            openMore: false,
        });
        if(value){
            this.uploadClickSensorsData(207);
        }else{
            this.uploadClickSensorsData(208);
        }
    }

    goMessage = async(type, source, idClient, msgTime) => {
        if(!source) return;
        const scenes = {1: 'team', 2: 'p2p'};
        source = source.replace(`${util.yach.getAccount()},`, '');
        source = source.replace(`,${util.yach.getAccount()}`, '');
        if(scenes == 'team'){
            if(!await this.checkSessionState(source)) return this.showDialog();
        }
        const timePoint = msgTime.indexOf('.');
        if(timePoint && timePoint>0){
            msgTime = msgTime.substr(0, timePoint);
        }
        this.uploadClickSensorsData(356);
        try {
            this.goSession(scenes[type], source, ()=>{
                for (let index = 0; index < this.props.messageList.length; index++) {
                    if(this.props.messageList[index].idClient == idClient) {
                        util.eventBus.emit('clickMessageId', idClient);
                        this.initialize();
                        return;
                    }
                }
                this.getBeforeItem(Number.parseInt(msgTime), idClient ,scenes[type], source);
            })
        } catch (error) {
            this.initialize();
        }
    }

    checkSessionState = async (remind_source) => {
        const obj =  await remindUserCheck({tid: remind_source});
        const {data = {}} = obj || {};
        return data.state || 0;
    }

    initialize = () => {
        this.props.hideSlideModal();
    }

    goSession = async (scene, target, cb) => {
        if(!~window.location.href.indexOf('/im')) this.props.history.replace('/im'); 
        // if(this.props.sessionActive.id != target){
        //     await util.nim.activeRow(scene, target+'');
        // }

        if(window.session_active.id != target)
            await util.nim.activeRow(scene, target+'');

        cb();
    };

    loadMoreDown = async(time, idClient,type, source) => {
        this.setState({ downLoading: false });
        let obj = {};
        try {
            obj = await util.nim.pushMessageList(type,source,time,20, true,1);
        } catch (error) {
            this.initialize();
        }
        if(obj) return this.hideSearchPop(idClient);
        this.initialize();
    }

    getBeforeItem = async(time, idClient,type, source) => {
        let obj = {};
        try {
            obj = await util.nimUtil.getLocalMsgs(type,'', source, time,10,false, '');
        } catch (error) {
            this.initialize();
        }
        if(obj && obj.msgs.length) {
            let time = undefined;
            time = obj.msgs.length<5 ? obj.msgs.pop().time : obj.msgs[4].time;
            return this.loadMoreDown(time, idClient,type, source);
        }
       this.hideSearchPop(idClient);
    }

    hideSearchPop = (idClient) => {
        this.time2 && clearTimeout(this.time2)
        this.time2 = setTimeout(() => {
            util.eventBus.emit('clickMessageId', idClient);
        }, 500);
        this.initialize();
    }

    showDialog = () => {
        this.setState({showDialog: true});
        this.time1 && clearTimeout(this.time1)
        this.time1 = setTimeout(() => {
            this.setState({showDialog: false});
        }, 3000);
    }

    handleRecall = () =>{
        const {id} = this.props.slideModal;
        this.setState({
            tipVisible: true,
            tipModalContent: this.locale('remind_confirm_recall')
        });
        this.tipCallback = () =>{
            this.props.remindListRDRequest({opr:'recall', id}); 
            this.tipClose();
            this.initialize();
        }
        this.uploadClickSensorsData(355);
    }

    handleDel = () =>{
        const {id} = this.props.slideModal;
        this.setState({
            tipVisible: true,
            tipModalContent: this.locale('remind_confirm_delete')
        });
        this.tipCallback = () =>{
            this.props.remindListRDRequest({opr:'delete', id}); 
            this.tipClose();
            this.initialize();
        }
        this.uploadClickSensorsData(197);
    }

    tipClose = () => {
        this.setState({
            tipVisible: false
        });
    }

    uploadClickSensorsData = (element_name, event) => {
        util.sensorsData.track(event || 'Click_TiXing_Element', {pageName: 206, $element_name: element_name});
    }

    uploadShowSensorsData = (value) => {
        if(!value) return;
        const{attachment, remind_source, state, creator} = value;
        if(attachment) this.uploadClickSensorsData(144, 'Expo_TiXing_Element');
        if(remind_source) this.uploadClickSensorsData(356, 'Expo_TiXing_Element');
        if(state == 2) this.uploadClickSensorsData(355, 'Expo_TiXing_Element');
        if(creator == util.yach.getAccount()) this.uploadClickSensorsData(358, 'Expo_TiXing_Element');
    }

    render() {
        const {
            inFo={},
            peopleStage,
            openMore,
            userAddShow,
            loading, 
            showDialog,
            tipModalContent,
            tipVisible,
            userList,
            defaultIds
        }=this.state;
        const props = {
            inFo,
            peopleStage,
            openMore,
            showDialog,
            userList,
            account: util.yach.getAccount(),
            goMessage: this.goMessage,
            changeOpenMore: this.changeOpenMore,
            changePeopleStage: this.changePeopleStage,
            handleShowUserAdd: this.handleShowUserAdd,
            handleRecall: this.handleRecall,
            handleDel: this.handleDel,
            uploadClickSensorsData: this.uploadClickSensorsData,
            locale:this.locale
        };
        const userAddProps = {
            loading: loading,
            show: userAddShow,
            onOk: this.okUserAdd,
            onClose: this.closeUserAdd,
            disabledids: defaultIds,
            title: this.locale('remind_useradd_share_title'),
            leftTitle: this.locale('remind_useradd_share_lefttitle'),
            maxLength: 1000
        };
        const tipModalProps = {
            title: this.locale('calendar_top_tab_remind'),
            visible: tipVisible,
            content: tipModalContent,
            callback: this.tipCallback,
            close: this.tipClose
        }

        return (
            <Fragment>
                <RemindInfo {...props} />
                <UserAdd {...userAddProps} />
                <TipModal {...tipModalProps}/>
            </Fragment>
        )
    }
}

const mapStateToProps = state => {
    return {
        // sessionActive: state.sessionActive,
        messageList: state.messageList,
        remindList: state.remindList
    };
};

const mapDispatchToProps = {
    remindListRDRequest: remindAction.remindListRDRequest,
    hideSlideModal
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(withRouter(RemindInfoContainer));
