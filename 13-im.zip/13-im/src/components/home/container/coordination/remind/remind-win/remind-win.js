// react
import React from 'react';

// css
import css from './index.scss';

import {Input,Button} from 'antd';
import CommonBtn from '@c/common/common-btn';
import * as util from '@/utils/util';

import UserCheck from './user-check/user-check';
import UserList from './user-list';
import {showPreviewModal} from '@r/actions/commonModal';
const {TextArea} = Input;

// Im
export default class RemindWin extends React.Component {
    constructor(props) {
        super(props);
    }

    showImg = (file) => {
        util.electronipc.electronOpenImage({
            success:true,
            data:[{id: file, url: file, curr: true}],
        });
        //window.store.dispatch(showPreviewModal({type: 'img', url: file || util.config.nim.showimg}));
    }

    render() {
        const {remindWin, remindType, remindText, files=[], users, usersShow,remindSourceType,
          loadingText, usersMessage, userChecked, isCheckedAll,
        } = this.props;
        const {
                handleInputChange,
                closeWin,
                handleSubmit,
                handleRemindTypeClick,
                handleShowUserAdd,
                handlePeopleDelte,
                handleFileDelete,
                handleFile,
                handleMaiDian,
                uploadLoading,
                checkAll,
                checkItem,
            } = this.props;

        let _html = util.yach.convertExpression(util.yach.textFiltering(remindText.substr(0, 1000)), '18px', '18px');
        return (
            <div style = {{display:remindWin.show?'':'none'}} className = {css.boxall} onMouseDown={(e)=>e.stopPropagation()}>
                {/* mask */}
                <div className = {css.mask}></div>
                {/* box */}
                {
                  remindSourceType === '3' ?
                      <div className = {css.bosh} id='checkusers'>
                        {/* title */}
                        <div className = {css.title}>
                          <span>{this.locale('calendar_create_info_notify_immediately')}</span>
                          <span className={css.close+' icon iconfont iconiconcha'} onClick={closeWin}></span>
                        </div>
                        {/* main */}
                        <ul className = {css.main}>
                          <li className = {`${css.item} ${css.remind}` }>
                            <div className = {`${css.icon} ${css.icontixing1} iconfont icontixing1`}/>
                            <ul className = {css.list}>
                              <li className = {remindType === '0'? css.cur : ''}
                                  onClick = {e => handleRemindTypeClick('0', 0)}>
                                <span className = {css.txt}>{this.locale('remind_type_option1')}</span>
                                <div className = {css.flash}>
                                  <span className = "icon iconfont-yach yach-147-icon-tixing-shandian"></span>
                                </div>
                              </li>
                              <li className = {remindType === '1'? css.cur : ''}
                                  onClick = {e => handleRemindTypeClick('1', remindWin.messageNum)}>
                                <span className = {css.txt}>{this.locale('remind_type_option2')}</span>
                                <div className = {css.flash}>
                                  <span className = "icon iconfont-yach yach-147-icon-tixing-shandian"></span>
                                  <span className = "icon iconfont-yach yach-147-icon-tixing-shandian"></span>
                                </div>
                              </li>
                              <li className = {remindType === '2'? css.cur : ''}
                                  onClick = {e => handleRemindTypeClick('2', remindWin.phoneNum)}>
                                <span className = {css.txt}>{this.locale('remind_type_option3')}</span>
                                <div className = {css.flash}>
                                  <span className = "icon iconfont-yach yach-147-icon-tixing-shandian"></span>
                                  <span className = "icon iconfont-yach yach-147-icon-tixing-shandian"></span>
                                  <span className = "icon iconfont-yach yach-147-icon-tixing-shandian"></span>
                                </div>
                              </li>
                            </ul>
                          </li>
                          <li className = {css.item}>
                            <div className = {css.icon + " icon iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-miaoshu"}></div>
                            <div className={css.remindTitle}>{remindText}</div>
                          </li>
                          <li className = {`${css.item} ${css.people}`}>
                            <div className = {css.icon + " icon iconfont iconcanyuren"} style={{paddingTop:5}}></div>
                            <UserCheck
                                loadingText={loadingText}
                                usersMessage={usersMessage}
                                userChecked={userChecked}
                                isCheckedAll={isCheckedAll}
                                checkAll={checkAll}
                                checkItem={checkItem}
                            />
                          </li>
                        </ul>
                        <div className = {css.bottom}>
                          <Button
                              type='primary'
                              onClick = {handleSubmit}
                              disabled={remindSourceType === '3' && userChecked.length === 0}
                          >{this.locale('remind_button_send')}</Button>
                        </div>
                      </div>
                      :
                      <div className = {css.box}>
                        {/* title */}
                        <div className = {css.title}>
                          <span>{this.locale('remind_button_create')}</span>
                          <span className={css.close+' iconfont iconguanbi'} onClick={closeWin}></span>
                        </div>
                        {/* main */}
                        <ul className = {css.main}>
                          <li className = {`${css.item} ${css.remind}` }>
                            <div className = {`${css.icon} ${css.icontixing1} iconfont icontixing1`}/>
                            <ul className = {css.list}>
                              <li className = {remindType === '0'? css.cur : ''}
                                  onClick = {e => handleRemindTypeClick('0', 0)}
                              >
                                {this.locale('remind_type_option1')}
                                <div className = {css.flash}>
                                  <span className = "iconfont iconjinji"></span>
                                </div>
                              </li>
                              <li className = {remindType === '1'? css.cur : ''}
                                  onClick = {e => handleRemindTypeClick('1', remindWin.messageNum)}
                              >
                                {this.locale('remind_type_option2')}
                                <div className = {css.flash}>
                                  <span className = "iconfont iconjinji"></span>
                                  <span className = "iconfont iconjinji"></span>
                                </div>
                              </li>
                              <li className = {remindType === '2'? css.cur : ''}
                                  onClick = {e => handleRemindTypeClick('2', remindWin.phoneNum)}
                              >
                                {this.locale('remind_type_option3')}
                                <div className = {css.flash}>
                                  <span className = "iconfont iconjinji"></span>
                                  <span className = "iconfont iconjinji"></span>
                                  <span className = "iconfont iconjinji"></span>
                                </div>

                              </li>
                            </ul>
                          </li>
                          <li className = {css.item}>
                            <div className = {css.icon + " iconfont iconmiaoshu"}></div>
                            <div className={css.inputOut}>
                              {!remindWin.edit?
                                  <div className={`${css.textContent} ${css.noEdit}`}
                                       dangerouslySetInnerHTML = {{__html: _html}}
                                  />
                                  :<TextArea maxLength={1000}
                                      // autoSize
                                             disabled = {remindWin.edit?false:true}
                                             value={remindText}
                                             className={css.textContent}
                                             placeholder={this.locale('remind_input_placeholder')}
                                             onChange = {handleInputChange}
                                  />
                              }
                              {remindWin.edit && <span className = {css.notice}>{remindText.length >= 1000 ? this.locale('remind_toast_more1000') : ''}</span>}
                            </div>
                          </li>
                          <li className = {`${css.item} ${css.people}`}>
                            <div className = {css.icon + " iconfont iconrenyuan1"} style={{paddingTop:5}}></div>
                            <div className={css.content}>
                              <div className={css.contentTop}>
                                <i>{this.locale('calendar_create_adduser_placeholder')}</i>
                                <span className={css.addIcon + " iconfont icontianjia5"} onClick = {handleShowUserAdd}></span>
                              </div>
                              <UserList users = {users} usersShow = {usersShow} handlePeopleDelte = {handlePeopleDelte}/>
                            </div>
                          </li>
                          <li className = {`${css.item} ${css.file}`}>
                            <div className = {css.icon + " iconfont iconfujian"} style={{marginTop:5}}></div>
                            <div className={css.content}>
                              <div className={css.contentTop}>
                                <i>{this.locale('calendar_create_addattachment_name')}</i>
                                {
                                  files.length < 9 ?
                                      <label className={css.fileAdd}>
                                            <span className={css.addIcon + " iconfont icontianjia5"}>
                                            </span>
                                        <input
                                            type="file"
                                            accept=".png,.jpg,.jpeg,.bmp,.gif"
                                            onChange={handleFile}
                                            onClick = {handleMaiDian}
                                        />
                                      </label> : null
                                }
                              </div>
                              <div className={css.contentBottom}>
                                {
                                  files.map(item => {
                                    const {file}=item;
                                    return <div className={css.fileItem} key={file}>
                                      <p onClick={() => this.showImg(file)} style={{background:`url(${file || util.config.nim.showimg}) no-repeat center /100%`}}>
                                        <i className={css.deleteIcon} onClick={(e) => {handleFileDelete(file,e)}}>
                                          <img src={require('@a/imgs/schedule/delete-icon.png')} alt=""/>
                                        </i>
                                      </p>
                                    </div>
                                  })
                                }
                              </div>
                            </div>
                          </li>
                        </ul>
                        <div className = {css.bottom}>
                          <CommonBtn
                              text={this.locale('remind_button_send')}
                              onClick = {handleSubmit}
                              style={{width:'80', float:'left', pointerEvents:`${uploadLoading ? 'none' : ''}`, opacity:`${uploadLoading ? '0.5' : '1'}`}}/>
                          <span className={css.bottomText} style= {{display: remindType === '0' ? 'none' : ''}}>
                                <span style= {{color:({0:'red'})[remindType === '1'?remindWin.messageNum: remindWin.phoneNum]}}>{this.locale('remind_send_num') + ":" + (remindType === '1'?remindWin.messageNum: remindWin.phoneNum)}</span>
                          </span>
                        </div>
                      </div>
                }
            </div>
        );
    }
}
