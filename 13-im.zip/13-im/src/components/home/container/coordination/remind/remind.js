// react
import React from 'react';
import InfiniteScroll from 'react-infinite-scroller';

// css
import css from './index.scss';

// img
import remindNoData from '@a/imgs/remind-no-data.png';

import * as util from '@u/util.js';

// remind
export default class Remind extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        let content = null;
        const {remindList, itemClick} = this.props;
        const data = remindList[`list${remindList.curType}`];
        const items = data.list;
        if(items && items.length){
            const index = remindList.index;
            content = (
                items.map(item=>{
                    let i = index.get(item);
                    let _content = util.yach.textFiltering(i.content);
                    let _html = util.yach.convertExpression(_content, '18px', '18px');
                    return (
                        <div onClick={() => itemClick(i)} 
                            className={`${i.state === 0 ? css.itemUnState : css.itemBg} ${css.item}` }
                            key={i.rid}
                        >
                            {i.state === 0 && <i className={css.poine}/>}
                            <span className={css.content} dangerouslySetInnerHTML={{
                                __html: _html
                            }}></span>
                            <span onClick={(e) => {util.yach.showUserinfo(i.creator_uid); e.stopPropagation();}} className={css.name}>{i.creator_name}</span>
                            {i.state === 2 && <i className={css.line}/>}
                            {i.state === 2 && <span className={css.state}>{this.locale('remind_list_item_recall')}</span>}
                            <span>{i.created_at}</span>
                        </div>
                    )
                })
            )
        }else{
            content = (
                <div className={css.noData}>
                    <img src={remindNoData}/>
                    <p>{this.locale('remind_list_empty')}</p>
                </div>
            )
        }
        return (
            <div className={css.box}>
                <InfiniteScroll
                    pageStart={0}
                    loadMore={() => {this.props.loadMore(data.page+1, remindList.curType)}}
                    hasMore={data.hasMore}
                    loader={<div className="loader" key={0} style = {{marginTop:'10px',color:'#B8BECC',textAlign:'center',fontSize:12}}>{this.locale('calendar_info_section_user_loading')}</div>}
                    useWindow={false}
                >
                    {content}
                </InfiniteScroll>
            </div>
        );
    }
}
