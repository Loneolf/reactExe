// react
import React, {Component} from 'react';
import { connect } from 'react-redux';
// util
import {message} from 'antd';
import * as util from '@/utils/util';
//import {remindEventsCreate} from '@s/remind/remind'
import {fileUploadCos} from '@u/lib/file/file'
import AddTipModal from '../../schedule/common/addTipModal';

// remind
import RemindWin from './remind-win';
import * as remindAction from '@r/actions/remind';
import UserAdd from "@/components/common/user-add/user-add-container";

import {fileInfoSave} from '@s/file/file-info'
import {getScheduleInfoPeople} from "@/services/schedule/schedule";

// ImContainer
class RemindWinContainer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            remindType : '0',
            remindText : '',
            remindSourceType: '0', //正常创建：0  群组：1    单聊会话：2  日程：3
            remindSource: '0', //	正常创建:0  群聊：group_tid  单聊会话：个人id  日程：日程id  当remind_source_type 非 0时必选
            msgId:'',//remind_source_type 非 0时必选
            msgTime: '',
            files: [],
            users: [],
            userInfo: {},
            // data
            remindWinData: null,
            //展示需要
            limit: 0,
            userWinLoading: false,
            userAddShow: false,
            usersShow: false,
            uploadLoading: false,
            // 加人上线
            maxLength: 2000,
            sendRemind:false,
            // 日程提醒
            loadingText: true,
            nodata: true,     // 无限加载一直有数据
            usersMessage: [],
            userChecked:[],
            isCheckedAll: true,
            page:0,
            visibleModal: false
        }
    }

    componentDidUpdate(preProps) {
        let {remindWin, remindList, remindListRequest, remindWinReset, remindWinLimitRequest }= this.props;
        const sourceType = {'team': '1','p2p': '2','schedule': '3'}
        if(this.props !== preProps){
            if(remindWin.data && remindWin.data != preProps.remindWin.data){
                // 从输入框提醒入口进来
                if(remindWin.data.come === 'boxSend'){
                    const {data} = remindWin
                    if(data.type === 'p2p'){
                        const {user} = data
                        this.setState({users:[{...data.user,uid: user.id, avatar: user.pic, disabled: false}],})
                    } else {
                        this.setState({sendRemind:true})
                    }
                } else {
                    // 之前进入提醒逻辑
                    let userList = [...this.state.users];
                    const user = remindWin.data.user;
                    if (user && Array.isArray(user)) {
                        const newUser = user.map(item => {
                            return { ...item, uid: item.id, avatar: item.pic, disabled: false }
                        })
                        // Array.prototype.push.apply(userList, user.map(item => {
                        //     return { ...item, uid: item.id, avatar: item.pic, disabled: true }
                        // }))
                        newUser.forEach(item => {
                            let is = false
                            userList.forEach((v, i) => {
                                if (+item.id === +v.id) is = true
                                if (v.disabled) userList.splice(i, 1)
                            })
                            if (!is) userList.push(item)
                        })
                    } else if (user) {
                        userList = [{
                            ...user,
                            uid: user.id,
                            avatar: user.pic,
                            disabled: true
                        }]
                    }

                    if(remindWin.data.scene === 'schedule'){
                        this.setState({
                            remindText: remindWin.data.text,
                            remindSourceType: sourceType[remindWin.data.scene],
                            remindWinData:remindWin.data,
                            users: userList,
                        });
                    }else{
                        this.setState({
                            remindText: remindWin.data.text,
                            remindSourceType: sourceType[remindWin.data.scene],
                            remindSource: remindWin.data.remindSource,
                            msgId: remindWin.data.msg.idClient,
                            remindWinData:remindWin.data,
                            msgTime: remindWin.data.msg.time,
                            users: userList,
                        });
                    }
                }
            }
            if (remindWin.request){
                if(remindWin.request.code === 200){
                    message.success(this.locale('calendar_toast_create_success'))
                    this.reset();
                    remindListRequest({remind_type:remindList.curType});//更新当前列表
                    remindWinReset();
                }else {
                    message.error(remindWin.request.msg);
                }
            }
            if(remindWin.show && (remindWin.show != preProps.remindWin.show)){
                remindWinLimitRequest();//获取限额
            }

            if(remindWin.data && remindWin.data.scene === 'schedule') this.intiateScrollObserver()
        }
    }

    componentDidMount() {
        const user_info = util.yach.getUserinfo()||{};
        this.setState({
            userInfo:{...user_info, uid: user_info.id, avatar: user_info.pic, disabled: true}
        });
       // this.props.remindWinLimitRequest();
       util.sensorsData.track('PageView_TiXing', {pageName: 205});
    }

    setUserlist = userList => {
        newUser.forEach(item => {
            let is = false
            userList.forEach(v => {
                if (item.id === v.id) is = true
            })
            if (!is) userList.push(item)
        })
    }

    reportData ($element_name) {
        util.sensorsData.track('Click_TiXing_Element', {pageName: 205,$element_name});
    }

    reset = () => {
        this.setState({
            remindType : '0',
            remindText : '',
            remindSourceType: '0',
            remindSource: '0',
            msgId:'',//remind_source_type 非 0时必选
            msgTime: '',
            files: [],
            users: [],
            usersShow: false,
            //userInfo: {},
            userWinLoading: false,
            userAddShow: false,
            // data
            remindWinData: null,
            //展示需要
            limit: 0,
            uploadLoading: false,
            sendRemind:false,
            // 日程
            loadingText: true,
            nodata: true,     // 无限加载一直有数据
            usersMessage: [],
            userChecked:[],
            isCheckedAll: true,
            page:0,
        });
    }
    handleSubmit = ()=>{

        const {remindWinData,remindText,remindType, remindSourceType, remindSource, msgId, users, files, limit, msgTime,isCheckedAll,userChecked} = this.state;

        if(remindSourceType === '3'){
            let uids;
            if(isCheckedAll) uids = 'all';
            else uids = userChecked.map(user => user.id).join(',');
            const params ={
                id:remindWinData.id,
                type:(parseInt(remindType)+1).toString(),// 1:运用内提醒，2：短信提醒，3：电话提醒
                uids,
            }
            this.props.scheduleRemindWinRequest({params});
        }else{
            if(remindText.trim().length === 0){
                message.error(this.locale('remind_toast_text_empty'))
                return;
            }
            if(users.length <= 0){
                message.error(this.locale('remind_toast_users_empty'))
                return;
            }
            if(limit && users.length > limit || users.length > this.state.maxLength){
                util.log('lichao','remindCreate','limit:',limit,'users:',users.length,"maxLength:",this.state.maxLength,'title:',remindText.slice(0,10));
                message.error(this.locale('remind_toast_over_num'))
                return;
            }
            let uids = users.map(user => user.id).join(',');
            let attachment = files.map(file => file.file).join(',')
            const params ={
                content:remindText,
                remind_type: remindType,
                uids,
                attachment,
                remind_source_type: remindSourceType,
                remind_source:remindSource,
                msg_id: msgId,
                ext: msgTime
            }

            this.props.remindWinRequest({params});
            this.reportData(260);
        }
    }

    handleRemindTypeClick = (type, limit) =>{
        const maxLength = +type === 0 ? 2000 : 1000
        this.setState({
            remindType: type,
            limit,
            maxLength
        });
        this.reportData(type*1+352);// 352 应用内，353 短信， 354 电话
    }

    handleInputChange = (evn)=>{
        this.setState({
            remindText: evn.target.value
        })
    }

    closeWin = ()=> {
        if(this.state.uploadLoading) return;
        const {remindText, users, files,remindSourceType} = this.state;
        if((remindText.trim().length > 0 || users.length > 0 || files.length > 0) && remindSourceType !== '3'){
            // this.showModal()
            this.setState({visibleModal:true})
        }else {
            this.reset();
            this.props.remindWinReset();
        }
        this.reportData(155);
    }

    handleShowUserAdd = () => {
        this.setState({
            userAddShow: true
        }, ()=>{
            const{edit} = this.props.remindWin;
            if(edit && !this.state.sendRemind) return;
            // const {id, showname} = this.props.sessionActive;
            const {id, showname} = window.session_active;
            util.eventBus.emit('userMembers', {id, showname});
        });
        this.reportData(358);
    }

    // 加人删除
    handlePeopleDelte = (id) => {
        this.setState(prv => {
            const arr = prv.users || {};
            return {
                users: arr.filter(item => item.uid != id),
                usersShow: true
            }
        })
    }
    // 加人ok
    okUserAdd = async (value) => {
        const {allDataUsers} = value;
        //console.log(allDataUsers)
        const arr=allDataUsers.map(item => ({...item, uid: item.id, avatar: item.pic}));
        const resArr=await util.yach.base64ImgArrGetTmp(arr,'avatar');
        this.setState({
            userAddShow: false,
            users: resArr,
            usersShow: false
        })
    }

    // 关闭加人弹框
    closeUserAdd = () => {
        this.setState({
            userAddShow: false,
            loading: false
        });
    };

    // 添加附件
    handleFile = async event => {
        this.reportData(143);
        let loading = message.loading(this.locale('common_msg18'), 0);
        this.setState({uploadLoading: true});

        let user_info = util.yach.getUserinfo()||{};
        let filetarget = event.target.files[0]

        event.target.value = ''

        let imageinfo = await util.imageDealer.getImageInfoFromClient(filetarget.path) || {}

        if (imageinfo.width * imageinfo.height > 9999 * 9999) {
            message.warn(util.locale('im_send_img_maxsize_limit'))
            this.setState({uploadLoading: false});
            return loading()
        }

        let limitBase64 = await util.imageDealer.resetImageLimitBase64(filetarget.path, 5000)

        util.electronipc.electronFileUpload({
            filepath: filetarget.path,
            filename: filetarget.name,
            filebase64: limitBase64 || undefined,
            costype: 'image',
            project: 'remind',
            filetype: 'image',
            size: filetarget.size
        }, res => {
            loading()
            if (res.error) return message.error(this.locale('common_msg20')+":" + res.error)

            message.success(this.locale('common_msg19'))

            this.setState(prv => ({
                files: [{ file: res.fileurl }]
            }))

            fileInfoSave({
                file_url: res.fileurl,
                file_name: res.filename,
                file_size: filetarget.size,
                file_mime: filetarget.type,
                file_extension: res.fileurl.slice(res.fileurl.lastIndexOf('.') + 1),
                source: 'remind',
                receive_type: 2,
                receive_id: user_info.id
            })
        })


        // const data = await fileUploadCos({formData,filetype:'image',receive_id:user_info.id,receive_type:2,project:'remind'});

        // console.warn(data,444);
        // message.destroy();
        // if (data && data.code === 200) {
        //     const url = data.obj && data.obj.origin_url;
        //     message.success('上传成功');
        //     this.setState(prv => ({
        //         files: [{file:url}]
        //     }))
        // } else if (data && data.code == '001') {
        //     message.error('仅支持上传图片');
        // } else {
        //     message.error('上传失败')
        // }
        this.setState({uploadLoading: false});
    }

    // 保存文件信息
    saveFileInfo = async () => {
        const user_info = util.yach.getUserinfo()||{};
        const savedata = await fileInfoSave({
            file_url: data.fileurl,
            file_name: data.filename,
            file_size: data.size,
            file_mime: mime,
            file_extension: ext,
            source: 'remind',
            receive_type: 2,
            receive_id: user_info.id
        })
    }

    handleMaiDian = () => {
    }

    // 删除附件
    handleFileDelete = (file,e) => {
        e.stopPropagation();
        this.setState(prv => {
            const arr = prv.files;
            return {
                files: arr.filter(item => item.file !== file)
            }
        })
    }

    /**
     *   无限
     */
    intiateScrollObserver = () => {
        const checkIsIns=document.querySelector("#checkIsIns");
        if(!checkIsIns) return;
        const options = {
            root: document.querySelector('#checkusers'),
            rootMargin: '0px',
            threshold: [0.6]
        };
        this.observer = new IntersectionObserver(this.callback, options);
        this.observer.observe(checkIsIns);
    }

    /**
     *    无限的回调
     */
    callback = (entries) => {
        entries.forEach((entry, index) => {
            if(!this.state.nodata) return;
            if (entry.isIntersecting) {
                this.setState(state=>({
                    page: state.page+1,
                }),()=>{
                    this.getJoinSchedulePeople({page:this.state.page})
                });
            }
        });
    };

    /**
     获取总人数和各类人的数目
     resp_state: 0：未响应，1：接受，2：拒绝  99全部
     step: 每一页显示的数据
     page: 页码
     */
    getJoinSchedulePeople = async({step=70,page=1})=>{
        try{
            const getPeople = await getScheduleInfoPeople({id:this.state.remindWinData.id,resp_state: 0,step,page});
            const {code,msg,obj={}} = getPeople;
            if(code !== 200){
                message.warn(msg);
                return;
            }
            this.interfaceActions(obj);
        }
        catch(e){ console.log('getJoinSchedulePeople>>>',e)}
    };

    /**
     *  处理info 人数处理 一页请求150 小于请求的总数或者没有数据  就关闭无限加载
     */
    interfaceActions = (obj)=>{
        const {list} = obj;
        if(list.length<70){
            this.setState(state=>({nodata:false}));
        }
        if(!list.length){
            this.setState(state=>({loadingText:false}));
            return;
        }
        const uids = list.map(item=>item.uid);
        this.getUserImage(uids);
    }

    /**
     *   获取云信端头像
     */
    getUserImage = async (params) => {
        if(!Array.isArray(params) || !params.length) return;
        try{
            const res = await util.nimUtil.getUsers(params);
            const resImg = res.map(item=> ({id:item.account,nick:item.nick,avatar:item.avatar}));

            const arr= await util.yach.base64ImgArrGetTmp(resImg,'avatar');

            if(this.state.isCheckedAll){
                this.setState(pre=>({
                    usersMessage:[...pre.usersMessage,...arr],
                    userChecked:[...pre.usersMessage,...arr],
                    loadingText:false
                }))
            }else{
                this.setState(pre=>({
                    usersMessage:[...pre.usersMessage,...arr],
                    loadingText:false
                }))
            }
        }
        catch(e){ console.log('getUserImage>>>',e)}
    };

    /**
     *   选择全部
     */
    checkAll = (e) => {
        const { usersMessage } = this.state
        if (e.target.checked) {
            this.setState({
                isCheckedAll: true,
                userChecked: usersMessage,
            })
        } else {
            this.setState({
                isCheckedAll: false,
                userChecked: []
            })
        }
    };

    /**
     *   单选
     */
    checkItem = (e) => {
        const { userChecked,usersMessage } = this.state;
        let newCurrList = userChecked;
        let ids = newCurrList.map(v => v.id);
        let item = usersMessage.find(v => v.id === e.target.value);

        if (ids.includes(e.target.value) && !e.target.checked) {
            newCurrList = newCurrList.filter(i => i.id !== item.id);
            this.setState({
                userChecked: newCurrList,
                isCheckedAll: false,
            })
        }
        if (!ids.includes(e.target.value) && e.target.checked) {
            newCurrList.push(item);
            this.setState({
                userChecked: newCurrList
            },()=>{
                // const {userChecked} = this.state;
                if(this.state.userChecked.length === usersMessage.length) {
                    this.setState({
                        isCheckedAll: true,
                    })
                }
            })

        }
    };

    render() {
        const {remindWinData,files, users, userWinLoading, userAddShow, uploadLoading, remindText,remindType,
            remindSourceType, usersShow, maxLength,sendRemind,loadingText,usersMessage,userChecked,isCheckedAll,visibleModal
        } = this.state;
        //remindWin component config
        const remindWinProps = {
            ...this.props,
            remindWinData,
            users,
            files,
            usersShow,
            uploadLoading,
            remindSourceType,
            loadingText,
            usersMessage,
            userChecked,
            isCheckedAll,
            remindType : remindType,
            remindText : remindText,
            closeWin: this.closeWin,
            handleSubmit: this.handleSubmit,
            handleInputChange: this.handleInputChange,
            handleShowUserAdd: this.handleShowUserAdd,
            handlePeopleDelte: this.handlePeopleDelte,
            handleFile: this.handleFile,
            handleMaiDian: this.handleMaiDian,
            handleFileDelete: this.handleFileDelete,
            handleRemindTypeClick: this.handleRemindTypeClick,
            checkAll: this.checkAll,
            checkItem: this.checkItem,
        }
        //select member component config
        const userIds = users.map(item => item.uid + '') || [];
        const userAddProps = {
            type: sendRemind ? 'members' : (remindSourceType !=1 ? 'creatGroup' : 'members'),
            loading: userWinLoading,
            show: userAddShow,
            onOk: this.okUserAdd,
            onClose: this.closeUserAdd,
            checkedids: userIds,
            title: this.locale('remind_useradd_share_title'),
            leftTitle: this.locale('remind_useradd_share_lefttitle'),
            maxLength
        };

        return (
            <div onMouseDown={e => e.stopPropagation()}>
                <RemindWin {...remindWinProps}/>
                <UserAdd {...userAddProps} />
                <AddTipModal
                    close={()=>{this.setState({visibleModal: false})}}
                    text={this.locale('calendar_toast_quit_nosave')}
                    type='confirm'
                    callback={()=>{
                        this.reset();
                        this.props.remindWinReset();
                        this.setState({visibleModal: false})
                    }}
                    visible={visibleModal}
                    dropout={true}
                />
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        remindWin: state.remindWin,
        // sessionActive: state.sessionActive,
        remindList: state.remindList
    };
};

const mapDispatchToProps = {
    remindWinUpdate: remindAction.remindWin,
    remindWinRequest: remindAction.remindWinRequest,
    remindWinReset: remindAction.remindWinReset,
    remindWinLimitRequest: remindAction.remindWinLimitRequest,
    remindListRequest: remindAction.remindListRequest,
    scheduleRemindWinRequest: remindAction.scheduleRemindWinRequest,
}


export default connect(mapStateToProps,mapDispatchToProps)(RemindWinContainer);
