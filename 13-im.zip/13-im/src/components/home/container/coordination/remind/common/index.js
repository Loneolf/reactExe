import React from 'react';
import { Button, Menu, Dropdown} from 'antd';
import './index.scss';
import * as util from '@u/util.js';
import {remindFeedConfirm} from "@/services/remind/remind";
import * as remindAction from '@r/actions/remind';
import {showSlideModal, hideSlideModal} from "@/redux/actions/commonModal";
import {locale} from '@u/util.js'

import { openNotification, closeNotification } from '@c/common/notification/common-notification';

// Notification提示
const openRemindNotification = async (data) => {
    console.log("changyiyi1————————》》》》",data);
    const { title = locale('calendar_top_tab_remind'), id, content,from } = data;

    let btn = null;
    const viewDetailsEl=<Button onClick={(e)=>{
        e.stopPropagation();
        goInfo();
    }}>{locale("remind_notification_viewdetails")}</Button>
   //立即处理
    const menu = <Menu>
                    <Menu.Item>
                        <span onClick={(e) => {
                            e.stopPropagation();
                            handleClick(1);
                        }} className="Dropdowncontent">{locale('remind_notification_received')}</span>
                    </Menu.Item>
                    <Menu.Item>
                        <span onClick={(e) => {
                            e.stopPropagation();
                            handleClick();
                        }}className="Dropdowncontent">{locale("remind_notification_ignore")}</span>
                    </Menu.Item> 
                </Menu>
    
    let remindtype=false;
    remindtype=!remindtype
                        
    const rightEl= <Dropdown overlay={menu} 
                    overlayClassName="remindDropdown"
                     placement="bottomCenter"
                    ><div><Button>{locale("remind_notification_fastprocess")}<img className="remindarrow" src={require('@a/imgs/schedule/reminddrop.png')}/></Button></div></Dropdown>
    btn = <div>{rightEl}{viewDetailsEl}</div>

    const notificationParams = {
        message: <div><span/><em>{locale('calendar_top_tab_remind')}</em></div>,
        description:
            <div className='tipContent'>
                <div>
                    {content}
                </div>
               { from.length?<div className="formContent">{locale.getLang()==='zh-CN'?"来自:":"From:"}&nbsp;&nbsp;&nbsp;{from}</div>:null}
            </div>,
        btn,
        className: 'remindTip',
        onClick: goInfo
    };

    openNotification({type: 'remind', id}, notificationParams);

    // notification.open({
    //     message: <div><span/><em>{locale('calendar_top_tab_remind')}</em></div>,
    //     description:
    //         <div className='tipContent'>
    //             <div>
    //                 {content}
    //             </div>
    //            { from.length?<div className="formContent">{locale.getLang()==='zh-CN'?"来自:":"From:"}&nbsp;&nbsp;&nbsp;{from}</div>:null}
    //         </div>,
    //     btn,
    //     getContainer: () => document.getElementById('slideModal'),
    //     duration: null,
    //     key,
    //     onClose: () => notification.close(key),
    //     className: 'remindTip',
    //     onClick: goInfo
    // });

    // type 种类；value:接受拒接种类
    function handleClick(type) {
        // 知道了，忽略
        if(type) remindFeed(id)
        // notification.close(key);
        closeNotification({type: 'remind', id});
        util.nimUtil.publishEvent(10003, {type:3,data:{rid: id}});
    }

    // 全局跳转详情
    function goInfo() {
        // notification.close(key);
        closeNotification({type: 'remind', id});
        window.store.dispatch(hideSlideModal());
        setTimeout(() => {
            window.store.dispatch(showSlideModal('remindInfo', { id }));
            remindFeed(id);
        }, 500);
    }

    // 获取用户列表
    async function remindFeed(id) {
        await remindFeedConfirm({rid: id});
        if (window.location.pathname === '/schedule') {
            window.store.dispatch(remindAction.remindListRequest({remind_type: window.store.getState().remindList.curType || 0}));
        }
    }
};

// 关闭弹框
const closeRemindNotification = (obj) => {
    const id = obj.id;
    closeNotification({type: 'remind', id});
    // const {id}=obj;
    // let key = '';
    // for (let [k, value] of window.remindMap) {
    //     if(k.id==id){
    //         // 存在，需要替换
    //         key=value;
    //         window.remindMap.delete(k);
    //         break;
    //     }
    // }
    // if(key){
    //     notification.close(key);
    // }
}

// 提醒页面刷新
const refrshData = () => {
    console.log('refrshData');
}

export {
    openRemindNotification,       //全局提醒
    closeRemindNotification,      //关闭弹框提示
    refrshData
}