// react
import React from 'react';

// css
import css from './user.scss';

import * as util from '@/utils/util';

export default class UserList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            num : 8, //展示数量
            users: [], //全部人员
            userList : [], //需展示的人员
            remainNum: 0, //未展示出的人数
            fold: true,
            more: false,
        }
    }
    componentDidUpdate (props) {
        const {users, usersShow} = this.props;
        const length = users.length;
        if ( users !== props.users){
            if( length > this.state.num){
                if(usersShow) {
                    let {fold} = this.state;
                    if(!fold){
                        this.setState((state) => {
                            return {
                                users,
                                fold: state.fold,
                                more: state.more,
                                userList: state.more ? users: users.slice(0, state.num),
                                remainNum: length - state.num
                            } 
                        })
                        return;           
                    }
                }
                this.setState((state) => {
                    return {
                        users,
                        userList : users.slice(0,state.num), 
                        more : true,
                        fold: true,
                        remainNum: length - state.num
                    } 
                })                
            }else {
                this.setState({
                    users,
                    userList : users,
                    more : false,
                    remainNum : 0
                })
            }

        } 
    }

    fold = () => {
        let {fold, users, userList, num} = this.state;
        if(fold){
            fold = false;
            userList = users;
        }else{
            fold = true;
            userList = users.slice(0, num);
        }
        this.setState({
            fold,
            userList
        });
    }

    render () { 
        const {
            handlePeopleDelte,
        } = this.props;
        const {fold, more, remainNum, userList} = this.state;

        const userListDom = userList.map(user => {
            const {uid=Math.random(), id, name, avatar,disabled} = user;
            return (
            <div
                className={css.user}
                key={uid}
            >
                <img onClick={() => util.yach.showUserinfo(+id)}
                    src={avatar} alt=""
                />
                <span>{name}</span>
                <i className={css.deleteIcon} style = {{display:disabled ? 'none' : ''}} onClick={() => handlePeopleDelte(uid)}>
                    <img src={require('@a/imgs/schedule/delete-icon.png')} alt=""/>
                </i>
            </div>)
        })

        return (
            <div  className = {css.userContainer}>
                <div  className = {css.userList}>
                    {
                        userListDom
                    }                     
                </div>

                <div style = {{display:more ? '' : 'none'}} className = {css.more}>
                    <span style = {{display: fold? '' : 'none'}} onClick = {()=>this.fold()}>
                        {this.locale('remind_button_more')}({remainNum})
                        <span className = "iconfont iconzhankai2 " style = {{fontSize:'9px'}}></span>
                    </span>
                    <span style = {{display: fold? 'none' : ''}} onClick = {()=>this.fold()}>{this.locale('common_fold')}</span>
                </div>
            </div>
        )
    }
}