// react
import React from 'react';
import { connect } from 'react-redux';

// redux
import {showSlideModal} from "@/redux/actions/commonModal";
import * as remindAction from '@r/actions/remind';
// util
import {message} from 'antd';
import * as util from '@u/util.js';
// remind
import Remind from './remind';

// ImContainer
class RemindContainer extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidUpdate = (preProps) => {
        const {remindList,remindListDelete, remindListRecall, remindListUpdate }= this.props;
        const opr = ({'delete':'删除', 'recall':'撤销'})[remindList.operation]; 
        if(this.props !== preProps){
            if(remindList.operation && remindList.operationData && (remindList.operation != preProps.remindList.operation)){
                if(remindList.operation === 'delete'){
                    remindListDelete({rid:remindList.operationData})
                }
                if(remindList.operation === 'recall'){
                    remindListRecall({rid:remindList.operationData})
                }
                message.success(`${opr==='删除'?this.locale('remind_toast_delete_success'):this.locale('remind_toast_recall_success')}`);
                //remindListRDRequest({opr:remindList.operation, id: remindList.operationData});
                remindListUpdate({operation:'',operationData:'',request:null});
            }
            if(remindList.operation && remindList.request){//删除或撤销是否成功
                if(remindList.request.code === 200){
                    message.success(`${opr==='删除'?this.locale('remind_toast_delete_success'):this.locale('remind_toast_recall_success')}`);
                }else {
                    message.error(remindList.request.msg);
                } 
              this.props.remindListUpdate({operation:'', operationData:'', request:null}); 
            }
            //可以在此处增加对more的判断
            
        }
    }
    componentDidMount = () =>{
        this.props.remindListRequest({remind_type:0});
    }

    showRemindInfo=(id)=>{
        this.props.showSlideModal('remindInfo', {id});
    }

    itemClick = (item) => {
        this.showRemindInfo(item.rid);//'AO_fXUqedCI'
        if(item.state === 0){  
            //this.props.remindListRDRequest({opr:'delete', id: item.rid});
            this.props.remindListUpdateOne({rid:item.rid, state: 1});//更新为可读
        }
        util.sensorsData.track('Click_TiXing_Element', {pageName: 204,$element_name:351});
    }
    loadMore = (page, remind_type) => {
        if(page){
            this.props.remindListRequest({remind_type,page})
        }
    }
    render() {
        return <Remind {...this.props} itemClick = {this.itemClick} loadMore = {this.loadMore}/>;
    }
}

const mapStateToProps = state => {
    return {
        // sessionActive: state.sessionActive,
        remindList: state.remindList
    };
};

const mapDispatchToProps = {
    remindListUpdate: remindAction.remindList,
    remindListRequest: remindAction.remindListRequest,
    remindListUpdateOne: remindAction.remindListUpdateOne,
    remindListRDRequest: remindAction.remindListRDRequest,
    remindListDelete: remindAction.remindListDelete,
    remindListRecall: remindAction.remindListRecall,
    showSlideModal,
}
export default connect(mapStateToProps, mapDispatchToProps)(RemindContainer);
