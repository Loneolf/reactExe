// react
import React, {Fragment} from 'react';
// css
import css from './index.scss';
import * as util from '@u/util.js';
import _ from 'lodash';
import {showPreviewModal} from '@r/actions/commonModal';


export default function RemindInfo(props) {
    const {
        inFo: {
            ext,
            state,
            is_del,
            msg_id,
            creator,
            content,
            created_at,
            creator_name,
            attachment,
            remind_source,
            remind_source_type,
            remind_source_text
        },
        peopleStage, 
        openMore, 
        changeOpenMore, 
        changePeopleStage, 
        handleShowUserAdd, 
        goMessage,
        showDialog,
        handleRecall,
        handleDel,
        account,
        userList,
        uploadClickSensorsData,
        locale
    } = props;

    function showImg(file) {
        util.electronipc.electronOpenImage({
            success:true,
            data:[{id: file, url: file, curr: true}],
        });
        uploadClickSensorsData(144);
    }

    // 处理参与者
    let showArr,
        mapArr = [];
    if(peopleStage){
        mapArr = userList.read || [];
    }else{
        mapArr = userList.unread || [];
    }
    if (openMore) {
        showArr = mapArr;
    } else {
        showArr = mapArr.slice(0, 12);
    }

    let contentText = util.yach.textFiltering(content);
    let _html = util.yach.convertExpression(contentText, '18px', '18px');

    return (
        <div className={css.box}>
            <div className={css.btn}>
                <p className={css.right}>
                    {(state != 2 && creator == account) && <span title={locale('remind_add_tip_recall')} onClick={handleRecall} className='icon iconfont iconchehui1'/>}
                    {(account == creator && state != 2) && <span title={locale('remind_add_tip_adduser')} onClick={handleShowUserAdd} className='icon iconfont iconicontianjia-1'/>}
                    {((account == creator && !is_del) || (account != creator && is_del != 1 && state != 2)) && <span title={locale('calendar_button_delete')} onClick={handleDel} className='icon iconfont iconiconshanchu-'/>}
                </p>
            </div>
            <div className={css.section}>
                <div>
                    <span className='icon iconfont icontixing1'/>
                    <div className={css.constent} dangerouslySetInnerHTML={{
                        __html: _html
                    }}></div>
                </div>
                <div>
                    <div>
                        <span className={css.name} onClick={() => util.yach.showUserinfo(creator)}>{creator_name}</span>
                        <i className={css.line}/>
                        <span className={css.time}>{created_at}</span>
                    </div>
                    {(remind_source_type !=0 && remind_source_text) &&
                        <div>
                            <span className={css.remindSource} onClick={_.debounce(()=>goMessage(remind_source_type, remind_source, msg_id, ext), 500)}>{remind_source_text} ></span>
                        </div>
                    }
                </div>
                <div className={css.people}>
                    <span className='icon iconfont iconrenyuan-copy'/>
                    <section className={css.peopleContent}>
                        <p>
                            <span onClick={() => changePeopleStage(0)}
                                  className={!peopleStage ? css.active : null}>{locale('common_unread')}({userList.unread_num})</span>
                            <span onClick={() => changePeopleStage(1)}
                                  className={peopleStage === 1 ? css.active : null}>{locale('common_read')}({userList.read_num})</span>
                        </p>
                        <div className={css.peopleout}>
                            <div className={css.peopleInner}>
                                {
                                    showArr.map(item => {
                                        const {id = Math.random(), name, pic} = item;

                                        return <div
                                            onClick={() => util.yach.showUserinfo(id)}
                                            className={css.peopleItem}
                                            key={id}>
                                            <img src={pic} alt=""/>
                                            <span>{name}</span>
                                        </div>
                                    })
                                }
                            </div>
                        </div>
                        {
                            !openMore && mapArr.length > 12 ?
                                <div className={css.seeMore} onClick={changeOpenMore}>
                                    {locale('calendar_button_info_users_seemore')+">>"}
                                </div> : null
                        }
                    </section>
                </div>
                {
                    attachment ? <div className={css.file}>
                        <span className='icon iconfont iconfujian'/>
                        <div className={css.fileContent}>
                            <p>{locale('remind_add_item_attachment')}</p>
                            <div className={css.fileImgOut}>
                            <div className={css.fileItem}>
                                <p onClick={() => showImg(attachment)} style={{background:`url(${attachment || util.config.nim.showimg}) no-repeat center /100%`}}>
                                </p>
                            </div>
                            </div>
                        </div>
                    </div> : null
                }
            </div>
            {showDialog &&
                <div className={css.showDialog}>
                    <span className='icon iconfont iconhuihua'/>
                    <p>{locale('remind_toast_no_session')}</p>
                </div>
            }
        </div>
    );
}
