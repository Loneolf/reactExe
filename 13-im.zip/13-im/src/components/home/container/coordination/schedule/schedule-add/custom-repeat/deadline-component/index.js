/*
 * @Des: 截止时间组件
 * @Author: cqx
 * @Date: 2020-05-27
 * @query: {string} p1  内容ID
 * @props: {string} p1  数据源
 * @event: {string} p1  des
 */

import React, { Component } from 'react';
import css from './index.scss';
import { Radio,DatePicker,message } from 'antd';
import moment from 'moment';
import { locale } from '@u/util.js';


class Deadline extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dateKey: 0,
      value: 1,
      selectedTime:'',
    };
  }

  componentWillMount() {
    const {repeatTime,getDate} = this.props;
    // 兼容年月日格式编辑
    const date = repeatTime ? locale.getLang()==='zh-CN'?repeatTime.split("于")[1]:repeatTime.split("until")[1] : null;
    const dates = date ? locale.getLang()==='zh-CN'? date.replace('年','-').replace('月','-').replace('日',''):date : null;
    const selectedTime = new Date(dates).getTime()/1000;

    this.setState({
      value: date?2:1,
      selectedTime,
    });
    getDate(date?2:1,selectedTime?moment(selectedTime*1000).format('YYYY-MM-DD'):'');
  }

  componentDidUpdate(prevProps, prevState) {
    const {value} = this.state;
    const {alternation,changeCount} = this.props;
    if(prevProps.alternation !== alternation && value===2 && changeCount) {
      this.setState({
        value: 1,
        dateKey: new Date(),
        selectedTime:''
      },()=>{
        const {selectedTime} = this.state;
        this.props.getDate(this.state.value,selectedTime);
      });
      message.warning({ content: locale('calendar_create_custom_repeat_reselect') });
    }
  }


  // 改变截止类型
  onChange = e => {
    const {full_start,getDate} = this.props;
    const { selectedTime } = this.state;
    this.setState({ value: e.target.value });

    if(e.target.value === 2) {
      getDate(
          e.target.value,
          selectedTime ? moment(selectedTime*1000).format('YYYY-MM-DD')
              : moment(full_start*1000).add(1,'years').format('YYYY-MM-DD')
      );
    } else getDate(e.target.value, '');
  };

  // 选择截止时间
  handleFullChange = e => {
    const selectedTime = moment(e._d).format('YYYY-MM-DD');
    this.setState({ selectedTime });
    this.props.getDate(this.state.value,selectedTime);
  };

  // 设置时间范围
  disabledDate = (current) => {
    if(!current) return false;
    const {full_start} = this.props;
    return current < moment(full_start*1000).endOf('day') ||
        ((this.props.alternation === 1 || this.props.alternation === 2)
            ? current > moment(full_start*1000).add(1, 'years').endOf('year')
            : current > moment(full_start*1000).add(9, 'years').endOf('year'))
  };

  render() {

    const { full_start } = this.props;

    const { value,dateKey,selectedTime } = this.state;

    const radioStyle = {
      display: 'block',
      height: '36px',
      lineHeight: '36px',
      fontFamily:'PingFangSC-Regular, PingFang SC',
      fontSize: '14px',
      color: '#2F3238',
    };

    return (
        <div className={css.out}>
          <div className={css.deadline}>{locale('calendar_create_custom_repeat_end_time')}：</div>
          <Radio.Group onChange={this.onChange} value={value} className={css.radio}>
            <Radio style={radioStyle} value={1}>
              {locale('calendar_create_custom_repeat_no_end')}
            </Radio>
            <Radio style={radioStyle} value={2}>
              {locale('calendar_create_custom_repeat_end_time')}
              <DatePicker
                  key = {dateKey}
                  format="YYYY-MM-DD"
                  defaultValue={selectedTime ? moment(selectedTime*1000) : moment(full_start*1000).add(1,'years')}
                  onChange={this.handleFullChange}
                  suffixIcon={<span/>}
                  allowClear={false}
                  className={css.dataInput}
                  dropdownClassName={css.dataPicker}
                  disabledDate={this.disabledDate}
                  showToday={false}
                  style={{width:250,height:36,marginLeft:59}}
                  disabled = {value === 1}
              />
            </Radio>
          </Radio.Group>
        </div>
    );
  }
}

export default Deadline;
