import React from "react"
import ScheduleSearch from "./schedule-search"
import {searchUserSearch} from "@s/search/search.js"
import {ucenterMultiuserInfoGet}  from "@s/ucenter/ucenter-multiuser.js"
import debounce from "lodash/debounce"
export default class ScheduleSearchContainer extends React.Component {
   constructor(props) {
       super(props);
       this.state={
           querytext:"",
           userlist:[],
           showpanel:false, 
       }
   }  
   componentDidMount(){
     this.getList=debounce(this.getList,400)
   }
   getUserList = async(text, page, pagesize) => {
    let list = [];
    let data = await searchUserSearch({querystr: text, page: page, pagesize: pagesize});
    if (data && data.code == 200) list = data.obj.list;
    return list;
  }
  getList=async ()=>{
    let datalist=[]
    datalist = await this.getUserList(this.state.querytext, 1, 1000);
    let list=[]
    list=datalist.map((item)=>{
      let n=item.id;
      if(n.toString().length==6){
        return item
      }
    })
    this.setState({
      userlist:list
    })
  }
  handleInput= (e)=>{
    this.setState({
      querytext:e.target.value,
      showpanel:true,
    })
    this.getList();
  }
  handleShowBlur=()=>{
    let input=document.getElementById("searchinput")
      document.addEventListener("click",(e)=>{
          if(e.target!== input)
         {
           this.setState({showpanel:false,querytext:""})
         }
        })
      }
  handleAddUser=async (e,userid)=>{
    let userinfo=[]
    userinfo.push(userid.toString())
    window.e? window.e.cancelBubble = true : e.stopPropagation();
    let adduser=[];
      let userData = await ucenterMultiuserInfoGet({
          user_ids: JSON.stringify(userinfo)  
      })
      if (userData && userData.code == 200) {
        adduser = userData.obj || [];
      }
      this.setState({
        showpanel:false,
      })
      this.props.getUser(adduser)
      this.setState({
        querytext:" "
      })
  };
 
   render(){
    
       return <ScheduleSearch
       handleInput={this.handleInput}
       querytext={this.state.querytext}
       userlist={this.state.userlist}
       showpanel={this.state.showpanel}
       handleShowBlur={this.handleShowBlur}
       handleAddUser={this.handleAddUser}
       />
   }

}