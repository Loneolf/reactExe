/*
 * @Descripttion: 日程的弹窗组件
 * @Author: qiuyanlong@100tal.com
 * @Date: 2020-04-18 16:23:02
 */

import React, { Component } from 'react';
import CreateCard from './schedule-hoc';
// import * as calenderAction from '@r/actions/calender';

import css from './index.scss';


class ScheduleCardContainer extends Component {

    constructor(props){
        super(props);
        this.node =  React.createRef();
        this.state = {
            st: {
                left:100,
                top:200
            }
        }

        this.maxLeft = 320; // 80 + 240;
    }


    componentDidMount(){
        let node = this.node.current;
        let tag = node.getBoundingClientRect();
        console.log(this.props);
        console.log(tag)
        
    }

    render() {
        //show:true,type,item,style
        return (
            <div className={css.cardContent} ref={this.node} style={this.state.st}>
                <header>
                    <h1>千人视频测试</h1>
                    <p> 2月27日 (周四) 12：00-13：00</p>
                </header>
                <section>   
                     
                </section>
            </div>
        );
    }
}

export default CreateCard(ScheduleCardContainer)


