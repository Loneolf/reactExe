import React, { Component } from 'react';
import moment from 'moment';
import { Input,message} from 'antd';
import { getTimeDate } from '../../../lib/commonTmp';
import TimePacker from '../../common/timePicker';
import css from './index.scss';

class Index extends Component {
    constructor(props){
        super(props);
        this.state = {
            full_start: '',
            full_end:   '',
            startTime:  '',
            endTime:    '',

            title:      '',
            address:    '',

            isMonth:    false 

        }
    }
    
    componentDidMount() {
        const { fastTimeLine,type} = this.props;
        const startTime=moment(fastTimeLine[0]).format('HH:mm');
        const endTime=moment(fastTimeLine[1]).format('HH:mm');

        this.setState({
            full_start: moment(fastTimeLine[0]).format('X'),       
            full_end:   moment(fastTimeLine[1]).format('X'),    
            startTime,
            endTime,     
            isMonth:type=='month'
        })
        this.input && this.input.focus();
    }

    commonChange = (field, value) => {
        this.setState({
            [field]: value,
        });
    };


    handleInputChange = (attr,event)=>{
        this.setState({
            [attr]: event.target.value
        })

        if(event.target.value.length === 31){     
            message.warning(this.locale('calendar_toast_create_title_maxlength'));
        }
    }

    until_common_time = ()=>{
        const { full_start,full_end,startTime,endTime } = this.state;
        let start_time = full_start;
        let end_time = full_end;
        start_time = moment(moment(start_time * 1000).format('YYYY-MM-DD') + " " + startTime).format('X');
        end_time = moment(moment(end_time * 1000).format('YYYY-MM-DD') + " " + endTime).format('X');

        return {start_time,end_time}
    }

    preCheck = () => {
        const {start_time,end_time} = this.until_common_time();
        if ( start_time > end_time){
            message.warning(this.locale('calendar_toast_create_time_wrong'));
            return;
        } 
        this.submitCreateSchedule();
    }

    // 表单提交 参数准备  也是传递给创建窗口的参数列表
    paramsPareFn = ()=>{
        // 调用创建接口
        let { title,address,isMonth}  =  this.state;
        const {start_time,end_time} = this.until_common_time();

         // 月视图
        if(isMonth){
            return{
                title,
                start_time: moment(Number(start_time)*1000).startOf('day').format('X'), 
                end_time:  moment(Number(end_time)*1000).endOf('day').format('X'),  
                address,
                is_full:  1 ,
                remind_time: 8,
            }
        }else{
            return{
                title,
                start_time, //moment(fastTimeLine[0]).format('X'),
                end_time,   //moment(fastTimeLine[1]).format('X'),
                address,
                is_full: 0,
                remind_time: 900,
            }
        }
    }

    // 表单输入的时候进行验证
    submitCreateSchedule = ()=>{
        let { title }  =  this.state;
        const params = this.paramsPareFn();
        if(title.trim().length ===0) title = this.locale('calendar_day_layout_notitle')
        this.props.onSubmit({...params,title});
    }

    // 点击更多调起日程创建
    openCreateSchedule = async ()=>{
        const params = this.paramsPareFn();
        this.props.onClose();
        this.props.onOpenScheduleAdd(params);
    }
    
    // 月视图  添加时间的状态修改
    addTimefn = ()=>{
        const {date} =this.props;
        let start = date+' '+moment().add(1,'h').format('HH:mm:ss');
        let end   = date+' '+moment().add(2,'h').format('HH:mm:ss');

        // todo:待改
        if(+ moment().add(1,'h')>= +moment().endOf('day')){
            start = moment(date+' '+ moment().format('HH:mm:ss')).add(1,'h').format('YYYY-MM-DD HH:mm:ss');
            end   = moment(date+' '+moment().format('HH:mm:ss')).add(2,'h').format('YYYY-MM-DD HH:mm:ss');
        }else if(+moment().add(2,'h')>=+moment().endOf('day')){
            end   = moment(date+' '+moment().format('HH:mm:ss')).add(2,'h').format('YYYY-MM-DD HH:mm:ss');
        }

        this.setState({
            isMonth:   false,
            startTime: getTimeDate(moment(start).format('HH:mm')),
            endTime:   getTimeDate(moment(end).format('HH:mm')),
            full_start: moment(start).startOf('day').format('X'),    //全天开始时间
            full_end: moment(end).endOf('day').format('X'),        //全天结束时间
        })
    }

    render() {
        let {pos,onClose} = this.props;
        let Mystyle = {...pos};

        return (
            <div className={css.out}>
                <div className={css.mask} onClick={onClose}></div>
                <div className={css.fastcreate} style={Mystyle}>
                    <div className={css.fastcreateHead}>
                        <h1>{this.locale('calendar_fastcreate_article')}</h1>
                        <span onClick={onClose} className={`icon iconfont iconguanbi ${css.iconfontsize} ${css.close}`}/>
                    </div>  
                    <div className={css.fastcreateContent}>
                        <div className={css.box}>
                            <span className={`icon iconfont-yach yach-xiezuo-richeng-xiangqing-zhuti ${css.iconfontsize}`}/>
                            <div className={css.listAreaRight}>
                                <Input placeholder={this.locale('calendar_fastcreate_title_placeholder')} ref={input=> this.input = input} value={this.state.title} maxLength={30} className={css.inputValue} onChange={(e)=>this.handleInputChange('title',e)} />
                            </div>   
                        </div>  
                        <div className={css.box}>
                            <span className={`icon iconfont-yach yach-xiezuo-richeng-xiangqing-shijian ${css.iconfontsize}`}/>
                            <div className={css.listAreaRight}>
                                <div className={css.timeOut}>
                                    <TimePacker 
                                        is_full={this.state.isMonth}  
                                        fullValue={this.state.full_start} 
                                        onFullChange ={this.commonChange} 
                                        dropStyle={{height:120}}
                                        type='start' 
                                        timeValue={this.state.startTime}
                                    />
                                    <i/>
                                    <TimePacker 
                                        is_full={this.state.isMonth} 
                                        fullValue={this.state.full_end} 
                                        onFullChange ={this.commonChange} 
                                        dropStyle={{height:120}}
                                        type='end'  
                                        timeValue={this.state.endTime}
                                    />
                                </div>
                                { this.state.isMonth && <p onClick={this.addTimefn} className={css.addTimes}>{this.locale('calendar_fastcreate_timepicker_addtime')}</p>}  
                            </div>   
                        </div> 
                        <div className={css.box}>
                            <span className={`icon iconfont-yach yach-xiezuo-richeng-xiangqing-didian ${css.iconfontsize}`}/>
                            <div className={css.listAreaRight}>
                                <Input placeholder={this.locale('calendar_fastcreate_address_placeholder')} className={css.inputValue} value={this.state.address} maxLength={30}  onChange={(e)=>this.handleInputChange('address',e)}/>
                            </div>   
                        </div> 
                        <div className={css.sub}>
                            <a className={css.more} onClick={ _.debounce(this.openCreateSchedule.bind(this),500)} >{this.locale('calendar_button_fastcreate_more')}</a>
                            <a className={css.submit} onClick={ _.debounce(this.preCheck.bind(this),500)}>{this.locale('calendar_button_submit')}</a>
                        </div>
                    </div>
                </div>
            </div> 
        );
    }
}

export default Index;


