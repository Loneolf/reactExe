import React from 'react';
import {configState,setCalenderColor} from '../../lib/until';

import c from './index.scss';


export default props  =>{

    const {
        monthDialog,
        mdate,
        nun,
        clickEventList,
        activeIndex,
        lang,
        locale

    } = props;

    const {list,show,posMox} = monthDialog;

    // 计算当前弹窗的高度
    const computeHeight = ()=>{

        if(!list.length) return 0;

        const sc = 80 + 32 + 44;  //顶部距离

        let diah = list.length * 32 + 51;   //卡片高度
        let doc  = document.body.clientHeight; //页面可视高度
        let docw = document.body.clientWidth; //页面可视宽度
        let { top,left:sleft,width } = posMox;
        let maxHeight = doc - sc;
        let left = 0;
        
        // 右侧极限 5 为上线波动范围
        (docw - sleft < width*2+5)  && (left = (200 - width + 5) * (-1) );

        // top 极限
        if( diah > maxHeight){
            return{
                top: -(top - sc),
                left,
                maxHeight
            }
        }
        //下面溢出情况，放上面
        else if( diah> doc - top ){
            return{
                top: -(diah - (doc - top) +10),
                left,
                maxHeight
            }
                
        }
        //默认放左边
        return {top:0,left,maxHeight}
    }

    return (
        <div className={c.dialog} style={computeHeight()} onClick={(e)=>e.stopPropagation()}>
            <div className={c.diaheader}> 
                <h1>{mdate}</h1>
                {lang ? <span>{nun}</span> : '' }
            </div>

            <div className={c.dialist} >
                {
                    !!list.length && show && list.map((item,index)=>{

                        if(!item) return null;
                        let permission = 0; 
                        let { package_info,title,current_user_info } = item;
                        let colorName = null;
                        const source=package_info && package_info.source;
    
                        if( source===2){
                            permission = package_info.permission;
                            title = permission === 1 ? (current_user_info.name +' | '+ locale('calendar_day_layout_busy')) : (current_user_info.name +' | '+title);
                        }

                        if(source===2||source===10) colorName = package_info.color;

                        let statusCancelName = permission === 0 && configState(item).type === 2 ? 'calender_refuse_text' : '';

                        return <p  
                             className={[statusCancelName, c.diaevent, activeIndex === index ? c.mactive:''].join(' ')}  
                             key={item.id} 
                             onClick={ (event)=>clickEventList(event,index,'',item) }
                          >
                          <em 
                            className={[c.colorBarlist, setCalenderColor(configState(item).type)].join(' ')}
                            style={{ backgroundColor: colorName }}
                          ></em>    
                        { (source===1||source===2) && configState(item).text }
                        { title }
                     </p> 
                    })
                }
            </div>
        </div>
    )
}