/*
 * @Descripttion:  日程列表ui组件
 * @Author: qiuyanlong@100tal.com
 */

import React from 'react';
import moment from 'moment';
import {Tooltip} from 'antd';
import * as sUtil from '../../lib/until';
import _ from 'lodash';
import {jionLive} from '@u/lib/video/liveFn';

import c from './index.scss';


export default props =>{

  const {initDate,eventList,showVideoSessioneModal,locale,showSlideModal} = props;
  const scheduleInfo =(id,source=1)=>{
    if(source===2||source===9) return
    showSlideModal('scheduleInfo', {id,source});
  }

  const timeFormate = (item)=>{
    let {year,month,day} = initDate;
    let {start_time,end_time,is_full} = item.extra_info;
    let begin =  moment.unix(start_time);
    let end = moment.unix(end_time);
    let res = '';
    let set_begtime = '00:00';
    let set_endtime = '23:59';
    let s_time = sUtil.timemillions(year,month,day,0,0,0);      // 早晨12：00
    let e_time = sUtil.timemillions(year,month,day,23,59,59);   // 午夜12：00 差一秒

    if(is_full){
      res = locale('calendar_day_layout_allday');
    }
    else{

      let bt = begin.format('MM\u6708DD\u65e5 HH:mm dddd').split(' ');
      let et = end.format('MM\u6708DD\u65e5 HH:mm dddd').split(' '); // ["10月17日", "12:42", "星期四"]

      // 把重复日程里面的跨天日程的文案修改掉。
      if( begin.date() === end.date()){
        res = bt[1]+' - ' +et[1];
      }
      else{
        if(start_time > s_time && end_time > e_time){
          res = bt[1] +' - '+ set_endtime;
        }
        if(start_time < s_time && end_time > e_time){
          res = set_begtime +' - '+ set_endtime;
        }
        if(start_time < s_time && end_time < e_time){
          res = set_begtime +' - '+ et[1];
        }
      }
    }
    return  res;
  }

  /*
      排序函数
      中国节假日 > 全天 > 非全天
      全天日程：按创建时间排列
      非全天日程：优先按开始时间排列，开始
      时间相同按创建时间排列
  */
  const sortlist = ()=>{
    const originList = getLayoutList(eventList);
    const copyDataList = _.cloneDeep(originList);
    let {year,month,day} = initDate;

    // 对当天的数据进行处理
    // 重复日程跨天 处理 ‘全天’ 文案和排序流程
    let s_time = sUtil.timemillions(year,month,day,0,0,0);      // 早晨12：00
    let e_time = sUtil.timemillions(year,month,day,23,59,59);   // 午夜12：00 差一秒

    for(let i=0; i<copyDataList.length; i++){
      let { extra_info } = copyDataList[i];
      let {start_time,end_time,is_full} = extra_info;
      if(extra_info.repeat_value){
        // 是重复日程
        if( start_time < s_time && end_time > e_time ){
          extra_info['is_full'] = 1;
        }
      }
    }
    return copyDataList.sort(function(a,b){
      if(a.extra_info.is_full || b.extra_info.is_full){
        return b.extra_info.is_full - a.extra_info.is_full;
      }
      else {
        if(a.begin_time < b.begin_time){
          return -1;
        }
        else if(a.begin_time === b.begin_time){
          if(a.created_time < b.created_time){
            return -1;
          }else{
            return 1;
          }
        }
        else{
          return 1;
        }
      }
    })
  }


  const getLayoutList = (ulist)=>{
    const RamArray = [];
    const {layout=[],list} = ulist;
    !!Object.keys(layout).length && layout.forEach(mt=>{
      !!mt.list.length && mt.list.forEach((item)=>{
        let ind =  item.index;
        RamArray.push(list[ind]);
      })
    })
    return RamArray;
  };

  const renderList = ()=>{
    const res = [];
    const slist = sortlist();
    for(let i=0; i< slist.length; i++){
      const item = slist[i];
      const {id,title,location,package_info,current_user_info,state,meeting={},finish_time,tags=[],live_id,speaker,creator,live_state} = item;
      let colorName = null;
      let temTitle = title;
      let permission = package_info.permission; // 默认权限是自己的日程
      const {source}=package_info;

      // 共享日程需要处理不同的颜色  here~ and here~
      if( source && source===2 ){
        temTitle = permission === 1 ? (current_user_info.name +' | '+locale('calendar_day_layout_busy')) : (current_user_info.name+' | '+title);
      }

      // 共享直播日程需要处理不同的颜色
      if(source===2||source===10) colorName = package_info.color;
      
      // 能看详情的日程有样式（个人、直播日程）
      let cursor = source ===1||source===10 ?{cursor: 'pointer'}:'';

      // 是否显示会议
      let isShowMeeting = sUtil.isShowMeeting(permission,meeting,state,finish_time, source);
      let emBgColor = sUtil.setCalenderColor(sUtil.configState(item).type);
      let statusCancelName =  sUtil.configState(item).type === 2?'calender_refuse_text':'';
      const showJoinLive=source==10 && current_user_info.uid!=speaker;


      res.push(
          <div className={[c.listx].join(' ')}  style={{...cursor}}  key={id} onClick={
            _.debounce(()=>{scheduleInfo(item.id,source)} ,300)
          }>
            <h2 className={statusCancelName + ' '+ c.titles}>
              <em className={emBgColor} style={{backgroundColor:colorName}}></em>
              { (source===1||source===2) && sUtil.configState(item).text}{temTitle}
            </h2>

            <p className={c.help_text}>{timeFormate(item)}</p>

            { location && source!==2 && <p className={c.help_text}>
              <span className={c.locations}>{location}</span></p>
            }
            { isShowMeeting && <div  className={c.addMetting} onClick={(e)=>showVideoSessioneModal(e,item)}>
              <span className="iconfont-yach yach-0421_xiezuo_shipinhuiyirukou"></span>
            </div>}
            { showJoinLive && (
              <Tooltip 
                placement="top" 
                title={locale(live_state==3?'calendar_button_info_joinreplay':'calendar_button_info_joinlive')}
              >
                <div  className={c.addMetting} onClick={(e)=>jionLive({id:live_id})}>
                  <span style={{fontSize:17}} className="iconfont-yach yach-0604-rili-richengxiangqingcehua-jinruzhibo"></span>
                </div>
              </Tooltip>
            )}
          </div>
      )
    }
    return res;
  }

  return(
      <div className={c.rightdate}>
        <h1>{locale('calendar_day_layout_right_title')}</h1>
        <div className={c.onedaylist}>
          {
            !renderList().length? <div className={c.nodadata}>{locale('calendar_day_layout_right_empty')}</div>:renderList()
          }
        </div>
      </div>
  )
};

