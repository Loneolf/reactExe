// react
import React from 'react';

// util
import { configState, setCalenderColor } from '../../../lib/until';
import {locationMinHeight} from '../../../lib/unit-core';

import {locale} from '@u/util.js';
import css from './index.scss';


/**
 * @description: 每一个日程小块
 * @param:type day/allday
 * @param:kind week/day
 */
// BoxOperationContainer
export default function Index({item,styles=null,type='day',checkAllDayCard,kind}) {
    // permission 1:查看标题；2:查看忙闲；
    // source 1:自己；2:他人；9:节假日；10:直播
    const { title,package_info,current_user_info,location,id} = item;
    let colorName = null;
    let temTitle = title;
    let permission = package_info.permission;; 
    const source=package_info.source;
    
    // 他人日程
    if (source === 2) {
        temTitle =
            permission === 1
                ? current_user_info.name + ' | ' + locale('calendar_day_layout_busy')
                : current_user_info.name + ' | ' + title;
    }

    // 共享直播日程需要处理不同的颜色
    if(source===2||source===10) colorName = package_info.color;

    let peddingStyle = (source===1||source===2) && configState(item).type === 5 ? {
        border:'1px dashed '+package_info.color
    } : {};

    // 拒绝取消标题中划线
    let statusCancelName = source!==2 && configState(item).type === 2 ? 'calender_refuse_text' : '';

    return (
         <div className={css.out} style={kind==='allday_week'?styles:null}>
            <div
                className={[
                    type==='allday'?'calender_allday':"",
                    'calender_commonstyle',
                    kind==='week'?'weekscheDraw':''
                ].join(' ')}
                key={id}
                onClick={(event) => checkAllDayCard(type, item, event, configState(item))}
                //onClick={ event => this.checkAllDayCard2( type, item, styles ) }
                style={kind==='allday_week'?{margin:0}:styles}
            >
                <div className='borderBg' style={peddingStyle} />
                <div className='main'>
                    <em
                        className={['calender_colorBar',setCalenderColor(configState(item).type)].join(' ')}
                        style={{ backgroundColor: colorName }}
                    ></em>
                    <div className="content">
                        <div className={"bg "+setCalenderColor(configState(item).type)+'_bg'} style={{ backgroundColor: colorName }} />
                        <div className="content_text">
                            <p className={`${statusCancelName} calender_title`}>
                                {(source===1||source===2) && configState(item).text}
                                {temTitle}
                                {type==='allday'&& source === 9 ?' | '+locale('calendar_selectcard_title_chinesefestival'):''}
                            </p>

                            {type==='day' && source!==2&& location && styles.height >= locationMinHeight && (
                                <p className="help_text">
                                    <span className="iconfont-yach yach-0421_xiezuo_richenghuiyishidingwei location" />
                                    <span className="calender_locations">{location}</span>
                                </p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
