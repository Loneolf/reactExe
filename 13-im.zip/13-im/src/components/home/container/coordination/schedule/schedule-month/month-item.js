/*
 * @Descripttion:
 * @version:
 */

import React from 'react';
import sloarToLunar from '../../lib/unti.nun';
import AllEventList from './month-list';
import * as sUtil from '../../lib/until';
import moment from 'moment';
import FastCreateSchedule from '../schedule-fastcreate';
import { Spin } from 'antd';
import DialogShowMore from './month-dialog';
import * as unitCore from '../../lib/unit-core';

import c from './index.scss';


export const UiDateList = (props) => {
    const {
        y,
        m,
        n,
        dayOfWeek,
        monthlist,
        loading,
        maskshow,
        handleMask,
        fastCreateSchedule,
        activeHeight,
        showMoreList,
        monthDialog,
        clickEventList,
        activeIndex,
        outtiveDate,
        locale,
        lang
    } = props;


    const renderArry = [];
    let nowMonthHasDayNum = sUtil.days_per_month(y);
    const td = new Date();
    let mboxHeigt = `calc(100% / ${n})`;
    const T = {};

    if (!!Object.keys(monthlist).length) {
        let { list = {}, layout = {} } = monthlist;
        !!Object.keys(layout).length &&
            layout.forEach((mt) => {
                T[mt.key] = [];
                mt.list.length &&
                    mt.list.forEach((item, num) => {
                        let ind = item.index;
                        if (!!list[ind]) {
                            T[mt.key].push(list[ind]);
                        }
                    });
            });
    }

    const renderMonthList = (arg)=>{

        let  { mdate,daylist,origindata,ttday,active,nun,datatime} = arg;

        return(
               <>
                <AllEventList
                        key             =   { mdate }
                        daylist         =   { daylist }
                        origindata      =   { origindata }
                        day             =   { ttday }
                        active          =   { active }
                        activeHeight    =   { activeHeight }
                        nun             =   { nun }
                        showMoreList    =   { showMoreList }
                        datatime        =   { datatime }
                        clickEventList  =   { clickEventList }
                        activeIndex     =   { activeIndex }
                        outtiveDate     =   { outtiveDate }
                        locale          =   { locale }
                    />
                    { monthDialog.show && monthDialog.datatime === datatime  && <DialogShowMore
                        monthDialog     =   { monthDialog }
                        mdate           =   { mdate }
                        nun             =   { nun }
                        clickEventList  =   { clickEventList }
                        activeIndex     =   { activeIndex }
                        lang            =   { lang }
                        locale          =   { locale }
                    /> }
               </>

        );
    }

    // 开渲染周每天的日期ui数据
    for (let oli = 0; oli < n; oli++) {
        for (let awk = 0; awk < 7; awk++) {
            let idx = 7 * oli + awk;
            let mdate = idx - dayOfWeek + 1;
            let greyC = '';
            let nextV = 0;
            let tt = m; // 月份的复制值 用于修改变化 日列表
            let dd = mdate; // 日期的复制值
            if (mdate <= 0) {
                tt = tt - 1;
                greyC = 'greyText';
                // 要跨年了，年月都需要做减法
                let preMonth = m - 1;
                if (preMonth < 0) {
                    preMonth = 11;
                    nowMonthHasDayNum = sUtil.days_per_month(y - 1);
                }
                mdate = parseInt(nowMonthHasDayNum[preMonth] + mdate);
                dd = mdate;
            } else if (mdate > nowMonthHasDayNum[m]) {
                greyC = 'greyText';
                nextV = mdate - nowMonthHasDayNum[m];
                tt = tt + 1;
                dd = nextV;
            } else {
                greyC = ' ';
            }

            let ng = new Date(y, tt, dd);
            let tranday = ng.getFullYear()+''+sUtil.fm(ng.getMonth()+1)+''+sUtil.fm(ng.getDate());



            let ttday = nextV > 0 ? nextV : mdate;
            let isnext = nextV > 0 ? true : false;
            let ispre = greyC === 'greyText' && !isnext ? true : false;

            let num_month = isnext && m + 2; // m+1 +1  下个月的意思
            num_month = ispre && m;

            let daylist = !!Object.keys(T).length && T[tranday];
            let buffer = [];
            let origindata = daylist && [...daylist];
            if(activeHeight && daylist){
                let aHeight =  (activeHeight+10- 37) / 19;
                let aHeights = aHeight - parseInt(aHeight);
                let floorH = aHeights>0.5? ~~aHeight:~~(aHeight-1);
                // let floorH = ~~aHeight;
                let rest = daylist.length - floorH >=0? daylist.length - floorH:0;
                if(daylist.length<=0b010){
                    buffer = [...daylist];
                }
                else{
                    buffer = [...daylist].slice(0,floorH);
                    daylist.length = 0;
                    for(let vv=0; vv<floorH ;vv++){
                        if( vv === floorH -1 && rest){
                            daylist.push(locale.getLang()==='zh-CN'?`还有${rest+1}项`:`${rest+1} more items...`)
                        }
                        else {

                                daylist.push(buffer[vv]);
                        }
                    }
                }
            }
            let datatime = `${ng.getFullYear()}-${sUtil.fm(ng.getMonth() + 1)}-${sUtil.fm(ng.getDate())}`;

            mdate === td.getDate() && y === td.getFullYear() && m === td.getMonth() && !greyC.trim()
            ? renderArry[renderArry.length] = <div
                          key={idx}
                          data-time={datatime}
                          style={{ height: mboxHeigt }}
                          onClick={(e) => {
                              fastCreateSchedule(e);
                          }}
                          className={c.mbox+' '+c.activembox}
                          data_id="active"
                      >
                    <p className={c.monthtitle +' ' + c.monthActive}>
                        <span className={c.day}>{mdate}</span>
                        {monthDialog? <span className={c.nun} style={{color:'#1560E7'}}>{sloarToLunar(y, m+1, ttday).lunarDay}</span>:''}
                    </p>
                    { !!daylist && renderMonthList({active:true,mdate,daylist,origindata,ttday,nun:sloarToLunar(y,isnext?m+2:ispre?m:m+1,ttday).lunarDay,datatime}) }
                 </div>

            :renderArry[renderArry.length] =
                <div
                    className={[c.mbox, greyC, oli + 1 === n ? c.lastline : ''].join(' ')}
                    data-lastline={oli + 1 === n ? 'lastline' : 'notlastline'}
                    data-time={datatime}
                    style={{ height: mboxHeigt }}
                    onClick={(e) => { fastCreateSchedule(e) }}
                    key={idx}
                    data_id="active"
                >
                    <p className={[c.monthtitle,greyC === 'greyText' ? c.greyText : c.nowmonth].join(' ')}>
                        <span className={c.day}>{ttday}</span>
                        {
                            lang ? <span className={c.nun} style={{color: greyC !== 'greyText' ? '#8C8C97' : ''}}>
                                     {sloarToLunar(y, isnext ? m + 2 : ispre ? m : m + 1, ttday).lunarDay}
                                   </span>
                                : ''
                        }
                    </p>
                    { !!daylist && renderMonthList({active:false,mdate,daylist,origindata,ttday,nun:sloarToLunar(y,isnext?m+2:ispre?m:m+1,ttday).lunarDay,datatime}) }
                </div>

        }
    }

    return (
        <div className={c.changeContent}>
            {loading && (
                <div className="calender_loading">
                    <Spin className="iconfont" style={{ fontSize: 20 }} />
                </div>
            )}
            <div className={c.monthwrap} id="monthwrap">
                <div className={c.monthheader}>
                    {unitCore.monthcalendar.map((item,index) => {
                        (index === 0) && (index = 7);
                        return (
                            <div className={[c.aweeks,moment().format('E') == index ? c.activeWeek : ''].join(' ')} key={item}>
                                {locale('calendar_format_week')+item}
                            </div>
                        );
                    })}
                </div>
                <div className={c.monthdetail}>
                    <FastCreateSchedule />
                    { renderArry }
                </div>
            </div>
            {maskshow && <div className={c.maskment} data-name="mask" onClick={handleMask}></div>}
        </div>
    );
};
