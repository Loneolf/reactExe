// react
import React from 'react';
import {DatePicker, Select} from 'antd';
import css from "./index.scss";
import moment from 'moment';

const { Option } = Select;

function genOption() {
    const arr=[];
    for(let i=0;i<24;i++){
        for(let n=0;n<6;n++){
            const result=(i>9?i:'0'+i)+':'+(n===0?'00':n*10);
            arr.push(<Option key={result} value={result}>{result}</Option>);
        }
    }
    return arr;
}

// BoxOperationContainer
class Index extends React.Component {
    handleFullChange=(value)=>{
        const {type,onFullChange}=this.props;
        if(!value) return;
        const newValue=type==='start'?value.startOf('day').format('X'):value.endOf('day').format('X');
        onFullChange('full_'+type,newValue);
        if(type==='start'){
            const time=this.props.timeValue;
            onFullChange('full_end',moment(value.format('YYYY-MM-DD')+' '+time+':00').add(1,'h').endOf('day').format('X'));
            onFullChange('endTime',moment(value.format('YYYY-MM-DD')+' '+time+':00').add(1,'h').format('HH:mm'));
        }
    }

    handleTimeChange=(value)=>{
        const {type,onFullChange}=this.props;
        onFullChange(type+'Time',value);
        if(type==='start'){
            const time=this.props.fullValue;
            onFullChange('full_end',moment(moment(time*1000).format('YYYY-MM-DD')+' '+value+':00').add(1,'h').endOf('day').format('X'));
            onFullChange('endTime',moment(moment(time*1000).format('YYYY-MM-DD')+' '+value+':00').add(1,'h').format('HH:mm'));
        }
    }
    
    render() {
        const {fullValue=null,timeValue,is_full,from,isMonth,style={width: 91, height: 30}} = this.props;
        const getClassSelect = from ==='fast'? css.fastselect : css.select;
        const getClassSelectList   = from === 'fast'? css.fastSelectList: null;

        return (
            <div className={css.out} id='datePickerOut'>
                <DatePicker
                    format="YYYY-MM-DD"
                    value={moment(new Date(fullValue*1000))}
                    onChange={this.handleFullChange}
                    suffixIcon={<span/>}
                    allowClear={false}
                    style={style}
                    dropdownClassName={css.dataPicker}
                    showToday={false}
                    getCalendarContainer={()=>document.getElementById('datePickerOut')}
                />
                {!is_full && !isMonth? <Select  
                           value={timeValue}
                           dropdownClassName={getClassSelectList}
                           getPopupContainer={()=> document.getElementById('datePickerOut')} onChange={this.handleTimeChange} className={getClassSelect}  showArrow={false}>
                        {genOption()}
                    </Select>:null
                }
                
            </div>
        );
    }
}

export default Index;
