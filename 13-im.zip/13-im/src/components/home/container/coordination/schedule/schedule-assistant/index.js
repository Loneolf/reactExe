/*
 * @Descripttion:  日历助手组件
 * @version: 1.1.3 - 1.1.7  -  1.1.9
 * @Author: 创建者：李超  修改者：qiuyanlong
 * @Date: 2019-12-02 10:43:08
 * @LastEditors: olei<wangzheng_jzb@100tal.com>
 * @LastEditTime: 2020-05-22 14:44:54
 *
 *
 */
import React, { Fragment } from 'react';
import { connect } from 'react-redux';
import { Spin, message } from 'antd';
import InfiniteScroll from 'react-infinite-scroller';
import css from './index.scss';
import * as util from "@/utils/util";
import { handleSheduleMsgList, timeEl, updateFn } from "@/components/home/container/coordination/schedule/common/common";
import { showSlideModal } from "@/redux/actions/commonModal";
import { scheduleListInit, scheduleListStateUpdate } from '@/redux/actions/calender'
import {withRouter} from 'react-router';
import {scheduleGuideMaterialGet} from '@s/schedule/schedule'

class Index extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false
        }
    }


    componentDidMount() {
        this.handleInfiniteOnLoad();
    }
    componentDidUpdate(prevProps) {
        if (prevProps.scheduleList.length != this.props.scheduleList.length && prevProps.scheduleList.length == 0) {
            this.scrollParentRef.scrollTop = 9999;
        }
    }
    componentWillUnmount() {
        this.props.dispatch(scheduleListInit([]));
        this.props.dispatch(scheduleListStateUpdate({
            lastId: '',
            hasMore: true,
        }));
    }
    handleInfiniteOnLoad = async () => {
        // default:{hasMore:true,lastId:""}
        let { lastId } = this.props.scheduleListState || {};
        this.setState({
            loading: true,
        });
        await handleSheduleMsgList(lastId);
        this.setState({
            loading: false,
        });
    }

    handleGoInfo = ({id,source},isType) => {
        if(window.getSelection().toString()) return
        if(isType){
            // 共享
            this.props.history.replace('/schedule');
        }
        else{
            this.props.dispatch(showSlideModal('scheduleInfo', { id,source }));
        }

        util.yachLocalStorage.ls('PageView_Schedule_SecondPage', 115);
    }

    handleMeetingGuideVideo=(url)=>{
        util.electronipc.electronOpenVideoPreview({
            url,
            onlyPlay: true
        });
    }

    handleGoShimo= async (eid)=>{
        // 请求接口得到地址，跳转石墨文档
        let url='',
            msg='';
        try {
            const s=await scheduleGuideMaterialGet({eid});
            if(s&&s.code==200){
                url=s.obj.link;
            }else{
                msg=s.msg;
            }
        } catch (e) {
            message.error('获取文档地址失败');
        }

        if(!url) return message.error(msg||'获取文档地址失败');
        window.open(url);
    }

    /**
     *
     * msg_state:
     * 普通日程：0:邀请、2:拒绝消息、3:取消、4:修改、5:移除消息、6:过期、7:提醒
     * 共享日程：20:共享移除消息、21:共享卡片
     * 直播日程：10:邀请、13:取消、14：修改、16：过期
     * 会议引导：30，
     * 2、5、20为消息卡片；其他为详情卡片
     */
    genItem = (item = {}) => {
        // const { showimg } = this.props.sessionActive || {};
        const showimg = window.session_active.showimg;
        const {
            msg_id, msg_state, msg_resp_state, msg_time, refuse_reason = '',
            schedule_info = {}, operator_user_info = {},source
        } = item;
        const { name } = operator_user_info;
        const {
            id, title, summary, location, begin_time, finish_time, repeat_type,repeat_txt,repeat_txt_en,
            is_full, scope,end_time,start_time
        } = schedule_info;

        // 日程起止时间
        const timeText = timeEl(begin_time, finish_time, is_full);

        let ContentEl = null;
        let isShareSchedule = false;
        // 共享日程 添加卡片 21  移除消息  20

        let typeStyleTile,
            typeStyleBody;
        if(msg_state==0||msg_state==3||msg_state==4||msg_state==6||msg_state==21||msg_state==10||msg_state==13||msg_state==14||msg_state==16||msg_state==7){
            /* 卡片类型*/
            // 卡片公共body
            let bodyContent = (
                <>
                    <div className={css.time}><i className='iconfont-yach yach-zhushou-rilizhushou-shijian-moren' />{timeText}</div>
                    {location ?<div className={css.address}><i className='iconfont-yach yach-zhushou-rilizhushou-didian-moren' /><div className={css.ellipsis}>{location || ''}</div></div> : null}
                    {repeat_type ? <div className={css.repeat}><i className='iconfont-yach yach-zhushou-rilizhushou-zhongfu-moren' /><span className={css.repeatText}>{this.locale.getLang()==='zh-CN'?repeat_txt:repeat_txt_en}</span></div> : null}
                </>
            );

            // 接受/拒绝、选中状状态按钮
            const receiveBtn = <span
                onClick={(e) => {
                    e.stopPropagation();
                    updateFn({ id, isRefuse: false, repeat: !!repeat_type });
                }}>{this.locale('calendar_button_notification_accept')}</span>;

            const refuseBtn = <span
                onClick={(e) => {
                    e.stopPropagation();
                    updateFn({ id, isRefuse: true, repeat: !!repeat_type });
                }}>{this.locale('calendar_button_notification_refuse')}</span>;

            const goInfoBtn=({style=null,pageName,$element_name,isShareSchedule}={})=> (
                <div className={css.btnblue +" "+ css.overdue} style={style} onClick={() => {
                    this.handleGoInfo({id,source},isShareSchedule);
                    pageName&&$element_name&&util.sensorsData.track('Click_Schedule_Element', {
                        pageName,
                        $element_name
                    });
                }}>
                    <span >{this.locale('calendar_button_notification_goinfo')}</span>
                    <span className="iconfont-yach yach-kapian-chakanxiangqing-jinru-moren"></span>
                </div>
            )


            const disableBtn = (text) => <span className={css.disabled}>{text}</span>;

            let btn = null;
            let Title = null;

            if (msg_state == 0 || msg_state == 4 || msg_state == 7) {
                if (msg_resp_state == 0) {
                    btn = <div className={css.btn}>{receiveBtn}{refuseBtn}</div>;
                } else if (msg_resp_state == 1) {
                    btn = <div className={css.btn}>{disableBtn(this.locale('calendar_button_info_accepted'))}{refuseBtn}</div>;
                } else if (msg_resp_state == 2) {
                    btn = <div className={css.btn}>{receiveBtn}{disableBtn(this.locale('calendar_button_info_refused'))}</div>;
                }
                if (msg_state == 4) {
                    Title = <p><span>{name}</span>{this.locale('calendar_assistant_title_edit')}</p>;
                } else if (msg_state == 7) {
                    Title = <p><span>{name}</span>{this.locale('calendar_create_info_notify_remind')}</p>;
                }
                else {
                    Title = <p><span>{name}</span>{this.locale('calendar_assistant_title_invite')}</p>;
                }
            } else if (msg_state == 6) {
                Title = <p>{this.locale('calendar_assistant_title_overtime')}</p>;
                typeStyleTile = css.overdueTop;
                typeStyleBody = css.overdueBody;
                btn=goInfoBtn({pageName: 121,$element_name: 166});
            } else if (msg_state == 3) {
                Title = <p><span>{name}</span>{this.locale('calendar_assistant_title_cancel')}</p>;
                typeStyleTile = css.cancelTop;
                btn=goInfoBtn();
            }else if(msg_state == 21){
                // 共享日程卡片
                isShareSchedule = true;
                Title = <p><span>{name}</span>{this.locale('calendar_assistant_title_share')}</p>;

                btn=goInfoBtn({style:{borderTop:'none'},pageName: 121,$element_name: 402,isShareSchedule});
                bodyContent  = null;
            }else if(msg_state==10||msg_state==13||msg_state==14||msg_state==16){
                // 直播的卡片   直播日程：10:邀请、13:取消、14：修改、16：过期
                if(msg_state==10){
                    Title = <p><span>{name}</span>{this.locale('calendar_live_assistant_title_invite')}</p>;
                }else if(msg_state==13){
                    typeStyleTile = css.cancelTop;
                    Title = <p><span>{name}</span>{this.locale('calendar_live_assistant_title_cancel')}</p>;
                }else if(msg_state==14){
                    Title = <p><span>{name}</span>{this.locale('calendar_live_assistant_title_edit')}</p>;
                }else if(msg_state==16){
                    typeStyleTile = css.overdueTop;
                    typeStyleBody = css.overdueBody;
                    Title = <p>{this.locale('calendar_live_assistant_title_overtime')}</p>;
                }
                btn=goInfoBtn();
            }

            ContentEl = <div className={css.schedule} onClick={() => {
                this.handleGoInfo({id,source},isShareSchedule);
                util.sensorsData.track('Click_Schedule_Element', {
                    pageName: 121,
                    $element_name: 165
                });
            }}>
                <div className={`${css.top} ${typeStyleTile}`} >
                    {Title}
                    <div className={css.content}>
                        <div className={css.ellipsis} title={title}>{isShareSchedule? name+this.locale('calendar_assistant_title_owner') :title}</div>
                    </div>
                </div>
                {
                    !isShareSchedule&&<div className={`${css.body} ${typeStyleBody}`}>{bodyContent}</div>
                }
                <div className={css.bottom}>
                    {btn}
                </div>
            </div>
        } else if(msg_state == 5 || msg_state == 2 || msg_state == 20) {
            // 消息类型

            // 消息公共body
            let bodyContent = (
                <>
                    <div className={css.ellipsis}><i className='iconfont-yach yach-quanju-tongzhi-zhuti-moren' />{title}</div>
                    <div className={css.time}><i className='iconfont-yach yach-zhushou-rilizhushou-shijian-moren' />{timeText}</div>
                    {repeat_type ? <div className={css.repeatContent}>{this.locale.getLang()==='zh-CN'?repeat_txt:repeat_txt_en}</div> : null}
                </>
            );

            // 拒绝了日程/拒绝了5月12 12:00的日程
            const titleT=scope==1?this.locale('calendar_assistant_title_refused')+' '+util.moment(start_time*1000).format(`MM${this.locale('calendar_format_month')}DD${this.locale('calendar_format_day')}`)+' '+this.locale('calendar_assistant_title_owner'):this.locale('calendar_assistant_refused')

            if (msg_state == 2) {
                // scope,end_time,start_time
                // 拒绝发的消息
                typeStyleTile = css.refusedTop;
                typeStyleBody = css.refusedBody;

                ContentEl = <div className={css.scheduleM} style={{ cursor: 'pointer' }} onClick={() => {
                    this.handleGoInfo({id,source});
                    util.sensorsData.track('Click_Schedule_Element', {
                        pageName: 121,
                        $element_name: 167
                    });
                }}>
                    <div className={`${css.topM} ${typeStyleTile}`}>
                        <div className={css.name}>{name}</div>
                        <p>{titleT + (refuse_reason.trim() ? ("：" + refuse_reason) : '')}</p>
                    </div>
                    <div className={`${css.bottom} ${typeStyleBody}`}>
                        <div className={css.ellipsis}><i className='iconfont-yach yach-quanju-tongzhi-zhuti-moren' />{title}</div>
                        <div className={css.time}><i className='iconfont-yach yach-zhushou-rilizhushou-shijian-moren' />{timeEl(start_time, end_time, is_full)}</div>
                        {repeat_type ? <div className={css.repeatContent}>{this.locale.getLang()==='zh-CN'?repeat_txt:repeat_txt_en}</div> : null}
                    </div>
                </div>
            } else if (msg_state == 5) {
                // 移出参与人的消息
                typeStyleTile = css.removedTop;
                typeStyleBody = css.removedBody;
                ContentEl = <div className={`${css.scheduleM} ${css.scheduleCancel}`}>
                    <div className={`${css.topM} ${typeStyleTile}`}>
                        <div className={css.name}>{name}</div>
                        <p>{this.locale('calendar_assistant_content_remove')}</p>
                    </div>
                    <div className={`${css.bottom} ${typeStyleBody}`}>
                        {bodyContent}
                    </div>
                </div>
            } else if(msg_state === 20){
                // 共享日程消息
                ContentEl = <div className={`${css.scheduleM} ${css.scheduleCancel}`}>
                    <div className={css.withdrawTop}>
                        <span style={{fontSize:14}}>{name+" "+this.locale('calendar_assistant_content_cancelshare')}</span>
                    </div>
                    <div className={css.withdrawBottom}>
                        <div className={css.ellipsis}>{name+" "+this.locale('calendar_assistant_title_owner')}</div>
                    </div>
                </div>
            }
        } else if(msg_state == 30){
            let {body,msg_title,msg_title_en,extra={}}=item;
            body=body||[];
            extra=extra||{};
            ContentEl=(
                <div className={css.meetingGuide}>
                    <div className={css.top}>{this.locale.getLang()==='zh-CN'?msg_title:msg_title_en}</div>
                    <div className={css.bottom}>
                        <div className={css.content}>
                            {
                                body.map(t=><p><em></em>{t}</p>)
                            }
                        </div>
                        <div className={css.btn}>
                            <div onClick={()=>this.handleMeetingGuideVideo(extra.guide_video)}>{this.locale('calendar_assistant_metting_guide_btn1')}</div>
                            <div onClick={()=>this.handleGoShimo(schedule_info.eid)}>{this.locale('calendar_assistant_metting_guide_btn2')}</div>
                        </div>
                    </div>
                </div>
            );
        }else{
            // todo不支持消息类型
            ContentEl=<div className={css.illegal}>暂不支持此类消息，请升级到新版本使用</div>;
        }

        return <div className={css.itemOut} id={msg_id} key={msg_id}>
            <img src={showimg} alt="" className='' />
            <div className={css.rightOut}>
                <div className={css.time}>
                    <em>{util.moment(msg_time * 1000).format('YYYY-MM-DD HH:mm')}</em>
                </div>
                {ContentEl}
            </div>
        </div>
    }


    // 查看自己所建日程信息
    render() {
        const { loading } = this.state;
        const { scheduleList = [], scheduleListState: { hasMore } } = this.props;
        return (
            <div className={css.box + util.style.getWinStyle(css, 'boxWin')}>
                <div className={css.content} ref={(ref) => this.scrollParentRef = ref}>
                    <InfiniteScroll
                        isReverse={true}
                        initialLoad={false}
                        pageStart={10}
                        loadMore={this.handleInfiniteOnLoad}
                        hasMore={!loading && hasMore}
                        useWindow={false}
                    >
                        {scheduleList.map(item => this.genItem(item))}
                        {/* {this.state.mockjson.map(item => this.genItem(item))} */}
                        {loading && hasMore && (
                            <div className={css.loading}>
                                <Spin />
                            </div>
                        )}
                    </InfiniteScroll>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        // sessionActive: state.sessionActive,
        scheduleList: state.calender.scheduleList,
        scheduleListState: state.calender.scheduleListState
    }
}
export default connect(mapStateToProps, null)(withRouter(Index));
