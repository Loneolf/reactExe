/*
 * @Descripttion:
 * @version:
 */
// 选项卡组件 复用在日视图和月视图和全局组件弹窗

import React, { Component } from 'react';
import moment from 'moment';
import { connect } from 'react-redux';
import { showSlideModal } from '@/redux/actions/commonModal';
import {Tooltip} from 'antd';
import css from './selectcard.scss';
import * as util from '@u/util.js';
//import * as sUntil from './until';
import _ from 'lodash';
import * as sUtil from '../../lib/until';
import {jionLive} from '@u/lib/video/liveFn';

import { setMonthDialog } from '@r/actions/calender';

const { isElementInViewport, setCalenderColor, configState, emptyObject } = sUtil;

class Selectcard extends Component {
    constructor(props) {
        super(props);
        this.calcateTopLeft.bind(this);
    }

    scheduleInfo = (id,source) => {
        this.props.dispatch(showSlideModal('scheduleInfo', { id,source }));
    };

    shouldComponentUpdate(nextProps) {
        if (_.isEqual(this.props, nextProps)) {
            return false;
        }
        return true;
    }

    // 检测某一侧是否可以完整的放下某个弹窗
    checkHasPos = ( pos )=>{
        const bar = 69;
        const dateBar = 240;
        const defaultWdith = 262;   // 弹窗的width
        const updown = 10;          // 波动范围

        const {left,right,width,top} = pos;
        let docw = document.body.clientWidth;


        // 默认右侧摆放
        if(docw - bar - dateBar - width >= defaultWdith  &&  docw - right> defaultWdith){
            console.log('qiuyanlong','left');
            return {
                left: right - bar + updown,
                top:  top - 55
            }
        }

        if(left - bar - dateBar >= defaultWdith){
            console.log('qiuyanlong','right');

            return {
                left: left - bar - defaultWdith - updown,
                top:  top - 55
            }
        }
    }

    calcateTopLeft(type, ievent) {

        let tar = ievent.target;
        let top = 0;
        let bottom = 0;
        let left = '50%';
        let twlb = !!tar && ievent.target.getBoundingClientRect();
        const MaxLeft  = 240; //216;


        console.log('qiuyanlong',twlb);

        if (type === 'month') {
            let docH = document.body.clientHeight;
            if (twlb.bottom > docH * 0.8) return { left:this.checkHasPos(twlb).left, bottom: docH - twlb.bottom + twlb.height + 5};
            return  { ...this.checkHasPos(twlb)}
        } else {
            if (!tar) return;
            let docH = document.body.clientHeight;
            let scrollBody = document.getElementById('graph_scrollDiv');
            let sh = scrollBody && scrollBody.clientHeight;
            let sw = scrollBody && scrollBody.clientWidth + 20; // 要加上20 有padding
            let sc = scrollBody && scrollBody.scrollTop;
            let t = twlb.top;
            let l = twlb.left;

            // 卡片默认宽度是300

            let up_to_bottom = document.documentElement.clientHeight - twlb.bottom;

            // 获取有定位的父元素
            left = twlb.left - 71 + twlb.width / 2 - 300 / 2;
            //console.log('是否在页面展示区域内',sh, left, sc,isElementInViewport(tar));

            if (!isElementInViewport(tar)) {
                if (twlb.height > sh) {
                    return {
                        left,
                        top: sh / 2,
                    };
                }
                if (t <= 54) {
                    top = twlb.bottom - 54 - sc;
                } else {
                    bottom = tar.clientHeight + up_to_bottom + 10 + sc;
                }
            }
            // 定位布局 155
            else if (t < 155 && twlb.height < sh * 0.7) {
                top = t + twlb.height + 17 - 58;
            } else {
                if (twlb.height > sh * 0.7) {
                    top = docH / 2;
                }
                if (twlb.bottom <= docH / 2) {
                    top = twlb.bottom - 60;
                } else {
                    bottom = docH - twlb.bottom + twlb.height;
                }
            }

            // 最后统一的返回出去，方便拦截统一设置
            if (left <= MaxLeft) {
                left = MaxLeft;
            }

            if (l + twlb.width / 2 + 300 / 2 >= sw + MaxLeft + 71) {
                left = sw - 300 + MaxLeft;
            }

            if (bottom > sh - 120) {
                bottom = sh - 120;
            }

            if (top <= 0) {
                top = 60;
            }

            if (bottom != 0) {
                return { left, bottom };
            } else {
                return { left, top };
            }
        }
    }

    async stopEvent(event) {
        event.nativeEvent.stopImmediatePropagation();
        util.sensorsData.track('Click_Schedule_Element', { pageName: 128, $element_name: 166 });
    }

    // timeFormate = (type, begin_time, finish_time, config, item) => {
    //     //    console.log(item);
    //     //    console.log('finish_time',finish_time);
    //     let begin = moment.unix(begin_time);
    //     let end = moment.unix(finish_time);
    //     let itemend = moment.unix(item.across_day); // allday 类型没有修真时间 采用下面的时间
    //     let begin_f = begin
    //         .format(`MM${this.locale('calendar_format_month')}DD${this.locale('calendar_format_day')} HH:mm ddd`)
    //         .split(' ');
    //     let end_f = end
    //         .format(`MM${this.locale('calendar_format_month')}DD${this.locale('calendar_format_day')} HH:mm ddd`)
    //         .split(' ');
    //     let itemend_f = itemend
    //         .format(`MM${this.locale('calendar_format_month')}DD${this.locale('calendar_format_day')} HH:mm ddd`)
    //         .split(' ');
    //     let res = '';

    //     if (type == 'allday') {
    //         begin.date() === end.date()
    //             ? (res = begin_f[0] + '  ' + begin_f[2])
    //             : (res = begin_f[0] + ' ' + begin_f[2] + '  -  ' + end_f[0] + ' ' + end_f[2]);
    //     } else {
    //         if (isNaN(itemend.date())) {
    //             // 非跨天
    //             begin_f[0] === end_f[0] && (res = begin_f[0] + '  ' + begin_f[2] + ' ' + begin_f[1] + '-' + end_f[1]);
    //             begin_f[0] !== end_f[0] && (res = begin_f[0] + '  ' + begin_f[1] + '-' + end_f[0] + '  ' + end_f[1]);
    //         } else {
    //             let cd = parseInt(itemend.date());
    //             let bd = parseInt(begin.date());
    //             // 跨天日程 cd 是结束日程
    //             cd > bd
    //                 ? (res = begin_f[0] + ' ' + begin_f[1] + ' - ' + itemend_f[0] + ' ' + itemend_f[1])
    //                 : (res = itemend_f[0] + ' ' + itemend_f[1] + ' - ' + end_f[0] + ' ' + end_f[1]);
    //         }
    //     }
    //     return res;
    // };
    timeFormate = (type, begin_time, finish_time) => {
        let begin = moment.unix(begin_time);
        let end = moment.unix(finish_time);
        let begin_f = begin
            .format(`MM${this.locale('calendar_format_month')}DD${this.locale('calendar_format_day')} HH:mm ddd`)
            .split(' ');
        let end_f = end
            .format(`MM${this.locale('calendar_format_month')}DD${this.locale('calendar_format_day')} HH:mm ddd`)
            .split(' ');
        
        let res = '';

        if (type == 'allday') {
            begin.date() === end.date()
                ? (res = begin_f[0] + '  ' + begin_f[2])
                : (res = begin_f[0] + ' ' + begin_f[2] + '  -  ' + end_f[0] + ' ' + end_f[2]);
        } else {
            begin_f[0] === end_f[0] && (res = begin_f[0] + '  ' + begin_f[2] + ' ' + begin_f[1] + '-' + end_f[1]);
            begin_f[0] !== end_f[0] && (res = begin_f[0] + '  ' + begin_f[1] + '-' + end_f[0] + '  ' + end_f[1]);
        }
        return res;
    };

    checkdetailfn(item) {
        // 月视图场景，关闭dialog
        this.props.dispatch(setMonthDialog({ show: false, datatime:"", list: []}));
        this.scheduleInfo(item.id,item.source);
        document.body.click();
    }

    render() {
        let { selectcard,showVideoSessioneModal } = this.props;
        let { type, item, ievent, config } = selectcard;
        if (emptyObject(selectcard) || emptyObject(item)) return null;
        let {
            title,
            summary,
            location,
            repeat_txt,
            repeat_txt_en,
            begin_time,
            finish_time,
            package_info,
            current_user_info={},
            meeting = {},
            tags = [],
            visibility,
            state,
            real_finish_time,
            live_id,speaker,live_state
        } = item;
        let source = 0;
        let permission = 0; // 默认权限是自己的日程
        let color = '';

        if (real_finish_time) {
            finish_time = real_finish_time;
        }

        if (package_info) {
            source = package_info.source;
            permission = package_info.permission || 0;
            source === 2 && (color = package_info.color);
        }

        let muystyle = this.calcateTopLeft(type, ievent);
        //let months = this.props.monthAndDayList.month ? { transform: [`translateX(-50%)`] } : null;
        let scheduleAttr = !visibility || visibility === 1 ? '' : this.locale('calendar_selectcard_primary_title');

        let emBgColor = permission === 0 ? setCalenderColor(configState(item).type) : ' ';
        let isShowMeeting = sUtil.isShowMeeting(permission, meeting, state, finish_time,source);

        const showJoinLive=source==10 && current_user_info.uid!=speaker;

        return (
            <React.Fragment>
                {!!this.props.selectcard.isshow && (
                    <div
                        className={css.cardlook}
                        onClick={this.stopEvent.bind(this)}
                        style={{ ...muystyle}}
                        ref={(ele) => (this.select = ele)}
                    >
                        <div className={css.top}>
                            {isShowMeeting && (
                                <div
                                    className={css.meeting}
                                    onClick={(e)=>showVideoSessioneModal(e,selectcard.item,'iscard')}
                                >
                                    <span className="iconfont-yach yach-0428-rili-richengxiangqing-jiaruhuiyi"/>
                                </div>
                            )}
                            {
                                showJoinLive &&(
                                    <Tooltip 
                                        placement="top" 
                                        title={this.locale(live_state==3?'calendar_button_info_joinreplay':'calendar_button_info_joinlive')}
                                    >
                                    <div
                                        className={css.meeting}
                                        onClick={(e)=>jionLive({id:live_id})}
                                    >
                                        <span className="iconfont-yach yach-0604-rili-richengxiangqingcehua-jinruzhibo"/>
                                    </div>
                                    </Tooltip>
                                )
                            }
                            {/* {
                                permission === 0&&!!config.stext&&<em>{config.stext}</em>
                            } */}
                            <div className={css.title}>
                                {permission === 1 && <p className={css.ctitles}>{config.text}{this.locale('calendar_selectcard_permission_no')}</p>}
                                {(permission === 2 || permission == 0) && (
                                    <p className={[config.type === 2 ? css.linethrough : '', css.ctitles].join(' ')}>
                                        {(permission === 2 || permission == 0) && config.text}
                                        {title}
                                    </p>
                                )}
                            </div>
                            <div className={css.time}>
                                <span> {this.timeFormate(type, begin_time, finish_time)} </span>
                            </div>
                        </div>

                        <div className={css.subcard}>
                            {item.extra_info.repeat_value !== 0 && permission === 0 && (
                                <div className={css.subline}>
                                    <span className={'iconfont-yach yach-0428-goutongmokuai-shituquxiaokapian-zhongfu-moren' + ' ' + css.subicon} />
                                    <span className={css.ctitles}> {this.locale.getLang()==='zh-CN'?repeat_txt:repeat_txt_en}</span>
                                </div>
                            )}

                            {scheduleAttr && (
                                <div className={css.subline}>
                                    <span
                                        className={'iconfont-yach yach-0428-goutongmokuai-shituquxiaokapian-simi-moren' + ' ' + css.subicon}
                                    />
                                    <span> {scheduleAttr}</span>
                                </div>
                            )}

                            {!!location && permission === 0 && (
                                <div className={css.subline}>
                                    <span className={'iconfont-yach yach-0428-goutongmokuai-shituquxiaokapian-dingwei-moren' + ' ' + css.subicon} />
                                    <span className="overflowX">{location}</span>
                                </div>
                            )}
                            {!!summary && permission === 0 && (
                                <div className={css.subline}>
                                    <span className={'iconfont-yach yach-0428-goutongmokuai-shituquxiaokapian-miaoshu-moren' + ' ' + css.subicon}/>
                                    <p className="overflowX">{summary}</p>
                                </div>
                            )}
                            <div className={css.subline}>
                                <span className={'iconfont-yach yach-0428-goutongmokuai-shituquxiaokapian-richeng-moren' + ' ' + css.subicon}/>
                                <span>
                                {/* <span style={{ color }}> */}
                                    {config.type === 4
                                        ? this.locale('calendar_selectcard_title_chinesefestival')
                                        : config.type === 6
                                        ? this.locale('calendar_selectcard_title_live')
                                        : permission === 0
                                        ? this.locale('calendar_selectcard_title_muschedule')
                                        : `${current_user_info.name} ${this.locale('calendar_assistant_title_owner')}`}
                                </span>
                            </div>
                            {source !== 9 && permission !== 1 && permission !== 2 && (
                                <div className={css.checkdetail}>
                                    <a onClick={this.checkdetailfn.bind(this, item)}>
                                        {this.locale('calendar_button_notification_goinfo')}
                                        <span className="iconfont-yach yach-0428-goutongmokuai-shituquxiaokapian-xiangqingyoujiantou-moren" style={{ fontSize: 10 }} />
                                    </a>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                {!!this.props.selectcard.isshow &&
                    util.sensorsData.track('PageView_Schedule_SecondPage', { pageName: 128 })}
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        selectcard: state.calender.selectcard,
        monthAndDayList: state.calender.monthAndDayList,
    };
};

export default connect(mapStateToProps, null)(Selectcard);
