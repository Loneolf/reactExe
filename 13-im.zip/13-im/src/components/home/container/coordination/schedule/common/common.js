/*
 * @Descripttion:  日程 助手 和创建日程等组件的共用组件
 * @version: 1.1.3 - 1.1.7  -  1.1.9
 * @Date: 2019-12-02 10:43:08
 * @LastEditors: olei<wangzheng_jzb@100tal.com>
 * @LastEditTime: 2020-05-14 11:29:01
 *
 *
 */

import React, { Fragment } from 'react';
import { Button, Dropdown, Icon, Input, Menu, message, Modal, notification, Radio } from 'antd';
import { scheduleEventsCancel, scheduleEventsFeedback, scheduleEventsHelper,scheduleEventsDelete } from '@s/schedule/schedule';
import {ucenterMultiuserInfoGet} from '@s/ucenter/ucenter-multiuser.js';


import './index.scss';
import css from './index.scss'

import { hideSlideModal, showSlideModal } from "@/redux/actions/commonModal";
import {
    scheduleListAdd,
    scheduleListInit,
    scheduleListStateUpdate,
    scheduleListUpdate
} from "@/redux/actions/calender";
import { refrshValue } from '@/redux/actions/calender';
import {showGloading,hideGloading} from '@r/actions/commonLoading'
import {showScheduleAdd,hideScheduleAdd} from '@r/actions/calender';

import {scheduleRemindState} from "@s/schedule/schedule.js"
import {scheduleRemindGetState} from "@s/schedule/schedule.js"
import * as util from '@u/util.js';
import 'moment/locale/zh-cn';

const { confirm } = Modal;
import {meetingCreateJoinFun} from '@u/lib/zoom/zoomFn';


import {locale} from '@u/util.js'
// 同步接口
const scheduleSync = (paramObj) => {
    console.log('参数',paramObj)
    const { id, alertType, type = 1,tid } = paramObj;
    const obj = {
        type,// 1：弹框 2:数据
        data: {
            scheduleId: id,
            alertType,tid
        }
    }
    console.log('发送同步',obj);
    util.nimUtil.publishEvent(10002, obj);
}

// 日程页面刷新
const refrshCalender = (type) => {
    window.store.dispatch(refrshValue({ value: Math.random() + 1, type }));
}
/*
* 及时详情拒接接受
* */

const getState=async(data)=>{
    let datatype=await scheduleRemindGetState(data);
    let state=datatype.obj.result[0].state;
    return state
}
 const commitState=async(data)=>{
    await scheduleRemindState(data)
 }

/*
* 拒绝/接受日程
* callBack: 完成回调
* id      : 日程id
* isRefuse: 拒绝/接受
* repeat  : 重复
* 例如     :updateFn({id, isRefuse: false, repeat, callBack: getDetail});
* */
const updateFn = (paramObj) => {
    const { id, isRefuse, repeat,scheduleInfo} = paramObj;
    if (!isRefuse&&!(scheduleInfo&&repeat)) {
        // 接受 详情 非重复
        updateStatus({id, isRefuse, scope: 2 });
    } else {
        let Modalinput,
            ModalRadio;

        confirm({
            className: css.ScheduleConfirm,
            getContainer: () => document.getElementById('slideModal'),
            centered: true,
            title: <div className={css.modalTitle}>{repeat ? scheduleInfo?locale('calendar_confirm_repeat'):locale('calendar_confirm_refuseall') : locale('calendar_confirm_refuseeone')}</div>,
            content: <div className={css.modalContent}>
                {/* 拒绝接受都是全部 */}
                {scheduleInfo && repeat ?
                    <Radio.Group className={css.radioOut} ref={el => ModalRadio = el} defaultValue={2}>
                        <Radio className={css.radio} value={1}>{locale('calendar_confirm_readio_option1')}</Radio>
                        <Radio className={css.radio} value={2}>{locale('calendar_notification_dropdown_all')}</Radio>
                    </Radio.Group> : null}
                {
                    isRefuse ? <Input placeholder={locale('calendar_confirm_input_reason_placeholder')} ref={el => Modalinput = el} /> : null
                }
            </div>,
            zIndex: 1011,
            onCancel() {
            },
            onOk() {
                const inputValue = Modalinput && Modalinput.state.value;
                const radioValue = ModalRadio && ModalRadio.state.value;

                // // 不重复日程传2，重复日程根据值来
                const scope = radioValue ? radioValue : 2;
                const paramO = {};
                if (isRefuse) paramO.reason = inputValue;
                updateStatus({ id, isRefuse, scope, ...paramO });

                // 埋点
                if (repeat) {
                    util.sensorsData.track('Click_Schedule_Element', {
                        pageName: 170,
                        $element_name: 129
                    });
                } else {
                    util.sensorsData.track('Click_Schedule_Element', {
                        pageName: 183,
                        $element_name: 129
                    });
                }
            },
            okText: locale('calendar_button_ok'),
            cancelText: locale('calendar_button_cancel'),
        });
    }

    // 埋点
    if (repeat) {
        util.sensorsData.track('PageView_Schedule_SecondPage', { pageName: 170 })
    } else {
        util.sensorsData.track('PageView_Schedule_SecondPage', { pageName: 183 })
    }
}

const updateStatus = async (paramObj) => {
    window.store.dispatch(showGloading());
    const { id, isRefuse, alertType } = paramObj;
    let msg = ''
    if (isRefuse) {
        msg = locale('calendar_confirm_msg_refuse');
        paramObj.state = 2;
    } else {
        msg = locale('calendar_confirm_msg_accept');
        paramObj.state = 1;
    }
    if (!paramObj.reason) delete paramObj.reason;
    const s = await scheduleEventsFeedback(paramObj);
    window.store.dispatch(hideGloading());
    if (s.code == 200) {
        const tid=s.obj.tid;
        // 同步
        scheduleSync({ type: 1, id, tid, alertType });
        scheduleSync({ type: 2, id, tid, alertType });
        message.success(msg);
        // 更新助手
        updateSheduleMsgList(id, paramObj.state);
        // 日程视图
        refrshCalender();
        // 关闭提醒弹框  
        closeScheduleNotification({tid, id});
        // 刷新详情
        if(window.store.getState().slideModal.kind==='scheduleInfo'){
            const id=window.store.getState().slideModal.id
            window.store.dispatch(hideSlideModal());
            window.store.dispatch(showSlideModal('scheduleInfo', {id}));
        }
    } else {
        message.warning(s.msg);
        // 日程修改之后的处理
        window.store.dispatch(hideSlideModal());
        handleSheduleMsgList();
        // 移除人之后邀请弹框不消失，点击拒绝/接受之后收起弹框
        closeScheduleNotification({id});
    }
}

/*
* 取消日程
* callBack: 完成回调
* paramObj: {
*   id,日常id
*   reason,取消原因
* }
* 例如     :cancelSchedule({id:123,reason:'有事'},callBack:fn)
* */
const cancelSchedule = async (paramObj, callBack) => {
    window.store.dispatch(showGloading());
   try{
        const s = await scheduleEventsCancel(paramObj);
        window.store.dispatch(hideGloading());
        if (s.code == 200) {
            message.success(locale('calendar_toast_cancel_success'));
            callBack && callBack(s.obj.sid);
            refrshCalender();
            scheduleSync({ type: 2 });
            util.log('calendar', `cancelSchedule:cancel schedule ok`, JSON.stringify(paramObj.id));
        }else{
            message.success(s.msg);
        }
   }
   catch(e){
         util.log('calendar', `cancelSchedule:cancel schedule fail`, JSON.stringify(paramObj.id));
   }
}

// 消息助手list  param 最后一个卡片或者消息的lastid
const handleSheduleMsgList = async (param) => {
    if (!param) window.store.dispatch(scheduleListInit([]));
    const { obj, code } = await scheduleEventsHelper({ size: 10, last_id: param });

    const list = obj && obj.list || [];
    let hasMore = true;
    if (list.length == 0) hasMore = false;
    const lastItem = list[0] || {};
    window.store.dispatch(scheduleListStateUpdate({ hasMore, lastId: lastItem.msg_id, }))

    if (code == 200 && list.length > 0) {
        if (!param) {
            window.store.dispatch(scheduleListInit(list));
        } else if (param) {
            window.store.dispatch(scheduleListAdd(list));
        }
    }
}

// 更新 msglist
const updateSheduleMsgList = (id, status) => {
    const { calender: { scheduleList }, sessionActive } = window.store.getState();
    if (sessionActive.id != 3004) return;
    const newArr = scheduleList.map(item => {
        if (item.schedule_info && item.schedule_info.id == id) {
            // 改造schedueleMessageList
            item.msg_resp_state = status;
        }
        return item;
    })
    window.store.dispatch(scheduleListUpdate(newArr));
}

// 关闭弹框
const closeScheduleNotification = (obj) => {
    const {tid,id}=obj;
    let key = '';
    for (let [k, value] of window.scheduleMap) {
        if(k.tid==tid||k.id==id){
            // 存在，需要替换
            key=value;
            window.scheduleMap.delete(k);
            break;
        }
    }
    if(key){
        notification.close(key);
    }
}

// Notification提示
//普通日程：1001：日程快到期的弹框（展示提醒弹框） 0:邀请 2拒绝 3:取消 4:修改 5:移出 7:提醒
//直播日程：10:邀请  13:取消 14:修改 17:直播开始提醒
const openScheduleNotification = async (data) => {
    console.log(data,'0000000000000');
    const { title, status, msg_id,invite, id, repeat_type, is_full, location, start_time, end_time, type,tid,meeting={},tags=[],invite_en} = data;
    let statetype,
        err;
    try{
        statetype=await getState({msg_ids:msg_id});
    }catch(e){
        err=e.toString();
    }

    util.log('calendar', `openScheduleNotification:${statetype?'success':'error'}`,JSON.stringify({title,id,start_time,end_time,tid,err}).slice(0,100));

    if(!statetype) return;
    let key ='';
    for (let [k, value] of window.scheduleMap) {
        if(k.tid==tid||k.id==id){
            // 存在，需要替换
            key=value;
            window.scheduleMap.delete(k);
            window.scheduleMap.set({id,tid},value);
            break;
        }
    }
    if(!key){
        // 不存在，需要新建
        key=id+''+tid;
        window.scheduleMap.set({id,tid},key);
    }

    let btn = null;
    const timeText = timeEl(start_time, end_time, is_full, 'tip');//时间详情
    //知道了
    const knowEl = <Button onClick={(e) => {
        e.stopPropagation();
        handleClick();
        uploadSensorsClickData(177);
    }}>{locale('calendar_button_notification_know')}</Button>;
    //忽略
    const ignoreEl = <Button onClick={(e) => {
        e.stopPropagation();
        handleClick();
        uploadSensorsClickData(173);
    }}>{locale('calendar_button_notification_ignore')}</Button>;
    //查看详情
    const goInfoEl = <Button onClick={(e) => {
        e.stopPropagation();
        handleClick()
        goInfo();
        uploadSensorsClickData(166);
    }}>{locale('calendar_button_notification_goinfo')}</Button>;
    //接受
    const receiveEl = <Button onClick={(e) => {
        e.stopPropagation();
        handleClick('receive');

        uploadSensorsClickData(146);
    }}>{locale('calendar_button_notification_accept')}</Button>;
    //拒绝
    const refuseEl = <Button onClick={(e) => {
        e.stopPropagation();
        handleClick('refuse');
        uploadSensorsClickData(147);
    }}>{locale('calendar_button_notification_refuse')}</Button>;
    //立即加入会议
    const joinRightNow =(type==1001 && meeting.type===1) ? (
        <div className="joinbutton" onClick={(e)=>{
            e.stopPropagation();
            handleClick();
            const hide=message.loading(locale('calendar_notification_jionmeeting'),15)
            meetingCreateJoinFun({daily_meeting:tags[0]&&tags[0].text,title,id:meeting.id,type:3},()=>{
            hide();
            // 日程弹窗-加入会议按钮点击 埋点
            util.electronipc.electronZoomCallFn('getMeetingID', null, async res => {
                console.log(!res,"resresresresresresres")
                if (res == 7) return util.yach.platformConfigGetFun();
                if(!res) {
                    util.sensorsData.track('Click_Schedule_Element', {
                        pageName: '123',
                        $element_name: '01-135'
                    });
                }
            });
            });
        }}>
            <span className='icon iconfont-yach yach-richeng-tixingdanchuang-huiyijiaruicon' />
            {locale('calendar_button_joinnow')}
        </div>
    ) : null;

    // const refuseReEl = <Dropdown overlay={
    //     <Menu onClick={(value) => handleClick('refuse', value)}>
    //         <Menu.Item key={1}>
    //             {locale('calendar_confirm_readio_option1')}
    //         </Menu.Item>
    //         <Menu.Item key={2}>
    //             {locale('calendar_notification_dropdown_all')}
    //         </Menu.Item>
    //     </Menu>}>
    //     <Button>
    //         {locale('calendar_button_notification_refuse')} <Icon type="down" />
    //     </Button>
    // </Dropdown>;

    // const receiveReEl = <Dropdown overlay={
    //     <Menu onClick={(value) => handleClick('receive', value)}>
    //         <Menu.Item key={1}>
    //             {locale('calendar_confirm_readio_option1')}
    //         </Menu.Item>
    //         <Menu.Item key={2}>
    //             {locale('calendar_notification_dropdown_all')}
    //         </Menu.Item>
    //     </Menu>}>
    //     <Button>
    //         {locale('calendar_button_notification_accept')} <Icon type="down" />
    //     </Button>
    // </Dropdown>;

    if (type == 0 || type == 7) {
        btn = <div>{ignoreEl}{refuseEl}{receiveEl}</div>
    } else if(type==10||type==13||type==14||type==17){
        btn = <div>{knowEl}{goInfoEl}</div>
    }else{
        // 其他按钮都是知道了和查看详情 加入会议
        btn = <div>{knowEl}{goInfoEl}{joinRightNow}</div>
    }

    // 数据打点
    let popupType = '';
    let alertType = '';
    if (type == 0 || type == 7) {
        // 邀请
        alertType = 1;
        popupType = 101;
    } else if (type == 3) {
        // 取消
        alertType = 3;
        popupType = 102;
    } else if (type == 4) {
        // 修改
        alertType = 2;
        popupType = 103;
    } else if (type == 1001) {
        // 开始前提醒
        alertType = 0;
        popupType = 104;
    }
    util.sensorsData.track('Expo_Schedule_MessagePopup', {
        PopupType: popupType
    });
    notification.open({
        message: <div><span/><em>{locale('calendar_top_tab_schecule')}</em></div>,
        description:
            <div className='tipContent'>
                <p className='tipTitle'>
                    <span>{locale.getLang()==='zh-CN'?invite:invite_en}</span>
                </p>
                <div title={title}><span className='iconfont-yach yach-quanju-tongzhi-zhuti-moren'></span>
                    {title}
                </div>
                <div>
                    <span className='iconfont-yach yach-quanju-tongzhi-shijian-moren'></span>
                    {timeText}
                </div>
                {
                    location ? <div title={location}>
                        <span className='iconfont-yach yach-quanju-tongzhi-didian-moren'></span>{location}
                    </div> : null
                }
            </div>,
        btn,
        getContainer: () => document.getElementById('slideModal'),
        duration: null,
        key,
        onClose: () => notification.close(key),
        className: 'tip',
        onClick: goInfo
    });

    // type 种类；value:接受拒接种类
     const handleClick =async(type, e) =>{
        commitState({"msg_ids":msg_id})
        if (!type) {
            // 知道了，忽略 、查看详情 加入会议
            notification.close(key);
            scheduleSync({ type: 1, id, tid, alertType });
            return;
        }
        // 接受拒接
        notificationInfoFn({
            id,
            isRefuse: type === 'refuse',
            repeat: repeat_type,
            alertType
        });
    }
    const notificationInfoFn = async (paramObj) => {
        const { isRefuse, repeat } = paramObj;
        const _id = paramObj.id
        const _alertType = paramObj.alertType
        // await commitState({"msg_ids":msg_id})
        // 通知都是重复不重复都是2；
        const scope = 2;

        if (isRefuse) {
            let Modalinput;
            confirm({
                className: css.ScheduleConfirm,
                getContainer: () => document.getElementById('slideModal'),
                centered: true,
                title: <div className={css.modalTitle}>{repeat?locale('calendar_confirm_refuseall'):locale('calendar_confirm_refuseeone')}</div>,
                content: <div className={css.modalContent}>
                    <Input placeholder={locale('calendar_confirm_input_reason_placeholder')} ref={el => Modalinput = el} />
                </div>,
                zIndex: 1011,
                onCancel() {
                },
                onOk() {
                    const inputValue = Modalinput && Modalinput.state.value;
                    // 不存在就是拒绝全部
                    const paramO = {};
                    if (isRefuse) paramO.reason = inputValue;
                    updateStatus({ id: _id, alertType: _alertType, isRefuse, scope, ...paramO });
                },
                okText: locale('calendar_button_ok'),
                cancelText: locale('calendar_button_cancel'),
            });
        } else {
            // 接受日程
            // await commitState({"msg_ids":msg_id})
            updateStatus({ id: _id, alertType: _alertType, isRefuse, scope })
        }
    }
    // 全局跳转日程详情
    function goInfo() {
        notification.close(key);
        scheduleSync({ type: 1, id: key,tid, alertType });
        const sessionActive = window.store.getState().sessionActive || {};
        if (sessionActive.id != 3004) util.nim.activeRow('p2p', '3004');
        window.store.dispatch(showSlideModal('scheduleInfo', { id,source:type }));
        util.yachLocalStorage.ls('PageView_Schedule_SecondPage', 116);
    }

    // 数据上报
    function uploadSensorsClickData(elementName) {
        util.sensorsData.track('Click_Schedule_Element', {
            pageName: 123,
            $element_name: elementName
        });
    };
};


// 时间转换
const timeEl = (start = 1570605099, end = 1570605099, is_full, type) => {
    const moment = util.moment;
    let text = '';
    const startTime = moment(start * 1000),
        endTime = moment(end * 1000);


    if (startTime.dayOfYear() !== endTime.dayOfYear()) {
        // 跨天的
        if (!type) {
            if (is_full) {
                text = <div className={css.time}>
                    <span>{startTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd`)}</span>
                    <span>{endTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd`)}</span>
                </div>
            } else {
                text = <div className={css.time}>
                    <span>{startTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd HH:mm`)}</span>
                    <span>{endTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd HH:mm`)}</span>
                </div>
            }
        } else {
            if (is_full) {
                text = startTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')}`) + '-' + endTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')}`);
            } else {
                text = startTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} HH:mm`) + '-' + endTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} HH:mm`);
            }
        }
    } else {
        // 同一天
        if (is_full) {
            text = startTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd`);
        } else {
            text = startTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd HH:mm`) + '-' + endTime.format('HH:mm');
        }
    }
    return text;
}

// 日程更改通知confirm弹框
const noticeConfirm = props => {
    const {
        title,
        callback
    } = props
    let ModalRadio
    confirm({
        className: css.ScheduleConfirm,
        centered: true,
        title: <div className={css.modalTop}>
                 <span className={css.modalTitle}>{title}</span>
               </div>,
        content: <div>
                    <Radio.Group className={css.radioOut} ref={el => ModalRadio = el} defaultValue={1}>
                        <Radio className={css.radio} value={1}>{locale('calendar_toast_notify_button')}</Radio>
                        <Radio className={css.radio} value={0}>{locale('calendar_toast_dont_Notify_button')}</Radio>
                    </Radio.Group>
                </div>,
        zIndex: 1011,
        onOk() {
            // callBack({ scope: radioValue, reason: inputValue }, { resolve, reject });
            callback({notify: ModalRadio.state.value})
        },
        okText: locale('calendar_button_ok'),
        cancelText: locale('calendar_button_continue_editing'),
    })
}

// 日程取消confirm弹框
const commmonModalConfirm = (paramObj) => {
    const { callBack, type } = paramObj;
    let title = '';
    if (type === 'rule') {
        title = locale('calendar_confirm_rule');
    } else if (type === 'cancleOne') {
        title = locale('calendar_confirm_canceleone');
    } else {
        title = locale('calendar_confirm_repeat');
    }
    let ModalRadio;
    let Modalinput;
    confirm({
        className: css.ScheduleConfirm,
        // getContainer: () => document.getElementById('slideModal'),
        centered: true,
        title: <div className={css.modalTop}>
                <span className={css.modalTitle}>{title}</span>
                {/* {type==="cancleOne" ? null:<img src={require('@a/imgs/schedule/cross.png')} className={css.iconCross}/>} */}

            </div>,
        content: <div className={css.modalContent}>
            {type === 'cancleOne' ? <Input maxLength={30} placeholder={locale('calendar_confirm_input_reason_placeholder')} ref={el => Modalinput = el} /> :
                <Radio.Group className={css.radioOut} ref={el => ModalRadio = el} defaultValue={type === 'rule' ? 2 : 1}>
                    {
                        type === 'rule' ? null : <Radio className={css.radio} value={1}>{locale('calendar_confirm_readio_option1')}</Radio>
                    }
                    <Radio className={css.radio} value={2}>{locale('calendar_confirm_readio_option2')}</Radio>
                </Radio.Group>
            }
        </div>,
        zIndex: 1011,
        onCancel() {
        },
        onOk() {
            const radioValue = ModalRadio && ModalRadio.state.value;
            const inputValue = Modalinput && Modalinput.state.value;
            return new Promise((resolve, reject) => {
                callBack({ scope: radioValue, reason: inputValue }, { resolve, reject });
            }).catch(() => console.log('Oops errors!'));
        },
        okText: locale('calendar_button_ok'),
        cancelText: locale('calendar_button_cancel'),
    });
}

// 日程删除confirm弹框
const deleteConfirm = (paramObj) => {
    const { confirTitle,type,defaultValue,sid,userState,repeat_value } = paramObj;
    if(userState==2&&repeat_value){
        // 针对参与人拒绝重复日程，点击删除的逻辑
        let ModalRadio;
        confirm({
            className: css.deleteConfirm,
            getContainer: () => document.getElementById('slideModal'),
            centered: true,
            title: <div className={css.modalTop}>
                    <span className={css.modalTitle}>{locale('calendar_confirm_repeat')}</span>
                </div>,
            content: <div className={css.modalContent}>
                <Radio.Group className={css.radioOut} ref={el => ModalRadio = el} defaultValue={1}>
                    <Radio className={css.radio} value={1}>{locale('calendar_confirm_readio_option1')}</Radio>
                    <Radio className={css.radio} value={3}>{locale('calendar_notification_dropdown_all')}</Radio>
                </Radio.Group>
            </div>,
            zIndex: 1011,
            onCancel() {},
            onOk() {
                const radioValue = ModalRadio && ModalRadio.state.value;
                const value=radioValue;
                if(radioValue==3){
                    confirm({
                        getContainer: () => document.getElementById('slideModal'),
                        centered: true,
                        content: locale('calendar_info_delete_warning'),
                        zIndex: 1011,
                        onCancel() {},
                        onOk() {
                            scheduleEventsDelete({id:sid,scope:value,refuse:0}).then(s=>{
                                const {code,msg}=s||{};
                                if(code == 200 ){
                                    message.success(locale('calendar_toast_delete_success'));
                                    refrshCalender();
                                }else{
                                    message.error(code,msg)
                                }
                                window.store.dispatch(hideSlideModal());
                            })
                            util.log('calendar', `handleDeleteSchedule`, JSON.stringify({id:sid,scope:value,refuse:type}));
                        }
                    })
                }else{
                    scheduleEventsDelete({id:sid,scope:value,refuse:0}).then(s=>{
                        const {code,msg}=s||{};
                        if(code == 200 ){
                            message.success(locale('calendar_toast_delete_success'));
                            refrshCalender();
                        }else{
                            message.error(code,msg)
                        }
                        window.store.dispatch(hideSlideModal());
                    })
                    util.log('calendar', `handleDeleteSchedule`, JSON.stringify({id:sid,scope:value,refuse:type}));
                }
                
            },
            okText: locale('calendar_button_ok'),
            cancelText: locale('calendar_button_cancel'),
        });
        return;
    }

    let ModalRadio;
    confirm({
        className: css.deleteConfirm,
        getContainer: () => document.getElementById('slideModal'),
        centered: true,
        title: <div className={css.modalTop}>
                <span className={css.modalTitle}>{confirTitle}</span>
            </div>,
        content: defaultValue===4?<div className={css.modalContent}>
            <Radio.Group className={css.radioOut} ref={el => ModalRadio = el} defaultValue={1}>
                <Radio className={css.radio} value={1}>{locale('calendar_confirm_readio_option1')}</Radio>
                <Radio className={css.radio} value={2}>{locale('calendar_confirm_readio_option2')}</Radio>
            </Radio.Group>
        </div>:null,
        zIndex: 1011,
        onCancel() {},
        onOk() {
            const radioValue = ModalRadio && ModalRadio.state.value;
            const value=radioValue?radioValue:defaultValue;
            scheduleEventsDelete({id:sid,scope:value,refuse:type}).then(s=>{
                const {code,msg}=s||{};
                if(code == 200 ){
                    message.success(locale('calendar_toast_delete_success'));
                    refrshCalender();
                }else{
                    message.error(code,msg)
                }
                window.store.dispatch(hideSlideModal());
            })
            util.log('calendar', `handleDeleteSchedule`, JSON.stringify({id:sid,scope:value,refuse:type}));
        },
        okText: locale('calendar_button_ok'),
        cancelText: locale('calendar_button_cancel'),
    });
}

// 日程图片查看
const showScheduleImg=(currid,attachments)=> {
    const arr=attachments.map(item=>{
        const {id=item.file,file}=item;
        const newItem={id,url:file};
        if(id===currid) newItem.curr=true;
        return newItem;
    });
    util.electronipc.electronOpenImage({
        success:true,
        data:arr,
    });
}

// 通过id获取用户信息
const getUsersInfo = async userids => {
    let data = await ucenterMultiuserInfoGet({
        user_ids: JSON.stringify(userids)
    })
    // console.log('userInfo',data)
    const {code,obj,msg}=data||{};
    if (code == 200) {
        return obj.map(item=>{
            const {pic,id, name}=item||{};
            return {id, name, avatar:pic}
        })
    }else{
        return []
    }
}
// 会话创建日程
const imCreateCanlendar= async (customObj={})=>{
    const {user=[]}=customObj
    customObj.users=await getUsersInfo(user);
    // 如果日程中创建弹窗是打开的，那么再次打开的时候就先关闭
    window.createDialog && window.store.dispatch(hideScheduleAdd());
    window.store.dispatch(showScheduleAdd({custom:customObj}));
    window.createSheduleFrom = 'im';
}


export {
    updateFn,               //拒绝/接受日程
    timeEl,                 //时间转换
    handleSheduleMsgList,   //消息助手list
    cancelSchedule,         //取消日程
    openScheduleNotification,       //全局提醒
    closeScheduleNotification,      //关闭弹框提示
    refrshCalender,         //刷新日程界面数据
    scheduleSync,
    commmonModalConfirm,    //拒绝选择
    showScheduleImg,
    noticeConfirm,
    deleteConfirm,
    imCreateCanlendar
}
