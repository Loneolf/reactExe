/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-05-09 10:39:21
 * @LastEditors: olei<wangzheng_jzb@100tal.com>
 * @LastEditTime: 2020-05-11 22:04:40
 */
// react
import React from 'react';
import css from './index.scss';

// util
import * as util from '@u/util.js';
import {locale} from '@u/util.js'

// BoxOperationContainer
export default function Index(props) {
    const { text = '', type = 'confirm', cancle = locale('calendar_button_cancel'), close, callback, visible, tipText = util.locale('common_tip'), dropout,maskClose } = props;

    return (
        <div>
            {visible ? (
                <div className={css.out} onMouseDown={(e) => e.stopPropagation()}>
                    <div className={css.mask} onClick={maskClose?maskClose:()=>{}}/>
                    <div className={css.container}>
                        {/* <div className={css.title}>  
                        {tipText}
                    </div> */}
                        {!dropout ? (
                            <div className={css.content}>{text}</div>
                        ) : (
                            <div className={css.cancleContent}>
                               <span className={css.iconRemind+" "+"iconfont-yach yach-xiezuo-xinjianricheng-richengchongtu-tishi"}></span>
                        <span className={css.remind}>{util.locale('common_tip')}</span>
                               <div  className={css.exitText}>{text}</div>
                            </div>
                        )}
                        <div className={css.btn}>
                            {type === 'confirm' ? (
                                <div className={css.confirm}>
                                    <span onClick={close} className={css.cancle}>
                                        {cancle}
                                    </span>
                                    <span onClick={callback} className={css.sure}>
                                        {locale('calendar_button_ok')}
                                    </span>
                                </div>
                            ) : (
                                <div className={css.tip}>
                                    <span onClick={close} className={css.known}>
                                        {locale('calendar_button_notification_know')}
                                    </span>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            ) : null}
        </div>
    );
}
