/*
 * @Descripttion: 周视图
 * @Date: 2020-04-05 14:30:13
 */

// react
import React, { Component } from 'react';
import { connect } from 'react-redux';

// action
import * as calenderAction from '@r/actions/calender';
import { showSlideModal } from '@/redux/actions/commonModal';
import ScheduleEventRender from '../common/scheduleEventRender';

import moment from 'moment';
import _ from 'lodash';

// util
import * as sUtil from '../../lib/until';
import * as util from '@u/util.js';
import * as co from './../../lib/unit-core';

import { Weekly } from './weekly';
import css from './index.scss';

const { scheduleLineHeight } = co;

const { initAllNum2 } = sUtil;

let count = 0;

class WeeklyContainer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            wdata: [],
            dyscnowtime: {
                isshow: true,
                top: 100,
                time: [0, 0],
            },
        };

        this.scrolldiv = React.createRef();
        this.alldayDiv = React.createRef();
    }

    componentDidMount() {
        this.getWeekTime();
        util.eventBus.addListener('getWeekTime', this.getWeekTime);
        util.eventBus.addListener('setWeekLoading', (value) => this.setWeekDataLoading(value));
        sUtil.setScrollDayViewHeight();
    }

    componentWillUnmount() {
        util.eventBus.removeListener('getWeekTime');
        clearTimeout(this.timer);
        this.setState = (state, callback) => {
            return;
        };
    }

    setWeekDataLoading = (data) => {
        this.props.setWeekDataLoading({ week_loading: data });
    };

    // 间隔线
    renderline = () => {
        let i = 0;
        let res = [];
        while (i < 24) {
            res.push(<div style={{ height: scheduleLineHeight }} className={css.lines} key={i} />);
            i++;
        }
        return res;
    };

    // 左侧时间 0:00
    rendertime = () => {
        const t = initAllNum2();
        return t.map((item, index) => (
            <span style={{ height: scheduleLineHeight }} key={item} data-tid={`t-${index + 1}`}>
                {item}
            </span>
        ));
    };

    // 日 一 二 UTC+8时区
    getWeekTime = () => {
        const { year, month, day } = this.props.initDate;
        const weekOfday = moment({ year, month, day }).format('E');
        const wdata = [];
        const td = moment();

        let active = false,
            tyear = td.year(),
            tmonth = td.month(),
            tdate = td.date();

        for (let x = 0; x < 7; x++) {
            let _temOfday;
            if (wdata.length >= 7) break;
            if (weekOfday == 7) {
                _temOfday = moment({ year, month, day }).add(x, 'days').format('YYYYMMDD');
            } else {
                x <= weekOfday
                    ? (_temOfday = moment({ year, month, day })
                          .subtract(weekOfday - x, 'days')
                          .format('YYYYMMDD'))
                    : (_temOfday = moment({ year, month, day })
                          .add(x - weekOfday, 'days')
                          .format('YYYYMMDD'));
            }
            let _tmeStram = moment(_temOfday).unix();

            tdate === moment(_temOfday).date() &&
            tmonth === moment(_temOfday).month() &&
            tyear === moment(_temOfday).year()
                ? (active = true)
                : (active = false);

            wdata.length <= 7 &&
                wdata.push({
                    unix: _tmeStram,
                    active,
                    temOfday: _temOfday,
                });
        }

        this.setState(
            (state) => ({
                wdata,
            }),
            () => {
                let [fd, , , , , , ld] = wdata;
                let cld = ld.unix + 60 * 60 * 24 - 1;
                const param = { start_time: fd.unix, end_time: cld, ...this.props.paramPareFn({ type: 'week' }) };
                this.props.getWeekDataRequest(param);
                this.updateComNowTime();
            }
        );
    };

    checkAllDayCard = (type, item, ievent, config) => {
        count += 1;
        ievent.persist();
        ievent.nativeEvent.stopImmediatePropagation();
        let Sevent = ievent;
        setTimeout(() => {
            if (count === 1) {
                let { selectcard } = this.props;
                selectcard.isshow &&
                    this.props.toggleSelectCard({ isshow: ![], type: '', item: {}, ievent: {}, config: {} });
                this.props.toggleSelectCard({ isshow: !0, type, item, ievent: Sevent, config });
            }
            if (count === 2) {
                let { id, package_info } = item;
                this.onDoubleClickfn(id, package_info.source, Sevent);
            }
            count = 0;
        }, 200);
        ievent.stopPropagation();
    };

    onDoubleClickfn(id, source, event) {
        if (source && (source === 9 || source === 2)) return;
        this.props.showSlideModal('scheduleInfo', { id });
        event.nativeEvent.stopImmediatePropagation();
    }

    DataFactoryCenters = (dayData = [], time = {}) => {
        return co.DataFactoryFn({
            originData: dayData,
            time,
            kind: 'week',
            checkAllDayCard: this.checkAllDayCard,
        });
    };

    allDayEventRender = (list=[], temIndex=0) => {
        // 计算位置
        let renderlist = [];
        if (!list.length) return;
        for (let i = 0; i < list.length; i++) {
            let item = list[i];
            let { id } = item;

            if (renderlist.findIndex((t) => t.key === id) !== -1) {
                break;
            }
            let styles = {
                height: 26,
                width: 'calc(100% / 7)',
                left: `${((temIndex * 1) / 7) * 100}%`,
                position: 'absolute',
                top: `${i * 28}px`,
            };
            renderlist[renderlist.length] = (
                <ScheduleEventRender
                    item={item}
                    type="allday"
                    kind="allday_week"
                    styles={styles}
                    checkAllDayCard={this.checkAllDayCard}
                />
            );
        }
        return renderlist;
    };

    // 原则上是循环当前的7天
    drawGraphy = () => {
        const { wdata } = this.state;
        const { weekDataList = new Map() } = this.props;
        const bigData = [];
        const allDate = [];
        const { nday, nmonth, nyear } = sUtil.getTodayStance();
        const _sunix = moment({ nyear, nmonth, nday }).unix();

        window.isToday = false;

        let len = wdata.length;
        if (weekDataList.size <= 0) {
            return {
                bigData,
                allDate,
            };
        }


        let alldayMaxHeight=0
        for (let i = 0; i < len; i++) {
            const { unix, active, temOfday } = wdata[i];

            let startTime = moment(temOfday).unix();
            let endTime = moment(temOfday).unix() + 24 * 60 * 60 - 1;
            const time={startTime,endTime};
            
            const getOne = weekDataList.has(Number(temOfday)) ? weekDataList.get(Number(temOfday)) : [];
            const [allday = [], commonsche = []] = getOne;
            
            let activeName = active ? css.activeItme : '';
            bigData[bigData.length] = (
                <div
                    className={css.dayColume + ' ' + activeName}
                    onClick={(e) => {
                        this.clickFastCreate(unix, i, e);
                    }}
                    key={i}
                >
                    {active && this.activeLine(active, allday)}
                    {this.DataFactoryCenters(this.actionDayOfData(commonsche,time),time )}
                </div>
            );
            allday.length && (allDate[allDate.length] = this.allDayEventRender(allday, i));
            _sunix === unix && (window.isToday = true);

            // 确定全天最高高度
            const newHeight=allday.length*28;
            if(newHeight>alldayMaxHeight) alldayMaxHeight=newHeight;
        }
        
        return {
            bigData,
            allDate,
            alldayMaxHeight
        };
    };

    // this week contain today
    isToday = () => {
        const { wdata } = this.state;
        return wdata.filter((item) => item.active !== false);
    };

    actionDayOfData = (arrlist,time) => {
        if (!arrlist.length) return [];
        return arrlist.map(item=>co.handleOriginData(item,time));
    };

    // 当天视图网格重新画
    activeLine = (active) => {
        return (
            <div className={css.peddingActive} style={{ background: active ? '#FCFCFC' : '' }}>
                {this.renderline()}
            </div>
        );
    };

    syncTimeLine = () => {
        const { wdata } = this.state;
        const activeItem = this.isToday();
        if (!wdata.length || !activeItem.length) return null;

        const { unix: initUnix } = wdata[0];
        const { unix: activeUnix } = activeItem[0];
        const pencentV = ~~(activeUnix - initUnix) / (24 * 3600);
        const left = `calc(${pencentV / 7} * 100% - 3px)`;

        return (
            <div className={css.nowTime} style={{ top: this.state.dyscnowtime.top }} id="tline">
                <span style={{ left }}></span>
            </div>
        );
    };

    /*
     time computer
   */
    updateComNowTime = () => {
        const { year, month, day } = this.props.initDate;
        let nowTime = Date()
            .replace(/^.*?(\d+:\d+).*?$/, '$1')
            .split(':');
        let startTime = sUtil.timemillions(year, month, day, 0, 0, 0);
        let begin_time = sUtil.timemillions(year, month, day, nowTime[0], nowTime[1], 0);
        let topline = co.changline(startTime, begin_time);
        let g0 = Number(nowTime[0]);
        let g1 = parseInt(+nowTime[1]);

        if ((g1 > 15 && g1 < 45) || !this.isToday().length) {
            this.setState({
                dyscnowtime: {
                    top: topline,
                    time: [nowTime[0], nowTime[1]],
                },
            });
            this.preTimeDom && this.preTimeDom[0] && (this.preTimeDom[0].style.visibility = 'visible');
            this.preTimeDom = null;
        } else {
            // 跨点防止再次获取一个无意义的值
            if (!this.preTimeDom && g0 !== 23) {
                let _t = 0;

                g1 < 15 && g1 > 0 && (_t = g0);
                g1 > 45 && (_t = g0 + 1);

                this.preTimeDom = sUtil.setDomHidden('span', 'data-tid', new RegExp(`t-${_t}`));
                this.preTimeDom && this.preTimeDom[0] && (this.preTimeDom[0].style.visibility = 'hidden');
            }

            this.setState((state) => ({
                dyscnowtime: {
                    top: topline,
                    time: [nowTime[0], nowTime[1]],
                },
            }));
        }

        if (this.isToday().length) {
            clearTimeout(this.timer);
            this.timer = setTimeout(this.updateComNowTime, 30000);
        } else {
            clearTimeout(this.timer);
        }
    };

    // 单击快捷创建
    clickFastCreate = (unix, i, event) => {
        event.persist();
        event.nativeEvent.stopImmediatePropagation();

        const scroll_t = this.scrolldiv.current.scrollTop;
        const allday_h = this.alldayDiv.current ? this.alldayDiv.current.clientHeight : 0;

        const startT = co.clickPositionComputer({ clientY: event.clientY, scroll_t, allday_h, type: 'week' });

        const ms = startT / scheduleLineHeight;

        if (ms >= 24 || ms <= 0) return;

        const tweek = moment.unix(unix);
        const year = tweek.year();
        const month = tweek.month();
        const day = tweek.date();
        const initTimeS = `${year}-${sUtil.fm(month + 1)}-${day} `;

        // 星期有7天
        const stand = (1 / 7) * 100;
        this.props.setFastCreatSchedule({
            show:true,
            data:{
                type: 'week',hourNum:ms,date:initTimeS,anchorLeft:i * stand + '%'
            }
        })
    };

    render() {
        return (
            <>
                <Weekly
                    weekregion={this.state.wdata}
                    drawGraphy={this.drawGraphy}
                    renderline={this.renderline}
                    rendertime={this.rendertime}
                    clickFastCreate={this.clickFastCreate}
                    dyscnowtime={this.state.dyscnowtime}
                    week_loading={this.props.week_loading}
                    syncTimeLine={this.syncTimeLine}
                    selectcard={this.props.selectcard}
                    scrolldiv={this.scrolldiv}
                    alldayDiv={this.alldayDiv}
                    locale={this.locale}
                    isToday={this.isToday}
                ></Weekly>
            </>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        initDate: state.calender.initDate,
        selectcard: state.calender.selectcard,
        weekDataList: state.calender.weekDataList,
        week_loading: state.calender.week_loading,
    };
};

const mapDispatchToProps = {
    getWeekDataRequest: calenderAction.getWeekDataRequest,
    toggleSelectCard: calenderAction.toggleSelectCard,
    setFastCreatSchedule: calenderAction.setFastCreatSchedule,
    setWeekDataLoading: calenderAction.getWeekDataLoading,
    showSlideModal: showSlideModal,
};

export default connect(mapStateToProps, mapDispatchToProps)(WeeklyContainer);
