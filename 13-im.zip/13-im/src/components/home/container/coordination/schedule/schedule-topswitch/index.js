import React from 'react';
import c from "./index.scss";
import _ from 'lodash';
export default  (props) =>{
    const handleChangeRight=()=>{
       props.changeCalender(1)
    }
    const handleChangeLeft=()=>{
        props.changeCalender(-1) 
    }

    const handleClick = (type)=>{
        if(type === 'day')   return props.DadMhandleChange("day");
        if(type === 'week')  return props.DadMhandleChange("week");
        return props.DadMhandleChange("month")
    }
   
    const { type,gototoday,monthAndDayList ,initDate,shownun,locale,getFormatTime,choiseTime}=props
        return (
            <div className={c.headerswitch} style = {{display: type !=='date' ? 'none' : ''}}>
               <div className={ props.gotoToday? c.istoday+' '+c.today:c.today} onClick={_.debounce(gototoday)}>{locale('calendar_button_top_backtoday')}</div>
               <div className={c.tabswitch}>
                   <div className={c.tab} onClick={_.debounce(handleChangeLeft,200)}>
                       <div>
                            <span className={c.arrowleft+" "+"iconfont-yach yach-0421-goutongmokuai-rilishitu-riqixuanzeqi-yuanquanneijiantou-zuo"}></span>
                       </div>
                   </div>
                   <div className={c.currentdate}>
                        <h1 className={c.dateday}>{getFormatTime(choiseTime,!!monthAndDayList.day) + (locale.getLang()==='zh-CN'&&!!monthAndDayList.day ? choiseTime.format('ddd'):"")}</h1>
                        {locale.getLang()==='zh-CN'&&!!monthAndDayList.day ? <p className={c.datebig}><span>农历 {shownun} </span></p> :null}
                   </div>
                <div className={c.tab} onClick={_.debounce(handleChangeRight,200)}>
                       <div>
                            <span className={c.arrowright+" "+"iconfont-yach yach-0421-goutongmokuai-rilishitu-riqixuanzeqi-yuanquanneijiantou-you"}></span>
                       </div>
                   </div>
               </div>
               <div className={c.scheduleChoose} style = {{display: type !=='date' ? 'none' : '',fontSize:locale.getLang()==='zh-CN'? 13:11}}>
                    <div className={monthAndDayList.day? c.showcolor+' '+c.scheduleday:c.scheduleday} onClick={()=>{handleClick('day')}}>{locale("calendar_top_select_day")}</div>
                    <div className={monthAndDayList.day||monthAndDayList.month?c.scheduleweek:c.showcolor+' '+c.scheduleweek}  onClick={()=>{handleClick('week')}}>{locale("calendar_top_select_week")}</div>
                    <div className={monthAndDayList.month? c.showcolor+' '+c.schedulemonth:c.schedulemonth} onClick={()=>{handleClick('month')}}>{locale( "calendar_top_select_month")}</div>
               </div>
            </div>
           
        );
     
} 
