import React from 'react';
import { connect } from 'react-redux';
import {message} from 'antd';
import FastCreateAnchor from './fastcreate-anchor';
import { scheduleEventsCreate } from '@s/schedule/schedule';
import { createSchdule, setFastCreatSchedule,showScheduleAdd } from '@r/actions/calender';
import {refrshCalender} from '../common/common';

/**
 *
 * fastCreateSchedule:{
 *     show:true,
 *     data:{
 *         type:day/week/month,
 *         date:2020-01-01,
 *         anchorLeft:20px,
 *         anchorTop:20px,
 *         hourNum:12,
 *     },
 *     closeBack:()=>{}
 * }
 */

 // todo:留一个入口，其他内容放进包内，公共的引用也放在这里

const Index = (props) => {
    const {
        fastCreateSchedule: { show, data, closeBack },
    } = props;
    const anchorProps = {
        fastCreateData: data,
        onClose:()=>{
            props.setFastCreatSchedule({show:false});
            closeBack && closeBack();
        },
        onOpenScheduleAdd: async (params)=>{
            await props.createSchdule({from:'fast',time:[],...params });
            props.showScheduleAdd({id:''});
        },
        onSubmit: async (params)=>{
            const s=await scheduleEventsCreate(params);
            const {code, msg} = s || {};
            if (code === 200) {
                refrshCalender('all');
                props.setFastCreatSchedule({show:false});
                closeBack && closeBack();
            } else {
                message.error(msg);
            }
        },
    };
    return show ? <FastCreateAnchor {...anchorProps} /> : null;
};

const mapStateToProps = (state) => {
    return {
        fastCreateSchedule: state.calender.fastCreateSchedule,
    };
};

const mapDispatchToProps = {
    setFastCreatSchedule,
    createSchdule,
    showScheduleAdd
};

export default connect(mapStateToProps,mapDispatchToProps)(Index);
