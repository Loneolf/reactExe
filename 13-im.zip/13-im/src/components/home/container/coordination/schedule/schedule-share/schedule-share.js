/*
 * @Descripttion: 共享日程的ui组件
 */
import React from 'react';
import css from './index.scss';
import {Icon, Select} from 'antd';




export const ShareMySchedule = props => {
    const {dataList,closeShareModel,showSelectPeople,toggleCommonModal,openCard,tabkey,setTabkey,setSubscriptionPermission,subscriptionPermission,doPermission,locale} = props
    
   

    return (
        <div className={css.shareWrapper}>
            <div className={css.flexdBg}></div>
            <div className={css.shareContent}>
                <img src={require('@a/imgs/schedule/sub-up.png')} className={css.hiddenUp}/>
                <img src={require('@a/imgs/schedule/sub-down.png')} className={css.hiddenDown}/>
                <div onClick={closeShareModel} className={css.subClose}>
                    <span className={css.closeBtn +' icon iconfont iconiconcha'}></span>
                    {/*<img src={require('@a/imgs/schedule/share-cancle.png')} className={css.closeBtn} />*/}
                </div>
                <div className={css.header}>{locale('calendar_useradd_share_title')}</div>
                <div className={css.tab}>
                    <div className={tabkey===0?css.active:null} onClick={()=>setTabkey(0)}>
                        <p>{locale('calendar_share_tab1')}</p>
                    </div>
                    <div className={tabkey===1?css.active:null} onClick={()=>setTabkey(1)}>
                        <p>{locale('calendar_share_tab2')}</p>
                    </div>
                </div>
                <div className={css.wcontent}> 
                    {
                        tabkey===0?<div className={css.addsharer} onClick={showSelectPeople}> 
                                <div>
                                    <img src={require('@a/imgs/schedule/share.png')} className={css.shareImg}/>
                                    <span className={css.adduser}>{locale('calendar_share_button_subscription')}</span> 
                                </div>
                                <div className={css.shareArrow} onClick={showSelectPeople}>
                                    <img src={require('@a/imgs/schedule/share-arrow.png')} className={css.shareArrowImg} />
                                </div>
                            </div>:  <div className={css.setPerssion}>
                                <div className={css.subuser}>
                                    <img src={require('@a/imgs/schedule/subscribe-user.png')} className={css.subImg}/>
                                    <span className={css.subText}>{locale('calendar_share_subscription_auth')}</span>
                                </div>
                                <Select value={subscriptionPermission} dropdownMatchSelectWidth={false} suffixIcon={<Icon type="caret-down" />}  onChange={setSubscriptionPermission} className={`${css.listDownList} ${locale.getLang()==='zh-CN'?css.cn:css.en}`}>
                                    <Select.Option value="1" className={css.busy} >{locale('calendar_share_subscription_auth_option1')}</Select.Option>
                                    <Select.Option value="2" className={css.busy}>{locale('calendar_share_subscription_auth_option2')}</Select.Option>
                                </Select>
                            </div>
                    }
                    <div className={css.content}>
                        {
                           !dataList.length && <div className={css.noman}>
                                <img src={tabkey===0?require('@a/imgs/schedule/share-no.png'):require('@a/imgs/schedule/subscribe-no.png')} alt={locale('calendar_share_share_empty')} />
                                <p>{tabkey===0?locale('calendar_share_share_empty'):locale('calendar_share_subscription_empty')}</p>
                            </div>
                        }
                        
                        <div className={css.listItemWrap}>
                           {
                               dataList.map(item=>{
                                   let per =  Number(item.permission);
                                    return(
                                        <div className={css.list} key={item.uid}>
                                            <img src={item.avatar}  onClick={()=>{openCard(item.uid)}} />
                                            <div className={css.info}>
                                                <div className={css.leftInof}>
                                                 <p className={css.name} onClick={()=>{openCard(item.uid)}}>{item.name}</p>
                                                    {
                                                        tabkey===0?<p className={css.pos} style={locale.getLang()==='zh-CN'?{width:185}:{width:135}} onClick={()=>{openCard(item.uid)}}>
                                                        { item.dept && item.dept.length > 17
                                                           ? item.dept.slice(0, 8) + '...' + item.dept.slice(-8)
                                                           : item.dept}
                                                     </p>:<p className={css.pos1} onClick={()=>{openCard(item.uid)}}>
                                                       {  item.dept}
                                                    </p>
                                                    }
                                                </div>
                                                {
                                                    // 解bug 既订阅了你  又分享给你  !isNaN(per) 
                                                    tabkey === 0 && !isNaN(per) &&<Select suffixIcon={<Icon type="caret-down" />}  
                                                                        onChange={(v)=>{doPermission(v,item.uid)}} 
                                                                        defaultValue={per} 
                                                                        dropdownMatchSelectWidth={false} 
                                                                        className={`${css.listDownList} ${locale.getLang()==='zh-CN'?css.cn:css.en}`}
                                                                        >
                                                        <Select.Option value={1} >{locale('calendar_share_subscription_auth_option1')}</Select.Option>
                                                        <Select.Option value={2}>{locale('calendar_share_subscription_auth_option2')}</Select.Option>
                                                    </Select>


                                                }
                                            </div>  
                                            {
                                                tabkey===0?<span className={css.closeBtnItem}  onClick={()=>{
                                                    toggleCommonModal(item.uid);
                                                }} >{locale('calendar_button_delete')}</span>:null
                                            }
                                        </div> 
                                    )
                               })
                           }
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
