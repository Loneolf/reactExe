/*
 * @Descripttion: 
 * @Author: olei<wangzheng_jzb@100tal.com>
 * @Date: 2020-05-18 18:15:28
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-05-22 03:22:29
 */
import React from 'react';
import {configState,setCalenderColor} from '../../lib/until';
import c from './index.scss';


export default props => {
    const {
        daylist,
        origindata,
        showMoreList,
        datatime,
        clickEventList,
        activeIndex,
        outtiveDate,
        locale
    } = props;

    return(
        <React.Fragment>  
           <div className={c.content}>
             {
                daylist.map((item,index)=>{
                    if(!item) return null;
                    let {package_info={},title='',current_user_info={}} = item;
                    let colorName = null;
                    let statusCancelName = '';
                    const source=package_info.source;
                    const permission = package_info.permission; 


                    if( typeof item !== 'string' ){
                          if(source===2){
                              title = permission === 1 ? (current_user_info.name +' | ' + locale('calendar_day_layout_busy')) : (current_user_info.name +' | '+title);
                          }

                          if(source===2||source===10) colorName = package_info.color;
                          
                          statusCancelName = source!==2 && configState(item).type === 2 ? c.canceltext : '';
                    }

                   return(
                           typeof item !== 'string' ? 
                            <p 
                              className={[c.mlinetitle,c.hovetitle,statusCancelName, datatime === outtiveDate && activeIndex===index ? c.mactive:''].join(' ')}
                              onClick={ (event)=>clickEventList(event,index,datatime,item) }
                              key={item.id}>
                            <em 
                               className={[c.colorBar, setCalenderColor(configState(item).type)].join(' ')}
                               style={{ background: colorName }}
                            ></em>    
                             { (source===1||source===2) && configState(item).text }
                              { title }
                             
                           </p> : <p key={index} className={c.mlinetitle+" "+c.showMonthCard}  onClick={(event)=>{showMoreList(event,origindata,datatime)}}>{item}</p>
                       )
                })
           }
           </div>
        </React.Fragment>
    )
};


