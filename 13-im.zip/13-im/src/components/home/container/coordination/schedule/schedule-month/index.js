/*
 * @Descripttion:
 */

import React, { Component } from 'react';
import moment from 'moment';
import { message } from 'antd';
import { connect } from 'react-redux';
import { initViewDate, setMonthlist, setFastCreatSchedule,setMonthDialog} from '@r/actions/calender';
import { sheduleEventList } from '@/services/schedule/schedule';
import * as util from '@u/util.js';
import * as sUtil from '../../lib/until';
import { UiDateList } from './month-item';
import { toggleSelectCard } from '@r/actions/calender';

import _ from 'lodash';

export class Monthcalender extends Component {

    state = {
        loading: true,
        maskshow: false,
        fastcreatePos: { left: 0, top: 0 },
        fastTimemonth: [0, 0],
        activeHeight:0,
        activeIndex:-1,
        outtiveDate:'',
    };

    componentDidMount() {
        this.props.onRef(this);
        let selectNowDate = this.props.initDate;
        const { year, month } = selectNowDate;
        let initd = new Date(year, month, 1);
        this.setCurrentYearMonth(initd);

        this.asyncMonthlist();

        setTimeout(()=>{  this.observerDomResize() },100);

        util.eventBus.addListener('click:month:card', ()=>{
            this.setState({activeIndex:-1});
        });
        util.sensorsData.track('PageView_MainPage', { pageName: 104, ViewType: 103 });
        // document.addEventListener("click", function(){
        //     this.props.dispatch(setMonthDialog({ show: false, datatime:"", list: []}));
        // });
    }

    componentWillUnmount() {
        let activediv = document.querySelector('#active');
        activediv && this.activedivObjserver.unobserve(activediv);
        this.props.dispatch(setFastCreatSchedule({show:false}));
        this.props.dispatch(setMonthDialog({ show: false, datatime:"", list: []}));
        this.props.dispatch(setMonthlist({}));
        this.setState = (state, callback) => {
            return;
        };
    }

    asyncMonthlist = async () => {
        console.time('-ca-month-asyncMonthlist--');
        this.setState((state) => ({ loading: true }));
        let { year, month, day } = this.props.initDate;
        const { nuncheckbox, cancelschedule, refuseschedule ,selfschedule} = this.props.mountcalender;
        const { shareScheduleList } = this.props;

        // 获取开始结束的时间戳 当月的
        let end_time = sUtil.timemillions(year, month, sUtil.days_per_month(year)[month] + 7, 23, 59, 59);
        let start_time = sUtil.timemillions(year, month, 1 - 7);

        let trad = !!nuncheckbox ? { has_holiday: 1 } : {};
        let has_cancel = !!cancelschedule ? { has_cancel: 0 } : { has_cancel: 1 };
        let has_refuse = !!refuseschedule ? { has_refuse: 0 } : { has_refuse: 1 };
        let has_self=!!selfschedule?{has_self:1}:{has_self:0};

        let sharList = shareScheduleList.filter((item) => item.selected);
        let uids = sharList.map((item) => item.uid).join();
        let timezone = sUtil.gZone(); // 午夜12：00 差一秒

        let list = await sheduleEventList({
            start_time,
            end_time,
            timezone,
            ...trad,
            ...has_cancel,
            ...has_refuse,
            ...has_self,
            uids,
        }); //   111001
        let { code, msg, obj = {} } = list || {};
        if (code === 200) {
            // 数据为空就不需要缓存了
            this.setState((state) => ({loading: false }));
            this.props.dispatch(setMonthlist(obj));
            util.log('calender', `month:asyncMonthlist:success`, true);
        } else {
            message.error(msg);
            util.log('calender', `month:asyncMonthlist:error`, msg);
        }
        console.timeEnd('-ca-month-asyncMonthlist--');
    };

    setCurrentYearMonth(date) {
        var month = date.getMonth();
        var year = date.getFullYear();
        this.props.dispatch(initViewDate({ year, month }));
    }

    changeMonth = async (v) => {
        const { month, year } = this.props.initDate;
        var monthAfter = +month + v;
        var newD = new Date(year, monthAfter, 1);
        await this.props.dispatch(
            initViewDate({ year: newD.getFullYear(), month: newD.getMonth(), day: newD.getDate() })
        );
        return false;
    };


    // mask 点击清楚事件机制
    handleMask = () => {
        this.setState({ maskshow: false });
        let fastdiv = document.getElementById('fastdiv');
        fastdiv && fastdiv.parentNode.removeChild(fastdiv);
        this.props.dispatch(setMonthDialog({ show: false, datatime:"", list: []}));
        this.setState({activeIndex:-1})
    };
    // 改变fast创建的位置
    changfastModule = (opt) => {
        this.setState({
            fastcreatePos: { ...opt },
        });
    };

    changtimeModule = (optime) => {
        this.setState({
            fastTimemonth: [...optime],
        });
    };

    observerDomResize = ()=>{
        const activediv = document.querySelector('[data_id="active"]');
        this.activedivObjserver = new ResizeObserver(_.throttle(entries => {
            entries.forEach(entry => {
               this.setState({
                  activeHeight:entry.contentRect.height
               })
            })
        }), 500);
        activediv && this.activedivObjserver.observe(activediv);
    }

    showMoreList =(e,data,datatime)=>{
        e.nativeEvent.stopImmediatePropagation();
        console.log("ok");
        let mbox  = e.target.parentNode.parentNode;
        let posMox = mbox.getBoundingClientRect();

        if(!Array.isArray(data)) return;
        this.props.dispatch(setMonthDialog({
            show: true,
            datatime,
            posMox,
            list: [...data]
        }));
        this.setState({ activeIndex:-1,maskshow: true, outtiveDate:' '});
    }

    clsoeactiveIndex = ()=>{
        this.setState({ activeIndex:-1, outtiveDate:' '});
    }

    clickEventList = (event,ind,datetime,item)=>{
        event.persist();
        event.nativeEvent.stopImmediatePropagation();
        datetime && this.setState({ outtiveDate:datetime });
        this.setState({activeIndex:ind});
        this.props.dispatch(  toggleSelectCard( { isshow: true, type:'month', item, ievent:event, config:sUtil.configState(item) }) );
    }

    fastCreateSchedule = (event) => {
        if( this.props.selectcard.isshow &&
            event.target.nodeType === 1 &&
            event.target.nodeName !== 'P'){
            this.clsoeactiveIndex();
            return;
        }

        if (event.target.getAttribute('data_id') === 'active'){
            // fastdiv.style.cssText = '';
            let dataTime = event.target.getAttribute('data-time') || moment().format('YYYY-MM-DD');
            const anchorLeft=event.target.offsetLeft;
            const anchorTop=event.target.offsetTop;
            
            // 给div.conent加个margin 防止被anchor盖住
            const div=event.target.querySelector('div');
            div && (div.id = 'anchorEffectDiv');

            this.props.dispatch(setFastCreatSchedule({
                show:true,
                data:{
                    type:'month',date:dataTime,anchorLeft,anchorTop,
                },
                closeBack:this.anchorEffectDiv
            }));
            event.nativeEvent.stopImmediatePropagation();
        }
    };

    anchorEffectDiv=()=>{
        const div=document.getElementById('anchorEffectDiv');
        div && (div.id = '');
    }

    render() {
        let { year, month } = this.props.initDate;

        const nowTimeInstance = moment([year, month + 1, 1].join('-'));
        const nowTimeObject = nowTimeInstance.toObject();
        const dayOfWeek = nowTimeInstance.day();
        const mday = sUtil.days_per_month(year);
        const dateLine = Math.ceil((dayOfWeek + mday[month]) / 7);

        let initAllVarib = {
            ...this.props,
            dayOfWeek,
            y                   : year,
            m                   : month,
            d                   : nowTimeObject.date,
            n                   : dateLine,
            monthlist           : this.props.monthlist,
            changfastModule     : this.changfastModule,
            changtimeModule     : this.changtimeModule,
            fastcreatePos       : this.state.fastcreatePos,
            fastTimemonth       : this.state.fastTimemonth,
            loading             : this.state.loading,
            maskshow            : this.state.maskshow,
            handleMask          : this.handleMask,
            fastCreateSchedule  : this.fastCreateSchedule,
            activeHeight        : this.state.activeHeight,
            showMoreList        : this.showMoreList,
            monthDialog         : this.props.monthDialog,
            clickEventList      : this.clickEventList,
            activeIndex         : this.state.activeIndex,
            outtiveDate         : this.state.outtiveDate,
            locale              : this.locale,
            lang                : this.locale.getLang()==='zh-CN'
        };


        return (  
            <>
               <UiDateList {...initAllVarib}/>
            </>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        initDate                : state.calender.initDate,
        monthlist               : state.calender.monthlist,
        mountcalender           : state.calender.mountcalender,
        shareScheduleList       : state.calender.shareScheduleList,
        monthDialog             : state.calender.monthDialog,
        selectcard              : state.calender.selectcard
    };
};

export default connect(mapStateToProps, null)(Monthcalender);
