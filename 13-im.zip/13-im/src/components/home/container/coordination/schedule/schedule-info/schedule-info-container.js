// react
import React, {Fragment} from 'react';
import {connect} from 'react-redux';
import {Input, message, Modal,Radio} from 'antd';
import {withRouter} from 'react-router';
// action/service
import {scheduleEventsInfo, scheduleUsersBind_group, scheduleUsersInvite,getScheduleInfoPeople,scheduleRemindStatus,scheduleRemind} from "@/services/schedule/schedule";
import {groupUsersAdd} from '@s/group/group-info.js';
import {showScheduleAdd} from "@/redux/actions/calender";


// component
import ScheduleInfo from './schedule-info';
import CommonSpain from '@/components/common/common-spin';
import UserAdd from '@c/common/user-add/user-add-container';

import {
    cancelSchedule,
    closeScheduleNotification,
    handleSheduleMsgList,
    refrshCalender,
    commmonModalConfirm,
    deleteConfirm
} from '@c/home/container/coordination/schedule/common/common'
//css
import css from "./index.scss";
// util
import * as util from '@u/util.js';
import {meetingCreateJoinFun} from '@u/lib/zoom/zoomFn';
import VideoSessione from '@c/common/video-session/video-session-container';
import { hideSlideModal,videoSessionlHide, videoSessionShow } from '@/redux/actions/commonModal';
// debounce
import debounce from 'lodash/debounce';
import { remindWin } from '@r/actions/remind';

class ScheduleInfoContainer extends React.Component {
    state = {
        inFo:{},
        peopleStage:-1,   // 已接受、已解决、待响应等  //  0：未响应，1：接受，2：拒绝  99全部
        openMore:false,   // 展开更多人
        userAddShow:false,
        loading:false,
        infoLoading:true,
        commonLoading:false,
        commonLoadingText:'',
        // usersId: [],
        usersMessage: [],  // 详情人数 切换面板人数容器
        usersMessageMap:   new Map(),
        infoUser:{},       // 请求的参数返回值
        page:0,
        nodata: true,     // 无限加载一直有数据
        loadingText: true,
        uid:[],
        liveUsers:[],       // 直播人员
        showVideo: false,
        isReportData: false, //数据埋点判断，页面展示一次，埋点一次
        isShowRemind: '0', // 是否显示催一下,（0:关 1:开)
        organizers: []
    };

    componentDidMount() {
        const {id,source}=this.props.slideModal;
        this.getDetail(id,source);
        // 数据埋点
        util.sensorsData.track('PageView_Schedule_SecondPage', {
            pageName: 116,
            source: util.yachLocalStorage.ls('PageView_Schedule_SecondPage') || 999
        });

        this.meetingSummaryClick = debounce(this.meetingSummaryClick, 500);

        // 获取云信数据
        const platformConfig = util.yachLocalStorage.ls('platformConfig') || {};
        this.setState({
          isShowRemind: platformConfig['100000016']
        })
    }

     // 显示音频视频控制弹窗 @cai qiuxai
     showVideoSessioneModal = () => {
        const parameter = {
          show: true,
          nickName: '',
          title: this.state.inFo.title
        };

        this.props.dispatch(videoSessionShow(parameter));
        this.setState({
          showVideo: true,
        });

        // 日程详情页-加入会议按钮点击 埋点
        util.electronipc.electronZoomCallFn('getMeetingID', null, async res => {
            console.log(!res,"resresresresresresres")
            if (res == 7) return util.yach.platformConfigGetFun();
            if(!res) {
                util.sensorsData.track('Click_Schedule_Element', {
                    pageName: '116',
                    $element_name: '01-135'
                });
            }
        });

    };

    // @cai qiuxai
   onlineOffice = (title,isVideoOff,isAudioOff) => {
      const {inFo,infoUser} = this.state
      const params = {
        daily_meeting:inFo.tags[0]&&inFo.tags[0].text,
        id:inFo.meeting.id,
        type:3,
        ismore:infoUser.resp_all_num,
        title,
        isVideoOff,
        isAudioOff
      }
      console.log(params,"changyi加入音视频弹框");
      this.handleJoinMeeting(params)
    }

    // 弹出加人组件
    handleShowUserAdd = () => {
        this.setState({
            userAddShow: true,
        });
        util.sensorsData.track('Click_Schedule_Element',{pageName: 116, $element_name: 152});
    }

    // 关闭加人弹框
    closeUserAdd = () => {
        this.setState({
            userAddShow: false,
        });
    };

    // 加人确认回调
    okUserAdd = async (value) => {
        const {inFo} = this.state
        
        if(!inFo.repeat_value){
            this.handleAddUser(value,3);
            return
        }  

        this.setState({
            userAddShow: false,
        })
        // 重复日程范围选择
        const that=this;
        let ModalRadio;
        Modal.confirm({
            className: css.ScheduleConfirm,
            getContainer: () => document.getElementById('slideModal'),
            centered: true,
            title: <div className={css.modalTitle}>{this.locale('calendar_confirm_repeat')}</div>,
            content: <div className={css.modalContent}>
                    <Radio.Group className={css.radioOut} ref={el => ModalRadio = el} defaultValue={3}>
                        <Radio className={css.radio} value={1}>{this.locale('calendar_confirm_readio_option1')}</Radio>
                        <Radio className={css.radio} value={2}>{this.locale('calendar_confirm_readio_option2')}</Radio>
                        <Radio className={css.radio} value={3}>{this.locale('calendar_notification_dropdown_all')}</Radio>
                    </Radio.Group>
            </div>,
            zIndex: 1011,
            onCancel() {
            },
            onOk() {
                const scope = ModalRadio && ModalRadio.state.value;
                that.handleAddUser(value,scope);
            },
            okText: this.locale('calendar_button_ok'),
            cancelText: this.locale('calendar_button_cancel'),
        });
    }

    // 加人逻辑
    handleAddUser= async (value,scope)=>{
        this.setState({
            loading: true
        })
        const {allDataUsers} = value;
        const {inFo={}}=this.state;
        let uid=this.state.uid||[];
        uid=uid.map(item=>item+'');

        const {id,sid}=inFo;
        const newAdd=allDataUsers.map(item=>item.id+'').filter(item=>!uid.includes(item));

        // 主要是处理如果选择一个
        if(!newAdd.length){
            message.success(this.locale('calendar_toast_add_success'));
            this.setState({
                userAddShow: false,
                loading: false
            })
            // 数据库主从插入快速读写  有问题 前端延时200
            setTimeout(()=>{this.changePeopleStage(-1)},200);
            return;
        };

        const s=await scheduleUsersInvite({id:sid,uids:newAdd.join(),scope});
        if(s.code==200){
            message.success(this.locale('calendar_toast_add_success'));
            // 请求新详情数据
            refrshCalender();
            this.getDetail(s.obj.sid);
            this.setState({
                userAddShow: false,
                loading: false
            })
            // 数据库主从插入快速读写  有问题 前端延时200
            setTimeout(()=>{this.changePeopleStage(-1)},200);
            util.log('calendar', `okUserAdd:schedule add user success`, JSON.stringify({id:sid}));
        }else{
            message.warning(s.msg);
            this.props.dispatch(hideSlideModal());
            handleSheduleMsgList();
            this.setState({
                userAddShow: false,
                loading: false
            })
        }
    }

    /*
       获取总人数和各类人的数目
       resp_state: 0：未响应，1：接受，2：拒绝  99全部
       step: 每一页显示的数据
       page: 页码
    */
   getJoinSchedulePeople = async({step=70,page=1})=>{
      try{
         let resp_state = this.state.peopleStage === -1 ? 99 :this.state.peopleStage;
         let {inFo}=this.state;

         // 获取组织者兼容没有创建者信息
         let creators = [];
         creators.push(inFo.creator)
         const res = await util.nimUtil.getUsers(creators);
         this.setState({organizers:[...res]})

         const getPeople = await getScheduleInfoPeople({id:inFo.sid,resp_state,step,page});
         const {code,msg,obj={}} = getPeople;
         if(code !== 200){
             message.warn(msg);
             return;
         }
         this.interfaceActions(obj);
      }
      catch(e){ console.log('getJoinSchedulePeople>>>',e)}
   }


    /**
    *  处理info 人数处理  infoUser  一页请求150 小于请求的总数或者没有数据  就关闭无限加载
    */
   interfaceActions = (obj)=>{
      const {list} = obj;

      if(list.length<70){
         this.setState(state=>({nodata:false}));
      }

      if(!list.length){
         this.setState(state=>({loadingText:false}));
         return;
      };

      const uids = list.map(item=>item.uid);
      this.getUserImage(uids);
      this.setState(state=>({  infoUser:obj }));
      	if(!this.state.isReportData && (!!obj && obj.resp_all_num > 1)){
			//显示会议纪要按钮时，数据埋点
			this.setState({
				isReportData: true
			},()=>{
				util.sensorsData.track('Expo_ScheduleDetail_Element', {
					$element_name: '02-101'
				})
			})
    	}
    }


    /**
    *   获取云信端头像
    */
    getUserImage = async (params) => {
        if(!Array.isArray(params) || !params.length) return;
        try{
            const res = await util.nimUtil.getUsers(params);
            const resImg = res.map(item=> ({id:item.account,nick:item.nick,avatar:item.avatar}));

            const arr= await util.yach.base64ImgArrGetTmp(resImg,'avatar');

            this.setState(pre=>({
                usersMessage:[...pre.usersMessage,...arr],
                loadingText:false
            }))
        }
        catch(e){ console.log('getUserImage>>>',e)}
    }

    /**
    *   无限
    */
    intiateScrollObserver = () => {
        const checkIsIn=document.querySelector("#checkIsIn");
        if(!checkIsIn) return;
        const options = {
          root: document.querySelector('#peopleout'),
          rootMargin: '0px',
          threshold: [0.6]
        };
        this.observer = new IntersectionObserver(this.callback, options);
        this.observer.observe(checkIsIn);
    }

    /**
    *    无限的回调
    */
    callback = (entries) => {
        entries.forEach((entry, index) => {
          if(!this.state.nodata) return;
          if (entry.isIntersecting) {
              this.setState(state=>({
                 page: state.page+1,
              }),()=>{
                 this.getJoinSchedulePeople({page:this.state.page})
              });
          }
        });
   }

    /*
        切换状态 同时初始化一下分页的状态值
    */
   changePeopleStage=(value)=>{
       this.setState(state=>({
            peopleStage:value,
            page:0,
            nodata:true,
            usersMessage:[],
            openMore:false,
            loadingText:true
        }),()=>{
            this.intiateScrollObserver()
        });
        // 已接受
        if(value == 1){
            this.uploadSensorsClickData(149);
        // 未响应
        } else if(value == 0){
            this.uploadSensorsClickData(150);
        // 已拒绝
        } else if(value == 2){
            this.uploadSensorsClickData(151);
        }
    }


    // 获取信息
    getDetail= async (id,source)=>{
        const s=await scheduleEventsInfo({id,source});

        const {code, obj} = s || {};
        if (code === 200) {
            const liveUsers= await this.getLiveUsersInfo(obj);
            this.setState({
                inFo:obj,
                uid: obj.extra_info.uids,
                liveUsers,
            });
            if(obj && obj.attachment && obj.attachment.length>0){
                this.uploadSensorsDetailData(144);
            }
            setTimeout(()=>{  this.intiateScrollObserver() },500);
        }else{
            if(window.location.pathname == '/im'){
                handleSheduleMsgList();
            } else if (window.location.pathname == '/schedule') {
                refrshCalender()
            }
            this.props.dispatch(hideSlideModal());
            closeScheduleNotification({id});
            message.warning(s.msg);
        }
        this.setState({
            infoLoading:false,
        })
    }

    // 直播人员信息获取 userids=>userInfos
    getLiveUsersInfo= async(obj)=>{
        const {speaker,creator}=obj;
        if(!speaker||!creator) return [];
        let params=[];
        if(speaker==creator){
            params=[speaker];
        }else{
            params=[speaker,creator]
        }
        try{
            const res = await util.nimUtil.getUsers(params)||[];
            const resImg = res.map(item=> {
                const id=item.account;
                let tag=id==speaker?this.locale('calendar_create_info_live_users_speaker'):this.locale('calendar_create_info_live_users_creator');
                return {id,nick:item.nick,avatar:item.avatar,tag}
            });
            const arr= await util.yach.base64ImgArrGetTmp(resImg,'avatar');
            return arr
        }catch(e){
            return []
        }
    }

    // 展开更多
    toggleOpenMore=()=>{
        this.setState(pre=>({
            openMore:!pre.openMore,
        }),()=>{
            if(this.state.openMore){
                this.intiateScrollObserver();
            }
        })
    }

    // 前端调用云信加群
    frontAddGroup=(back_group_id,id)=>{
        util.log('calendar', `handleAddGroup:${back_group_id?'join':'create'} team`,JSON.stringify({id,back_group_id}));
        const userid=window.store.getState().userInfo.id;
        groupUsersAdd({
            tid:back_group_id,
            users: JSON.stringify([userid]),
            source: JSON.stringify({
                type:5,
                user_id:userid,
                id:id,
            })
            }).then((data)=>{
                if (data.code == 200) {
                    this.props.dispatch(hideSlideModal());
                    this.props.history.replace('/im');
                    //util.nim.activeRow('team', `${back_group_id}`);
                    util.yach.itemActiveRow(`${back_group_id}`,'team');
                } else {
                    message.error(data.msg);
                }
            }).catch(e=>{
                util.log('calendar', 'handleAddGroup:groupUsersAdd error',e.toString().slice(0,100));
            });
    }
    // 一键拉群
    handleAddGroup=(group_id,params,isCreater)=>{
        // 不存在群
        const {inFo={}}=this.state;
        const {id}=inFo;

        // 超过2000人判断
        if(params>2000) {
            message.warn(this.locale('calendar_toast_info_creategroup_over2000'));
            return
        }

        if(!group_id){
            const that=this;
            Modal.confirm({
                getContainer: () => document.getElementById('slideModal'),
                className: css.gropAdd,
                centered: true,
                // title: null,
                // icon:null,
                // width:245,
                content: <div className={css.modalContent}>{this.locale('calendar_confirm_creatgroup')}</div>,
                zIndex: 1011,
                onCancel() {},
                onOk() {
                    that.setState({
                        commonLoading:true,
                    })

                    scheduleUsersBind_group({id}).then(s=>{
                        const {code,obj={},msg}=s||{};
                        const back_group_id=obj.tid;
                        if(code==200 && back_group_id){
                            that.frontAddGroup(back_group_id,id);
                        }else{
                            message.warn(msg);
                            that.setState({
                                commonLoading:false,
                            })
                        }
                    }).catch((e)=>{
                         util.log('calendar', 'handleAddGroup:get back_group_id',e.toString().slice(0,100));
                    });
                }
            })

        }else{
            this.setState({
                commonLoading:true,
            })
            scheduleUsersBind_group({id}).then(s=>{
                const {code,obj={},msg}=s||{};
                const back_group_id=obj.tid;
                if(code==200 && back_group_id){
                    this.frontAddGroup(back_group_id,id);
                }else{
                    message.warn(msg);
                    that.setState({
                        commonLoading:false,
                    })
                }
            }).catch((e)=>{
                util.log('calendar', 'handleAddGroup:get back_group_id',e.toString().slice(0,100));
           });
        }

        util.sensorsData.track('Click_Schedule_Element',{pageName: 116, $element_name: 153});
    }

    // TODO 跳转编辑，获取uid
    // 跳转编辑
    scheduleEdit=(id)=>{
        util.sensorsData.track('Click_Schedule_Element',{pageName: 116, $element_name: 198});
        this.props.dispatch(hideSlideModal());
        this.props.dispatch(showScheduleAdd({id}));
    }

    // 删除日程
    scheduleDelete=(obj)=>{
        deleteConfirm(obj);
    }

    // 取消日程
    handleCancelSchedule=(repeat,id,is_last)=>{
        const type=repeat&&is_last||!repeat?'cancleOne':'';
        commmonModalConfirm({type,callBack:async (paramObj,promiseObj)=>{
            const {reason,scope=1}=paramObj;
            await cancelSchedule({id,reason,scope});
            promiseObj&&promiseObj.resolve();
        }})
        util.sensorsData.track('Click_Schedule_Element',{pageName: 116, $element_name: 154});
    }

    // 数据埋点
    uploadSensorsClickData = (elementName) => {
        util.sensorsData.track('Click_Schedule_Element', {
            pageName: 116,
            $element_name: elementName
        });
    }

    // 数据埋点
    uploadSensorsDetailData = (elementName) => {
        util.sensorsData.track('Expo_ScheduleDetail_Element', {
            $element_name: elementName
        });
    }

    // jion metting
    handleJoinMeeting=(prams)=>{
        //console.log(prams,888);
        if(prams.ismore && prams.ismore>500){
            message.warn(this.locale('calendar_toast_info_joinmeeting_over500'))
            //不支持超过500人的日程创建视频会议
            return;
        }
        this.setState({
            commonLoading:true,
            showVideo: false,
            commonLoadingText:this.locale('calendar_notification_jionmeeting')
            //正在进入会议
        })
        meetingCreateJoinFun(prams,()=>{
            this.setState({
                commonLoading:false,
                commonLoadingText:''
            })
            util.log('calendar', `handleJoinMeeting:join schedule-meeting ok`, JSON.stringify({id:prams.id,title:prams.title}));
        });
    }

    closePale = ()=>{
        this.props.dispatch(hideSlideModal());
    }
    meetingSummaryClick = async(sid) => {
        //请求接口，如果有会议纪要文档地址，直接打开，如果没有，服务端会创建一个新文档
        const data = await util.summaryUtil.meetingSummaryGetUrl({
            sid
        })
        data.title = this.locale('calendar_create_meeting_summary')
        data.sessionActive = this.props.sessionActive
        util.summaryUtil.goDocument(data)

        //数据埋点
        util.sensorsData.track('Click_Schedule_Element', {
            pageName: 116,
            $element_name: '02-101'
        })

        this.closePale()
    }

    // 催一下
    remindOne = async(item) => {
        let data = await scheduleRemindStatus({id:item.inFo.id})
        const {code,obj} = data;
        if(code === 200){
          if(obj.allow === 1){
            const datas = {
              type: 'schedule', // 类型参数
              scene: 'schedule', // 场景参数
              id: item.inFo.id,
              text: item.inFo.title,
              user: item.usersMessage,
            };
            this.props.dispatch(remindWin({
              show: true,
              messageNum: null,
              phoneNum: null,
              data:datas
            }));
          } else {
            message.warning(this.locale('calendar_create_info_notify_warning'))
          }
        }
    };

    render() {
        const {inFo={},peopleStage,openMore,userAddShow,loading,infoLoading,commonLoading,commonLoadingText,showVideo,liveUsers,isShowRemind,organizers}=this.state;

        const props = {
            inFo,peopleStage,openMore,infoLoading,liveUsers,isShowRemind,organizers,
            getDetail                : this.getDetail,
            toggleOpenMore           : this.toggleOpenMore,
            changePeopleStage        : this.changePeopleStage,
            handleShowUserAdd        : this.handleShowUserAdd,
            handleAddGroup           : this.handleAddGroup,
            scheduleEdit             : this.scheduleEdit,
            handleCancelSchedule     : this.handleCancelSchedule,
            uploadSensorsClickData   : this.uploadSensorsClickData,
            uploadSensorsDetailData  : this.uploadSensorsDetailData,
            handleJoinMeeting        : this.handleJoinMeeting,
            getUserImage             : this.getUserImage,
            usersMessage             : this.state.usersMessage,
            infoUser                 : this.state.infoUser,
            nodata                   : this.state.nodata,
            loadingText              : this.state.loadingText,
            showVideoSessioneModal   : this.showVideoSessioneModal,
            locale                   : this.locale,
            closePale                : this.closePale,
            meetingSummaryClick      : this.meetingSummaryClick,
            scheduleDelete           : this.scheduleDelete,
            remindOne                : this.remindOne,
        };


        const defaultIds= inFo.extra_info ?inFo.extra_info.uids.map(item=>item+''):[];
        const userAddProps = {
            type: 'creatGroup',
            loading: loading,
            show: userAddShow,
            onOk: this.okUserAdd,
            onClose: this.closeUserAdd,
            disabledids: defaultIds,
            title: this.locale('calendar_useradd_info_title'),
            leftTitle: this.locale('calendar_useradd_info_lefttitle'),
            rightTitle: this.locale('calendar_useradd_info_righttitle'),
            maxLength: 5000
        };

        return <Fragment>
            <ScheduleInfo {...props} />
            <UserAdd {...userAddProps} />
             {
              showVideo ? <VideoSessione
                  onlineOffice = {this.onlineOffice}
                  teamType = 'schedule'
              /> : null
            }
            {
                commonLoading?<CommonSpain text={commonLoadingText} />:null
            }
        </Fragment>
    }
}

const mapStateToProps = state => {
    return {};
};

export default connect(
    mapStateToProps,
    null
)(withRouter(ScheduleInfoContainer));


