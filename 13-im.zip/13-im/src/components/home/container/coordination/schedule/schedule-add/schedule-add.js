/*
 * @Date: 2020-02-03 13:43:10
 */

import React, { useState, useEffect,useRef } from 'react';
import { Checkbox, Input, Select,Button ,Icon,Spin,Radio,Tooltip, Modal} from 'antd';
import css from './index.scss';
import * as util from '@/utils/util';
import TimePacker from '../common/timePicker';
import _ from 'lodash';
import moment from 'moment';
import * as unitCore from '../../lib/unit-core';


import ScheduleSearch from "../schedule-search/schedule-search-container"
import { genPercentAdd } from 'antd/lib/upload/utils';
const { Option } = Select;
const { TextArea } = Input;
let timer = null;



function genOption(arr) {
    return arr.map(item => {
        const { text, selected, value } = item;
        return (
            <Option key={value} value={value}>
                {text}
            </Option>
        );
    });
}

function handleFocus() {
    util.sensorsData.track('Click_Schedule_Element', { pageName: 119, $element_name: 159 });
}



// BoxOperationContainer
export default function ScheduleAddContainer(props) {
    const {
        full_start,
        full_end,
        startTime,
        endTime,
        is_full,
        title,
        remark,
        users,
        address,
        files,
        remind_time,
        repeat_types,
        repeat,
        isMeeting,
        meeting_type,
        scheduleId,
        alertArr,
        closeShowAdd,
        showImg,
        onFullChange,
        handleInputChange,
        handleShowUserAdd,
        onCheckboxChange,
        handleFile,
        handleFileDelete,
        handlePeopleDelte,
        handleSelectChange,
        handleSelectRepeat,
        preCheck,
        container,
        handleMaiDian,
        handleMeetingChange,
        handleMeetingType,

        // 冲突部分
        rendertime,
        renderline,
        conData,
        dyscnowtime,
        computeHeight,
        initDate,
        defaultToday,
        toggleDay,
        isToday,
        comeToToday,
        conflictup,
        uptoup,
        setConflictArea,
        conflictext,
        over_50,
        innertext,
        isShowConflictArea,
        scheAttr,
        setguild,

        loadingText,
        isCreate,
        handleScheduleAttr,
        handleUserInfo,

        showMask,
        locale,
        isConflict,
        contentControllerWidth,
    } = props;
    const timeCommon = {
        is_full,
        onFullChange
    };

    const timeFomat=unitCore.formatTime(moment.unix(defaultToday));
    const userNameList = conData.map(item=>item.name);
    const userOriginData = users;

    useEffect(() => {
        // 使用浏览器的 API 更新页面标题
        util.sensorsData.track('PageView_Schedule_SecondPage', { pageName: 119 });
        let titleInput = document.getElementById('titleInput');
        titleInput && titleInput.focus();
        return ()=>{
            console.log('卸载了这个函数组件')
        }
    },[]);

    let conflictAreaStyle = over_50
         ? { width: contentControllerWidth, left:'auto', top:'auto', position:'fixed', height:'100%', display:'flex',justifyContent:'center'}
         : { top:setConflictArea().top,height:setConflictArea().height,position:'absolute',left:0};


    const showText = ()=>{
        let str = '';
        if(is_full || !conflictext){
            str = (<p><span className="iconfont icontongyi" style={{color:'#45C99C',fontSize:16,paddingRight:5}}></span>{locale('calendar_create_conflict_statustext_allavailable')}</p>);
        }
        else{
            str = (<p><span className="iconfont iconshibai" style={{color: '#FFB843',paddingRight: 5}}></span>{conflictext}</p>);
        }
         return ( <div className={css.helptext}>{str}</div>)
    }

    const wrapAttrText = ()=>{
          return locale('calendar_create_visiblity_tip')
    };

    /** //TODO 日程新建/编辑页面 */
    return (
        <div className={css.boxall} onMouseDown={e => e.stopPropagation()} id="createSchedule">
            {showMask && <div className={css.maskDiv}></div>}
            <div className={css.box}>
                <div className={css.wrapContent}>
                    <div id="peopleList" className={css.main} ref={container}>
                        <div className={`${css.title} ${css.absBox}`}>
                            <div className={css.icon}>
                                <span className={`${css.close} iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-zuoshangjiaoguanbi`} onClick={closeShowAdd}/>
                            </div>
                            <div className={css.content}>
                                <div className={css.inputOut}>
                                    <Input
                                        onChange={e => handleInputChange('title', e)}
                                        placeholder={locale('calendar_create_title_placeholder')}
                                        value={title}
                                        maxLength={30}
                                        type="text"
                                        id='titleInput'
                                        style={{width:330}}
                                    />
                                    {/* {title.length === 30 ? <span>最多输入30个字</span> : null} */}
                                </div>
                                <div onClick={preCheck} className={css.subBtn}>{locale('calendar_button_submit')}</div>
                            </div>
                        </div>
                        <div className={css.time}>
                            <div className={css.icon}>
                                {/* <span className="icon iconfont iconshijian2" /> */}
                            </div>
                            <div className={css.content}>
                                <div className={css.contentTop}>
                                    <TimePacker
                                        {...timeCommon}
                                        type="start"
                                        fullValue={full_start}
                                        timeValue={startTime}
                                    />
                                    <i />
                                    <TimePacker {...timeCommon} type="end" fullValue={full_end} timeValue={endTime} />
                                </div>
                                <div className={css.content}>
                                    <span
                                        onClick={e => {
                                            e.target.nodeName === 'DIV' &&
                                                util.sensorsData.track('Click_Schedule_Element', {
                                                    pageName: 119,
                                                    $element_name: 217
                                                });
                                        }}
                                    >
                                        <Select
                                            value={repeat}
                                            className={css.selectMultiple}
                                            onChange={handleSelectRepeat}
                                            suffixIcon={
                                                <span className={`${css.selectIcon} iconfont-yach yach-0428-richeng-xialakuangneijiantou-shouqi`}>
                                                    {/* <img src={require('@a/imgs/schedule/select-icon.png')} alt="" /> */}
                                                </span>
                                            }
                                        >
                                              {genOption(repeat_types)}
                                        </Select>
                                    </span>
                                    <div className={css.contentBottom} style={{display:'inline-block',marginLeft:15}}>
                                        <Checkbox checked={is_full} onChange={onCheckboxChange}>
                                            {locale('calendar_create_timepacker_isfull_name')}
                                        </Checkbox>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div className={css.people}>
                            <div className={css.icon}>
                                <span className="icon iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-canyuren" />
                            </div>
                            <div className={css.content}>
                                <div className={css.contentTop}>
                                     <ScheduleSearch getUser={handleUserInfo}></ScheduleSearch>
                                     {/* <InputSearch></InputSearch>   */}
                                     {/* <i onClick={handleShowUserAdd}>添加参与人</i> */}
                                     <div
                                        className={`icon iconfont-yach yach-0428_richengxiangqing-chuangjianricheng-tianjiajiahao ${css.addIcon}`}
                                        onClick={handleShowUserAdd}
                                    />
                                </div>
                                <div className={`${css.contentBottom} ${css.alignCenter}`}>
                                        {userOriginData.map((item,index) => {
                                            const { id, name, avatar, disabled } = item;
                                            return (
                                                <div className={css.peopleItem} key={index}>
                                                    <img
                                                        onClick={() => util.yach.showUserinfo({ id, showRight: true })}
                                                        src={avatar}
                                                        alt=""
                                                    />
                                                    <span>{name}</span>
                                                    {disabled? null : (
                                                        <i
                                                            className={`${css.deleteIcon} iconfont-yach yach-0428-richengxiangqing-chuangjianricheng-canyurenshanchu`}
                                                            onClick={() => handlePeopleDelte(id)}
                                                        >
                                                            {/* <img src={require('@a/imgs/schedule/delete-icon.png')} alt="" /> */}
                                                        </i>
                                                    )}
                                                </div>
                                            );
                                        })}
                                        { loadingText && !isCreate && <p className={css.loadingText}>{locale('calendar_create_adduser_loading')}</p> }
                                        {!isCreate && <p id="checkIsIn"></p>}
                                    </div>
                                </div>
                            </div>
                        <div className={css.address} style={{marginTop: 8}}>
                            <div className={css.icon}>
                                <span className="icon iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-weizhi" />
                            </div>
                            <div className={css.content}>
                                <div className={css.radioCheckBox}>
                                    <Input
                                        onChange={e => handleInputChange('address', e)}
                                        placeholder={locale('calendar_create_address_placeholder')}
                                        value={address}
                                        maxLength={30}
                                        type="text"
                                        onFocus={handleFocus}
                                    />
                                    <div className={css.checkboxWrapper}>
                                        <Checkbox checked={meeting_type} onChange={handleMeetingType}>
                                            <span style={{color: '#2F3238'}}>
                                            {locale('calendar_create_onlinemeetig_name')}
                                            </span>
                                        </Checkbox>
                                        <Tooltip placement="right"
                                                    overlayClassName={css.sceduleArrow}
                                                    title={locale('calendar_create_onlinemeeting_tip')}
                                                    getPopupContainer={() => document.getElementById('createSchedule')	}>
                                            <span className={`${css.iconQuestionMark} icon iconfont-yach yach-0428_chuangjianricheng-chuangjian-bangzhuwenhao`}></span>
                                        </Tooltip>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div className={css.meeting}>
                            <div className={css.icon}>
                                <span className="icon iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-rihui" />

                            </div>
                            <div className={`${css.contentBottom} ${css.alignCenter}`}>
                                <Checkbox checked={isMeeting} onChange={handleMeetingChange}>
                                    {locale('calendar_create_meeting_name')}
                                </Checkbox>
                            </div>
                        </div>
                        <div className={css.alert}>
                            <div className={css.icon}>
                                <span className="icon iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-tixing" />
                            </div>
                            <div className={css.content}>
                                <Select
                                    mode="multiple"
                                    value={remind_time}
                                    className={css.selectMultiple}
                                    onChange={handleSelectChange}
                                    suffixIcon={
                                        <span className={`${css.selectIcon} iconfont-yach yach-0428-richeng-xialakuangneijiantou-shouqi`}>
                                            {/* <img src={require('@a/imgs/schedule/select-icon.png')} alt="" /> */}
                                        </span>
                                    }
                                >
                                    {genOption(alertArr)}
                                </Select>
                            </div>
                        </div>
                        <div>
                            <div className={css.icon}>
                                <Tooltip placement="top"
                                     visible={setguild}
                                     overlayClassName={css.guildTextIcon}
                                     getPopupContainer={() => document.getElementById('createSchedule')	}
                                     title={locale('calendar_create_visible_tip')}>
                                     <span className="icon iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-simi" />
                                 </Tooltip>
                            </div>
                            <div className={css.content}>
                                <span>
                                    <Select
                                        className={css.selectMultiple}
                                        onChange={handleScheduleAttr}
                                        value={scheAttr}
                                        suffixIcon={
                                            <span className={`${css.selectIcon} iconfont-yach yach-0428-richeng-xialakuangneijiantou-shouqi`}>
                                                {/* <img src={require('@a/imgs/schedule/select-icon.png')} alt="" /> */}
                                            </span>
                                        }
                                    >
                                        <Select.Option value={0} >{locale('calendar_create_visible_option1')}</Select.Option>
                                        <Select.Option value={1}>{locale('calendar_create_visible_option2')}</Select.Option>
                                    </Select>

                                    {/* 私密日程：日历的共享人或订阅者只能查看忙闲 */}
                                    <Tooltip placement="right"
                                             overlayClassName={css.guildText}
                                             getPopupContainer={() => document.getElementById('createSchedule')	}
                                             title={wrapAttrText()}>
                                            <span style={{display: 'inline-block',marginLeft:6}} className={`${css.iconQuestionMark} icon iconfont-yach yach-0428_chuangjianricheng-chuangjian-bangzhuwenhao`}></span>
                                    </Tooltip>
                                </span>
                            </div>
                        </div>

                        <div className={css.text}>
                            <div className={css.icon}>
                                <span className="icon iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-miaoshu" />
                            </div>
                            <div className={css.content}>
                                <div className={css.inputOut+' '+css.eareBox}>
                                    <TextArea
                                        maxLength={1000}
                                        onChange={e => handleInputChange('remark', e)}
                                        value={remark}
                                        className={css.textContent}
                                        autoSize = {{minRows: 2}}
                                        placeholder={locale('calendar_create_remark_placeholder')}
                                        style={{width:366,backgroundColor:'#ffffff'}}
                                    />
                                    {remark.length === 1000 ? <span>{locale('calendar_create_input_remark_over1000')}</span> : null}
                                    <div className={css.file}>
                                        <div className={css.content} style={{marginTop:9}}>
                                            <div className={css.contentTop}>
                                                {files.length < 9 ? (
                                                    <label className={css.fileAdd}>
                                                        <i>{locale('calendar_create_addattachment_name')}</i>
                                                        <input
                                                            type="file"
                                                            accept=".png,.jpg,.jpeg,.gif"
                                                            onChange={handleFile}
                                                            onClick={handleMaiDian}
                                                        />
                                                    </label>
                                                ) : null}
                                            </div>
                                            <div className={css.contentBottom} style={{flexWrap: 'nowrap',display:'block'}}>
                                                {files.map(item => {
                                                    const { file, id } = item;
                                                    return (
                                                        <div style={{position:'relative'}}>
                                                            <div className={css.fileItem} key={file}>
                                                                <p>
                                                                    {<img onClick={() => showImg(id || file, files)}
                                                                    src={file || util.config.nim.showimg} alt=""/>}
                                                                </p>
                                                            </div>
                                                            <i
                                                                className={`${css.deleteIcon} ${css.fileDelete}`}
                                                                onClick={e => {
                                                                    handleFileDelete(file, e);
                                                                }}
                                                            >
                                                                <img src={require('@a/imgs/schedule/delete-icon.png')} alt="" />
                                                            </i>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* <div className={css.sendBox}>
                            <button onClick={preCheck}>{locale('calendar_button_submit')}</button>
                        </div> */}
                    </div>

                    <div className={css.confictwrap} id="contentController">
                    {over_50?<div className={css.conficthide}></div>:null}
                        <div className={css.header}>
                             <span onClick={()=>{toggleDay(-1)}}  className={css.arrow+' '+css.np+' '+'iconfont'}>&#xe68d;</span>
                             <h1>{timeFomat}&nbsp;&nbsp;{moment.unix(defaultToday).format('ddd')}</h1>
                             <span onClick={()=>{toggleDay(1)}}   className={css.arrow+' '+css.np+' '+'iconfont'}>&#xe68a;</span>
                             {
                                 !isToday &&
                                //  <Button size="small"  onClick={()=>{comeToToday()}} style={{lineHeight:'22px',marginLeft:38}}>{locale('calendar_button_conflict_backtoday')}</Button>
                                 <div className={css.todayButt} onClick={()=>{comeToToday()}} style={{lineHeight:'22px',marginLeft:28}}>{locale('calendar_button_conflict_backtoday')}</div>
                             }
                        </div>
                        
                        
                        {/* 顶部文案判断区域 */}
                        {showText()}

                        {/* 冲突弹窗布局开始 --  搞过的最麻烦的一个布局！！！ fk~ */}
                        <div className={css.controller} id="conflictArea">
                        
                            {!userNameList.length && !over_50 && <div className={css.loading}><Spin /></div>}

                             {
                                 !over_50 && <div className={css.headerController}>
                                    <div className={css.pedding}></div>
                                    <div className={css.calenderTitle}>
                                        <div className={css.cell}>
                                        {
                                            userNameList.map((name,index)=><div className={css.inner} key={index}>{name}</div>)
                                        } { /** 创建日程人姓名 */ }
                                        </div>
                                    </div>
                                </div>
                             }


                             <div className={css.contentController}>
                             
                                 <div className={css.leftTimeController}>
                                         {rendertime()}
                                         {
                                             isToday && <div className={css.nowD} style={{top:dyscnowtime.top}}>
                                                {
                                                     dyscnowtime.isshow && <span>{dyscnowtime.time[0]}:{dyscnowtime.time[1]}</span>
                                                }
                                            </div>
                                         }
                                 </div>

                                 <div className={css.rightContentController}>

                                       {/* 向上的箭头 */}
                                       { conflictup && <div  onClick={()=>{uptoup()}} className={css.littleArrow}></div>}


                                       {/* 当天的动态时间线 */}
                                       {
                                        isToday && <div className={css.nowTime}  style={{top:dyscnowtime.top}}></div>
                                       }


                                     {/* 当前选择的时间线范围 */}
                                        {
                                            isShowConflictArea() && <div className={`${!over_50 ? (isConflict ? css.selectTimeAreaConflict : css.selectTimeArea) : css.selectTimeAreaAll}`} style={conflictAreaStyle}>
                                                {
                                                    !over_50 && <div className={css.centerText}>{innertext}</div>
                                                }
                                                {
                                                     over_50 && <p style={{marginTop:200,marginLeft:'-70px'}}>{innertext}</p>
                                                }
                                           </div>
                                        }
                                      {/* 一个完整的某人的日程模板 */}
                                      {
                                       conData.map(item=>{
                                          const { layout } = item;
                                          const { ranges } = layout[0] || [];
                                          return (
                                                <div className={css.calendarSomeOne} key={item.uid}>
                                                { renderline() }
                                                {
                                                    !!layout.length && <div className={css.filter}>
                                                    {
                                                        ranges.map((evlist,ind)=>{
                                                            return( <div
                                                                   className={css.eventlist}
                                                                   key={ind}
                                                                   style={{top:computeHeight(evlist).top,height:computeHeight(evlist).height}}
                                                               ></div>)
                                                        })
                                                    }
                                               </div>
                                                }
                                            </div>
                                          )
                                        })
                                     }

                                 </div>
                             </div>
                        </div>
                        {/* 冲突弹窗布局结束 */}

                    </div>
                </div>
            </div>
        </div>
    );
}
