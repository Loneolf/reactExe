import React from 'react';
import { message,Modal } from 'antd';
import * as util from '@/utils/util';
import moment from 'moment';
import {connect} from 'react-redux';

import {
    scheduleDicAll,
    scheduleEventsCreate,
    scheduleEventsInfo,
    conflictSchedule,
    conflictSchedulelist,
} from '@s/schedule/schedule';
import {fileInfoSave} from '@s/file/file-info'

import {fileUploadCos} from '@u/lib/file/file'
import UserAdd from '@c/common/user-add/user-add-container';
import ScheduleAdd from './schedule-add';
import AddTipModal from '../common/addTipModal';
import {refrshCalender, scheduleSync, commmonModalConfirm, noticeConfirm, showScheduleImg as showImg } from '../common/common';
import {showGloading,hideGloading} from '@r/actions/commonLoading'
import * as sUtil from '../../lib/until';
import _ from 'lodash';
import css from './index.scss';
import {createSchdule} from '@r/actions/calender';
import CustomRepeat from './custom-repeat/index';


const { initAllNum2,sortFunc,usersMsgOrder } = sUtil;



let initalDate='';
let repeatDate='';
let repeatCustom={};
const pageNum=150;


// BoxOperationContainer
class ScheduleAddContainer extends React.Component {
    state = {
        usersingle:[],
        is_full: false,                                     //是否全天

        title: '',
        remark: '',
        address: '',
        files: [],
        userInfo: {},
        remind_time: [900],
        repeat:0,
        isMeeting:false,
        meeting_type:true,

        loading: false,
        userAddShow: false,
        dicObj: {},

        showCommomModal: false,
        CommonModalCallback:null,

        conData:[],
        headImg: [],

        // 日程冲突  当前时间线模块参数
        dyscnowtime: {
            isshow:true,
            top:100,
            time:[0,0]
        },
        // 日程冲突 默认当天起始日期
        defaultToday: moment().unix(),
        // 默认是当天
        isToday: true,
        // 冲突向上箭头
        conflictup:true,

        // 顶部日程冲突文案  '10:30 - 11:30 孟兴、于涛、等人有冲突'
        conflictext:'',


        innertext:'',             // 日程选中区域文案
        isConflict: false,        // 日程是否冲突


        over_50:false,            // 是否超过50人


        page:0,                   // 无限加载默认的页数

        loadingText: true,        // 用户信息加载loading

        uids:[],                  //  info接口拿到的全量的用户数据

        isCreate: true,           //  是日程创建

        users: [],                //  当前用户的容器

        scheAttr:0,               //  当前日程的属性,默认属性

        setguild: false,
        dropout:false,
        contentControllerWidth: 0,// 外容器宽度

        isvalid: true,            // 编辑日程判断是否过期,默认有效
        isNotice: false,          // 是否需要通知

        showCustomRepeat: false,  // 显示自定义重复日程
        repeatEndTime: '',        // 自定义重复截止时间
        repeatTimeObj: {},           // 自定义重复时间
        groupInfo:{}
    };

    container = React.createRef();

    // 获取词典的顺序需要前置！
    getSscheduleDicAll = async ()=>{
       console.time('-ca-getSscheduleDicAll');
       let res =  await scheduleDicAll();
       try{
            const {code, obj} = res || {};
            if (code === 200) {
              this.setState({
                dicObj: obj
              })
            }
       }
       catch(e){
           console.error('获取数据字典失败',e);
       }
       console.timeEnd('-ca-getSscheduleDicAll');
    }

    componentDidCatch(error, info) {
        console.log(error, info);
    }

    async componentDidMount() {  
        // 日程冲突初始化  自己
        const {scheduleId,custom={}} = this.props;
        const user_info = util.yach.getUserinfo()||{};
        const avatar=await util.yach.base64ImgGetTmp(user_info.pic);
        this.setState(state=>({
            userInfo:{id: user_info.id+'', avatar,name:user_info.name}
        }))

        await this.getSscheduleDicAll();
        scheduleId ? this.scheduleEidtHandle(scheduleId) : this.scheduleCreaterHandle(custom);
        document.addEventListener('click',this.bindSchuedulelocal,false); 

        // 共享日程时间线开始
        this.updateComNowTime();
        const titleInput = document.getElementById('titleInput');
        titleInput && titleInput.focus();

        this.getControllerWidth()
        window.addEventListener('resize', this.getControllerWidth)
    }

    componentWillUnmount(){
        window.createSheduleFrom='';
        this.timer && clearTimeout(this.timer);
        this.setState = (state, callback) => {
            return
        }
        window.removeEventListener('resize', this.getControllerWidth)
    }

    // 获取外容器宽度
    getControllerWidth = () => {
        // 70 为左侧控制bar宽度
        try {
            this.setState({
                contentControllerWidth: document.getElementById('contentController').offsetWidth - 70
            })
        } catch(e) {}
    }

    /*
        日程创建
    */
    scheduleCreaterHandle = (custom)=>{
        const {createSheduleFrom}=window;
        const td = util.moment();
        const {year,month,day}=createSheduleFrom==='im'||createSheduleFrom==='office'?{year  :  td.year(),month :  td.month(), day :td.date()}:this.props.initDate;

        const {
            from,
            time=[],
            title,
            start_time,
            end_time,
            is_full,
            address,
        }=this.props.createDate;

        if(from === 'fast'){
            // 快捷创建的More
            this.setState({
                title,
                is_full,
                address,
                isCreate: true,
                full_start: start_time,//moment(start).startOf('day').format('X'),
                full_end:   end_time,
                remind_time: is_full === 1? [8] : [900],
                startTime:  moment(Number(start_time)*1000).format('HH:mm'),
                defaultToday:moment.unix(start_time).startOf('day').format('X'),
                endTime:    moment(Number(end_time)*1000).format('HH:mm'),
            },()=>{
                const {title,remark,address,files,users,remind_time,is_full,full_start,full_end,startTime,endTime,repeat,isMeeting,meeting_type}=this.state;
                initalDate=JSON.stringify({title,remark,address,files,users,remind_time,is_full,full_start,full_end,startTime,endTime,repeat,isMeeting,meeting_type});
                setTimeout(()=>{ this.initconflict()},120);
            })
        } else{
            // 外部创建，meeting/群聊
            const startT=time[0], endT=time[1];
            let startV, endV;

            let start=year+'-'+(Number(month)+1)+'-'+day+' '+moment().add(1,'h').format('HH:mm:ss');
            let end=year+'-'+(Number(month)+1)+'-'+day+' '+moment().add(2,'h').format('HH:mm:ss');

            (startT - Math.floor(startT)) >= 0.4 ?(startV = `${Math.floor(startT)}:30`):(startV = `${Math.floor(startT)}:00`);
            (endT - Math.floor(endT))  >= 0.4 ?(endV = `${Math.floor(endT)}:30`):(endV = `${Math.floor(endT)}:00`);


            if(+ moment().add(1,'h')>= +moment().endOf('day')){
                start=moment(year+'-'+(Number(month)+1)+'-'+day+' '+ moment().format('HH:mm:ss')).add(1,'h').format('YYYY-MM-DD HH:mm:ss');
                end=moment(year+'-'+(Number(month)+1)+'-'+day+' '+moment().format('HH:mm:ss')).add(2,'h').format('YYYY-MM-DD HH:mm:ss');
            }else if(+moment().add(2,'h')>=+moment().endOf('day')){
                end=moment(year+'-'+(Number(month)+1)+'-'+day+' '+moment().format('HH:mm:ss')).add(2,'h').format('YYYY-MM-DD HH:mm:ss');
            }


            if(from === 'double' || from === 'drag'){
                start=year+'-'+(Number(month)+1)+'-'+day+' '+startV;
                end=year+'-'+(Number(month)+1)+'-'+day+' '+endV; //2020-03-26 00:12:05
            }

            this.setState({
                isCreate:true,
                full_start: moment(start).startOf('day').format('X'),    //全天开始时间
                full_end: moment(end).endOf('day').format('X'),        //全天结束时间
                startTime: sUtil.getTimeDate(moment(start).format('HH:mm')),    //非全天开始时分
                endTime: sUtil.getTimeDate(moment(end).format('HH:mm')),      //非全天结束时分
                defaultToday:moment(start).startOf('day').format('X'),
                ...custom
            },()=>{
                const {title,remark,address,files,users,remind_time,is_full,full_start,full_end,startTime,endTime,repeat,isMeeting,meeting_type}=this.state;
                initalDate=JSON.stringify({title,remark,address,files,users,remind_time,is_full,full_start,full_end,startTime,endTime,repeat,isMeeting,meeting_type});
                setTimeout(()=>{ this.initconflict()},120)
            })
        }


        // 日程冲突ui
        let conflictArea = document.getElementById('conflictArea');
        let addUpto = ()=>{
            if( conflictArea.scrollHeight - conflictArea.scrollTop - conflictArea.clientHeight <= 40) {
                this.setState(state=>({
                    conflictup:false
                }))
            }
            else{
                this.setState(state=>({
                    conflictup:true
                }))
            }
        };

        conflictArea.addEventListener('scroll',_.debounce(addUpto,200),false);

        setTimeout(()=>{ this.setScrollDayViewHeight() },300);

        if(!util.yachLocalStorage.ls('scheduleGuild')){
            this.setState({ setguild:true})
        }
    }
   /*
      日程编辑
   */
   scheduleEidtHandle = (scheduleId)=>{
     scheduleEventsInfo({id: scheduleId}).then(s => {
        const {code, obj} = s || {};
        if (code === 200) {
            this.initData = obj.extra_info
            const {title = '', location = '', attachments = [], visibility,uids, alert_times_values = [], end_time, start_time, is_full, summary,repeat_value} = obj.extra_info || {};
            const {is_last,sid,tags=[],meeting={}}=obj||{}
            const newStart = start_time * 1000,
                newEnd = end_time * 1000;
                repeatDate=repeat_value;

            // 处理日会
            let isMeeting=false;
            tags.forEach(item=>{
                if(item.id=='1'){
                    isMeeting=true;
                    return;
                }
            })

            // 自定义重复时间
            const {repeat_txt,repeat_txt_en,repeat_custom,repeat_end_time} = obj;
            if(repeat_value === 99){
              // const {repeat_txt,repeat_txt_en,repeat_custom} = obj;
              if(Object.keys(repeat_custom).length !== 0){
                this.getRepeatTime({repeatTime:this.locale.getLang()==='zh-CN'?repeat_txt:repeat_txt_en});
              }
              repeatCustom = repeat_custom;
            }

            this.setState(prv => ({
                is_full: Boolean(is_full),
                full_start: moment(newStart).startOf('day').format('X'),    //全天开始时间
                full_end: moment(newEnd).endOf('day').format('X'),        //全天结束时间
                startTime: moment(newStart).format('HH:mm'),    //非全天开始时分
                endTime: moment(newEnd).format('HH:mm'),      //非全天结束时分
                defaultToday: moment(newStart).startOf('day').format('X'),
                isCreate:false,
                title,
                remark: summary,
                address: location,
                files: attachments,
                uids:uids.map(item=>item+''),
                remind_time: alert_times_values,
                repeat:repeat_value,
                repeatTimeObj: {
                  frequency:repeat_value===99?repeat_custom.interval:null,
                  alternation:repeat_value===99?repeat_custom.freq:null,
                  customTime:repeat_value===99?repeat_custom.values:null,
                  repeatTime:repeat_value===99?this.locale.getLang()==='zh-CN'?repeat_txt:repeat_txt_en:null,
                },
                repeatEndTime:repeat_end_time,
                is_last,
                isMeeting,
                meeting_type:meeting.type==1,
                sid,
                scheAttr:visibility === 1?0:1,
                isvalid: newEnd > +new Date()
            }),()=>{
                const {title:sTitle,remark,address,files,remind_time,is_full: sIsFull,full_start,full_end,startTime,endTime,repeat,repeatTimeObj,repeatEndTime,isMeeting: sIsMeeting,meeting_type}=this.state;
                initalDate=JSON.stringify({title: sTitle,remark,address,files,remind_time,is_full: sIsFull,full_start,full_end,startTime,endTime,repeat,repeatTimeObj,repeatEndTime,isMeeting: sIsMeeting,meeting_type})
                setTimeout(()=>{
                     // 开始加载首屏头像信息
                     this.intiateScrollObserver();
                     this.initconflict()
                },120)

            })
        }
      })
   }

   /*
      引导tooltips展示方式 util.yachLocalStorage.ls('scheduleGuild',true)

   */
  bindSchuedulelocal = ()=>{
      if(this.state.setguild && !util.yachLocalStorage.ls('scheduleGuild')){
           util.yachLocalStorage.ls('scheduleGuild',true);
           this.setState({ setguild:false});
      }
  }

   /*
     @日程冲突
     下滑到底部实现
     pm 上线前该动画  不需要动画
    */
    setScrollDayViewHeight = async () => {
        let sc = document.getElementById('conflictArea');
        if(new Date().getHours()>12){
            // window.scrollBottom = setInterval(()=>{
            //     if(new Date().getHours() * 40 -  sc.scrollTop <150 || sc.scrollHeight - sc.scrollTop - sc.clientHeight <= 20){
            //         clearInterval( window.scrollBottom );
            //     }
            //     else{
            //         sc.scrollTop +=10;
            //     }
            // },30);
            sc.scrollTop = conflictArea.clientHeight;
        }

    }

   /*
      @日程冲突
      时间生成
   */
    rendertime = ()=>{
        const t = initAllNum2();
        return t.map(item=> <div key={item} className={css.tbox}><span>{item}</span></div>);
    }

     /*
      @日程冲突
      时间线生成
    */
    renderline = ()=>{
        let i=0;
        let res = [];
        while(i<23){
            res.push(<div className={css.lines} key={i}> </div>);
            i++
        }
       return res;
    }

    /*
    @日程冲突
    当前时间线
   */
    updateComNowTime  = ()=>{
        const {year,month,day}=this.props.initDate;
        let nowTime = Date().replace(/^.*?(\d+:\d+).*?$/, '$1').split(':');
        let startTime = sUtil.timemillions(year,month,day,0,0,0);
        let begin_time = sUtil.timemillions(year,month,day,nowTime[0],nowTime[1],0);
        let topline = sUtil.changline(startTime,begin_time);
        if(parseInt( +nowTime[1])>15 &&parseInt(+nowTime[1])<45){
            this.setState({
                dyscnowtime: {
                    isshow:true,
                    top:topline,
                    time:[nowTime[0],nowTime[1]]
                }
            });
        }
        else{
            this.setState({
                dyscnowtime: {
                    isshow:false,
                    top:topline,
                    time:[nowTime[0],nowTime[1]]
                }
            });
        }

        this.timer = setTimeout(this.updateComNowTime,30000);
    };


    /*
    @日程冲突
     属性计算
     list: [1581495476,1581497216]
   */
    computeHeight = (list)=>{
        const [begin_time,finish_time] = list;
        let ns = moment.unix(this.state.defaultToday);

        let  startTime   =  ns.startOf('day').unix();
        let  endTime     =  ns.endOf('day').unix();

        let height = sUtil.changline(begin_time,finish_time);
        let top = sUtil.changline(startTime,begin_time);

        return {
            top,
            height
        };
     }


     /*
      @日程冲突
       判断是当天
   */
     itIsToday= ()=>{
        let ns = moment.unix(this.state.defaultToday);
        let isToday = true;
        let td = new Date();
        if(td.getFullYear() === ns.year() && td.getMonth() === ns.month() && td.getDate() === ns.date()){
            isToday = true
        }
        else{
            isToday = false;

        }
        this.setState(state=>({
            isToday,
        }));
     }

      /*
      @日程冲突
      当前日期切换 上下一天
      日期改变
   */
    toggleDay = (dir)=>{

        let ns = moment.unix(this.state.defaultToday);
        let uidlist =  this.state.isCreate? this.state.users.map(item=>item.id):this.state.uids;
        ns.add(dir,'days');
        let  start_time   =  ns.startOf('day').unix();
        let  end_time     =  ns.endOf('day').unix();


        this.setState(state=>({
            defaultToday:ns.unix()
        }),()=>{
            this.itIsToday();
            this.conflictSchedulelist({start_time,end_time,uids: uidlist.join()});
        });

    }



     /*
      @日程冲突
      返回今天
   */
    comeToToday = () =>{
        this.setState(state=>({
            isToday:true,
            defaultToday: moment().unix()
        }),()=>{
            // 回到今天  再次初始化
            this.initconflict(1);
            this.setScrollDayViewHeight();
        });

    }



    /*
        @ 日程冲突
        获取当前选择的时间范围的时间戳  10位
        isformate: 格式化输出跨天日程
        acrossday：格式化输出非跨天日程
    */
  getUnixMillions = (isformate=false,acrossday=false)=>{
      let {startTime,endTime,full_start,full_end} = this.state;
      let start_time = full_start;
      let end_time = full_end;
      start_time = moment(moment(start_time * 1000).format('YYYY-MM-DD') + " " + startTime).format('X');
      end_time = moment(moment(end_time * 1000).format('YYYY-MM-DD') + " " + endTime).format('X');
      if(isformate && !acrossday){
          return{
            start_time: moment.unix(start_time).format('YYYY-MM-DD HH:mm'),
            end_time: moment.unix(end_time).format('YYYY-MM-DD HH:mm')
          }
      }
      else if(isformate && acrossday){
         return{
             start_time: moment.unix(start_time).format('HH:mm'),
             end_time: moment.unix(end_time).format('HH:mm')
          }
      }
      else{
        return {
            start_time,end_time
          }
      }
  }



    /*
        @ 日程冲突
        当天冲突区域覆盖面积
        setDefault: 主动传递进来值，设置当前该值为输出值
    */
   setConflictArea = ()=>{
      let {start_time,end_time} = this.getUnixMillions();
      let rightToday = this.state.defaultToday;
      let height,top;

      let  start_time_StartTime   =  moment.unix(start_time).startOf('day').unix();
      let  start_time_EndTime     =  moment.unix(start_time).endOf('day').unix();

      let changed_StarTime        =  moment.unix(rightToday).startOf('day').unix();
      let changed_EndTime         =  moment.unix(rightToday).endOf('day').unix()

      if( end_time >= start_time_EndTime ){
          //console.log('跨天了')
          // 在判断当前右侧的时间切换了没
          if(changed_EndTime === start_time_EndTime){
              // 没切换
              top = sUtil.changline(start_time_StartTime,start_time) || 1;
              height = sUtil.changline(start_time,start_time_EndTime) || 1;
          }
          else if(changed_EndTime >= end_time && changed_StarTime<=end_time){
              top = 0;
              height = sUtil.changline(changed_StarTime,end_time) || 1;
          }
          else if(changed_StarTime<end_time && changed_EndTime<end_time && changed_StarTime>start_time){
              top = 0;
              height = sUtil.changline(changed_StarTime,changed_EndTime) || 1;
          }
      }
      else{
          height = sUtil.changline(start_time,end_time) || 1;
          top = sUtil.changline(start_time_StartTime,start_time) || 1;
      }

      return {top,height}
   }


   /*
     @ 日程冲突
     选人发送请求
   */
  selectRequest = ()=>{
    // 日程创建者自己的日程

   let {start_time,end_time} = this.getUnixMillions();
   let  start_time_StartTime   =  moment.unix(start_time).startOf('day').unix();
   let  start_time_EndTime     =  moment.unix(start_time).endOf('day').unix();


   let uidlist = this.state.isCreate ? this.state.users.map(item=>item.id):this.state.uids;
   let uids = uidlist.join();

   if( uidlist.length >=50 ){
       this.setState({
           over_50: true,
           innertext:this.locale('calendar_create_conflict_over50_text')
       })
   }
   else{
       this.setState({
           over_50: false,
       });
       this.getConflict({start_time,end_time,uids});
       // 获取这些人的当天的日程
       this.conflictSchedulelist({start_time:start_time_StartTime,end_time:start_time_EndTime,uids});
   }
 }





  /*
     @ 日程冲突
     初始化 一上来先检查当前时间是否和自己冲突
     gotoToday: 是否返回今天  如果是返回今天的话，今天的真实时间并不是选择的时间，而应该是右侧的时间为今天  fk! 注意了
   */

   initconflict = (gotoToday=false)=>{
      let {start_time,end_time} = this.getUnixMillions();
      let start_time_StartTime,start_time_EndTime,defaultData;
      if(gotoToday){
          // 返回今天 刷新接口
           defaultData = this.state.defaultToday;
           start_time_StartTime   =  moment.unix(defaultData).startOf('day').unix();
           start_time_EndTime     =  moment.unix(defaultData).endOf('day').unix();
      }
      else{
           start_time_StartTime   =  moment.unix(start_time).startOf('day').unix();
           start_time_EndTime     =  moment.unix(start_time).endOf('day').unix();
      }


      let uidlist =  this.state.isCreate? this.state.users.map(item=>item.id):this.state.uids;
      let uids = uidlist.join();

      this.itIsToday();

      const {sid}=this.state;

      if(uidlist.length>50){
        this.setState({
            over_50: true,
            innertext:this.locale('calendar_create_conflict_over50_text')
        })
        return;
      }
      this.getConflict({start_time,end_time,uids,id:sid})
      this.conflictSchedulelist({start_time:start_time_StartTime,end_time:start_time_EndTime,uids,id:sid});

   }




   /**
    * @ 日程冲突
    * 冲突用户的名匹配，直接去云信查询
    */
   matchname = async (params)=>{

        console.log('params',params)

        if(!Array.isArray(params) || !params.length) return;
        try{
            const res = await util.nimUtil.getUsers(params);
            return res.map(item=>item.nick);
        }
        catch(e){ console.log('matchname>>>',e)}
   }


   /*
      @日程冲突
       获取用户的当日的日程
   */

  conflictSchedulelist = async(...arg)=>{
     if( this.isNoMeanintData() ){
        console.log('schedule conflictSchedulelist error Invalid schedule');
        return
     }
      try{
          let timezone = sUtil.gZone();
          arg[0] && (arg[0]['timezone'] = timezone);

          const list = await conflictSchedulelist(...arg);
          const {code,msg,obj = {}} = list || {};
          if(code === 200){this.userConflictSuccess(obj)}
          else{ message(msg)}
      }
      catch(e){
         console.error('conflict schedule list error',e);
      }
  }


  /*
      @日程冲突
       获取用户的当日的日程成功的回调
  */

  userConflictSuccess = (obj)=>{
      const {list} = obj;
      this.setState({conData:[...list]})
  }

  /*
     @ 日程冲突
       判断当前请求之前 是否是有效的时间 否则 get out!
  */
  isNoMeanintData = ()=>{
    let {start_time,end_time} = this.getUnixMillions();
    if( Number(end_time) < Number(start_time) ){
        return !0;
    }
    return ![];
  }


   /*
     @ 日程冲突
      获取冲突
   */
   getConflict = async (...arg)=>{

     if( this.isNoMeanintData() ){
         console.log('schedule getconflict error Invalid schedule');
         return
     }
      try{
         const id =  util.yach.getAccount();
         const list = await conflictSchedule(...arg);
         const {code,msg,obj = {}} = list || {};
         if(code === 200){this.conflictSuccess(obj)}
         else{ message(msg)}
      }
      catch(e){
          console.error('conflict schedule',e);
      }
   }

    /*
     @ 日程冲突
       是否展示冲突区域
   */
   isShowConflictArea = ()=>{
        let  {start_time,end_time}  =  this.getUnixMillions();
        let  start_time_EndTime     =  moment.unix(start_time).endOf('day').unix();
        let  start_time_StarTime    =  moment.unix(start_time).startOf('day').unix();


        let rightToday              =  this.state.defaultToday;
        let changed_StarTime        =  moment.unix(rightToday).startOf('day').unix();

        let  { is_full } = this.state;
        if( ((end_time >= start_time_EndTime) || Number(changed_StarTime)===Number(start_time_StarTime))  && !is_full){
            return !0;
        }
        else{
            return ![];
        }
   }


   /*
     @ 日程冲突
       成功的函数回调和逻辑解析
   */
   conflictSuccess = async(obj)=>{
        let  {conflicts} = obj;
        let  names = await this.matchname(conflicts)||[];


        let  {start_time,end_time}   = this.getUnixMillions();
        let  innertext ;
        let  start_time_EndTime     =  moment.unix(start_time).endOf('day').unix();
        let  isacross = false;

        let copyName = names.length>3 ? names.slice(0,3) : names;

        // 冲突区域文案和外面文案是不一样
        end_time >= start_time_EndTime ? isacross =!0 : isacross = ![];
        innertext = isacross ? this.getUnixMillions(1,0).start_time+'-'+this.getUnixMillions(1,0).end_time : this.getUnixMillions(1,1).start_time+'-'+this.getUnixMillions(1,1).end_time;

        if(!names.length){
            this.setState({
                conflictext:'',
                innertext,
                isConflict: false
            })
        }
        else if(names.length <= 3){
            this.setState({
                conflictext: this.locale.getLang()==='zh-CN'?`${names.join('、')}有日程冲突`:`${names.join('、')} are unavailable`,
                innertext: this.locale.getLang()==='zh-CN'?`${innertext} ${names.join('、')}有日程冲突`:`${innertext} ${names.join('、')} are unavailable`,
                isConflict: true
            })
        }
        else{
            this.setState({
                conflictext: this.locale.getLang()==='zh-CN'?`${copyName.join('、')} 等${names.length}人有日程冲突`:`${copyName.join('、')} and ${names.length-4} others are unavailable`,
                innertext: this.locale.getLang()==='zh-CN'?`${innertext} ${copyName.join('、')} 等${names.length}人有日程冲突`:`${innertext} ${copyName.join('、')} and ${names.length-4} others are unavailable`,
                isConflict: true
            })
        }
   }


  /*
     @ 日程冲突
       返回顶部
   */
  uptoup = ()=>{
    let conflictArea = document.getElementById('conflictArea');
    let anitimer = setInterval(()=>{
        if(  conflictArea.scrollHeight - conflictArea.scrollTop - conflictArea.clientHeight <= 20){
            clearInterval(anitimer);
        }
        else{
            conflictArea.scrollTop += 10;
        }
    },10);
  }



    // input 的change
    handleInputChange = (field, e) => {
        const opt = {
            [field]: e.target.value
        }
        this.setState(opt)
    }



    /*
       非input change
     @ 日程冲突  增加初始化右侧的
   */

    commonChange = (field, value) => {
        if (field === 'is_full') {
            this.setState({
                [field]: value,
                remind_time: value ? [8] : [900]
            });
        } else {
            if(field === 'full_start'){
                this.setState({
                    defaultToday:value,
                    [field]: value,
                },()=>{
                    this.initconflict();

                });
            }
            else{
                this.setState({
                    [field]: value,
                },()=>{
                    this.initconflict();
                });
            }

        }
    };


  /**
  *  处理info 人数处理  infoUser  一页请求150 小于请求的总数或者没有数据  就关闭无限加载
  */
    interfaceActions = (target)=>{
        const {page,uids}=this.state;
        const list=page===-1?[]:uids.slice(page*pageNum,(page+1)*pageNum);
        if(list.length<pageNum) this.observer.unobserve(target);
        if(!list.length) return;
        this.getUserImage(list);
    }


   /**
  *   获取云信端头像
  */
    getUserImage = async (params) => {
        if(!Array.isArray(params) || !params.length) return;
        try{
            // todo:确定参数是否可以string返回值是否string
            const res = await util.nimUtil.getUsers(params);
            const resImg = res.map(item=> ({id:item.account,name:item.nick,avatar:item.avatar}));

            const arr= await util.yach.base64ImgArrGetTmp(resImg,'avatar');
            this.setState(state=>({
                users: [...state.users,...arr],
                loadingText: false,
                page:state.page+1
            }));
            this.setState({loadingText:false})
        }
        catch(e){ console.log('getUserImage>>>',e)}
    }

      /**
    *   无限
    */
   intiateScrollObserver = () => {
        const options = {
        root: document.querySelector('#peopleList'),
        rootMargin: '0px 0px 20px 0px',
        threshold: [0.6]
        };
        this.observer = new IntersectionObserver(this.callback, options);
        this.observer.observe(document.querySelector("#checkIsIn"));
    }

    /**
    *    无限的回调
    */
    callback = (entries, observer) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                this.interfaceActions(entry.target);
            }
        });
    }

    /*
       设置日程的私密属性
    */
   handleScheduleAttr = (scheAttr)=>{
        this.setState({scheAttr})
   }


    // checkbox change
    onCheckboxChange = e => {
        if(e.target.checked) {
            util.sensorsData.track('Click_Schedule_Element',{pageName: 119, $element_name: 156});
        }
        this.commonChange('is_full', e.target.checked);
    }

    // 添加附件
    handleFile = async event => {
        const type=event.target.files[0]&&event.target.files[0].type;
        if (!/\gif|jpg|jpeg|png|bmp|BMP|GIF|JPG|PNG$/.test(type)) {
            message.error(this.locale('calendar_create_attachment_upload_info'))
            return;
        }

        let loading = message.loading(this.locale('calendar_create_attachment_upload_loading'), 0);
        let user_info = util.yach.getUserinfo()||{};
        let filetarget = event.target.files[0]

        event.target.value = ''

        let imageinfo = await util.imageDealer.getImageInfoFromClient(filetarget.path) || {}

        if (imageinfo.width * imageinfo.height > 9999 * 9999) {
            message.warn(util.locale('im_send_img_maxsize_limit'))
            return loading()
        } 

        let limitBase64 = await util.imageDealer.resetImageLimitBase64(filetarget.path, 5000)

        util.electronipc.electronFileUpload({
            filepath: filetarget.path,
            filename: filetarget.name,
            filebase64: limitBase64 || undefined,
            costype: 'image',
            project: 'schedule',
            filetype: 'image',
            size: filetarget.size
        }, res => {
            loading()
            if (res.error) return message.error(this.locale('calendar_create_attachment_upload_error'))

            message.success(this.locale('calendar_create_attachment_upload_success'))

            this.setState(prv => ({
                files: [...prv.files, {file: res.fileurl}]
            }),()=>{
                this.container.current.scrollTop=this.container.current.offsetHeight;
            })

            fileInfoSave({
                file_url: res.fileurl,
                file_name: res.filename,
                file_size: filetarget.size,
                file_mime: filetarget.type,
                file_extension: res.fileurl.slice(res.fileurl.lastIndexOf('.') + 1),
                source: 'schedule',
                receive_type: 2,
                receive_id: user_info.id
            })
        })
    }
    handleMaiDian = () => {
        util.sensorsData.track('Click_Schedule_Element',{pageName: 119, $element_name: 143});
    }
    // 删除附件
    handleFileDelete = (file,e) => {
        e.stopPropagation();
        this.setState(prv => {
            const arr = prv.files;
            return {
                files: arr.filter(item => item.file !== file)
            }
        })
    }

    // 关闭加人弹框
    closeUserAdd = () => {
        this.setState({
            userAddShow: false,
            loading: false
        });
    };

    // 加人ok
    okUserAdd = async (value) => {
        const {userInfo}=this.state;

        // olei
        const {users, allDataUsers} = value;
        // const usersOrder = users.length === allDataUsers.length ? usersMsgOrder(users.map(item => +item.id), allDataUsers) : allDataUsers

        // 人员按添加顺序排序
        const usersOrder = usersMsgOrder(users.map(item => +item.id), allDataUsers)

        if (allDataUsers.length > users.length) {
            const userIds = users.map(item => +item.id)
            allDataUsers.forEach(item => {
                if (!userIds.includes(+item.id)) usersOrder.push(item)
            })
        }

        let userDate = usersOrder.filter(item=>item.id!==userInfo.id);

        let newuid;

        if(!this.state.isCreate){
            newuid =  userDate.map(item=>item.id+'');
            userDate=[{...userInfo,pic:userInfo.avatar},...userDate];
            // 编辑选人之后，就不用分页加载了
            this.setState({
                page:-1,
            })
        }

        const list= userDate.map(item => ({id:item.id+'',name:item.name,avatar:item.pic}));
        const resArr= await util.yach.base64ImgArrGetTmp(list,'avatar');


        this.setState(state=>({
            users:resArr,
            userAddShow: false,
            // olei 注
            // uids:!this.state.isCreate?[...new Set([...state.uids,...newuid])]:[]
            uids: !this.state.isCreate ? newuid : []
        }),()=>{
            this.selectRequest();
        })
    }

    // 加人删除
    handlePeopleDelte = (id) => {
        util.sensorsData.track('Click_Schedule_Element',{pageName: 116, $element_name: 197});
        this.setState(prv => {
            const arr = prv.users;
            return {
                users: arr.filter(item => item.id != id),
                uids: this.state.isCreate?[]:prv.uids.filter(item => item != id)
            }
        },()=>{
            console.log('加人删除成功')
            this.selectRequest();
        })

    }

    // 弹出加人组件
    handleShowUserAdd = () => {
        util.sensorsData.track('Click_Schedule_Element',{pageName: 119, $element_name: 158});

        // todo触发emit事件
        this.setState({
            userAddShow: true,
        },()=>{
            const{id,showname} = this.state.groupInfo;
            if(!id) return;
            util.eventBus.emit('userMembers', {id, showname});
        });
    }

    // 修改提示
    handleModifyConfirm=(value)=>{
        // is_last: 0 重复还有多次
        // is_last: 1 重复只有一次/非重复

    }

    // XXX 这里需要优化 提示内容保存
    // 编辑日程修改内容校验
    checkModify = ({title, address, repeat, repeatTimeObj,startTime, endTime, full_start, full_end, is_full, users}, filter) => {
        if (this.state.isCreate) return false

        const {start_time, end_time} = this.initData
        const newStart = start_time * 1e3
        const newEnd = end_time * 1e3

        const oldStartTime = moment(newStart).format('HH:mm');    //非全天开始时分
        const oldEndTime = moment(newEnd).format('HH:mm');      //非全天结束时分

        const day = 60 * 60 * 24
        const opt = {
            isModifyTime: Math.abs(start_time - full_start) > day || Math.abs(end_time - full_end) > day || startTime !== oldStartTime || endTime !== oldEndTime || !!this.initData.is_full !== is_full,
            isModifyTitle: this.initData.title !== title,
            isModifyAddress: this.initData.location !== address,
            isModifyRepeat: this.initData.repeat_value !== repeat,
            isModifyRepeatCustom: JSON.stringify(JSON.parse(initalDate).repeatTimeObj) !== JSON.stringify(repeatTimeObj),
            isRepeat: repeat !== 0,
            isOne: users.length < 2
        }

        if (filter) return filter(opt)
        return opt
    }
    // XXX 这里需要优化 提示内容保存
    checkModifyOther = ({meeting_type, isMeeting, remind_time, scheAttr, remark, files}, filter) => {
        if (this.state.isCreate) return false
        const oldInitData = JSON.parse(initalDate);
        const opt = {
            isModifyMeetingType: oldInitData.meeting_type !== meeting_type,
            isModifyMeeting: oldInitData.isMeeting !== isMeeting,
            isModifyRemindTime: oldInitData.remind_time.join('') !== remind_time.join(''),
            isModifyVisibility: this.initData.visibility === scheAttr,
            isModifyRemark: oldInitData.remark !== remark,
            isModifyFiles: oldInitData.files.map(item => item.file).join('') !== files.map(item => item.file).join('')
        }
        if (filter) return filter(opt)
        return opt
    }


    // 通知询问弹窗展示
    noticeDialog = () => {
        noticeConfirm({
            title: this.locale('calendar_toast_notify_participants'),
            callback: this.handleSubmit
        })
    }

    // 保存数据
    savePromiseObj = (paramObj, promiseObj) => {
        this.paramObj = paramObj
        this.promiseObj = promiseObj
        promiseObj&&promiseObj.resolve()
        this.noticeDialog()
    }

    // 是否通知提醒条件
    editFilter = ({isModifyTime, isModifyTitle, isModifyAddress, isModifyRepeat, isModifyRepeatCustom, isOne}) => {
        if (isOne) return false
        return isModifyTime || isModifyTitle || isModifyAddress || isModifyRepeat || isModifyRepeatCustom
    }

    // 判断两个对象是否相同
    isObjectValueEqual = (a, b) => {
      const aProps = Object.getOwnPropertyNames(a);
      const bProps = Object.getOwnPropertyNames(b);
      if (aProps.length != bProps.length) return false;
      for (let i = 0; i < aProps.length; i++) {
        const propName = aProps[i]
        const propA = a[propName]
        const propB = b[propName]
        if ((typeof (propA) === 'object')) {
          if (!this.isObjectValueEqual(propA, propB)) return false
        } else if (propA !== propB) return false
      }
      return true
     };

    // 创建校验
    preCheck = () => {
        util.sensorsData.track('Click_Schedule_Element',{pageName: 119, $element_name: 196});
        const {scheduleId} = this.props;
        const {full_start, full_end, startTime, endTime, is_full, title,repeat,repeatEndTime,repeatTimeObj,is_last} = this.state;

        let start_time = full_start;
        let end_time = full_end;
        let nowTime = moment().subtract(1, 'd').format('X');
        if (!is_full) {
            start_time = moment(moment(start_time * 1000).format('YYYY-MM-DD') + " " + startTime).format('X');
            end_time = moment(moment(end_time * 1000).format('YYYY-MM-DD') + " " + endTime).format('X');
            nowTime = moment().format('X');
        }

        const isNotice = this.checkModify(this.state, this.editFilter);
        this.setState({
            isNotice
        })

        //自定义重复时间
        let repeat_custom;
        if(repeat === 99){
          repeat_custom = {
            freq: repeatTimeObj.alternation,//频率
            interval: repeatTimeObj.frequency,//间隔
            values: Array.isArray(repeatTimeObj.customTime) ? repeatTimeObj.customTime.join(",") : repeatTimeObj.customTime,//值
            until: repeatEndTime?repeatEndTime:0,
          };
        }

        if (title.trim().length === 0) {
            let icon=<span className={css.iconRemind+" "+"iconfont-yach yach-xiezuo-xinjianricheng-richengchongtu-tishi"}></span>
            message.error({
                content:this.locale('calendar_toast_create_title_empty'),
                icon,
            });
            return;
        } else if(scheduleId&&repeatDate){
            // 修改重复 或者自定义重复
            if(repeatDate!==repeat || (repeat_custom?(!this.isObjectValueEqual(repeatCustom,repeat_custom)):false)){
                //修改规则
                if(!is_last){
                  // 不是最后一次
                  commmonModalConfirm({
                    callBack: isNotice ? this.savePromiseObj : this.handleSubmit,
                    // callBack: this.handleSubmit,
                    type:'rule'
                  });
                }else{
                    this.handleSubmit();
                }
            }else {
                //修改其他
                if(!is_last){
                  // 不是最后一次
                  commmonModalConfirm({
                    callBack: isNotice ? this.savePromiseObj : this.handleSubmit
                    // callBack: this.handleSubmit
                  });
                }else{
                    this.handleSubmit();
                }
            }
        } else if (start_time >= end_time) {
            this.setState({
                showCommomModal: true,
                CommonModalText: this.locale('calendar_toast_create_time_wrong'),
                CommonModalType: 'tip'
            })
            return;
        } else if(repeat&&end_time-start_time>=10*24*60*60){
            this.setState({
                showCommomModal: true,
                CommonModalText: this.locale('calendar_toast_create_time_repeat'),
                CommonModalType: 'tip'
            })
            return;
        } else if (start_time < nowTime) {
            // 过去的日程
            this.setState({
                showCommomModal: true,
                CommonModalText: this.locale('calendar_toast_create_time_past'),
                CommonModalType: 'confirm'
            })
            return;
        } else if (start_time >= repeatEndTime?repeatEndTime:0) {
            // 截止时间不能早于开始时间
            this.setState({
              showCommomModal: true,
              CommonModalText: this.locale('calendar_create_custom_repeat_not_earlier'),
              CommonModalType: 'tip'
            });
            return;
        } else if (isNotice) {
            this.noticeDialog()
        } else {
            this.handleSubmit();
        }
    }

    // 人员增减  勿删
    getUsers = () => {
        if (this.state.isCreate) return false
        const { uids } = this.initData
        const users = this.state.users.map(item => +item.id)
        const add = users.filter(item => !uids.includes(item))
        const del = uids.filter(item => !users.includes(item))
        return { add, del }
    }


    // 创建
    handleSubmit = async(paramObj={},promiseObj) => {
      paramObj = this.paramObj ? {...this.paramObj, ...paramObj} : paramObj
      promiseObj = this.promiseObj || promiseObj

      // 人员增减
      // const memberInfo = this.getUsers()

      this.props.dispatch(showGloading());
      const {scope = 1} = paramObj;
      const {scheduleId} = this.props;
      const {title, remark, address, files, users, is_full, remind_time, repeat, repeatEndTime, repeatTimeObj, full_start, full_end, startTime, endTime, isMeeting, isCreate, meeting_type, uids} = this.state;
      // 处理时间
      let start_time = full_start;
      let end_time = full_end;

      let uidlist = isCreate ? users.map(item => item.id) : uids;

      if (!is_full) {
        start_time = moment(moment(start_time * 1000).format('YYYY-MM-DD') + " " + startTime).format('X');
        end_time = moment(moment(end_time * 1000).format('YYYY-MM-DD') + " " + endTime).format('X');
      }

      //处理tags
      let tags;
      if (isMeeting) tags = 1;

      //处理自定义重复时间
      let repeat_custom;
      if(repeat === 99){
        repeat_custom = {
          freq: repeatTimeObj.alternation,//频率
          interval: repeatTimeObj.frequency,//间隔
          values: Array.isArray(repeatTimeObj.customTime) ? repeatTimeObj.customTime.join(",") : repeatTimeObj.customTime,//值
          until: repeatEndTime?repeatEndTime:0,
        };
      }

        let timezone = sUtil.gZone();
        // 调用创建接口
        const params = {
            title,
            start_time,
            end_time,
            participant: uidlist.join(),
            address,
            is_full: Number(is_full),
            attachment: files.map(item=>item.file).join(),
            remark,
            remind_time: remind_time.join(),
            id:scheduleId,
            repeat,
            repeat_end_time:repeatEndTime,
            repeat_custom:JSON.stringify(repeat_custom),
            scope,
            tags,
            meeting_type:meeting_type?1:'',
            visibility: this.state.scheAttr === 0? 1 :2,
            timezone
        }

        if (typeof paramObj.notify !== 'undefined') params.notify = paramObj.notify


        if (!scheduleId) {
            delete params.id;
            delete params.scope;
        }


        if ( uidlist.length >100 && this.state.repeat !== 0) {
            this.props.dispatch(hideGloading());
             message.warn(this.locale('calendar_create_repeat_over100'));
        } else {
            try{
                const res = await scheduleEventsCreate(params);
                const {code, msg} = res || {};
                this.props.dispatch(hideGloading());
                if( code !== 200)  message.error(msg);
                else {
                    scheduleSync({type:2});             // 状态同步
                    refrshCalender('all');
                    promiseObj&&promiseObj.resolve();   // 不能删除，是要关闭这次还是下次弹框。

                    !scheduleId && promiseObj&&promiseObj.reject();
                    message.success(scheduleId?this.locale('calendar_toast_eidt_success'):this.locale('calendar_toast_create_success'));
                    this.props.closeShowAdd();
                    this.props.dispatch(createSchdule({from:'create',time:[]}));
                    delete this.paramObj
                    delete this.promiseObj
                }
            }
            catch(e){
                util.log('calendar', `handleSubmit:error`, e.toString() );
            }
        }
        util.log('calendar', `handleSubmit:${scheduleId?'edit':'creat'} calender`,JSON.stringify({id:params.id,start_time,end_time,title}));
      }

    // 切换提示框
    toggleCommonModal = () => {
        this.setState(prv => ({
            showCommomModal: !prv.showCommomModal
        }))

        if( !this.state.showCommomModal ){
            window.createSheduleFrom =  window.createDialog = undefined;
        }
    }

    // 提醒时间
    handleSelectChange = (value) => {
        this.setState({
            remind_time: value.length===0?[-1]:(value[value.length-1] === -1 ? [-1] : value.filter(item => item !== -1))
        })
    }

    // 自定义重复
    handleSelectRepeat=(value)=>{
        this.setState({ repeat:value })
        const {repeatTimeObj} = this.state;
        if(value === 999) {
          if(Object.keys(repeatTimeObj).length != 0){
            this.showShowCustomRepeat(true);
          }else{
            this.showShowCustomRepeat(false);
          }
        }
    };

    handleCloseShowAdd=()=>{
        const {title,remark,address,files,users,remind_time,is_full,full_start,full_end,startTime,endTime,repeat,repeatTimeObj,isMeeting,meeting_type}=this.state;

        let isModify = this.checkModify(this.state, opt => opt.isModifyTime || opt.isModifyTitle || opt.isModifyAddress || opt.isModifyRepeat);
        if (!isModify) isModify = this.checkModifyOther(this.state, opt => {
            for (const key in opt) {
                if (opt[key]) return true
            }
            return false
        });
        // 人员增减
        const memberInfo = this.getUsers()
        if (!isModify && memberInfo) isModify = memberInfo.add.length || memberInfo.del.length
        // 自定义时间修改
        if(repeatTimeObj.customTime && Array.isArray(repeatTimeObj.customTime)) repeatTimeObj.customTime = repeatTimeObj.customTime.join(',');
        if (!isModify && repeatTimeObj) isModify = !(JSON.stringify(JSON.parse(initalDate).repeatTimeObj)===JSON.stringify(repeatTimeObj));
        // XXX 这里需要优化 提示内容保存
        if(!this.state.isCreate && !isModify || (this.state.isCreate && initalDate===JSON.stringify({
            title,remark,address,files,users,remind_time,is_full,full_start,full_end,startTime,endTime,repeat,isMeeting,meeting_type
        }))) {
            this.props.closeShowAdd();
            window.createSheduleFrom =  window.createDialog = undefined;
        }else{
            this.setState({
                showCommomModal: true,
                dropout:true,
                CommonModalText: this.locale('calendar_toast_quit_nosave'),
                CommonModalType: 'confirm',
                CommonModalCallback:this.props.closeShowAdd
            })
        }
        this.props.dispatch(createSchdule({from:'create',time:[]}));
    }

    // 日会选择
    handleMeetingChange=()=>{
        this.setState(prv=>({
            isMeeting:!prv.isMeeting
        }))
    }
    // 会议种类
    handleMeetingType=(e)=>{
        this.setState({
            meeting_type:e.target.checked
        })
    }
    handleUserInfo=(data=[])=>{
        console.log('qiuyanlong','data',data);
        const {id,name,pic}=data[0]||{};
        const {isCreate,users,uids,userInfo}=this.state;

        if(isCreate){
            // 创建用users过滤
            if([userInfo,...users].map(item=>item.id).includes(id)) return;
            this.setState(pre=>({
               users:[...pre.users,{id,name,avatar:pic}],
            }))
        }else{
            // 编辑用uids(不能用users,可能会有分页加载没放进users都数据)
            // 超过分页数不放进users，用uids分页加载
            if(uids.includes(id)) return;
            this.setState(pre=>({
                users:pre.uids.length>=pageNum?pre.users:[...pre.users,{id,name,avatar:pic}],
                uids:[...pre.uids,id]
             }))
        }

        this.selectRequest();
    };


    showShowCustomRepeat=(isedit)=>{
        this.setState({
            showCustomRepeat:true,
            customRepeatEdit:!!isedit,
        })
    }

    hideShowCustomRepeat=()=>{
        let selectObj = {};
        const {dicObj:{repeat_types}} = this.state;
        repeat_types && repeat_types.map(item => {
          if(item.selected === 1) selectObj = item
        });
        this.setState({
            showCustomRepeat: false,
            repeat: selectObj.value, // 重置选中
        });
    };

    // 确认自定义重复时间
    getRepeatTime = (repeatTimeObj) => {
      const timeObj = {
        text: repeatTimeObj.repeatTime,
        value: 99,
        selected: 1
      };
      // 处理自定义重复截止时间
      const date = this.locale.getLang()==='zh-CN'? repeatTimeObj.repeatTime.split("于")[1] : repeatTimeObj.repeatTime.split("until")[1];
      const strtime = date+' 23:59:59';
      const repeatEndTime = new Date(strtime).getTime()/1000;
      // 选中
      this.setState({
        repeat: timeObj.value,
        repeatEndTime,
        repeatTimeObj,
      });
      // 更新列表
      const {dicObj:{repeat_types}} = this.state;
      if(repeat_types && repeat_types.length===8) {
        repeat_types.splice(repeat_types.length-1, 0, timeObj);
        repeat_types[0].selected = 0;
      } else if(repeat_types && repeat_types.length===9) {
        repeat_types.splice(repeat_types.length-2, 1, timeObj);
        repeat_types[8].selected = 0;
      }
      // 关闭弹窗
      this.setState({ showCustomRepeat: false })
    };

    render() {
        const {scheduleId} = this.props;
        const {
            full_start, full_end, startTime, endTime, is_full, title, remark, address, files , userInfo, remind_time,repeat,repeatTimeObj,
            userAddShow, loading,isMeeting,meeting_type,groupInfo,
            dicObj: {
                alert_times = [], alert_times_fullday = [],repeat_types=[],
            },
            showCommomModal, CommonModalText, CommonModalType,CommonModalCallback,
            uids,
            isCreate,
            showCustomRepeat,
            customRepeatEdit,
        } = this.state;

        // 添加自定义重复数据
        let idAddOption = false;
        repeat_types.length>0 && repeat_types.map(item => {
          return idAddOption = item.value === 999
        });
        if(!idAddOption){
          repeat_types.push({
            text: this.locale('calendar_create_custom_repeat_title'),
            value: 999,
            selected: 0
          });
        }

        let {users}=this.state;

        users=isCreate?[userInfo,...users]:[...users].sort(sortFunc('id',uids));

        const alertArr = is_full ? alert_times_fullday : alert_times;


        const scheduleAddProps = {
            full_start, full_end, startTime, endTime, title, remark, address, files, isMeeting,meeting_type,
            remind_time:remind_time.sort(function(a,b){return a-b}),
            repeat_types,
            is_full,
            // isMeeting,
            scheduleId,
            users:users.map(item=>item.id===userInfo.id?{...item,disabled:true}:item),
            alertArr,
            repeat,
            closeShowAdd:this.handleCloseShowAdd,
            onFullChange: this.commonChange,
            handleInputChange: this.handleInputChange,
            handleShowUserAdd: this.handleShowUserAdd,
            onCheckboxChange: this.onCheckboxChange,
            handleFile: this.handleFile,
            handleFileDelete: this.handleFileDelete,
            handlePeopleDelte: this.handlePeopleDelte,
            preCheck: this.preCheck,
            handleSelectChange: this.handleSelectChange,
            handleSelectRepeat: this.handleSelectRepeat,
            showImg,
            container:this.container,
            titleInput:this.titleInput,
            handleMaiDian : this.handleMaiDian,
            handleMeetingChange:this.handleMeetingChange,
            handleMeetingType:this.handleMeetingType,



            loadingText:        this.state.loadingText,
            isCreate:           this.state.isCreate,
            scheAttr:           this.state.scheAttr,
            setguild:           this.state.setguild,
            handleScheduleAttr: this.handleScheduleAttr,
            handleUserInfo:     this.handleUserInfo,
            showMask:           window.createSheduleFrom === 'im' ||  window.createSheduleFrom === 'office' ?true:false,

            // 冲突部分
            rendertime:         this.rendertime,
            renderline:         this.renderline,
            conData:            this.state.conData,
            dyscnowtime:        this.state.dyscnowtime,
            computeHeight:      this.computeHeight,
            initDate:           this.props.initDate,
            defaultToday:       this.state.defaultToday,
            toggleDay:          this.toggleDay,
            isToday:            this.state.isToday,
            comeToToday:        this.comeToToday,
            conflictup:         this.state.conflictup,
            uptoup:             this.uptoup,
            setConflictArea:    this.setConflictArea,
            conflictext:        this.state.conflictext,
            over_50:            this.state.over_50,
            innertext:          this.state.innertext,
            isShowConflictArea: this.isShowConflictArea,
            locale:             this.locale,
            contentControllerWidth: this.state.contentControllerWidth,
            isConflict:         this.state.isConflict
        }

        const userIds = !isCreate ? uids.filter( item=>item !== userInfo.id ) :users.filter(item => item.id!== userInfo.id).map(item=>item.id);

        const userAddProps = {
            type: groupInfo.id?'members':'creatGroup',
            loading: loading,
            show: userAddShow,
            onOk: this.okUserAdd,
            onClose: this.closeUserAdd,
            disabledids: [userInfo.id],
            checkedids:  userIds,
            title: this.locale('calendar_useradd_info_title'),
            leftTitle: this.locale('calendar_useradd_info_lefttitle'),
            rightTitle: this.locale('calendar_useradd_info_righttitle'),
            maxLength: 5001
        };

        const showCustomRepeatProps={
            full_start,customRepeatEdit,repeatTimeObj,
            hideShowCustomRepeat:this.hideShowCustomRepeat,
            getRepeatTime:this.getRepeatTime,
        }

        return (
            <div onMouseDown={e => e.stopPropagation()} id='createScheduleOut'>
                <ScheduleAdd {...scheduleAddProps}/>
                <UserAdd {...userAddProps} />
                <AddTipModal
                    close={this.toggleCommonModal}
                    text={CommonModalText}
                    type={CommonModalType}
                    callback={!CommonModalCallback ? (this.state.isNotice ? () => {this.toggleCommonModal();this.noticeDialog()} : this.handleSubmit) : CommonModalCallback}
                    visible={showCommomModal}
                    dropout={this.state.dropout}
                />
                {showCustomRepeat&&<CustomRepeat{...showCustomRepeatProps}/>}
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        initDate:state.calender.initDate,
        createDate:state.calender.create_schedule
    };
};

export default connect(
    mapStateToProps,
    null
)(ScheduleAddContainer);
