/*
 * @Descripttion:
 * @version:
 */

import React from 'react';
import css from './index.scss';
import { Select } from 'antd';
import { locale } from '@u/util.js';

const {Option}=Select;

function genOption(arr) {
    return arr.map((item) => {
        const { text, value } = item;
        return (
            <Option key={value} value={value}>
                {text}
            </Option>
        );
    });
}

const Arr30 = Array.from({ length: 30 }, (item, index) => ({ value: index + 1, text: index + 1 }));
const Arr10 = Array.from({ length: 10 }, (item, index) => ({ value: index + 1, text: index + 1 }));

const Arrfrequency = locale('calendar_create_custom_repeat_alternation')
    .split(',')
    .map((item, index) => ({ text: item, value: index + 1 }));
const customTimeWeek = locale('calendar_chinese_day_text_6')
    .split(',')
    .map((item, index) => ({ text: item, value: index }));
// 处理周数据
customTimeWeek.map(item => {if(item.value === 0) item.value = 7})
const customTimeMonth = Array.from({ length: 31 }, (item, index) => ({ value: index + 1, text: index + 1 }));


export default (props) => {
    const {
        frequency,
        alternation,
        customTime,
        handleSelectFrequency,
        handleSelectAlternation,
        handleSelectCustomTime,
    } = props;

    const frequencyOption = alternation == 1 || alternation == 2 ? Arr30 : Arr10;

    return (
        <div className={css.out}>
            <div className={css.top}>
                <span>{locale('calendar_create_custom_repeat_title1')}</span>
                <div className={css.select}>
                    {
                        locale.getLang()==='zh-CN'&&<em>每</em>
                    }
                    <div className={css.selectOut}>
                        <Select
                            value={frequency}
                            className={css.selectMultiple}
                            onChange={handleSelectFrequency}
                            suffixIcon={
                                <span
                                    className={`${css.selectIcon} iconfont-yach yach-0428-richeng-xialakuangneijiantou-shouqi`}
                                />
                            }
                        >
                            {genOption(frequencyOption)}
                        </Select>
                        <Select
                            value={alternation}
                            className={css.selectMultiple}
                            onChange={handleSelectAlternation}
                            suffixIcon={
                                <span
                                    className={`${css.selectIcon} iconfont-yach yach-0428-richeng-xialakuangneijiantou-shouqi`}
                                />
                            }
                        >
                            {genOption(Arrfrequency)}
                        </Select>
                    </div>
                </div>
            </div>
            {alternation === 2 && (
                <div className={css.week}>
                    {customTimeWeek.map((item) => {
                        const { text, value } = item;
                        return (
                            <div
                                key={value}
                                onClick={handleSelectCustomTime.bind(null, value)}
                                className={customTime.includes(value) ? css.active : null}
                            >
                                {text}
                            </div>
                        );
                    })}
                </div>
            )}
            {alternation === 3 && (
                <div className={css.month}>
                    {customTimeMonth.map((item) => {
                        const { text, value } = item;
                        return (
                            <div
                                key={value}
                                onClick={handleSelectCustomTime.bind(null, value)}
                                className={customTime.includes(value) ? css.active : null}
                            >
                                {text}
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};
