import React, { Component } from 'react';
import {connect} from 'react-redux';
import {shareModelState} from '@r/actions/calender';
import UserAdd from '@c/common/user-add/user-add-container';
import AddTipModal from './../common/addTipModal';
import {ShareMySchedule} from './schedule-share';
import {scheduleAddAndDelete,scheduleSubscriptionSettings,scheduleSubscriptionFollowers,scheduleGetMySharer,scheduleChangeVote} from "@/services/schedule/schedule";
import * as util from '@u/util.js';
import {message} from 'antd';
import {showGloading,hideGloading} from '@r/actions/commonLoading'



export class sheduleShareContainer extends Component {
    state = {
        showselect:false, 
        showStopShareOne:false,
        hasSelected:[], 
        tabkey:0,
        subscriptionPermission:'2',
        dataList:[]
    }

    componentDidMount(){
        this.getMyShareLists();
    }


    componentWillUnmount(){
        this.props.dispatch(shareModelState(false));
    }


    // 展示选择人组件
    showSelectPeople = (b)=>{ 
        const {dataList} = this.state;
        const uids =  dataList.map(item=>item.uid+'')||[];
        this.setState(state=>({
            showselect: true,
            hasSelected: [...uids]
        }))
    }
    // 关闭选择人组件
    onClose = ()=>{
        this.setState({
            showselect: false,
        });
    }

    // 选择人的回调函数 选人组件确认按钮
    selected = async (res)=>{
        //console.log('我的选择',res);
        await this.props.dispatch(showGloading());
        const {allDataUsers} = res;
        const { dataList } = this.state;
        const uid = allDataUsers.map(item=>item.id);
        const storeUid = dataList.map(item=>item.uid);

        if(uid.sort().toString() !== storeUid.sort().toString()){
            this.setState(state=>({
                showselect: false
            }),()=>{
                this.addOrRemoveSharer(uid.join(),1, storeUid.length - uid.length );
            });
        }
        else{
            this.setState(state=>({
                showselect: false
            }));
            this.props.dispatch(hideGloading());
        }   
    }

    // 关闭共享组件model
    closeShareModel = ()=>{
       this.props.dispatch(shareModelState(false));
    }

    // 关闭弹窗  是否解除共享联系人
    toggleCommonModal = (b)=>{
        this.setState({ showStopShareOne:b });
    }

    addOrRemoveSharer = async (uids,op,hasAdd) => {
        if(!uids){
            message.error(this.locale('calendar_toast_share_illegalid') + msg);
            return 
        }
        const removeOne = await scheduleAddAndDelete({uids,op});
        const { code, msg } = removeOne || {};
         if(code === 200){
            //  op === 2 ?this.toggleCommonModal(false):null;
             if(op === 2) this.toggleCommonModal(false);
             this.getMyShareLists();
             op === 2 ? message.success(this.locale('calendar_toast_delete_success')) : hasAdd >=1 ? message.success(this.locale('calendar_toast_delete_success')): message.success(this.locale('calendar_toast_add_success'));
         }
         else{
             message.error(this.locale('calendar_toast_add_wrong'));
             
         }
        this.props.dispatch(hideGloading());
    }
    
    // 确定解除共享联系人 回调
    CommonModalCallback = async ()=>{
        const uids = this.state.showStopShareOne;
        this.addOrRemoveSharer(uids,2);
    }

    openCard = uid => {
        util.yach.showUserinfo(id);
    }

     // 获取我的共享人列表
     getMyShareLists  = async ()=>{
        this.props.dispatch(showGloading());
        const myshareLsit = await scheduleGetMySharer();
        const {code, msg, obj = []} = myshareLsit || {};
        if(code === 200){
            const dataList=await util.yach.base64ImgArrGetTmp(obj,'avatar');
            this.setState({
                dataList
            })
        }
        else{
            message.error(msg);
        }
        this.props.dispatch(hideGloading());
    }

    getSubscriptionFollowers= async ()=>{
        this.props.dispatch(showGloading());
        const s= await scheduleSubscriptionFollowers();
        const {code, msg, obj:{list,permission}} = s || {};
        if(code !== 200){
            message.error(msg);
        }else{
            const dataList=await util.yach.base64ImgArrGetTmp(list,'avatar');
            this.setState({
                subscriptionPermission:permission+'',
                dataList
            })
        }
        this.props.dispatch(hideGloading());
    }

    // 切换tab
    setTabkey=(value)=>{
        this.setState({
            tabkey:value
        },()=>{
            // 请求列表
            const {tabkey}=this.state;
            if(tabkey=='1'){
                this.getSubscriptionFollowers();
            }else{
                this.getMyShareLists();
            }
        })
    }

    // 设置订阅权限
    setSubscriptionPermission= async(value)=>{
        const s = await scheduleSubscriptionSettings({permission:value})
        const {code, msg} = s || {};
        if(code !== 200){
            message.error(msg);
        }else{
            message.success(this.locale('calendar_toast_setting_success'));
            this.setState({
                subscriptionPermission:value,
            })
        }
    }

     // 设置分享给当前用户的权限设置 
    doPermission = async (v,uid)=>{
        if(!v || !uid) {
           message.error(this.locale('calendar_toast_share_userinfo_wrong'));
           return;
        }
        const setV = await scheduleChangeVote({uid,permission:v})
        const {code, msg} = setV || {};
        if(code !== 200){
            message.error(msg);
        }else{
            message.success(this.locale('calendar_toast_setting_success'));
            this.getMyShareLists();
        }
}

    render() {
        const {tabkey,subscriptionPermission,dataList}=this.state;
        const userAddProps = {
            type: 'creatGroup',
            loading: false,
            show: this.state.showselect,
            onOk: this.selected,
            onClose: this.onClose,
            disabledids: [this.props.userInfo.id +''],
            checkedids:  this.state.hasSelected,
            title: this.locale('calendar_useradd_share_title'),
            leftTitle: this.locale('calendar_useradd_share_lefttitle'),
            rightTitle: this.locale('calendar_useradd_info_righttitle'),
            maxLength: 101
        };
        

        return (
          <>
            <UserAdd {...userAddProps} />
            <ShareMySchedule 
                freshValue = {this.state.freshValue}
                updateFreshValue = {this.updateFreshValue}
                closeShareModel={this.closeShareModel}
                toggleCommonModal = {this.toggleCommonModal}
                showSelectPeople={this.showSelectPeople}
                openCard = {this.openCard}
                tabkey = {tabkey}
                setTabkey = {this.setTabkey}
                subscriptionPermission = {subscriptionPermission}
                setSubscriptionPermission = {this.setSubscriptionPermission}
                dataList={dataList}
                doPermission = {this.doPermission}
                locale={this.locale}

            />
            <AddTipModal
                close={()=>{this.toggleCommonModal(false)}}
                text= {this.locale('calendar_confirm_delete_share')}
                tipText= ' '
                callback= {this.CommonModalCallback}
                visible= {this.state.showStopShareOne}
            />
          </>
        );
    }
}

const mapStateToProps = (state) =>{
    return{
        userInfo            : state.userInfo,
    }
};

export default connect(mapStateToProps, null)(sheduleShareContainer);
