import ReactDOM from 'react-dom';
import React, { Component } from 'react';
import {scheduleLineHeight,lineMinHeight} from '../../../lib/commonTmp';
import FastCreateCard from '../fastcreate-card';
import css from './index.scss';

// 快捷创建的参数
const fastCreatePopup={
    w:446,
    h:278,
    p:8
}

/**
 * @description: fastcreate位置计算
 * @author: 李超
 */
const calcFastCreatePos=(params={})=>{
    const {target,type}=params;
    const {top,left,right,width,height}=target.getBoundingClientRect();
    const {w,h,p}=fastCreatePopup;

    let fastTop=0,
        fastLeft=0;

    if(type==='day'){
        if(top < h + p + 10){  // 弹框高度(278) 间距（8）不紧挨在最上面（间距10）
            fastTop=top + lineMinHeight +p; //条高度（17）/间距（8）
            fastLeft=left;
        }
        else{
            fastTop=top - h - p; //弹框高度（278）/间距（8）
            fastLeft=left;
        }
    }else if(type==='month'||type==='week'){
        let docw = document.body.clientWidth;
     
        if(top < h + p + 10){  // 弹框高度(278) 间距（8）不紧挨在最上面（间距10）
            fastTop = top //条高度（17）/间距（8）
        }
        else{
            fastTop = top+height - h  //弹框高度（278）/间距（8）
        }

        if(docw-right > w + p + 10){  // 弹框高度(278) 间距（8）不紧挨在最上面（间距10）
            // 右边
            fastLeft = right + p;
        }else if(left-80> w + p + 10){
            // 左边
            fastLeft = left - w - p //弹框高度（278）/间距（8）
        }else{
            // 中间
            fastLeft = left + width/2 - w/2;
            fastTop = fastTop<top?fastTop-height-p:fastTop+height+p;
        }
        
    }
    
    return{
        top:fastTop,
        left:fastLeft
    }
}

class Index extends Component {
    constructor(props) {
        super(props);
        this.state = {
            anchorPosition: {
                top:0,
                left:0
            },
            fastTimeLine:[],
            pos:{},
            showCard:false,
        };
    }

    componentDidMount(){
        const {type}=this.props.fastCreateData;
        const {anchorPosition,fastTimeLine}=type==='month'?this.computerAnchorPositionMonth():this.computerAnchorPosition();
        this.setState({
            anchorPosition,
            fastTimeLine,
            },() => {
                // 渲染 anchor div之根据这个div再做处理
                const pos = calcFastCreatePos({ target: this.fastdiv, type });
                this.setState({
                    pos,
                    showCard:true,
                })
            }
        );
    }

    // 月视图位置 时间
    computerAnchorPositionMonth=()=>{
        const {date,anchorLeft,anchorTop} = this.props.fastCreateData;
        return {
            fastTimeLine:[`${date} 00:00:00`, `${date} 23:59:59`],
            anchorPosition:{top:anchorTop,left:anchorLeft}
        }
    }


    // 计算日/周 anchor位置 和快捷创建的起止时间
    computerAnchorPosition = () => {
        const { hourNum, date,anchorLeft=0 } = this.props.fastCreateData;
        let c = hourNum - (hourNum << 0) <= 0.5;
        let top = 0,
            fastTimeLine = [];
        if (c) {
            top = Math.floor(hourNum) * scheduleLineHeight;
            fastTimeLine = [`${date}` + Math.floor(hourNum) + ':00', `${date}` + Math.floor(hourNum) + ':30'];
        } else {
            top = Math.floor(hourNum) * scheduleLineHeight + scheduleLineHeight / 2;
            const endNum=Math.ceil(hourNum);
            fastTimeLine = [`${date}` + Math.floor(hourNum) + ':30', `${date}` + (endNum==24?'23:59': (endNum+ ':00'))];
        }

        return {
            anchorPosition:{top,left:anchorLeft},
            fastTimeLine
        }
    };


    render() {
        const {anchorPosition,pos,fastTimeLine,showCard}=this.state;
        const {onClose,onOpenScheduleAdd,onSubmit}=this.props;
        const {type,date}=this.props.fastCreateData;
        return (
            <>
                <div
                    className={`${css.anchor} ${css[type+'anchor']}`}
                    style={{
                        ...anchorPosition,
                        height: scheduleLineHeight / 2,
                        lineHeight: scheduleLineHeight / 2 + 'px',
                    }}
                    ref={(e) => {this.fastdiv = e;}}
                >
                    {this.locale('calendar_day_layout_notitle')}
                </div>
                {
                    showCard&&ReactDOM.createPortal(<FastCreateCard {...{date,type,fastTimeLine,pos,onClose,onOpenScheduleAdd,onSubmit}} />, document.body)
                }
            </>
        );
    }
}

export default Index;

