// react
import React, { useRef } from 'react';
import { Switch, Dropdown } from 'antd';
// util
import * as util from '@u/util.js';
// css
import css from './index.scss';

// BoxOperation
export default function ScheduleSetting(props) {

    const groupRef = useRef();

    const {
        disnotice,
        isTop,
        onFixtop,
        onNodisturb,
        locale,
        id,
        onMachineTranslation,
        isTranslation,
        showAutoTranslation,
        effectMode,
        groupName,
        effectMenu,
    } = props;
    return (
        <div className={css.box}>
            <div className={css.bottom} id="groupExit">
                {
                    effectMode ? (
                        <Dropdown overlay={effectMenu(disnotice)} 
                            trigger={['click']} 
                            overlayClassName={css.EffectMenuWrapBox}
                            getPopupContainer={() => document.getElementById('groupExit')}
                            placement="bottomRight"
                        >
                            <p className={css.exit} ref={groupRef}>
                                <span>{util.locale('im_effect_mode_text_23')}</span>
                                <span className={css.exitChBox}>
                                    <span className={css.groupName}>{groupName}</span>   
                                    <span className={`${css.exit_icon} iconfont-yach yach-quanju-qunshezhi-youcedianji`} ></span>
                                </span>
                            </p>
                        </Dropdown>
                    ) : null
                }
                <p>
                    <span>{locale('calendar_assistant_setting_totop')}</span>
                    <Switch checked={isTop && true} onChange={onFixtop} />
                </p>
                {/* id为3004说明是日程助手，为其他值说明是机器人 */}
                {id != 3004 && showAutoTranslation && (
                    <p className={css.autoTranslation}>
                        <span>{locale('im_auto_translation')}</span>
                        <Switch checked={!!isTranslation} onChange={onMachineTranslation} />
                    </p>
                )}
                {id != 3004 && showAutoTranslation && <p className={css.autoTranslationMsg}>{locale('im_MWTPLA')}</p>}
                <p>
                    <span>{locale('calendar_assistant_setting_disnotice')}</span>
                    <Switch checked={disnotice} onChange={onNodisturb} />
                </p>
            </div>
        </div>
    );
}
