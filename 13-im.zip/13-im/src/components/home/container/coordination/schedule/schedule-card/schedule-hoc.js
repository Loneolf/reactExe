/*
 * @Descripttion: 
 * @Author: qiuyanlong@100tal.com
 * @Date: 2020-04-18 16:38:08
 */
import React, { Component } from 'react';
import ReactDOM from  'react-dom';

import css from './index.scss';

export default WrapperComponen =>{
    return class extends Component{

        constructor(props){
            super(props);

            if(!this.node){
                this.node = document.createElement('div');
                document.body.appendChild(this.node);
            }
        }

       componentWillUnmount(){
           this.node && this.node.remove();
       }

       renderContent = ()=>{
           return(
               <div>
                   <div className={css.bg}></div>
                   <WrapperComponen {...this.props} />
               </div>
           )
       }

       render(){
           const {show} =  this.props;
           if(show){
               return (
                   this.node && ReactDOM.createPortal(this.renderContent(),this.node)
               )
           }
           else
                return null;
       }

    }
}
