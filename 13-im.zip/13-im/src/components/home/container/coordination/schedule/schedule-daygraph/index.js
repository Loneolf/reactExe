/*
 * @Descripttion:
 * @Date: 2019-09-15 10:52:56
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as sUtil from '../../lib/until';
import { toggleSelectCard, createSchdule, setFastCreatSchedule, setScheduleCard,initViewDate } from '@r/actions/calender';
import { showSlideModal } from '@/redux/actions/commonModal';
import * as util from '@u/util.js';
import DayEventList from './../schedule-eventlist';
import _ from 'lodash';
import { Spin } from 'antd';
import { NewDateLine } from './synctime/index';
import FastCreateSchedule from '../schedule-fastcreate';
import * as co from './../../lib/unit-core';
import css from './index.scss';
import ScheduleEventRender from '../common/scheduleEventRender';


const { initAllNum } = sUtil;
const { envConstComputer,scheduleLineHeight } = co;

let count = 0;

class DayGraphy extends Component {
    constructor(props) {
        super(props);
        this.timeoutIDClick = null; // 单击和双击定时器
        this.state = {
            t: [...initAllNum()],
            drag: false,
            initY: 0,
            dragstyle: {
                top: 0,
                bottom: 0,
                height: 0,
            },
            selectTime:'11:00 - 12:00',
        }
    }  
      
    // 遍历当天的全天事件   
    static eventlistFilter = (list)=>{
        let isFull = [];
        let notFull = [];
        if (!list.length) return { isFull, notFull };
        list.forEach((item) => {
            if (!!item.is_full || item.package_info.source === 9) {
                isFull.push(item);
            } else {
                notFull.push(item);
            }
        });
        return { isFull, notFull };
    };

    shouldComponentUpdate(nextProps, nextState) {
        if (_.isEqual(this.props, nextProps) && _.isEqual(this.state, nextState)) {
            return false;
        } else {
            //console.log('nextProps, nextState--',nextProps, nextState);
            return true;
        }
    }

    componentDidMount() {
        !!window.store.getState().calender.monthAndDayList.day && sUtil.setScrollDayViewHeight();
        util.sensorsData.track('PageView_MainPage', { pageName: 104, ViewType: 101 });
    }

    componentDidCatch(error, errorInfo) {
        console.log('日程月视图产生错误日志:');
        console.error(error, errorInfo);
    }

    componentWillUnmount(){
        document.onmousemove = null;
        document.onmouseup = null;
        this.props.setFastCreatSchedule({show:false});
        this.setState = (state, callback) => {
            return;
        };
    }

    scheduleInfo = ({id,source}) => {
        this.props.showSlideModal('scheduleInfo', {id,source});
    };

    // 点击事件 需要优化 1
    checkAllDayCard = (type, item, ievent, config) => {
        count += 1;
        ievent.persist();
        let Sevent = ievent;
        setTimeout(() => {
            if (count === 1) {
                let { selectcard } = this.props;
                selectcard.isshow &&
                    this.props.toggleSelectCard({ isshow: ![], type: '', item: {}, ievent: {}, config: {} });
                this.props.toggleSelectCard({ isshow: !0, type, item, ievent: Sevent, config });
            }
            if (count === 2) {
                let { id, package_info } = item;
                this.onDoubleClickfn(id, package_info.source, Sevent);
            }
            count = 0;
        }, 200);
        util.sensorsData.track('Click_ScheduleMain_Detail');
    };

    checkAllDayCard2 = (type, item, styles) => {
        console.log('点击了', type, item, styles);
        this.props.setScheduleCard({ show: true, type, item, styles });
    };

    onDoubleClickfn(id, source, event) {
        // 要在清楚定时器的后面，先干掉单击事件的冒泡！
        if (source && (source === 9 || source === 2)) return;
        this.scheduleInfo({id,source}); // 传统节假日 共享  无详情
        event.nativeEvent.stopImmediatePropagation();
    }

    // 双击
    doubleClick = async (event) => {
        clearTimeout(this.timeoutIDClick);
        this.setState((state) => ({ drag: false }));
        let scroll_t = this.scrolldiv.scrollTop;
        let allday_h = this.alldayDiv ? this.alldayDiv.clientHeight : 0;
        let t = co.clickPositionComputer({clientY:event.clientY,scroll_t,allday_h,type:'day'}) / scheduleLineHeight;

        if (t>= 24||t<=0) return;
        if (t>23) t=23;

        await this.props.createSchdule({ from: 'double', time: [t, t + 1] });
        this.props.scheduleAdd();
    };

    // 单击
    clickSchedule = (event) => {
        event.persist();
        clearTimeout(this.timeoutIDClick);
        this.timeoutIDClick = setTimeout(() => {
            if(this.props.scheduleAddShow) return;
            const scroll_t = this.scrolldiv.scrollTop;
            const allday_h = this.alldayDiv ? this.alldayDiv.clientHeight : 0;

            const startT=co.clickPositionComputer({clientY:event.clientY,scroll_t,allday_h,type:'day'});
            const ms = startT / scheduleLineHeight;

            if (ms >= 24||ms<=0) return;

            const { year, month, day } = this.props.initDate;
            const initTimeS = `${year}-${sUtil.fm(month + 1)}-${sUtil.fm(day)} `;
            this.props.setFastCreatSchedule({
                show:true,
                data:{
                    type:'day',hourNum:ms,date:initTimeS,anchorLeft:0
                }
            })

            event.nativeEvent.stopImmediatePropagation();
       },200); 
    }


    // right 整体区域 mouseleave 事件
    cancelDragfn = () => {
        this.setState((state) => ({
            drag: false,
        }));
        document.onmousemove = null;
        document.onmouseup = null;
    };

    // 移动
    mouseDownfn = (event) => {
        const y=event.clientY;
        const scroll_t = this.scrolldiv.scrollTop;
        const allday_h = this.alldayDiv ? this.alldayDiv.clientHeight : 0;
        const stratTop=co.clickPositionComputer({clientY:y,scroll_t,allday_h,type:'day'});
        let startT = stratTop / scheduleLineHeight; 

        let inputs = '';
        let inpute = '';
        let startTime = +new Date();
        // down
        this.setState((state) => ({
            initY: y,
        }));

        document.onmousemove = (eve) => {
            this.setState((state) => ({
                drag: true,
            }));
            let _tem = eve.clientY;
            let endT = co.clickPositionComputer({clientY:_tem,scroll_t,allday_h,type:'day'})/scheduleLineHeight;

            // 上下拖拽边界值处理
            if (startT <= 0) {
                startT = 0;
            }

            if (endT <= 0) {
                endT = 0;
            }

            if (endT > 24) {
                endT = 23.5;
            }

            
            inputs= util.moment().startOf('day').add(co.dragCustomRound(startT),'h').format('HH:mm');
            inpute= util.moment().startOf('day').add(co.dragCustomRound(endT),'h').format('HH:mm');

            // down
            if (_tem - y > 0) {
                if (this.state.drag) {
                    let h = parseInt(eve.clientY - this.state.initY);
                    this.setState((state) => ({
                        dragstyle: { ...state.dragstyle, top: stratTop, height: h },
                        selectTime: `${inputs} - ${inpute}`,
                    }));
                }
            }
            // up
            else {
                let h = parseInt(this.state.initY - eve.clientY);
                this.setState((state) => ({
                    dragstyle: {
                        ...state.dragstyle,
                        height: h,
                        top:co.clickPositionComputer({clientY:eve.clientY,scroll_t,allday_h,type:'day'}),
                    },
                    selectTime: `${inpute} - ${inputs}`,
                }));
            }
            return false;
        };

        document.onmouseup = (eve) => {
            if (y === eve.clientY || Math.abs(eve.clientY - y) < scheduleLineHeight/2 || +new Date() - startTime <= 250) {
                this.setState((state) => ({
                    drag: false,
                }));
                document.onmousemove = null;
                document.onmouseup = null;
                eve.preventDefault();
                return false;
            }
            try {
                eve.preventDefault();
                let endT =co.clickPositionComputer({clientY:eve.clientY,scroll_t,allday_h,type:'day'})/scheduleLineHeight;

                endT <= 0 && (endT = 0);
                endT > 24 && (endT = 23.5);
                
                document.onmousemove = null;
                document.onmouseup = null;

                startT=co.dragCustomRound(startT);
                endT=co.dragCustomRound(endT);

                if(endT==startT) {
                    this.setState({
                        drag: false,
                    });
                    return false;
                }


                startT > endT
                    ? this.props.createSchdule({ from: 'drag', time: [endT, startT] })
                    : this.props.createSchdule({ from: 'drag', time: [startT, endT] });

                this.props.scheduleAdd();
                this.setState((state) => ({
                    drag: false,
                    initY: 0,
                    dragstyle: {
                        top: 0,
                        height: 0,
                    },
                }));
            } catch (e) {
                console.log('drag has an opps,please check your drag fauntion');
                this.setState(
                    (state) => ({
                        drag: false,
                    }),
                    () => {
                        this.props.createSchdule({ from: 'create', time: [] });
                        this.props.scheduleAdd();
                    }
                );
            }
        };

    };

    allDayEventRender = (list) => { 
        let renderlist = [];
        for (let i = 0; i < list.length; i++) {
            let item = list[i];
            let { id } = item;
            if(renderlist.findIndex(item=>item.key ===id) !==-1 ) {break;}  
             
            renderlist[renderlist.length] = <ScheduleEventRender item={item} type='allday' checkAllDayCard={this.checkAllDayCard}/>
        }
        return renderlist;  
     }

    // originDataAction = () => {
    //     let { eventList } = this.props;
    //     let { list, layout } = eventList;
    //     const RamArray = [];

    //     !!Object.keys(layout).length &&
    //         layout.forEach((mt) => {
    //             !!mt.list.length &&
    //                 mt.list.forEach((item) => {
    //                     // 查找的时候需要注意，当月的数据也有可能包括下个月的数据。或者其他月的，跨天重复事件，虽然这次不做重复事件
    //                     let ind = item.index;
    //                     if (!!list[ind] && list[ind].is_full !== 1 && list[ind].package_info.source !== 9) {
    //                         //去掉全天日程和中国节假日
    //                         let b = list[ind].begin_time;
    //                         let e = list[ind].finish_time;

    //                         list[ind].begin_time = b - (b % 60);
    //                         list[ind].finish_time = e - (e % 60);

    //                         if (e - b < 1800) {
    //                             list[ind]['real_finish_time'] = list[ind].finish_time;
    //                             list[ind].finish_time = Number(list[ind].finish_time) + 1800 - (e - b);
    //                         }

    //                         RamArray[RamArray.length] = list[ind];
    //                     }
    //                 });
    //         });
    //     return RamArray;
    // };


    originDataAction = (time) => {
        let { eventList } = this.props;
        let { list, layout } = eventList;
        const RamArray = [];

        !!Object.keys(layout).length &&
            layout.forEach((mt) => {
                !!mt.list.length &&
                    mt.list.forEach((item) => {
                        // 查找的时候需要注意，当月的数据也有可能包括下个月的数据。或者其他月的，跨天重复事件，虽然这次不做重复事件
                        let ind = item.index;
                        if (!!list[ind] && list[ind].is_full !== 1 && list[ind].package_info.source !== 9) {
                            RamArray[RamArray.length] = co.handleOriginData(list[ind],time);
                        }
                    });
            });
        return RamArray;
    };

    DataFactoryCenters = () => {
        let {  initDate, day_isloading } = this.props;
        if (!day_isloading) return;

        let { year, month, day } = initDate;
        let startTime = sUtil.timemillions(year, month, day, 0, 0, 0); // 当天的开始点 ->ui 最高点
        let endTime = sUtil.timemillions(year, month, day, 23, 59, 59); // 当天的结束点 ->ui 最低点
        const time={endTime,startTime};
        return co.DataFactoryFn({originData:this.originDataAction(time),kind:'day',time,checkAllDayCard:this.checkAllDayCard});
    };

    // 画线   onMouseMove = {this.mouseMovefn}
    renderline = () => {
        let s = [];
        for (let i = 0; i < 24; i++) {
            s.push(
                <div
                    className={css.line}
                    style={{height:scheduleLineHeight}}
                    key={i}
                    onClick={this.clickSchedule}
                    onMouseDown={(e) => this.mouseDownfn(e)}
                    onDoubleClick={this.doubleClick}
                ></div>
            );
        }
        return s;
    };

    changetimet = (t) => {
        let data;
        if (t === 'sync') {
            data = [...initAllNum()];
        } else {
            data = this.state.t.map((v) => {
                v == t && (v = ' ');
                return v;
            });
        }

        this.setState((state) => ({
            t: data,
        }));
    };

    rendertime = () => {
        return this.state.t.map((item, index) => (
            <div key={item} style={{height:scheduleLineHeight}} className={css.item} data-tid={`t-${index + 1}`}>
                <span>{item}</span>
            </div>
        ));
    };

    rendertime2 = () => {
        const t = initAllNum();
        return t.map((item, index) => (
            <div key={item} style={{height:scheduleLineHeight}} className={css.item} data-tid={`t-${index + 1}`}>
                <span>{item}</span>
            </div>
        ));
    };

    render() {
        const {eventList,initDate,selectcard} = this.props;  // 全天事件就直接拿list里面的数据
        let   { year,month,day } = initDate;
        const alldaydate = DayGraphy.eventlistFilter(eventList.list).isFull;

        let today = new Date();
        let _year = today.getFullYear();
        let _month = today.getMonth();
        let _day = today.getDate();
        let bswitch = false;

        if (_year === year && month === _month && day === _day) {
            bswitch = true;
        }

        return (
              <div className={css.wrapcontent} >
                 <div className={css.centerdate} >
                     
                    { (selectcard.isshow) && <div className="calender_fastcreatMask"></div>}

                    { 
                        !this.props.day_isloading && <div className={css.daygraph_loading} > 
                            <Spin  className="iconfont" style={{fontSize:20}}/>
                        </div> 
                    }
                    {
                        alldaydate.length!==0 && <div className={css.allDay}  ref={alldayDiv=>{this.alldayDiv=alldayDiv} } > 
                                <div className={css.alldayl}><span>{this.locale('calendar_day_layout_allday')}</span></div>     
                                <div className={css.alldayline}>{this.allDayEventRender(alldaydate)}</div>   
                        </div>   
                    }
                    <div className={css.cawrap} id="graph_scrollDiv"  ref={scrolldiv=>{this.scrolldiv=scrolldiv} }>
                        <div className={css.out}>
                            <div className={css.left}>
                                <div className={css.timelist}>{ bswitch ? this.rendertime(): this.rendertime2()}</div>
                            </div> 
                            <div className={css.right} onMouseLeave={this.cancelDragfn}  >
                                <div className={css.con} >{ this.renderline()}</div>
                                <FastCreateSchedule />
                                <div className={css.fliter}>
                                    {this.state.drag ? (
                                        <div 
                                            ref={dragele=>{this.dragele=dragele} }
                                            className={css.draggearea} 
                                            style={this.state.dragstyle}
                                        >
                                            <p>{this.state.selectTime}</p>
                                        </div>
                                    ):null}
                                    <React.Fragment>
                                        { 
                                            this.DataFactoryCenters()
                                        }
                                        { bswitch && <NewDateLine {...{year,month,day,changetimet:this.changetimet,getEventListTime:this.props.getEventListTime,initViewDate:this.props.initViewDate}} /> }
                                    </React.Fragment> 
                                </div>
                            </div>
                        </div>
                </div>
             </div>
            
            <DayEventList {...{initDate,eventList,locale:this.locale,showVideoSessioneModal:this.props.showVideoSessioneModal,showSlideModal:this.props.showSlideModal}} />
           </div> 
        );
    }
}

const mapStateToProps = (state) => {
    return {
        initDate: state.calender.initDate,
        eventList: state.calender.eventList,
        refreshv: state.calender.refreshv,
        selectcard: state.calender.selectcard,
        fastCreateSchedule: state.calender.fastCreateSchedule,
        scheduleAddShow:state.calender.scheduleAdd.show,
    };
};

const mapDispatchToProps = {
    setFastCreatSchedule,
    showSlideModal,
    toggleSelectCard,
    setScheduleCard,
    createSchdule,
    initViewDate,
};

export default connect(mapStateToProps, mapDispatchToProps)(DayGraphy);
