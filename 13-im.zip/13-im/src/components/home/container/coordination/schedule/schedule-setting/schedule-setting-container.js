// react
import React from 'react';
import { connect } from 'react-redux';
// util
import * as util from '@/utils/util';
// services
import { sessionTopAdd, sessionTopCancel, setAutoMachineTranslation } from '@/services/session/session';
// antd
import { Menu} from 'antd';
// component
import ScheduleSetting from './schedule-setting';
import { renderCustomMenu } from './../../../im/im-list/group-menu';
// css
import css from './index.scss';
// BoxOperationContainer
class ScheduleSettingContainer extends React.Component {
    state = {};

    componentDidMount() {}
    // 置顶
    handleFixtop = async (value) => {
        // const { id } = this.props.sessionActive;
        const { id } = window.session_active;
        if (value) {
            await util.nim.handleFixtop(id, true);
            sessionTopAdd({ top_id: id });
            this.uploadSensorsClickData(168);
        } else {
            await util.nim.handleFixtop(id, false);
            sessionTopCancel({ top_id: id });
            this.uploadSensorsClickData(169);
        }
    };

    // 消息免打扰
    handleNodisturb = (value) => {
        // const { id, type } = this.props.sessionActive;
        const { id, type } = window.session_active;
        if (value) {
            util.nim.handleMuteList(type, id, true);
            this.uploadSensorsClickData(170);
        } else {
            util.nim.handleMuteList(type, id, false);
            this.uploadSensorsClickData(171);
        }
    };

    uploadSensorsClickData = (elementName) => {
        util.sensorsData.track('Click_Schedule_Element', {
            pageName: 122,
            $element_name: elementName,
        });
    };
    //机器翻译
    handleMachineTranslation = async (value) => {
        // let { id } = this.props.sessionActive;
        let { id } = window.session_active;
        id = `${id}`;
        await util.nim.handleMachineTranslation(id, !!value);
        await setAutoMachineTranslation({ session_id: id, auto_translate: value ? 1 : 0 });
        util.sensorsData.track('Click_Chat_Element', {
            chat_id: id,
            pageName: 136,
            $element_name: value ? '01-230':'01-231',
        });
    };

    // 所在分组
    effectMenu = (disnotice)=>{
        // const {sessionActive} = this.props;
        const sessionActive = window.session_active;
        return(
            <Menu className={css.EffectMenuWrap} onClick={(e)=>util.yach.selectHandleClick(e,sessionActive.id)}>
                {renderCustomMenu(sessionActive.id,disnotice,false)}
           </Menu>
        )
    }

    render() {
        // const { sessionList, sessionActive, effectMode } = this.props;
        const { sessionList, effectMode } = this.props;
        const sessionActive = window.session_active;

        const { disnotice, isTop } =
            sessionList.filter((item) => {
                return item.id === sessionActive.id;
            })[0] || {};
        const { translationList = [] } = this.props;
        let isTranslation = translationList.includes(`${sessionActive.id}`);

        const info = util.yach.checkTypeofSession(sessionActive.id);
        const groupName = util.locale(info.attr)? util.locale(info.attr): info.attr;

        const props = {
            disnotice,
            isTop,
            onFixtop: this.handleFixtop,
            onNodisturb: this.handleNodisturb,
            locale: this.locale,
            id: sessionActive.id,
            onMachineTranslation: this.handleMachineTranslation,
            isTranslation,
            showAutoTranslation: util.yach.showAutoTranslation(),
            groupName,
            effectMode,
            effectMenu: this.effectMenu,
        };
        return <ScheduleSetting {...props} />;
    }
}

const mapStateToProps = (state) => {
    return {
        // sessionActive       : state.sessionActive,
        sessionList         : state.sessionList,
        translationList     : state.translationList,
        effectMode          : state.effectMode,
        effectlist          : state.effectInterfaceDate,
    };
};

export default connect(mapStateToProps, null)(ScheduleSettingContainer);
