import React from 'react';
import css from './index.scss';

const Index = (props) => {
    const { showSelectPeople, openCard, dataList, toggleSubscriptionModal, addOrRemoveSharer,locale } = props;

    return (
        <div className={css.shareWrapper}>
            <div className={css.flexdBg}></div> 
            <div className={css.shareContent}> 
                <img src={require('@a/imgs/schedule/sub-up.png')} className={css.hiddenUp}/>
                <img src={require('@a/imgs/schedule/sub-down.png')} className={css.hiddenDown}/>
                <div className={css.headerClose} onClick={toggleSubscriptionModal}>
                    <span className={css.closeBtn +' icon iconfont iconiconcha'}></span>
                    {/*<img src={require('@a/imgs/schedule/share-cancle.png')} className={css.closeBtn} />*/}
                </div>
                <div className={css.header}>{locale('calendar_subscription_article')}</div>
                <div className={css.wcontent}>
                    {!dataList.length && (
                        <div className={css.noman}>
                            <img src={require('@a/imgs/schedule/subscribe-no.png')} alt={locale('calendar_share_subscription_empty')} />
                            <p>{locale('calendar_share_subscription_empty')}</p>
                        </div>
                    )}
                    <div className={css.addsharer} onClick={showSelectPeople}>
                        <div className={css.contentLeft}>
                            <img src={require('@a/imgs/schedule/go-subscribe.png')} className={css.subImg}/>
                            <div className={css.centerText}>
                                <span className={css.subText}>{locale('calendar_subscription_button_gosubscription')}</span>
                                <p>{locale('calendar_subscription_remind_text')}</p>
                            </div>
                        </div>
                        <div className={css.subArrow} onClick={showSelectPeople}>
                            <img src={require('@a/imgs/schedule/share-arrow.png')} className={css.subArrowImg} />
                        </div>
                       
                    </div>
                    <div className={css.content}>
                        <div className={css.listItemWrap}>
                            {dataList.map((item) => {
                                return (
                                    <div className={css.list} key={item.uid}>
                                        <img
                                            src={item.avatar}
                                            onClick={() => {
                                                openCard(item.uid);
                                            }}
                                        />
                                        <div className={css.info}>
                                            <div className={css.leftInof}>
                                                <p
                                                    className={css.name}
                                                    onClick={() => {
                                                        openCard(item.uid);
                                                    }}
                                                >
                                                    {item.name}
                                                </p>
                                                <p
                                                    className={css.pos}
                                                    onClick={() => {
                                                        openCard(item.uid);
                                                    }}
                                                >
                                                    {item.dept && item.dept.length > 17
                                                        ? item.dept.slice(0, 8) + '...' + item.dept.slice(-8)
                                                        : item.dept}
                                                </p>
                                            </div>
                                        </div>
                                        <span
                                            className={css.delete}
                                            onClick={() => {
                                                addOrRemoveSharer(item.uid, 2);
                                            }}
                                        >
                                            {locale('calendar_button_subscription_unsubscribe')}
                                        </span>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Index;
