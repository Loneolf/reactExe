 import React from "react"
 import css from "./index.scss"
 import {Input} from "antd"
 export default class ScheduleSearch extends React.Component {
    constructor(props) {
        super(props);
    }
   
    render(){
        const {handleInput,querytext,userlist,showpanel,
            handleShowBlur,handleAddUser}=this.props;
        return (
        <div className={css.scheduleSearch} id="scheduleSearch">
           
            <Input
            placeholder={this.locale('calendar_create_adduser_placeholder')}
            value={querytext}
            maxLength={30}
            onBlur={handleShowBlur}
            id="searchinput"
            onChange={handleInput}
            />
           { showpanel  && <div className={css.panel} id="panel" >
               {
                !userlist.length&&<div className={css.searchContent}>
                    <div>
                        <img src={require('@a/imgs/schedule/search-user.png')} className={css.searchImg}/>
                        <p className={css.seachtext}>{this.locale('calendar_create_search_empty')}</p>
                    </div>
                </div>
                }

                {userlist.length>0&&<div className={css.panelContent}>
                {userlist.length>0&&userlist.map((user)=>{
                   return(
                   <li key={user.id} onClick={(e)=>{handleAddUser(e,user.id)}}>
                        <img src={user.pic} alt="" />
                        <div>
                            <span className={css.username}>{user.name}</span>
                            {!!user.dept && (
                                <span style={{color: '#757b82'}} className={css.userinfo}>
                                    {user.dept.length > 17
                                        ? user.dept.slice(0, 8) + '...' + user.dept.slice(-8)
                                        : user.dept}
                                </span>
                            )}
                        </div>
                   </li>) 
                   })}
                </div>
                }
            </div>}
        </div>)
}
 
}