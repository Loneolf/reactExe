import React, { Component } from 'react';
import css from './index.scss';
import * as util from '@u/util.js';
import {message} from 'antd'

const { clipboard } = require('electron')

export default class BoxCopy extends Component {
    componentDidMount(){
        const el= document.getElementById('scheduleInfoOut');
        el&&el.addEventListener('contextmenu',this.contextmenuHandle)
    }

    componentWillUnmount(){
        const el= document.getElementById('scheduleInfoOut');
        el&&el.removeEventListener('contextmenu',this.contextmenuHandle)
    }

    // 当鼠标右键时，判断有没有选中文字，有选中文字的话，根据选取和鼠标位置控制是否显示复制文字及显示位置。
    contextmenuHandle = (e)=>{
        e.preventDefault();
        if(!this.copyBox) return;
        // if(!util.yachLocalStorage.ls('isSelectText')) return 
        this.selectedText = window.getSelection().toString();
        if(!this.selectedText || this.sendBoxArea) return this.copyBox.style.display = 'none';
        let select = window.getSelection().getRangeAt(0).getBoundingClientRect()
        if(e.x < select.x || e.x > select.x+select.width) return
        if(e.y < select.y || e.y > select.y+select.height) return
        let x = e.x
        let width = document.documentElement.clientWidth - (util.electron.isMac() ? 97 : 114)
        if(x > width) x = width
        this.copyBox.style.top = e.y + 2 + 'px';
        this.copyBox.style.left = x + 2 + 'px';
        this.copyBox.style.display = 'block';
    }

    // 点击选中文字，复制选中文字到剪切板，将复制提示消失。
    copySelect = ()=>{
        if(!this.selectedText){
            this.copyBox.style.display = 'none'
            return message.error(util.locale('im_copy_failure'),0.5)
        }
        let userSign = util.yachLocalStorage.ls('userInfoSignCopy')
        if(userSign && userSign.new){
            if(~this.selectedText.indexOf(userSign.new)) this.selectedText = this.selectedText.replace(userSign.new,userSign.all)
        }
        clipboard.writeText(this.selectedText.trim())
        message.success(util.locale('im_copy_success'),0.5)
        this.copyBox.style.display = 'none'
    }


    render() {
        const isMac=util.electron.isMac();
        return (
            <div
                ref={(dom)=>{this.copyBox = dom}} 
                className={css.copyBox}
            >
                <div className={css.copyMask} onClick={()=>{this.copyBox.style.display = 'none';}} />
                <div className={`${css.text} ${!isMac ? css.windowText : ''}`} onClick={this.copySelect}>{util.locale('im_copy')} {isMac ? '(⌘' : '(ctrl+'}C)</div>
            </div>
        );
    }
}
