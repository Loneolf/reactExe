/*
 * @Descripttion:
 * @Author: qiuyanlong@100tal.com
 * @Date: 2020-04-18 14:33:48
 */
import React,{useEffect,useState} from 'react';
import { toggleNunclick, addSheduleList } from '@r/actions/calender';
import _ from 'lodash';
import {Tooltip } from 'antd';
import * as sUtil from '../../lib/until';
import * as util from '@u/util.js';
import { sensorsData } from '@u/util.js';
import { setMonthDialog } from '@r/actions/calender';
import css from './index.scss';
const setUserSettingOfCalender = sUtil.setUserSettingOfCalender;
import {scheduleSubscriptionSubscribers} from "@/services/schedule/schedule";


const getSubscriptionSubscribers= async ()=>{
    try{
        const s= await scheduleSubscriptionSubscribers();
        const {obj=[]} = s || {};
        return !!obj.length;
    }catch{}

    return false
}

/*
   挂载我的日历，中国节假日 ，共享日程 ui 组件   
*/
export default (props) => {
    const {
        mountcalender:{ cancelschedule, nuncheckbox, refuseschedule,selfschedule},
        monthAndDayList,
        getEventListTime,
        asyncMonthlist,
        getLittleDot,
        showShareModle,
        shareScheduleList,
        toggleSubscriptionModal,
        locale,
        dispatch
    } = props;

    const [showSubtip,setShowSubtip]=useState(false);
    const [mountSchduelLocal,setMountSchduelLocal]=useState({
        mySchdule: true,  // 我的日程
        shareShdule:true, // 共享给我的
        tradSchdule:true, // 传统节假日
        hiddenShdule:true // 隐藏日程
    })

    useEffect(()=>{
        /**
         * 是否显示订阅引导
         * 1.是否点击过订阅
         * 2.后台是否有订阅信息
         */
        const handleShowSubtip= async()=>{
            if (!util.yachLocalStorage.ls('subscribeGuild')) {
                // 用户没点击订阅
                const ifSubscribe= await getSubscriptionSubscribers();
                if(!ifSubscribe){
                    setShowSubtip(true)
                }else{
                    util.yachLocalStorage.ls('subscribeGuild', true);
                }
            }
        }
        handleShowSubtip();
    },[])

    // 点击tooltip
    const bindSubscribelocal=()=>{
        if (showSubtip && !util.yachLocalStorage.ls('subscribeGuild')) {
            util.yachLocalStorage.ls('subscribeGuild', true);
            setShowSubtip(false)
        }
    }

    // 点击订阅按钮
    const showSubscriptionModal=()=>{
        bindSubscribelocal();
        toggleSubscriptionModal();
    }

    // 处理展开关闭
    const setAction = (value) => {
        setMountSchduelLocal({...mountSchduelLocal,...value})
    };

    const setdownAndUp = (type, arrow) => {
        switch (type) {
            case 'ofmine':
                arrow === 'up' ? setAction({ mySchdule: true }) : setAction({ mySchdule: false });
                break;
            case 'oflocal':
                arrow === 'up' ? setAction({ tradSchdule: true }) : setAction({ tradSchdule: false });
                break;
            case 'ofhidden':
                arrow === 'up' ? setAction({ hiddenShdule: true }) : setAction({ hiddenShdule: false });
                break;
            case 'ofshare':
                if (arrow === 'up') {
                    setAction({ shareShdule: true });
                    util.sensorsData.track('Click_Schedule_Element', { pageName: 115, $element_name: 201 });
                } else {
                    setAction({ shareShdule: false });
                    util.sensorsData.track('Click_Schedule_Element', { pageName: 115, $element_name: 202 });
                }
                break;
        }
    };
    const { hiddenShdule, mySchdule, shareShdule, tradSchdule } = mountSchduelLocal;

    // 选中状态；
    const mountCalenderOfLocal = async (type) => {
        // dispatch(setMonthDialog({ show: false, datatime:"", list: []}));
        switch (type) {
            case 'cancel':
                await dispatch(toggleNunclick({ cancelschedule: !cancelschedule }));
                setUserSettingOfCalender({ cancelschedule: !cancelschedule });
                sensorsData.track('Click_Schedule_Element', {
                    pageName: 104,
                    $element_name: 231,
                });
                break;  
            case 'trad':
                await dispatch(toggleNunclick({ nuncheckbox: !nuncheckbox }));
                setUserSettingOfCalender({ nuncheckbox: !nuncheckbox });
                break;
            case "self":
                await dispatch(toggleNunclick({ selfschedule: !selfschedule }));
                setUserSettingOfCalender({ selfschedule: !selfschedule });
                break;
            case "refuse":
                await dispatch(toggleNunclick({ refuseschedule: !refuseschedule }));
                setUserSettingOfCalender({ refuseschedule: !refuseschedule });
                sensorsData.track('Click_Schedule_Element', {
                    pageName: 104,
                    $element_name: 232,
                });
                break;
            default:
                break;
        }
        !!monthAndDayList.day && getEventListTime();
        !!monthAndDayList.month && asyncMonthlist();
        if (!monthAndDayList.month && !monthAndDayList.day) {
            util.eventBus.emit('getWeekTime');
            util.eventBus.emit('setWeekLoading', true);
        }
        getLittleDot();
    };

    // 共享日程点击 选择
    const setSharerState = async (item) => {
        let list = { ...item };
        list['selected'] = list['selected'] === 1 ? 0 : 1;
        let copyShareScheduleList = [...shareScheduleList];
        let nowId = copyShareScheduleList.findIndex((ite) => ite.uid === list.uid);
        if (nowId !== -1) {
            copyShareScheduleList.splice(nowId, 1, list);
        }

        await dispatch(addSheduleList(copyShareScheduleList));

        !!monthAndDayList.day && getEventListTime();
        !!monthAndDayList.month && asyncMonthlist();
        if (!monthAndDayList.month && !monthAndDayList.day) {
            util.eventBus.emit('getWeekTime');
            util.eventBus.emit('setWeekLoading', true);
        }
        list['selected'] === 1 && sensorsData.track('Click_Schedule_Element', { pageName: 115, $element_name: 203 });
    };

    return (
        <div id="createSubscribe" className={css.localCalender}>
            <Tooltip
                placement="top"
                visible={showSubtip}
                overlayClassName={css.subGuidArrow}
                getPopupContainer={() => document.getElementById('createSubscribe')}
                autoAdjustOverflow={true}
                arrowPointAtCenter={true}
                title={
                    <div onClick={bindSubscribelocal} className={css.subGuidContent}>
                        <div>{locale('calendar_myschedule_tip')}</div>
                        <span className='iconfont-yach yach-0428-rili-richengxiangqing-guanbixiangqing' />
                    </div> 
                }
            >
                <div className={css.addSubscription} onClick={showSubscriptionModal}>
                    <span className='iconfont-yach yach-pcduan-tianjiadingyuerilianniu' />
                    <i>{locale('calendar_myschedule_article')}</i> 
                </div>
            </Tooltip>
            <div className={css.sharemind}> 
                <div className={css.contentItem}>
                    <div className={css.schecollarrow} onClick={()=>{setdownAndUp('ofmine', mySchdule?'down':'up');}}>
                        <h2 className={css.title}>{locale('calendar_myschedule_title_myschedule')}</h2>
                        <div className={css.calArrow}>
                            <span className={`iconfont-yach yach-0421_xiezuo_gongxiangwoderili_shouqi ${!mySchdule?css.rotate:''}`} />
                        </div>
                    </div>
                    {mySchdule && (
                        <div className={css.boxsday}>
                            <div className={css.calleft+" "+css.mySchdulebtn} onClick={_.throttle(() => mountCalenderOfLocal('self'), 200)}>
                                <div className={`${css.checkboxOut} ${css.mySchduleColor}`}>
                                    {selfschedule?<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-xuanzhong' />:<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-moren' />}
                                </div>
                                <p>{locale("calendar_myschedule_title_myschedule_item")}</p>
                            </div>
                            <div
                                className={css.shareIcon}
                                onClick={showShareModle}
                            >
                                <i className={css.sceduleshare+" "+"iconfont-yach yach-0421_xiezuo_gongxiangwoderili"}></i>
                                <span className={css.sharetext}>{locale('calendar_myschedule_title_myschedule_button')}</span>
                            </div>
                        </div>
                    )}
                </div>
 
                {!!shareScheduleList.length && 
                    <div className={css.contentItem}>
                        <div className={css.schecollarrow} onClick={()=>{setdownAndUp('ofshare', shareShdule?'down':'up')}}>
                            <h2 className={css.title}>{locale('calendar_myschedule_title_otherschedule')}</h2>
                            <div className={css.calArrow}>
                                <span className={`iconfont-yach yach-0421_xiezuo_gongxiangwoderili_shouqi ${!shareShdule?css.rotate:''}`} />
                            </div>
                        </div>
                        {shareShdule && 
                            shareScheduleList.map((item) => {
                                const { color = '#EC6D6D' } = item;
                                return (
                                    <div className={css.boxsday} key={item.uid} onClick={() => {setSharerState(item)}}>
                                        <div className={css.calleft}>
                                            <div className={css.checkboxOut} style={{color:color}}>
                                                {!!item.selected?<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-xuanzhong' />:<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-moren' />}
                                            </div>
                                            <p>{item.name}</p>
                                        </div>
                                    </div>
                                );
                            })
                        }
                    </div>
                }

                <div className={css.contentItem}>
                    <div className={css.schecollarrow} onClick={()=>{setdownAndUp('oflocal', tradSchdule?'down':"up");}}>
                        <h2 className={css.title}>{locale('calendar_myschedule_title_localschedule')}</h2>
                        <div className={css.calArrow}>
                            <span className={`iconfont-yach yach-0421_xiezuo_gongxiangwoderili_shouqi ${!tradSchdule?css.rotate:''}`} />
                        </div>
                    </div>
                    {tradSchdule && (
                        <div className={css.boxsday} onClick={_.throttle(() => mountCalenderOfLocal('trad'), 200)}>
                            <div className={css.calleft}>
                                <div className={`${css.checkboxOut} ${css.tradScheduleColor}`}>
                                    {nuncheckbox?<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-xuanzhong' />:<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-moren' />}
                                </div>
                                <p>{locale('calendar_selectcard_title_chinesefestival')}</p>
                            </div>
                        </div>
                    )}
                </div>

                <div className={css.contentItem}>
                    <div className={css.schecollarrow}  onClick={()=>setdownAndUp('ofhidden', hiddenShdule?'down':"up")}>
                        <h2 className={css.title}>{locale('calendar_myschedule_title_showschedule')}</h2>
                        <div className={css.calArrow}>
                            <span className={`iconfont-yach yach-0421_xiezuo_gongxiangwoderili_shouqi ${!hiddenShdule?css.rotate:''}`} />
                        </div>
                    </div>
                    {hiddenShdule && (
                        <>
                            <div className={css.boxsday}  onClick={_.throttle(() => mountCalenderOfLocal('cancel'), 200)}>
                                <div className={css.calleft}>
                                    <div div className={`${css.checkboxOut} ${css.hiddenScheduleColor}`}>
                                        {!cancelschedule?<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-xuanzhong' />:<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-moren' />}
                                    </div>
                                    <p>{locale('calendar_button_info_cancelled')}</p>
                                </div>
                            </div>
                            <div className={css.boxsday} onClick={_.throttle(() => mountCalenderOfLocal('refuse'), 200)}>
                                <div className={css.calleft}>
                                    <div div className={`${css.checkboxOut} ${css.hiddenScheduleColor}`}>
                                        {!refuseschedule?<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-xuanzhong' />:<span className='iconfont-yach yach-0421-rili-rilibiaoqianxianshitubiao-moren' />}
                                    </div>
                                    <p>{locale('calendar_button_info_refused')}</p>
                                </div>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};
