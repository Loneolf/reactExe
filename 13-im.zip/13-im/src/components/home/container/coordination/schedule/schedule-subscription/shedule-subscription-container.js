import React, { Component } from 'react';
import {connect} from 'react-redux';
import UserAdd from '@c/common/user-add/user-add-container';
import Subscription from './shedule-subscription';
import {scheduleSubscriptionSubscribersUpdate,scheduleSubscriptionSubscribers} from "@/services/schedule/schedule";
import * as util from '@u/util.js';
import {message} from 'antd';
import {showGloading,hideGloading} from '@r/actions/commonLoading'
import {refrshCalender} from '@c/home/container/coordination/schedule/common/common';


export class sheduleSubscriptionContainer extends Component {
    state = {
        showselect:false,
        hasSelected:[],
        dataList:[]
    }

    componentDidMount(){
        this.getSubscriptionSubscribers();
    }

    // 展示选择人组件
    showSelectPeople = (b)=>{ 
        const {dataList} = this.state;
        const uids =  dataList.map(item=>item.uid+'')||[];
        this.setState(state=>({
            showselect: true,
            hasSelected: [...uids]
        }))
    }
    // 关闭选择人组件
    onClose = ()=>{
        this.setState({
            showselect: false,
        });
    }

    sleep = ()=>{
        return new Promise(resolve=>{ setTimeout(resolve,800)})
    }

    // 选择人的回调函数 选人组件确认按钮
    selected = async (res)=>{
        //console.log('我的选择',res);
        await this.props.dispatch(showGloading());
        const {allDataUsers} = res;
        const { dataList } = this.state;
        const uid = allDataUsers.map(item=>item.id);
        const storeUid = dataList.map(item=>item.uid);

        if(uid.sort().toString() !== storeUid.sort().toString()){
            this.setState(state=>({
                showselect: false
            }),()=>{
                this.addOrRemoveSharer(uid.join(),1, storeUid.length - uid.length );
            });
        }
        else{
            this.setState(state=>({
                showselect: false
            }));
            this.props.dispatch(hideGloading());
        }   
    }

    addOrRemoveSharer = async (uids,op,hasAdd) => {
        if(!uids){
            message.error(this.locale('calendar_toast_share_illegalid') + msg);
            return 
        }
        const removeOne = await scheduleSubscriptionSubscribersUpdate({uids,op});
        const { code, msg } = removeOne || {};
         if(code === 200){
             op === 2 ? message.success(this.locale('calendar_toast_subscription_unsubscribe_success')) : hasAdd >=1 ? message.success(this.locale('calendar_toast_subscription_unsubscribe_success')): message.success(this.locale('calendar_toast_subscription_subscribe_success'));
             await this.getSubscriptionSubscribers();
             await window.getShareShedule();
             refrshCalender('all');
         }
         else{
             console.error('错误信息: '+ msg);
             message.error(this.locale('calendar_toast_add_wrong'));
         }
    }
    
    openCard = uid => {
        util.yach.showUserinfo(uid);
    }

    
    getSubscriptionSubscribers= async ()=>{
        this.props.dispatch(showGloading());
        const s= await scheduleSubscriptionSubscribers();
        const {code, msg, obj=[]} = s || {};
        if(code !== 200){
            message.error(msg);
        }else{
            const dataList=await util.yach.base64ImgArrGetTmp(obj,'avatar');
            this.setState({
                dataList
            })
        }
        this.props.dispatch(hideGloading());
    }

 

    render() {
        const {dataList}=this.state;
        const {toggleSubscriptionModal} =this.props;
        const userAddProps = {
            type: 'creatGroup',
            loading: false,
            show: this.state.showselect,
            onOk: this.selected,
            onClose: this.onClose,
            disabledids: [this.props.userInfo.id +''],
            checkedids:  this.state.hasSelected,
            title: this.locale('calendar_myschedule_article'),
            leftTitle: this.locale('calendar_useradd_subscription_lefttitle'),
            rightTitle: this.locale('calendar_useradd_share_righttitle'),
            maxLength: 101
        };
        

        return (
          <>
            <UserAdd {...userAddProps} />
            <Subscription 
                showSelectPeople={this.showSelectPeople}
                openCard = {this.openCard}
                dataList={dataList}
                toggleSubscriptionModal={toggleSubscriptionModal}
                addOrRemoveSharer={this.addOrRemoveSharer}
                locale={this.locale}
            />
          </>
        );
    }
}

const mapStateToProps = (state) =>{
    return{
        userInfo            : state.userInfo,
    }
};

export default connect(mapStateToProps, null)(sheduleSubscriptionContainer);
