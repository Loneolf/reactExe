import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import ScheduleAdd from './schedule-add-container';
import { hideScheduleAdd } from '@/redux/actions/calender';

/**
 *
 * scheduleAdd:{
 *     show:true,
 *     data:{
 *          id:xx,
 *          title:'',
 *          user:[],            // 人id
 *          groupInfo:{
 *              id:"选人时群ID",
 *              showname:'选人时群name'
 *          },
 *          meeting_type:true/false,// 是否是会议群
 *     },
 * }
 */


 /**
 *
 * createSchedule:{
 *     data:{
 *          from:fast/create/drag/double,
 *          time:[1,13],
 *          title,
            start_time, //moment(fastTimeLine[0]).format('X'),
            end_time,   //moment(fastTimeLine[1]).format('X'),
            address,
            is_full: 0,
            remind_time: 900,
 *     }
 * }
 */

function Index(props) {
    const {
        scheduleAdd: { show, id, custom, },
    } = props;

    const ScheduleAddProps = {
        closeShowAdd: () => {
            props.dispatch(hideScheduleAdd());
        },
        scheduleId: id,
        custom,
    };
    if (show) {
        return document.body && ReactDOM.createPortal(<ScheduleAdd {...ScheduleAddProps} />, document.body);
    } else {
        return null;
    }
}

// mapStateToProps：将state映射到组件的props中
const mapStateToProps = (state) => {
    return {
        scheduleAdd: state.calender.scheduleAdd,
    };
};

export default connect(mapStateToProps)(Index);
