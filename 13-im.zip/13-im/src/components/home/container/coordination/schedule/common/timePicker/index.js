import React from 'react';
import {DatePicker, Input} from 'antd';
import css from "./index.scss";
import moment from 'moment';

function genOption(value='00:00',clickFn) {
    const arr=[];
    for(let i=0;i<24;i++){
        for(let n=0;n<6;n++){
            const result=(i>9?i:'0'+i)+':'+(n===0?'00':n*10);
            arr.push(<div id={result===value?'active_option':''} onMouseDown={clickFn.bind(null,result)} className={value===result?`${css.option} ${css.optionActive}`:css.option} key={result}>{result}</div>);
        }
    }
    return arr;
}


function regfn(value){
    let regValue='00:00';
    let result=/([\s\S]?[0-9]):([0-5][[\s\S]?)/.exec(value);
    if(!result){ 
        value=Number(value)||'';
        /**
         * 不符合正则取分钟整数(钉钉)
         * 1、必须是数字
         * 2、长度是2以下
         * 3、小于等于23
         * 4、不满足任何一项是00:00
         *  */ 
        regValue=(''+value).length<=2 && /^[0-9]+$/.test(value) && value<=23?(value>9?value:'0'+value)+':00':'00:00';
    }else{
        /**
         * 符合正则(s1:1s;)(飞书)
         * 1、11:11格式不做处理
         * 2、11:1s==>11:01
         * 3、s1:11==>01:11
         * 4、大于23:xx==>00:00
         *  */ 
        const arr=result[0].split(':');
        let m = Number(arr[0]),
            s = Number(arr[1]);
        
        m= isNaN(m)?'0'+arr[0].substring(1,2):(m<=23?(m >9?m:'0'+m):'00')
        s = !isNaN(s)?(s>9?s:'0'+s):'0'+arr[1].substring(0,1);
        regValue=m+':'+s;
    }
    return regValue;
}

// BoxOperationContainer
class Index extends React.Component {
    state={
        inputValue:'',// 输入框的文字
        regValue:'',// 正则处理过之后的
        dropVisible:false
    }

    componentWillReceiveProps(nextProps){
        // input显示和regValue保持最新
        // 1.上层的timeValue不同
        // 2.匹配之后上传timeValue不变，input显示错误
        if(this.props.timeValue!=nextProps.timeValue||this.state.inputValue!=nextProps.timeValue){
            const timeValue=nextProps.timeValue;
            this.setState({
                inputValue:timeValue,
                regValue:timeValue,
            })
        }
    }

    componentDidUpdate(prevProps, prevState){
        const {dropVisible}=this.state;
        // 下拉展示/input匹配
         if((prevState.regValue!==this.state.regValue && dropVisible)||dropVisible ){
         //if(prevState.regValue!==this.state.regValue && dropVisible ){
            const activeOptin=document.getElementById('active_option');
            activeOptin&&activeOptin.scrollIntoView();
        }
    }

    handleTimeChange=()=>{
        this.handleDropVisible(false);

        const value=this.state.regValue;
        const {type,onFullChange}=this.props;
        onFullChange(type+'Time',value);

        if(type==='start'){
            const time=this.props.fullValue;
            onFullChange('full_end',moment(moment(time*1000).format('YYYY-MM-DD')+' '+value+':00').add(1,'h').endOf('day').format('X'));
            onFullChange('endTime',moment(moment(time*1000).format('YYYY-MM-DD')+' '+value+':00').add(1,'h').format('HH:mm'));
        }
    }

    handleFullChange=(value)=>{
        const {type,onFullChange}=this.props;
        if(!value) return;
        const newValue=type==='start'?value.startOf('day').format('X'):value.endOf('day').format('X');
        onFullChange('full_'+type,newValue);
        if(type==='start'){
            const time=this.props.timeValue;
            onFullChange('full_end',moment(value.format('YYYY-MM-DD')+' '+time+':00').add(1,'h').endOf('day').format('X'));
            onFullChange('endTime',moment(value.format('YYYY-MM-DD')+' '+time+':00').add(1,'h').format('HH:mm'));
        }
    }

    hadleInputChange=(e)=>{
        const value=e.target.value;
        // // 匹配 12:12格式,直接赋值(暂时不做，之后在处理吧)
        // if(/^(?:[01]\d|2[0-3])(?::[0-5]\d)$/.test(value)){
        //     this.setState({
        //         inputValue:value,
        //         regValue:value
        //     },()=>{
        //         this.handleTimeChange();
        //     })
        // }else{
        //     this.setState({
        //         inputValue:value,
        //         regValue:regfn(value)
        //     })
        //     const {schedule_popup_visible,type}=this.props;
        //     schedule_popup_visible.type!==type && this.handleDropVisible(type);
        // }

        this.setState({
            inputValue:value,
            regValue:regfn(value)
        })
    }

    handleSelectValue=(value)=>{
        this.setState({
            inputValue:value,
            regValue:value
        },()=>{
            this.handleTimeChange();
        })
    }

    handleDropVisible=(value)=>{
        this.setState({
            dropVisible:value
        })
    }

    render() {
        const {inputValue,regValue,dropVisible}=this.state;
        const {fullValue=null,is_full,dropStyle={}} = this.props;

        return (
            <div className={css.out} id='datePickerOut'>
                <DatePicker
                    format="YYYY-MM-DD"
                    value={moment(new Date(fullValue*1000))}
                    onChange={this.handleFullChange}
                    suffixIcon={<span/>}
                    allowClear={false}
                    dropdownClassName={css.dataPicker}
                    showToday={false}
                    style={{width:109,height:36}}
                    getCalendarContainer={()=>document.getElementById('datePickerOut')}
                />
                {!is_full && <div className={css.timeOut}>
                    <Input 
                        value={inputValue} 
                        onChange={this.hadleInputChange} 
                        onFocus={this.handleDropVisible.bind(this,true)}
                        onBlur={this.handleTimeChange}
                    />
                    {
                        dropVisible && <div className={css.dropOut} style={dropStyle}>
                            {
                                genOption(regValue,this.handleSelectValue)
                            }
                        </div> 
                    }
                </div>
                }
            </div>
        );
    }
}

export default Index;
