/*
 * @Descripttion:
 * @Author: qiuyanlong@100tal.com
 * @Date: 2020-04-17 11:18:48
 */

import React, { Component } from 'react';
import { connect } from 'react-redux';

import { changeTodayState, initViewDate } from '@r/actions/calender';

import UiDateList from './date';

import * as sUtil from './../../lib/until';
import _ from 'lodash';
import moment from 'moment';
import * as util from '@u/util.js';
import * as unitCore from '../../lib/unit-core';


import c from './index.scss';

moment.suppressDeprecationWarnings = true;

// calender model
class Datecalender extends Component {
    componentDidMount() {
        let { year, month, day } = this.props.initDate;
        this.setCurrentYearMonth(new Date(year, month, day));
    }

    async setCurrentYearMonth(date) {
        var month = date.getMonth();
        var year = date.getFullYear();
        var day = date.getDate();
        await this.props.dispatch(initViewDate({ year, month, day }));
    }

    // 实现一个函数 传递进来一个时间参数 20190928
    // 查询一条数据 应该上下个月回头看的策略 如果不在这个月,是否在上下个月数据里面
    filterDotShoe(dotlist, val) {
        if (!Object.keys(dotlist).length) return false;
        let tval = val.replace(/^(\d{4})(\d{2})(\d{2})$/, '$1-$2');
        let hs = Object.keys(dotlist).length && -1;
        for (let prop of Object.keys(dotlist)) {
            // prop  2019-09
            hs = dotlist[prop].findIndex((item) => item == val);
            if (!!hs) break;
        }
        if (hs !== -1) return !0;
        return ![];
    }

    // 上下月切换
    changeMonth = async (v) => {
        const { day, month, year } = this.props.initDate;
        let { day: mday, month: mmonth } = this.props.monthAndDayList;

        var monthAfter = +month + v;
        var newD = new Date(year, monthAfter, 1);
        this.setCurrentYearMonth(newD);
        this.props.dispatch(changeTodayState(true));

        !!mmonth && this.props.getAsyncMonthlist();
        !!mday && this.props.getEventListTime();

        if (!mmonth && !mday) {
            util.eventBus.emit('setWeekLoading', true);
            util.eventBus.emit('getWeekTime');
        }

        this.props.getLittleDot();
        util.sensorsData.track('Click_Schedule_Element', { pageName: 104, $element_name: 194 });
        return false;
    };

    selectBoxFn = async (clikd, nexF, greyC, y, m) => {
        let { day: mday, month: mmonth } = this.props.monthAndDayList;

        if (!!greyC.trim()) {
            // 看是上个月还是下个月的
            var act = !!nexF ? 1 : -1;
            var newD = new Date(y, +m + act, clikd);
            this.setCurrentYearMonth(newD);
            await this.props.dispatch(changeTodayState(true));
            this.props.getLittleDot();
            await this.props.getEventListTime(newD.getFullYear(), newD.getMonth(), clikd);
        } else {
            // 当前月份数据点击 单独处理点击的是今天
            if (clikd === new Date().getDate() && m === new Date().getMonth()) {
                util.sensorsData.track('Click_ScheduleMain_Date', { isToday: 101 });
                await this.props.dispatch(changeTodayState(false));
            } else {
                util.sensorsData.track('Click_ScheduleMain_Date', { isToday: 102 });
                await this.props.dispatch(changeTodayState(true));
            }
            !greyC.trim() && (await this.props.dispatch(initViewDate({ day: clikd })));
            await this.props.getEventListTime(y, m, clikd);
        }

        if (!mmonth && !mday) {
            util.eventBus.emit('setWeekLoading', true);
            util.eventBus.emit('getWeekTime');
        }
    };

    render() {
        let { dotlist } = this.props;
        let { year, month, day } = this.props.initDate;
        const nowTimeInstance = moment([year, month + 1, 1].join('-'));
        const nowTimeObject = nowTimeInstance.toObject();
        const dayOfWeek = nowTimeInstance.day(); // 当月1号是周几 0.1.2...
        const mday = sUtil.days_per_month(year); // 获取当前年里面月数组
        const dateLine = Math.ceil((dayOfWeek + mday[month]) / 7); //确定日期表格所需的行数


        let initAllVarib = {
            y: year,
            m: month,
            d: nowTimeObject.date,
            n: dateLine,
            dayOfWeek,
            c,
            dotlist,
            clickelActiveDay: { day, month }, //因为ui渲染函数里面是从0开始渲染的，因此入参的时候就减去这个1
            selectBoxFn: this.selectBoxFn,
            filterDotShoe: this.filterDotShoe,
            lang: this.locale.getLang()==='zh-CN'
        };
        return (
            <div className={c.calender}>
                <header>
                    <div className={c.left} onClick={_.debounce(this.changeMonth.bind(this, -1), 200)}>
                        <span className="iconfont-yach">&#xe609;</span>
                    </div>
                    <h3>
                        {unitCore.formatTime( moment([year, month + 1, day].join('-')),'noday')}
                    </h3>
                    <div className={c.right} onClick={_.debounce(this.changeMonth.bind(this, 1), 200)}>
                        <span className="iconfont-yach">&#xe60a;</span>
                    </div>
                </header>

                <div className={c.datelist}>
                    <div className={c.weeks}>
                        {unitCore.mycalendar.map((item) => {
                            return (
                                <div className={c.awk} key={item}>
                                    {item}
                                </div>
                            );
                        })}
                    </div>
                    <div className={c.date}>
                        <UiDateList {...initAllVarib} />
                    </div>
                </div>

            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        selectNowDate: state.calender.selectNowDate,
        initDate: state.calender.initDate,
        gotoToday: state.calender.gotoToday,
        monthAndDayList: state.calender.monthAndDayList,
        dotlist: state.calender.dotlist,
    };
};

export default connect(mapStateToProps, null)(Datecalender);
