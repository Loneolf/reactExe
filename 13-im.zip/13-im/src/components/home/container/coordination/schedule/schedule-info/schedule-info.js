/**
 * @Description: 日程详情
 * */

// react
import React from 'react';
// css
import css from './index.scss';
import * as util from '@u/util.js';
import { updateFn, showScheduleImg } from '@c/home/container/coordination/schedule/common/common';
import * as sUtil from '../../lib/until';
import { Spin } from 'antd';
import { Tooltip, Button } from 'antd';
import _ from 'lodash';
import { jionLive } from '@u/lib/video/liveFn';
import BoxCopy from '../common/box-copy';

const { usersMsgOrder } = sUtil;
const defaultOpenNum = 16;

function genDelBtn(
    { isOne, isCreator, isvalid, finish_time, repeat_value, state, locale, sid, userState },
    scheduleDelete
) {
    //删除btn
    let deleteObj = {
        type: 0, // 0:直接删除:1:拒绝并删除;2:没有删除按钮
        defaultValue: 0, //0:单人日程（ 本次）；1:本次（本次）；2:本次及以后;3:全部（所有）;4:可选本次及以后（没有默认值）。用来传默认值和确定文案
        sid,
        repeat_value,
        userState,
    };

    // 处理文案
    if (isOne) {
        // 都是直接删除
    } else {
        // 多人日程
        if (isCreator) {
            // 创建者
            if (isvalid) {
                // 未过期：没有删除按钮
                deleteObj.type = 2;
            } else {
                // 其余都是直接删除
            }
        } else {
            // 参与者
            if (isvalid && userState != 2) {
                // 未过期：拒绝并删除
                deleteObj.type = 1;
            } else {
                // 其余都是直接删除
            }
        }
    }

    // 处理默认值
    if (repeat_value) {
        // 重复日程
        if (isOne) {
            if (isvalid) {
                // 未过期且重复：可选本次和之后每一次
                deleteObj.defaultValue = 4;
            } else if (state == 3) {
                // 老版本取消
                deleteObj.defaultValue = 3;
            } else {
                // 仅本次
                deleteObj.defaultValue = 1;
            }
        } else {
            // 多人日程
            // deleteObj.defaultValue=1;
            if (finish_time * 1000 < +new Date()) {
                // 已过期删除所有
                deleteObj.defaultValue = 1;
            } else {
                // 其他情况都是删除所有
                deleteObj.defaultValue = 3;
            }
        }
    } else {
        //非重复传0
    }
    if (deleteObj.type == 2) return null;

    // 弹框文案
    let confirTitle = '';
    if (deleteObj.defaultValue === 0 || deleteObj.defaultValue === 1) {
        confirTitle = locale('calendar_confirm_delete');
    } else if (deleteObj.defaultValue === 4) {
        confirTitle = locale('calendar_confirm_repeat');
    } else {
        confirTitle = locale('calendar_confirm_delete_repeat');
    }

    if (deleteObj.type === 1) {
        confirTitle = locale('calendar_confirm_refuse_delete');
        if (repeat_value) confirTitle = locale('calendar_confirm_refuse_delete_repeat');
    }

    deleteObj.confirTitle = confirTitle;

    return (
        <Tooltip
            placement="bottom"
            overlayClassName={css.sceduleicon}
            title={locale(deleteObj.type === 0 ? 'calendar_button_delete' : 'calendar_button_refuse_delete')}
            getPopupContainer={() => document.getElementById('scheduleDetail')}
        >
            <span
                onClick={() => scheduleDelete(deleteObj)}
                className={'iconfont-yach yach-145-rili-richengxiangqing-richengshanchu' + ' ' + css.addicon}
            />
        </Tooltip>
    );
}

export default function ScheduleInfo(props) {
    const {
        inFo: {
            state,
            summary,
            is_full,
            is_last,
            group_id,
            tags = [],
            meeting = {},
            is_creator,
            visibility,
            sid,
            location,
            title,
            attachments = [],
            alert_times_txt,
            alert_times_txt_en,
            repeat_txt,
            repeat_txt_en,
            repeat_value,
            begin_time,
            finish_time,
            extra_info = {},
            current_user_info = {},
            package_info = {},
            live_id,
            speaker,
            creator,
            live_state,
        },
        nodata,
        loadingText,
        infoUser,
        infoLoading,
        peopleStage,
        openMore,
        toggleOpenMore,
        changePeopleStage,
        handleShowUserAdd,
        handleAddGroup,
        scheduleEdit,
        handleCancelSchedule,
        uploadSensorsClickData,
        uploadSensorsDetailData,
        // handleJoinMeeting,
        usersMessage,
        showVideoSessioneModal,
        locale,
        meetingSummaryClick,
        scheduleDelete,
        liveUsers,
        remindOne,
        isShowRemind,
        organizers,
    } = props;

    // 组织者
    const organizer = organizers.filter((item) => item.account == creator)[0];

    function showImg(currid, attachments) {
        showScheduleImg(currid, attachments);
        uploadSensorsClickData(144);
    }
    // 日程来源 1:自己的日程 2:他人的日程 9:节假日 10:直播
    const source = package_info.source;
    const userState = current_user_info.state;
    // 接受/拒绝 /取消/过期btn
    let btnEl;

    // 是否是单人日程
    let isOne = extra_info.uids && extra_info.uids.length < 2;

    // 有效日程：修改和初始状态
    const isvalid = (state == 4 || state == 0) && finish_time * 1000 > +new Date();
    // 是否创建者
    const isCreator = is_creator === 1; //; creator_info.uid == util.yach.getAccount();

    // 一键拉群：1、成员超过三个人及以上 2、日程创建者
    const addgroup = infoUser.resp_all_num > 2;
    // 日程总人数
    const allNum = infoUser.resp_all_num;
    // 拉人进日程：1、创建者 2、接收者接收
    const adduser = isCreator || (!isCreator && userState == 1);
    // 会议纪要 日程人数超过1人
    const meetingSummary = infoUser.resp_all_num > 1;
    // 加人会议：有日会标签，不是取消状态
    const joinMeeting = meeting.type == 1 && meeting.id && state !== 3;
    // 观看直播
    const showJoinLive = source == 10 && current_user_info.uid != speaker;
    // 编辑：1、创建者
    const edit = isCreator;
    // 取消：1、创建者;2、非单人日程（单人日程删除代替）
    const cancel = isCreator && !isOne;

    const scheduleAttr = !visibility || visibility === 1 ? '' : locale('calendar_selectcard_primary_title');

    const gall_uids = extra_info.uids;

    /**
     * @Description: 参与人排序
     * */
    const usersMessageOrder = usersMsgOrder(gall_uids, usersMessage);

    const receiveEl = (
        <div
            onClick={() => {
                updateFn({ id:sid, isRefuse: false, repeat: repeat_value,scheduleInfo:true });
                uploadSensorsClickData(146);
            }}
            className={css.rf}
        >
            {locale('calendar_button_notification_accept')}
        </div>
    );

    const refuseEl = (
        <div
            onClick={() => {
                updateFn({ id:sid, isRefuse: true, repeat: repeat_value,scheduleInfo:true });
                uploadSensorsClickData(147);
            }}
            className={css.rf}
        >
            {locale('calendar_button_notification_refuse')}
        </div>
    );

    if (state == 0) {
        if (userState == 0) {
            btnEl = (
                <>
                    {receiveEl}
                    {refuseEl}
                </>
            );
            uploadSensorsDetailData(147);
            uploadSensorsDetailData(146);
        } else if (userState == 1) {
            btnEl = (
                <>
                    <div className={css.hasrf}>{locale('calendar_button_info_accepted')}</div>
                    {refuseEl}
                </>
            );
            uploadSensorsDetailData(147);
        } else if (userState == 2) {
            btnEl = (
                <>
                    {receiveEl}
                    <div className={css.hasrf}>{locale('calendar_button_info_refused')}</div>
                </>
            );
            uploadSensorsDetailData(146);
        }
    }

    if (isCreator || source == 10) {
        // 创建者/直播日程 没有拒绝接受
        btnEl = null;
    }

    if (state == 3) {
        btnEl = <div className={css.hascd}>{locale('calendar_button_info_cancelled')}</div>;
    } else if (state == 6 || finish_time * 1000 < +new Date()) {
        btnEl = <div className={css.hascd}>{locale('calendar_button_info_overdate')}</div>;
    }

    // 时间转换
    const timeEl = (start = 1570605099, end = 1570605099, is_full, type) => {
        const moment = util.moment;
        let text = '';
        const startTime = moment(start * 1000),
            endTime = moment(end * 1000);

        if (startTime.dayOfYear() !== endTime.dayOfYear()) {
            // 跨天的
            if (!type) {
                if (is_full) {
                    text = (
                        <div className={css.time}>
                            <span>
                                {startTime.format(
                                    `MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd`
                                )}
                            </span>
                            <span>&nbsp;-&nbsp;</span>
                            <span>
                                {endTime.format(
                                    `MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd`
                                )}
                            </span>
                        </div>
                    );
                } else {
                    text = (
                        <div className={css.time}>
                            <span>
                                {startTime.format(
                                    `MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd HH:mm`
                                )}
                            </span>
                            <span>&nbsp;-&nbsp;</span>
                            <span>
                                {endTime.format(
                                    `MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd HH:mm`
                                )}
                            </span>
                        </div>
                    );
                }
            } else {
                if (is_full) {
                    text =
                        startTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')}`) +
                        '-' +
                        endTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')}`);
                } else {
                    text =
                        startTime.format(
                            `MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} HH:mm`
                        ) +
                        '-' +
                        endTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} HH:mm`);
                }
            }
        } else {
            // 同一天
            if (is_full) {
                text = startTime.format(`MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd`);
            } else {
                text =
                    startTime.format(
                        `MM${locale('calendar_format_month')}DD${locale('calendar_format_day')} ddd HH:mm`
                    ) +
                    '-' +
                    endTime.format('HH:mm');
            }
        }
        return text;
    };
    const timeText = timeEl(begin_time, finish_time, is_full);

    // 主讲人
    const mainUser = liveUsers.filter(
        (item) => item.tag !== (locale.getLang() === 'zh-CN' ? '主讲人' : 'Presenter')
    )[0];
    // 发起人
    const creatUser = liveUsers.filter((item) => item.tag !== (locale.getLang() === 'zh-CN' ? '发起人' : 'Sponsor'))[0];

    return infoLoading ? (
        <div className={css.loading}>
            <Spin />
        </div>
    ) : (
        <div id="scheduleInfoOut" className={css.out}>
            <BoxCopy />
            <div className={css.box}>
                <div className={css.schduletop} id="scheduleDetail">
                    <div className={css.btn}>
                        <div className={css.left}>{btnEl}</div>
                        {source != 10 ? (
                            <p className={css.right}>
                                {addgroup &&
                                    util.sensorsData.track('Expo_ScheduleDetail_Element', { $element_name: 153 })}
                                {
                                    <>
                                        {
                                            <>
                                                {state !== 3 && adduser ? (
                                                    <Tooltip
                                                        placement="bottom"
                                                        overlayClassName={
                                                            locale.getLang() === 'zh-CN' ? css.adduserzh : css.adduseren
                                                        }
                                                        title={locale('calendar_create_adduser_placeholder')}
                                                        getPopupContainer={() =>
                                                            document.getElementById('scheduleDetail')
                                                        }
                                                    >
                                                        <span
                                                            onClick={handleShowUserAdd}
                                                            className={
                                                                'iconfont-yach yach-0428-rili-richengxiangqing-tianjiacanyuren' +
                                                                ' ' +
                                                                css.addicon
                                                            }
                                                        />
                                                    </Tooltip>
                                                ) : null}
                                                {state !== 3 &&
                                                    adduser &&
                                                    util.sensorsData.track('Expo_ScheduleDetail_Element', {
                                                        $element_name: 152,
                                                    })}
                                            </>
                                        }
                                        {state !== 3 && edit ? (
                                            <Tooltip
                                                placement="bottom"
                                                overlayClassName={css.sceduleicon}
                                                title={locale('calendar_info_icon_tip_edit')}
                                                getPopupContainer={() => document.getElementById('scheduleDetail')}
                                            >
                                                <span
                                                    onClick={() => scheduleEdit(sid)}
                                                    className={
                                                        'iconfont-yach yach-0428-rili-richengxiangqing-bianjiricheng' +
                                                        ' ' +
                                                        css.addicon
                                                    }
                                                />
                                            </Tooltip>
                                        ) : null}
                                        {state !== 3 &&
                                            edit &&
                                            util.sensorsData.track('Expo_ScheduleDetail_Element', {
                                                $element_name: 198,
                                            })}
                                        {isvalid && (
                                            <>
                                                {cancel ? (
                                                    <Tooltip
                                                        placement="bottom"
                                                        overlayClassName={css.sceduleicon}
                                                        title={locale('calendar_info_icon_tip_cancel')}
                                                        getPopupContainer={() =>
                                                            document.getElementById('scheduleDetail')
                                                        }
                                                    >
                                                        <span
                                                            onClick={() =>
                                                                handleCancelSchedule(repeat_value, sid, is_last)
                                                            }
                                                            className={
                                                                'iconfont-yach yach-0428-rili-richengxiangqing-shanchuricheng' +
                                                                ' ' +
                                                                css.addicon
                                                            }
                                                        />
                                                    </Tooltip>
                                                ) : null}
                                                {addgroup &&
                                                    util.sensorsData.track('Expo_ScheduleDetail_Element', {
                                                        $element_name: 153,
                                                    })}
                                            </>
                                        )}
                                        {genDelBtn(
                                            {
                                                isOne,
                                                isCreator,
                                                isvalid,
                                                finish_time,
                                                repeat_value,
                                                state,
                                                locale,
                                                sid,
                                                userState,
                                            },
                                            scheduleDelete
                                        )}
                                    </>
                                }
                            </p>
                        ) : null}
                    </div>
                    <div className={css.title}>
                        <p className={title.length > 16 ? css.multiLine : css.singleLine}>{title}</p>
                    </div>
                    <div className={css.date}>{timeText}</div>
                    <div className={css.groupsession}>
                        {addgroup ? (
                            <Tooltip
                                placement="bottom"
                                overlayClassName={css.addicon}
                                title={locale('calendar_button_info_joingroup')}
                                getPopupContainer={() => document.getElementById('scheduleDetail')}
                            >
                                <div onClick={() => handleAddGroup(group_id, allNum, isCreator)}>
                                    <span className="iconfont-yach yach-0428-rili-richengxiangqing-jiaruqunliao" />
                                </div>
                            </Tooltip>
                        ) : null}
                        {joinMeeting ? (
                            <Tooltip
                                placement="bottom"
                                overlayClassName={css.addicon}
                                title={locale('calendar_button_info_joinmeeting')}
                                getPopupContainer={() => document.getElementById('scheduleDetail')}
                            >
                                <div onClick={showVideoSessioneModal}>
                                    <span className="iconfont-yach yach-0428-rili-richengxiangqing-jiaruhuiyi" />
                                </div>
                            </Tooltip>
                        ) : null}
                        {meetingSummary ? (
                            <Tooltip
                                placement="bottom"
                                overlayClassName={css.addicon}
                                title={locale('calendar_create_edit_meeting_summary')}
                                getPopupContainer={() => document.getElementById('scheduleDetail')}
                            >
                                <div onClick={() => meetingSummaryClick(sid)}>
                                    <span className="iconfont-yach yach-richengxiangqing-huiyijiyao" />
                                </div>
                            </Tooltip>
                        ) : null}
                        {showJoinLive ? (
                            <Tooltip
                                placement="bottom"
                                overlayClassName={css.addicon}
                                title={locale(
                                    live_state == 3
                                        ? 'calendar_button_info_joinreplay'
                                        : 'calendar_button_info_joinlive'
                                )}
                                getPopupContainer={() => document.getElementById('scheduleDetail')}
                            >
                                <div onClick={() => jionLive({ id: live_id })}>
                                    <span className="iconfont-yach yach-0604-rili-richengxiangqingcehua-jinruzhibo" />
                                </div>
                            </Tooltip>
                        ) : null}
                    </div>
                </div>
                {
                    // TODO 日程详情 日程接受人 列表，分页
                }
                <div className={css.section}>
                    {tags[0] && tags[0].text ? (
                        <div>
                            <span className="iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-rihui" />
                            <div className={css.textShort}>
                                {locale.getLang() === 'zh-CN' ? tags[0].text : tags[0].text_en}
                            </div>
                        </div>
                    ) : null}
                    {alert_times_txt ? (
                        <div>
                            <span className="iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-tixing" />
                            <div className={css.textShort}>
                                {locale.getLang() === 'zh-CN' ? alert_times_txt : alert_times_txt_en}
                            </div>
                        </div>
                    ) : null}{' '}
                    {/** 提醒时间—— 15分钟前 */}
                    {location ? (
                        <div className={css.textShort}>
                            <span className="iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-weizhi" />
                            <div>{location}</div>
                        </div>
                    ) : null}{' '}
                    {/** 会议地址 */}
                    {meeting.type == 1 ? (
                        <div className={css.textShort}>
                            <span className="iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-xianshanghuiyi" />
                            <div>{locale('calendar_create_onlinemeetig_name')}</div>
                        </div>
                    ) : null}{' '}
                    {/**会议类型 —— 线上会议 */}
                    {repeat_value && repeat_txt ? (
                        <div className={css.textShort}>
                            <span className="iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-xunhuan" />
                            <div className={css.textRepeat}>
                                {locale.getLang() === 'zh-CN' ? repeat_txt : repeat_txt_en}
                            </div>
                        </div>
                    ) : null}{' '}
                    {/** 是否重复 */}
                    {scheduleAttr && (
                        <div className={css.textShort}>
                            <span
                                className={
                                    'iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-simi'
                                }
                                style={{ fontSize: 19.5 }}
                            />
                            <div>{scheduleAttr}</div>
                        </div>
                    )}
                    {summary ? (
                        <div className={css.textShort}>
                            <span className="iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-miaoshu" />
                            <p
                                className={css.textContent}
                                dangerouslySetInnerHTML={{ __html: util.yach.textFiltering(summary) }}
                            ></p>
                        </div>
                    ) : null}
                    {attachments && attachments.length ? (
                        <div className={css.file}>
                            <span className="iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-fujian" />
                            <div className={css.fileContent}>
                                <p>{locale('calendar_create_attachment_name')}</p>
                                <div className={css.fileImgOut}>
                                    {attachments.map((item) => {
                                        const { id, file } = item;
                                        return (
                                            <div className={css.fileItem} key={id}>
                                                <p
                                                    onClick={() => showImg(id, attachments)}
                                                    style={{
                                                        background: `url(${
                                                            file || util.config.nim.showimg
                                                        }) no-repeat center /100%`,
                                                    }}
                                                ></p>
                                                {/* <div className={css.action}>
                                                <span onClick={() => showImg(id,attachments)}>预览</span>
                                                <span>下载</span>
                                            </div> */}
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        </div>
                    ) : null}
                    {source != 10 && organizer ? (
                        <div className={css.textShort}>
                            <span className="icon iconfont-yach yach-147_richeng_faqiren" />
                            <div className={css.creater} onClick={() => util.yach.showUserinfo(organizer.account)}>
                                <img src={organizer.avatar} alt="" />
                                <span>{organizer.nick}</span>
                                <span className={css.createrIcon}>{locale('calendar_create_organizer')}</span>
                            </div>
                        </div>
                    ) : (
                        <>
                            {mainUser && mainUser.id !== creatUser && creatUser.id && (
                                <div className={css.textShort}>
                                    <span className="icon iconfont-yach yach-147_richeng_faqiren" />
                                    <div className={css.creater} onClick={() => util.yach.showUserinfo(mainUser.id)}>
                                        <img src={mainUser.avatar} alt="" />
                                        <span>{mainUser.nick}</span>
                                        <span className={`${css.createrIcon} ${css.createrIconOrg}`}>
                                            {locale('calendar_create_sponsor')}
                                        </span>
                                    </div>
                                </div>
                            )}
                            {creatUser && (
                                <div className={css.textShort}>
                                    <span className="icon iconfont-yach yach-147_richeng_zhuchiren" />
                                    <div className={css.creater} onClick={() => util.yach.showUserinfo(creatUser.id)}>
                                        <img src={creatUser.avatar} alt="" />
                                        <span>{creatUser.nick}</span>
                                        <span className={`${css.createrIcon} ${css.createrIconMain}`}>
                                            {locale('calendar_create_presenter')}
                                        </span>
                                    </div>
                                </div>
                            )}
                        </>
                    )}
                    {
                        source != 10 ? (
                            <div className={css.people}>
                                <span
                                    className={
                                        'iconfont-yach yach-0428-xiezuomokuai-richengxiangqing-richengchuangjian-canyuren' +
                                        ' ' +
                                        css.adduser
                                    }
                                />
                                <section className={css.peopleContent}>
                                    <div className={css.useraction}>
                                        <div
                                            className={[
                                                peopleStage === -1 ? css.active : null,
                                                locale.getLang() === 'zh-CN' ? null : css.fontEn,
                                            ].join(' ')}
                                        >
                                            {peopleStage === -1 ? (
                                                <span>
                                                    {locale.getLang() === 'zh-CN'
                                                        ? `全部${infoUser.resp_all_num | 0}`
                                                        : `All ${infoUser.resp_all_num | 0}`}
                                                </span>
                                            ) : (
                                                <span onClick={_.debounce(() => changePeopleStage(-1), 300)}>
                                                    {locale.getLang() === 'zh-CN'
                                                        ? `全部${infoUser.resp_all_num | 0}`
                                                        : `All ${infoUser.resp_all_num | 0}`}
                                                </span>
                                            )}
                                        </div>
                                        <div
                                            className={[
                                                peopleStage === 1 ? css.active : null,
                                                locale.getLang() === 'zh-CN' ? null : css.fontEn,
                                            ].join(' ')}
                                        >
                                            {peopleStage === 1 ? (
                                                <span>
                                                    {locale.getLang() === 'zh-CN'
                                                        ? `已接受${infoUser.resp_accept_num | 0}`
                                                        : `Accepted ${infoUser.resp_accept_num | 0}`}
                                                </span>
                                            ) : (
                                                <span onClick={_.debounce(() => changePeopleStage(1), 300)}>
                                                    {locale.getLang() === 'zh-CN'
                                                        ? `已接受${infoUser.resp_accept_num | 0}`
                                                        : `Accepted ${infoUser.resp_accept_num | 0}`}
                                                </span>
                                            )}
                                        </div>
                                        <div
                                            className={[
                                                peopleStage === 0 ? css.active : null,
                                                locale.getLang() === 'zh-CN' ? null : css.fontEn,
                                            ].join(' ')}
                                        >
                                            {peopleStage === 0 ? (
                                                <span>
                                                    {locale.getLang() === 'zh-CN'
                                                        ? `未响应${infoUser.resp_waiting_num | 0}`
                                                        : `Pending ${infoUser.resp_waiting_num | 0}`}
                                                </span>
                                            ) : (
                                                <span onClick={_.debounce(() => changePeopleStage(0), 300)}>
                                                    {locale.getLang() === 'zh-CN'
                                                        ? `未响应${infoUser.resp_waiting_num | 0}`
                                                        : `Pending ${infoUser.resp_waiting_num | 0}`}
                                                </span>
                                            )}
                                        </div>
                                        <div
                                            className={[
                                                peopleStage === 2 ? css.active : null,
                                                locale.getLang() === 'zh-CN' ? null : css.fontEn,
                                            ].join(' ')}
                                        >
                                            {peopleStage === 2 ? (
                                                <span>
                                                    {locale.getLang() === 'zh-CN'
                                                        ? `已拒绝${infoUser.resp_refuse_num | 0}`
                                                        : `Rejected ${infoUser.resp_refuse_num | 0}`}
                                                </span>
                                            ) : (
                                                <span onClick={_.debounce(() => changePeopleStage(2), 300)}>
                                                    {locale.getLang() === 'zh-CN'
                                                        ? `已拒绝${infoUser.resp_refuse_num | 0}`
                                                        : `Rejected ${infoUser.resp_refuse_num | 0}`}
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                    {/** 参会人员列表 详情 */}
                                    <div className={css.peopleout}>
                                        <div className={css.peopleInner}>
                                            {usersMessageOrder.map((item, ind) => {
                                                const { id, nick, avatar } = item;
                                                if (!openMore && ind > defaultOpenNum - 1) return;
                                                return (
                                                    <div
                                                        onClick={() => util.yach.showUserinfo(id)}
                                                        className={css.peopleItem}
                                                        key={ind}
                                                    >
                                                        <img src={avatar} alt="" />
                                                        <span>{nick}</span>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                        {loadingText && (
                                            <p className={css.userLoading}>
                                                {locale('calendar_info_section_user_loading')}
                                            </p>
                                        )}
                                        {!openMore && usersMessage.length > defaultOpenNum ? (
                                            <div className={`${css.speciel} ${css.seeMore}`} onClick={toggleOpenMore}>
                                                {locale('calendar_button_info_users_seemore') + '>>'}
                                            </div>
                                        ) : (
                                            <p id="checkIsIn" className={css.checkIsIn}></p>
                                        )}
                                        {!nodata && openMore ? (
                                            <div className={css.seeMore} onClick={toggleOpenMore}>
                                                {locale('calendar_button_info_users_normal')}
                                            </div>
                                        ) : null}
                                    </div>
                                </section>
                            </div>
                        ) : null
                        //     (
                        //     <div className={css.liveUserOut}>
                        //         <span className={"iconfont-yach yach-0604-rili-richengxiangqingxiaokapian-faqiren"+" "+css.adduser} style={{marginTop:10}}/>
                        //         <section className={css.userOut}>
                        //             {
                        //                 liveUsers.map(item=>{
                        //                     const {id,nick,avatar,tag}=item;
                        //                     return (
                        //                         <div className={css.item} key={id} onClick={() => util.yach.showUserinfo(id)}>
                        //                             <img src={avatar}  alt=""/>
                        //                             <span>{tag}</span>
                        //                             <p>{nick}</p>
                        //                         </div>
                        //                     )
                        //                 })
                        //             }
                        //         </section>
                        //     </div>
                        // )
                    }
                </div>
            </div>
            {/**会议未响应提醒 —— 催一下 */}
            {isCreator &&
                peopleStage === 0 &&
                isShowRemind === '1' &&
                state !== 3 &&
                state !== 6 &&
                infoUser.resp_waiting_num > 0 && (
                    <div className={css.remind}>
                        <Button type="primary" onClick={remindOne.bind(this, props)}>
                            {locale('calendar_create_info_notify_immediately')}
                        </Button>
                    </div>
                )}
        </div>
    );
}
