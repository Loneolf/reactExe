/*
 * @Descripttion:自定义重复时间卡片
 * @version:
 */

import React, { Component } from 'react';
import css from './index.scss';
import RepeatComponent from './repeat-component/index'
import Deadline from "./deadline-component";
import { Button } from 'antd';
import moment from 'moment';
import { locale } from '@u/util.js';

class Index extends Component {
    state = {
        frequency:1,// 频率 天、周：1-10/月、你那：1-30
        alternation:1,// 周期 天:1/周：2/月：3/年
        customTime:[],//周:1-7,周日是7；月：1-31
        defaultweek:[], //默认选中的周几
        defaultday:[],//默认选中的日期
        deadline:'',//截止时间
        changeCount:false,//是否初次操作
    };

    // 确定自定义时间
    handleSelectTime = () => {
        const { frequency,alternation,customTime,deadline } = this.state;
        // 处理customTime数据
        if(Array.isArray(customTime)) customTime.sort((a,b)=>a-b);
        // 处理周
        const customTimeWeek = locale('calendar_chinese_day_text_6').split(',').map((item, index) => ({ text: item, value: index }));
        customTimeWeek.map(item => {if(item.value === 0) item.value = 7});
        let customTimeText = [];
        if(alternation===2 && Array.isArray(customTime)){
            customTime.map(items => {
                return customTimeWeek.map(item => {
                    if(items === item.value) customTimeText.push(
                        (locale.getLang()==='zh-CN'?locale('calendar_create_custom_repeat_week'):'')+item.text.trim()
                    )
                })
            })
        }
        //处理月
        let customTimStr = '';
        if(alternation === 3) customTimStr = Array.isArray(customTime) ? customTime.join("、") : customTime;
        // 选中显示数据
        let repeats = locale('calendar_create_custom_repeat_every') + (frequency!==1?frequency:'') +
        (frequency!==1&&locale.getLang()!=='zh-CN'?alternation===1?' days ':alternation===2?' weeks ':alternation===3?' months ':' years ':  // 英文复数，时间单位
          locale(alternation===1?'calendar_create_custom_repeat_day':alternation===2?'calendar_create_custom_repeat_week':  // 中文复数+英文单数，时间单位
            alternation===3?'calendar_create_custom_repeat_month':'calendar_create_custom_repeat_year')) +
        // (alternation===2||alternation===3&&customTimeText||customTimStr?locale('calendar_create_custom_repeat_on'):'') +
        (alternation===2||alternation===3||customTimStr?locale('calendar_create_custom_repeat_on'):'') +
        (alternation===2?customTimeText.join("、"):alternation===3?customTimStr+(locale.getLang()==='zh-CN'?'号':''):'') +  // 周月的单位
        locale('calendar_create_custom_repeat');

        const repeatTime = repeats+(deadline?','+deadline:deadline);
        this.props.getRepeatTime({frequency,alternation,customTime,repeatTime});
    };

    componentDidMount(){
        const {full_start,customRepeatEdit,repeatTimeObj}=this.props;
        let {frequency,alternation,customTime} = repeatTimeObj;
        let week=moment(full_start*1000).day();
        week=week==0?7:week;
        const day= moment(full_start*1000).date();
        this.setState({
            defaultweek:[week],
            defaultday:[day],
        })

        if(customRepeatEdit){
            // 编辑的逻辑
            if(customTime && !Array.isArray(customTime)) customTime = customTime.split(',').map(item => +item);
            this.setState({
                frequency:frequency?frequency:this.state.frequency,
                alternation:alternation?alternation:this.state.alternation,
                customTime:customTime?customTime:[week]
            })
        }else{
            // 新建的逻辑
            this.setState({
                customTime:[week]
            })
        }
    }

    // 获取截止时间
    getDate = (repeatTimeType,data) => {
        if (repeatTimeType === 2) {
            if(data){
                this.setState({
                    deadline: locale('calendar_create_custom_repeat_end_to') + data,
                })
            }else{
                // 兼容年月日格式编辑
                const {repeatTime} = this.props.repeatTimeObj;
                const date = repeatTime ? locale.getLang()==='zh-CN'?repeatTime.split("于")[1]:repeatTime.split("until")[1] : null;
                const dates = date ? locale.getLang()==='zh-CN'? date.replace('年','-').replace('月','-').replace('日',''):date : null;
                this.setState({
                    deadline: locale('calendar_create_custom_repeat_end_to') + dates,
                })
            }
        }
        else this.setState({deadline: ''})
    };

    // 频率change
    handleSelectFrequency=(value)=>{
        this.setState({
            frequency:value,
            changeCount:true,
        })
    }

    // 周期change
    handleSelectAlternation=(value)=>{
        console.log(value,4444);
        // 给定默认值
        const {defaultweek,defaultday,frequency}=this.state;
        let customTime=[];
        if(value===2){
            customTime=defaultweek;
        }else if(value===3){
            customTime=defaultday;
        }

        this.setState({
            alternation:value,
            frequency:frequency>10&&(value==3||value==4)?1:frequency,
            customTime,
            changeCount:true,
        })
    }

    // 特定天数change
    handleSelectCustomTime=(value)=>{
        const preCustomTime=this.state.customTime;
        if(preCustomTime.length===1&&preCustomTime.includes(value)) return;

        this.setState(pre=>{
            let {customTime}=pre;
            return {
                customTime:customTime.includes(value)?customTime.filter(i=>value!==i):[...customTime,value]
            }
        })
    }


    render() {
        const {hideShowCustomRepeat,full_start,repeatTimeObj}=this.props;
        const {frequency,alternation,customTime,changeCount}=this.state;
        const RepeatComponentProps={
            frequency,alternation,customTime,
            handleSelectFrequency:this.handleSelectFrequency,
            handleSelectAlternation:this.handleSelectAlternation,
            handleSelectCustomTime:this.handleSelectCustomTime
        };
        const DeadLineProps={
            full_start,frequency,alternation,changeCount,
            getDate:this.getDate,
            repeatTime:repeatTimeObj.repeatTime,
        }

        return (
            <div className={css.out}>
                <div className={css.mask} onClick={hideShowCustomRepeat}></div>
                <div className={css.customRepeat}>
                    <div className={css.title}>{locale('calendar_create_custom_repeat_title')}</div>
                    <RepeatComponent {...RepeatComponentProps}/>
                    <Deadline {...DeadLineProps}/>
                    <div className={css.handle}>
                        <Button  className={css.cancel} onClick={hideShowCustomRepeat}>{locale('calendar_button_cancel')}</Button>
                        <Button  className={css.confirm} onClick={this.handleSelectTime} disabled={!navigator.onLine}>{locale('calendar_button_ok')}</Button>
                    </div>
                </div>
            </div>
        );
    }
}

export default Index;
