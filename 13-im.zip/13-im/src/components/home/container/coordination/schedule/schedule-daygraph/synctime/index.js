/*
 * @Descripttion: 当天动态时间线展示 model
 * @version: 
 */
import React, {Component} from 'react';
import * as sUtil from '../../../lib/until';
import * as util from '@u/util.js';
import {changline} from  '../../../lib/unit-core';
import moment from 'moment';
import css from './index.scss';


export class NewDateLine extends Component{
    state = {
        top:0,
        vibchage: "visibilitychange" || "webkitvisibilitychange" || "mozvisibilitychange"
    }

    getNowtime = ()=>{
        let {year,month,day,changetimet,getEventListTime} = this.props;
        let nowTime = Date().replace(/^.*?(\d+:\d+).*?$/, '$1').split(':');
        let startTime = sUtil.timemillions(year,month,day,0,0,0);  // 当天的开始点 ->ui 最高点
        let begin_time = sUtil.timemillions(year,month,day,nowTime[0],nowTime[1],0); // s就忽略了
        let topline = changline(startTime,begin_time);
        let td = new Date(); 
        //console.log(nowTime)
        // 每天晚上23：59：59的下一秒就自动切换到下一天的日程 
        if( td.getFullYear() !== year ||
            td.getMonth() !== month ||
            td.getDate() !== day
         ){
            this.props.initViewDate({year:td.getFullYear(),month:td.getMonth(),day:td.getDate()});
            getEventListTime();
         }

         let b = parseInt(nowTime[0]);
         let e = parseInt(nowTime[1]);

        if(e>15 &&e<45){
            changetimet('sync');
        }
        else{
            if(e>45){
                 if(+nowTime[0]=='00'){
                    changetimet('01:00')
                }
                if(parseInt(nowTime[0])<9){
                    changetimet('0'+(b+1)+':00'); 
                }
                else{
                    changetimet((b+1)+':00'); 
                }
            }
            if(e<15){
                changetimet((nowTime[0])+':00');
            }
        }
        this.setState(state=>({
            top:topline
        }));
       if(util.electron.isElectron() && util.electron.isWin()){
            this.winstyle= {  
                left: -38,
                fontSize:13
            };
        }
        else{
            this.winstyle= {}  
        }
        this.timer = setTimeout(this.getNowtime,10000);//30000
    }
    
    //开启一个一分钟的定时器按照分钟轮训当前时间线条 1分钟一次 
   componentWillMount(){
        this.getNowtime();  
        document.addEventListener(this.state.vibchage,this.changeTime)    
   }

    changeTime  = ()=>{
        var bowhidden="hidden" in document ? "hidden": "webkithidden" in document?"webkithidden": "mozhidden" in document ?"mozhidden": null;
        if(!document[bowhidden]){
            // 切回
            this.getNowtime(); 
        }
        else{
            // 切出
            clearTimeout(this.timer);
        }
    }

    componentWillUnmount(){
        clearTimeout(this.timer);
        document.removeEventListener(this.state.vibchage,this.changeTime)
        this.setState = (state, callback) => {
            return
        }    
    }
    render(){
            return (
               <div className={css.relinewrap} style={{top:this.state.top}}>
                    <div key={+new Date()} className={css.redlines}  style={this.mystyle}></div>
                    <div className={css.nowtimeline} style={this.winstyle}>{moment().format('HH:mm')}</div>
               </div>
            ); 
        }
}
