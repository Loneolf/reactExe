/*
 * @Descripttion:
 * @Date: 2020-04-03 14:30:03
 */
import React from 'react';
import moment from 'moment';
import FastCreateSchedule from '../schedule-fastcreate';
import { Spin } from 'antd';
import css from './index.scss';

export const Weekly = (props) => {
    const {
        weekregion,
        drawGraphy,
        rendertime,
        renderline,
        dyscnowtime,
        scrolldiv,
        alldayDiv,
        selectcard,
        week_loading,
        locale,
        syncTimeLine,
        isToday
    } = props;

    const {allDate,bigData,alldayMaxHeight}=drawGraphy();

    return (
        <div className={css.weeklyWrap}>
            {week_loading && (
                <div className="calender_loading">
                    {' '}
                    <Spin className="iconfont" style={{ fontSize: 20 }} />{' '}
                </div>
            )}

            <div className={css.weekHeader} ref={alldayDiv}>
                <div className={css.header}>
                    <div className={css.box50}></div>
                    <div className={css.weekText}>
                        {weekregion.map((item) => {
                            const { unix, active, temOfday } = item;
                            const _temTram = moment.unix(unix);
                            const wek = _temTram.format('ddd');
                            const activeClass = active ? css.active : null;

                            return (
                                <div className={css.week + ' ' + activeClass} key={temOfday}>
                                    <p>{wek}</p>
                                    <h1>{_temTram.date()}</h1>
                                </div>
                            );
                        })}
                    </div>
                </div>
                {!!drawGraphy().allDate.length && (
                    <div className={css.allDayWrap}>
                        <span>{locale('calendar_day_layout_allday')}</span>
                        <div className={css.alldayContent} style={{height:alldayMaxHeight}}>{allDate}</div>
                    </div>
                )}
            </div>

            <div className={css.weekContent} id="graph_scrollDiv" ref={scrolldiv}>
                {selectcard.isshow && <div className="calender_fastcreatMask" style={{ height: 1296 }}></div>}
                <div className={css.timeWrap}>
                    <div className={css.timeDiv}>
                        {rendertime()}
                        {!!isToday().length && (
                            <div className={css.syncline} style={{ top: dyscnowtime.top }}>
                                {dyscnowtime.time[0]}:{dyscnowtime.time[1]}
                            </div>
                        )}
                    </div>
                </div>
                <div className={css.daysWrap}>
                    <div className={css.lineWrap}>{renderline()}</div>
                    <div className={css.dayContainer}>
                        {bigData}
                        {syncTimeLine()}
                    </div>
                    <FastCreateSchedule />
                </div>
            </div>
        </div>
    );
};
