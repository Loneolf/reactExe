/*
 * @Descripttion:
 * @Author: qiuyanlong@100tal.com
 * @Date: 2020-04-17 11:47:25
 */
import React from 'react';
import * as sUtil from './../../lib/until';
import _ from 'lodash';

import c from './index.scss';

// ui组件
export default (props) => {
    const { y, h, m, d, n, lang, dotlist, dayOfWeek, selectBoxFn, clickelActiveDay, filterDotShoe } = props;

    const renderArry = [];
    let nowMonthHasDayNum = sUtil.days_per_month(y);
    const td = new Date();

    for (let oli = 0; oli < n; oli++) {
        for (let awk = 0; awk < 7; awk++) {
            let idx = 7 * oli + awk;
            let mdate = idx - dayOfWeek + 1;
            let greyC = '';
            let nextV = 0;
            let _temTime = '';
            // 不管是那个月 都必须知道 月 年份数据
            if (mdate <= 0) {
                greyC = c.greyText;
                // 要跨年了，年月都需要做减法
                let preMonth = m - 1;
                let _tem_pre = y;
                if (preMonth < 0) {
                    preMonth = 11;
                    nowMonthHasDayNum = sUtil.days_per_month(y - 1);
                    _tem_pre = +y - 1;
                }
                mdate = parseInt(nowMonthHasDayNum[preMonth] + mdate);
                _temTime = `${_tem_pre}${sUtil.fm(preMonth + 1)}${sUtil.fm(mdate)}`;
            } else if (mdate > nowMonthHasDayNum[m]) {
                greyC = c.greyText;
                nextV = mdate - nowMonthHasDayNum[m];

                let _tem_nex = +m + 1;
                let _tem_m = y;
                if (_tem_nex > 11) {
                    _tem_nex = 0;
                    _tem_m = +y + 1;
                }
                _temTime = `${_tem_m}${sUtil.fm(_tem_nex + 1)}${sUtil.fm(nextV)}`;
            } else {
                greyC = ' ';
                _temTime = `${y}${sUtil.fm(m + 1)}${sUtil.fm(mdate)}`;
            }

            let clikd = nextV > 0 ? nextV : mdate;
            let nexF = nextV > 0 ? true : false;
            let dot = filterDotShoe(dotlist, _temTime) ? c.calebderDot : '';

            mdate === td.getDate() && y === td.getFullYear() && m === td.getMonth() && !greyC.trim()
                ? renderArry.push(
                      <div key={idx} className={c.box}>
                          <div
                              onClick={_.debounce(() => selectBoxFn(clikd, nexF, greyC, y, m), 100)}
                              className={[
                                  c.innerText,
                                  lang ? c.calenderActive :c.engActive,
                                  filterDotShoe(dotlist, _temTime) ? c.calenderActiveDot : '',
                              ].join(' ')}
                          >
                              <div className={c.hotarea}>{ lang ?'':mdate}</div>
                          </div>
                      </div>
                  )
                : renderArry.push(
                      <div className={[c.box, greyC].join(' ')} key={idx}>
                          <div
                              onClick={() => {
                                  selectBoxFn(clikd, nexF, greyC, y, m);
                              }}
                              className={[
                                  clickelActiveDay.day === mdate && !greyC.trim() ? c.calender_date_grey : ' ',
                                  c.innerText,
                                  dot,
                              ].join(' ')}
                          >
                              <div className={c.hotarea}>{nextV > 0 ? nextV : mdate}</div>
                          </div>
                      </div>
                  );
        }
    }

    return <>{renderArry}</>;
};
