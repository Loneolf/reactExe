// react
import React from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import * as util from '@u/util.js';
import debounce from 'lodash/debounce';
import { windowSizeChange } from '@r/actions/windowInfo';
// Box
import Box from './box';
import { meetingLiveDownloadShow } from '@r/actions/meeting';
import { zoomListenCb } from '@u/lib/zoom/zoom-listen.js';

import { emailStatusGet } from '@s/email/email.js';
import {audioBusStatus, getTranslationList, getTargetLanguage, audioBusHighlightPull } from '@/services/session/session';
import { isArray } from 'util';
import { translationListAddBatch } from '@r/actions/translationList';
import { setEffectQuickMode, setEffectQuickAtingChange, setEffectQuickLateringChange } from '@r/actions/effectMode';


// BoxContainer
class BoxContainer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            boxStyle: {},
            bottomStyle: {},
            isShowStatement: false,
        };
    }

    componentDidMount = async () => {
        util.nim.init();
        this.uploadBpit();
        this.resizeHandle();
        util.yach.platformConfigGetFun();

        window.addEventListener('resize', debounce(this.resizeHandle, 10));
        util.eventBus.addListener('userpanelShowEndorsement', (isShowStatement) =>
            this.showEndorsement(isShowStatement)
        );

        util.yach.handleClientGroup();
        this.setEmailParams();
        zoomListenCb(); //注册回调

        //获取自动翻译的群聊和单聊列表
        this.getTranslationList();

        //获取目标语言
        this.getTargetLanguage();

        //监听设置窗口手动设置目标语言
        this.onSetTargetLanguage();

        //获取直通车模式
        this.getEffectQuickMode();

        // sensors
        util.sensorsData.init(util.config.sensorsUrl);
    };

    componentWillUnmount() {
        window.removeEventListener('resize', debounce(this.resizeHandle, 10));
        util.eventBus.removeListener('userpanelShowEndorsement');
    }

    showEndorsement = (isShowStatement) => {
        this.setState({ isShowStatement });
    };

    uploadBpit = () => {
        var end_time = new Date().getTime();
        var load_time = end_time - window.bpit_elk_page_start_time;
        util.elk.uploadELKPageData('home', load_time);
    };

    closeLiveDownload = () => {
        this.props.meetingLiveDownloadShow(false);
    };
    setEmailParams = async () => {
        let res = await emailStatusGet({});
        if (!res || res.code != 200 || !res.obj) return;
        const { red_point_status } = res.obj;
        util.yachLocalStorage.ls('email_status', { red_point_status: !!+red_point_status });
    };

    // hack
    resizeHandle = () => {
        this.props.windowSizeChange({
            innerHeight: window.innerHeight,
            innerWidth: window.innerWidth,
        });
        if (!util.electron.isMac()) return false;
        this.setState({
            boxStyle: { WebkitAppRegion: 'drag' },
            bottomStyle: { WebkitAppRegion: 'no-drag' },
        });
    };

    doubliclick = () => {
        // util.yach.systemAppActionDoubleClick()
    };

    getTranslationList = async () => {
        //获取自动翻译的群聊和单聊列表，更新state
        let res = null;
        try {
            res = await getTranslationList({});
        } catch (error) {
            util.log('panghaojie','getTranslationList','error')
        }
        if (!res || res.code != 200 || !res.obj || !Array.isArray(res.obj)) return;
        const tempArr = res.obj.map((item) => `${item.session_id}`);

        if (this.props.translationListAddBatch && !!tempArr.length) this.props.translationListAddBatch(tempArr);
    };
    getTargetLanguage = async () => {
        //获取目标语言，更新state
        let res = null;
        try {
            res = await getTargetLanguage({});
        } catch (error) {
            util.log('panghaojie','getTargetLanguage','error')
        }
        const generalData = util.yachLocalStorage.ls('systemset_general') || {};
        let translation_target_language = (!!res && res.code == 200 && !!res.obj) && res.obj.target_language

        //目标语言尚未配置
        const targetLanguageSaved = !translation_target_language ? 0 : 1
        if(!translation_target_language) translation_target_language = util.locale.getLang() == 'en-US' ? 'en' : 'zh'

        util.yachLocalStorage.ls('systemset_general', {
            ...generalData,
            locale: generalData.locale == 'locale' ? 'locale' : util.locale.getLang(),
            translation_target_language,
            targetLanguageSaved
        });
        util.nim.handleTargetLanguageUpdate(translation_target_language);
    };

    onSetTargetLanguage = () => {
        //监听设置窗口手动设置目标语言
        util.electronipc.electronSetTargetLanguage((res) => {
            util.nim.handleTargetLanguageUpdate(res.data);
        })
    };

    getEffectQuickMode = async () => {
        let modedata = await audioBusStatus()
        if (modedata && modedata.code == 200) {
            let status = modedata.obj.status == 1
            this.props.setEffectQuickMode(status)
        }

        let highdata = await audioBusHighlightPull()
        if (highdata && highdata.code == 200) {
            let isating = highdata.obj.at == 1
            let islatering = highdata.obj.later == 1
            this.props.setEffectQuickAtingChange(isating)
            this.props.setEffectQuickLateringChange(islatering)
        }
    }

    render() {
        return (
            <Box
                boxStyle={this.state.boxStyle}
                bottomStyle={this.state.bottomStyle}
                isShowStatement={this.state.isShowStatement}
                groupModal={this.props.groupModal}
                pathname={this.props.location.pathname}
                editionInfo={this.props.editionInfo}
                loading={this.props.loading}
                gLoading={this.props.gLoading}
                meetingLiveDownload={this.props.meetingLiveDownload}
                closeLiveDownload={this.closeLiveDownload}
                doubliclick={this.doubliclick}
            />
        );
    }
}

const mapStateToProps = (state) => {
    return {
        groupModal: state.groupModal,
        editionInfo: state.editionInfo,
        loading: state.loading,
        gLoading: state.gLoading,
        meetingLiveDownload: state.meetingLiveDownload,
    };
};
const mapDispatchToProps = (dispatch) => {
    return {
        windowSizeChange: (v) => dispatch(windowSizeChange(v)),
        meetingLiveDownloadShow: (v) => dispatch(meetingLiveDownloadShow(v)),
        translationListAddBatch: (v) => dispatch(translationListAddBatch(v)),
        setEffectQuickMode: v => dispatch(setEffectQuickMode(v)),
        setEffectQuickAtingChange: v => dispatch(setEffectQuickAtingChange(v)),
        setEffectQuickLateringChange: v => dispatch(setEffectQuickLateringChange(v)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(BoxContainer));
