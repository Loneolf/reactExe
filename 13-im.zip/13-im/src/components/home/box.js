// react
import React from 'react';
import { connect } from 'react-redux';
// css
import css from './index.scss';

// components
import Sidebar from './sidebar/sidebar-container.js';
import Container from './container/container-container.js';
import Slidemodal from '../common/silde-modal/slide-modal-container';
import CommonModal from '@/components/common/common-modal';
import ElargeImg from '@/components/common/enlarge-img/enlarge-img-container';
import EdtionInfo from '@/components/common/edition-info/edition-info-container';
import Loading from '@c/common/loading/loading';
import CommonSpin from '@c/common/common-spin';

import RemindWin from '@c/home/container/coordination/remind/remind-win/remind-win-container';
import SlidePanle from '@c/common/slidePanel/panel-box.js';
import LiveDownload from '@c/home/container/online-office/live-box/live-download/live-download-container'
import Alert from '@c/common/alert'
import Confirm from '@c/common/confirm'
import ScheduleAdd from '@c/home/container/coordination/schedule/schedule-add/schedule-add-portals'
import WebviewModal from '@c/common/webview-modal/webview-modal-container'
import StatementValues from '@c/common/statement-values/statement-values-container';




import UploadFileControl from '@c/common/upload-file-control';

import * as util from '@u/util.js';

// Box
class Box extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            modalVisible: false
        };
    }

    componentDidMount() {
        window.addEventListener('unhandledrejection', event => {
            if (
                event &&
                event.reason &&
                event.reason.message ==
                    "Failed to execute 'transaction' on 'IDBDatabase': The database connection is closing."
            ) {
                this.setState({
                    modalVisible: true
                });
            }
        });
    }

    render() {
        // const pathname = this.props.pathname;
        // let style = {};
        // if (pathname.startsWith('/work')) style.width = '1081px';
        const { editionInfo, loading, gLoading, doubliclick, isShowStatement } = this.props;
        return (
            <div className={css.box} style={this.props.boxStyle}>
                <div className={css.container} id="container">
                    {/* <Top /> */}
                    <div className={css.bottom} style={this.props.bottomStyle}>
                    {/* {util.electron.isMac() && <div className={css.drag}></div>} */}
                    <div className={css.drag} onDoubleClick={doubliclick}></div>
                    <Sidebar />
                    <Container />
                    </div>
                    <Slidemodal />
                    {loading && <Loading />}
                    {gLoading ? <CommonSpin /> : null}
                    {editionInfo ? <EdtionInfo /> : null}
                    <CommonModal
                        modalTile={util.locale('common_tip')}
                        modalVisible={this.state.modalVisible}
                        setOKModal={() => {}}
                        setonCancelModal={() => window.location.reload()}
                        modalContent= {this.locale('common_msg36')}
                        okButtonProps={{ style: { display: 'none' } }}
                        cancelButtonProps={{ style: { backgroundColor: ' #326FEF', color: '#FFFFFF' } }}
                        cancelText={this.locale('common_ok')}
                    />
                    <ElargeImg />
                    <RemindWin />
                    <SlidePanle />
                    <LiveDownload
                        show={this.props.meetingLiveDownload.show}
                        closefn={this.props.closeLiveDownload}
                    />
                    < Alert />
                    <Confirm />
                    <UploadFileControl/>
                    <ScheduleAdd />
                    <WebviewModal />
                    {isShowStatement && <StatementValues />}
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        userPanel: state.userPanel
    };
};
export default connect(mapStateToProps, null)(Box);
